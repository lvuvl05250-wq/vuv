const store = require('../../services/store');
const ui = require('../../services/ui');

const PRESETS = [
  { name: '收缩压', unit: 'mmHg' }, { name: '舒张压', unit: 'mmHg' },
  { name: '静息心率', unit: '次/分' }, { name: '骨密度 T 值', unit: '' },
  { name: '骨密度 Z 值', unit: '' }, { name: '身高', unit: 'cm' },
  { name: '体重', unit: 'kg' }, { name: '体脂率', unit: '%' },
  { name: '空腹血糖', unit: 'mmol/L' }, { name: '餐后血糖', unit: 'mmol/L' },
  { name: '总胆固醇', unit: 'mmol/L' }, { name: '甘油三酯', unit: 'mmol/L' },
  { name: '高密度脂蛋白胆固醇', unit: 'mmol/L' }, { name: '低密度脂蛋白胆固醇', unit: 'mmol/L' },
  { name: '腰围', unit: 'cm' }, { name: '臀围', unit: 'cm' },
  { name: '尿酸', unit: 'μmol/L' }, { name: '握力', unit: 'kg' },
  { name: '最大摄氧量', unit: 'mL/(kg·min)' }
];

Page({
  data: {
    records: [], groups: [], totalCount: 0, filterNames: ['全部项目'], filterIndex: 0,
    editorOpen: false, id: '', name: '', value: '', unit: '', date: '', today: '',
    source: 'manual', reportId: '', reportTitle: '', presets: [], dirty: false,
    saving: false, loadError: '', error: ''
  },
  onLoad(options) {
    this._namespace = store.getNamespace();
    this.setData({ date: store.today(), today: store.today(), id: options.id || '', editorOpen: !!options.id });
    this.updatePresets('');
  },
  onShow() {
    this.reload();
    if (this.data.id && !this.data.dirty) {
      const record = this.data.records.find((item) => item.id === this.data.id);
      if (record) this.fillEditor(record);
      else this.setData({ error: '这条测量记录已不存在，请关闭编辑后重新选择。' });
    }
  },
  onUnload() { this._gone = true; },
  canUseDraft() {
    if (this._gone) return false;
    if (store.getNamespace() === this._namespace) return true;
    this.setData({ error: '账号已变化，请返回个人档案后重新打开。' });
    return false;
  },
  reload() {
    try {
      const records = store.getMeasurements();
      const previousName = this.data.filterNames[this.data.filterIndex] || '全部项目';
      const filterNames = ['全部项目'];
      records.forEach((record) => { if (filterNames.indexOf(record.name) === -1) filterNames.push(record.name); });
      const filterIndex = Math.max(0, filterNames.indexOf(previousName));
      this.setData({ records, totalCount: records.length, filterNames, filterIndex, today: store.today(), loadError: '' });
      this.buildGroups();
    } catch (error) { this.setData({ loadError: error.message || '测量记录没有读取成功，请重试。' }); }
  },
  buildGroups() {
    const selected = this.data.filterNames[this.data.filterIndex];
    const records = this.data.records.filter((record) => selected === '全部项目' || record.name === selected).slice().sort((a, b) => b.date.localeCompare(a.date) || (b.createdAt || '').localeCompare(a.createdAt || ''));
    const groups = [];
    records.forEach((record) => {
      let group = groups.find((item) => item.date === record.date);
      if (!group) { group = { date: record.date, label: ui.dateLabel(record.date), records: [] }; groups.push(group); }
      group.records.push(record);
    });
    this.setData({ groups });
  },
  chooseFilter(event) {
    this.setData({ filterIndex: Number(event.detail.value) });
    this.buildGroups();
  },
  updatePresets(name) { this.setData({ presets: PRESETS.map((preset) => Object.assign({}, preset, { selected: preset.name === name })) }); },
  newRecord() {
    if (this.data.saving) return;
    this.setData({ editorOpen: true, id: '', name: '', value: '', unit: '', date: store.today(), source: 'manual', reportId: '', reportTitle: '', dirty: false, error: '' });
    this.updatePresets('');
    wx.pageScrollTo({ scrollTop: 0, duration: 200 });
  },
  fillEditor(record) {
    let reportTitle = '';
    if (record.reportId) { const report = store.getReports().find((item) => item.id === record.reportId); if (report) reportTitle = report.title; }
    this.setData({ editorOpen: true, id: record.id, name: record.name, value: record.value, unit: record.unit, date: record.date, source: record.source, reportId: record.reportId || '', reportTitle, dirty: false, error: '' });
    this.updatePresets(record.name);
  },
  async editRecord(event) {
    if (this.data.saving) return;
    if (this.data.editorOpen && this.data.dirty && !await ui.confirm('放下这次未保存的修改？', '切换后，当前还没保存的文字不会保留。')) return;
    if (!this.canUseDraft()) return;
    try {
      const record = store.getMeasurements().find((item) => item.id === event.currentTarget.dataset.id);
      if (!record) { ui.toast('这条记录已不存在。'); this.reload(); return; }
      this.fillEditor(record);
      wx.pageScrollTo({ scrollTop: 0, duration: 200 });
    } catch (error) { ui.error(error); }
  },
  choosePreset(event) {
    if (this.data.saving) return;
    const preset = PRESETS.find((item) => item.name === event.currentTarget.dataset.name);
    if (!preset) return;
    this.setData({ name: preset.name, unit: preset.unit, dirty: true, error: '' });
    this.updatePresets(preset.name);
  },
  onField(event) {
    if (this.data.saving) return;
    const field = event.currentTarget.dataset.field;
    if (['name', 'value', 'unit', 'date'].indexOf(field) === -1) return;
    const patch = { dirty: true, error: '' }; patch[field] = event.detail.value;
    this.setData(patch);
    if (field === 'name') this.updatePresets(event.detail.value);
  },
  async closeEditor() {
    if (this.data.saving) return;
    if (this.data.dirty && !await ui.confirm('暂时不保存这次修改？', '已经保存过的记录会保留，这次改动会放下。')) return;
    if (this._gone) return;
    this.setData({ editorOpen: false, id: '', dirty: false, error: '' });
  },
  save() {
    if (this.data.saving || !this.canUseDraft()) return;
    const name = this.data.name.trim(); const value = this.data.value.trim(); const unit = this.data.unit.trim();
    if (!name || !value) { this.setData({ error: '填写项目名称和原始数值后，再保存这次记录。' }); return; }
    if (name.length > 100 || value.length > 100 || unit.length > 60) { this.setData({ error: '名称和数值各最多 100 字，单位最多 60 字。' }); return; }
    const patch = { name, value, unit, date: this.data.date, source: this.data.source, reportId: this.data.reportId };
    if (this.data.id) patch.id = this.data.id;
    this.setData({ saving: true, error: '' });
    try {
      store.saveMeasurement(patch);
      this.setData({ saving: false, editorOpen: false, id: '', dirty: false });
      this.reload();
      ui.toast('这次测量已记下。');
    } catch (error) { this.setData({ saving: false, error: error.message || '保存没有完成，填写的内容还在。' }); }
  },
  async deleteRecord() {
    if (this.data.saving || this._deletePending || !this.data.id || !this.canUseDraft()) return;
    this._deletePending = true;
    const accepted = await ui.confirm('删除这条测量记录？', '删除后无法恢复。原始报告仍保留在资料册里。');
    this._deletePending = false;
    if (!accepted || !this.canUseDraft()) return;
    this.setData({ saving: true, error: '' });
    try {
      store.deleteMeasurement(this.data.id);
      this.setData({ saving: false, editorOpen: false, id: '', dirty: false });
      this.reload();
      ui.toast('这条记录已删除。');
    } catch (error) { this.setData({ saving: false, error: error.message || '删除没有完成，请重试。' }); }
  },
  openReport() { if (this.data.reportId && this.data.reportTitle) wx.navigateTo({ url: '/pages/report/index?id=' + encodeURIComponent(this.data.reportId) }); },
  scanReport() { wx.navigateTo({ url: '/pages/report/index' }); }
});
