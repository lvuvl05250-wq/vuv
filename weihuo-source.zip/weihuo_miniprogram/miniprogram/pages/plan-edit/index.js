const store = require('../../services/store');
const api = require('../../services/api');
const ui = require('../../services/ui');

function resultText(result, keys) {
  if (typeof result === 'string') return result.trim().slice(0, 8000);
  for (const key of keys) if (result && typeof result[key] === 'string' && result[key].trim()) return result[key].trim().slice(0, 8000);
  return '';
}
function addDays(date, amount) {
  const parts = date.split('-').map(Number);
  const local = new Date(parts[0], parts[1] - 1, parts[2] + amount, 12);
  return local.getFullYear() + '-' + String(local.getMonth() + 1).padStart(2, '0') + '-' + String(local.getDate()).padStart(2, '0');
}
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  return addDays(value, 0) === value;
}
Page({
  data: {id: '', title: '', type: 'life', goal: '', startDate: '', dayCount: 7, source: 'manual', days: [],
    note: '', saving: false, aiBusy: false, apiLabel: '', apiConfigured: false, aiError: '', aiBody: '', aiNotice: '', aiDraft: false, missing: false,
    types: [{value: 'life', label: '生活安排'}, {value: 'strength', label: '力量活动'}, {value: 'aerobic', label: '有氧活动'}],
    lengths: [3, 7, 14], dayNumbers: Array.from({length: 31}, (_, index) => String(index + 1).padStart(2, '0'))},
  onLoad(query) { this._id = query.id || ''; },
  onShow() {
    try {
      const status = api.status();
      this.setData({apiLabel: status.label || (status.configured ? 'AI 已配置' : 'AI 暂未连接'), apiConfigured: status.configured});
      if (this._loaded || this._dirty) return;
      this._loaded = true;
      if (this._id) {
        const plan = store.getPlans().find((p) => p.id === this._id);
        if (!plan) return this.setData({missing: true});
        this.setData({id: plan.id, title: plan.title, type: plan.type, goal: plan.goal || '', source: plan.source || 'manual',
          days: plan.days, note: plan.note || '', startDate: plan.days.length ? plan.days[0].date : store.today()});
      } else this.setData({startDate: store.today(), days: [{date: store.today(), title: '', minutes: 5, details: '', done: false}]});
    } catch (error) { ui.error(error); }
  },
  onUnload() { this._unloaded = true; },
  editField(e) {
    const field = e.currentTarget.dataset.field;
    if (['title', 'goal', 'note'].indexOf(field) === -1 || this.data.aiBusy) return;
    this._dirty = true; this.setData({[field]: e.detail.value});
  },
  setType(e) { if (!this.data.aiBusy) { this._dirty = true; this.setData({type: e.currentTarget.dataset.value}); } },
  setStart(e) { if (!this.data.aiBusy) this.setData({startDate: e.detail.value}); },
  setLength(e) { if (!this.data.aiBusy) this.setData({dayCount: Number(e.currentTarget.dataset.value)}); },
  editDay(e) {
    if (this.data.aiBusy) return;
    const index = Number(e.currentTarget.dataset.index);
    const field = e.currentTarget.dataset.field;
    if (!this.data.days[index] || ['title', 'date', 'minutes', 'details'].indexOf(field) === -1) return;
    this._dirty = true;
    this.setData({['days[' + index + '].' + field]: e.detail.value});
  },
  addDay() {
    if (this.data.aiBusy) return;
    if (this.data.days.length >= 31) return ui.toast('一个计划最多保留 31 件事');
    const last = this.data.days[this.data.days.length - 1];
    this._dirty = true;
    this.setData({days: this.data.days.concat([{date: last ? addDays(last.date, 1) : this.data.startDate, title: '', minutes: 5, details: '', done: false}])});
  },
  async removeDay(e) {
    if (this.data.aiBusy) return;
    const index = Number(e.currentTarget.dataset.index);
    const day = this.data.days[index];
    if (!day) return;
    if ((day.title || day.details) && !await ui.confirm('移除这件事？', day.title || '这一行填写的内容会从当前草稿中移除。')) return;
    this._dirty = true;
    this.setData({days: this.data.days.filter((_, i) => i !== index)});
  },
  async generate() {
    if (this.data.aiBusy || this.data.saving) return;
    if (!this.data.goal.trim()) return ui.toast('先写下你希望怎样安排这些日子');
    const profile = store.getProfile();
    if (profile.specialCondition || (profile.restrictions || []).length) {
      if (await ui.confirm('需要适合你的活动安排', '档案中记录了特殊情况或活动限制，AI 暂时无法可靠适配。可以查看档案，或手动记录已确认适合自己的安排。')) wx.navigateTo({url: '/pages/profile-edit/index'});
      return;
    }
    if (this.data.days.some((d) => String(d.title || '').trim()) && !await ui.confirm('用 AI 建议替换当前日程草稿？', '新建议会放在下方供你修改，只有点击「确认并保存计划」才会保存。')) return;
    this.setData({aiBusy: true, aiError: '', aiBody: '', aiNotice: ''});
    const namespace = store.getNamespace();
    try {
      const result = await api.request('generatePlan', {type: this.data.type, goal: this.data.goal.trim(),
        startDate: this.data.startDate, dayCount: this.data.dayCount, profile, constraints: profile.restrictions || []});
      if (this._unloaded) return;
      if (store.getNamespace() !== namespace) throw new Error('账号已变化，原草稿仍保留，请重新打开计划页');
      const rows = result && Array.isArray(result.days) ? result.days : [];
      const prose = resultText(result, ['body', 'text', 'content', 'note']);
      const dates = {}, days = [];
      let partial = !rows.length || rows.length > 31;
      rows.slice(0, 31).forEach(day => {
        if (!day || typeof day !== 'object' || Array.isArray(day)) { partial = true; return; }
        const minutes = Number(day.minutes);
        const hasDuration = (typeof day.minutes === 'number' || typeof day.minutes === 'string') && String(day.minutes).trim() !== '';
        const date = typeof day.date === 'string' && validDate(day.date) ? day.date : '';
        const title = typeof day.title === 'string' ? day.title.trim().slice(0, 120) : '';
        const duration = hasDuration && Number.isFinite(minutes) && minutes >= 0 && minutes <= 240 ? minutes : '';
        if (!date || !title || duration === '' || dates[date]) partial = true;
        if (date) dates[date] = true;
        const actionIds = Array.isArray(day.actionIds) ? Array.from(new Set(day.actionIds.filter(id => typeof id === 'string' && id.trim()))).slice(0, 10) : [];
        days.push({date, title, minutes: duration, details: typeof day.details === 'string' ? day.details.slice(0, 2000) : '', actionIds, done: false});
      });
      if (partial) {
        // An incomplete projection must never replace the person's current editor.
        const fragments = days.map(day => [day.date || '日期待填写', day.title || '内容待填写', day.minutes === '' ? '时长待填写' : day.minutes + ' 分钟', day.details].filter(Boolean).join(' · ')).join('\n');
        this.setData({aiBody: [prose, fragments ? '可参考的日程片段：\n' + fragments : ''].filter(Boolean).join('\n\n'),
          aiNotice: rows.length ? '这次只返回了部分日程信息，原草稿保留。可以参考上面的内容继续填写。' : prose ? '这次返回的是文字建议，还没有可填入的逐日日程。原草稿保留，可以继续手动编写。' : '这次没有返回日程内容，原草稿保留。可以手动填写或重试。'});
        return;
      }
      this._dirty = true;
      this.setData({days, title: this.data.title || resultText(result, ['title']).slice(0, 80),
        note: this.data.note || resultText(result, ['note']).slice(0, 2000), source: 'ai', aiDraft: true,
        aiBody: prose, aiNotice: '已填入 ' + days.length + ' 天日程草稿，核对后再保存。'});
      ui.toast('日程草稿已填入，请核对');
    } catch (error) {
      if (!this._unloaded) { this.setData({aiError: error.message || '生成失败，请稍后重试'}); ui.error(error); }
    } finally { if (!this._unloaded) this.setData({aiBusy: false}); }
  },
  save() {
    if (this.data.saving || this.data.aiBusy) return;
    const title = this.data.title.trim();
    if (!title || title.length > 80) return ui.toast('给计划写一个 1–80 字的名字');
    if (!this.data.days.length) return ui.toast('至少写下一件准备做的事');
    const profile = store.getProfile();
    if (this.data.type !== 'life' && profile.specialCondition) return ui.toast('档案中记录了不适合一般运动的特殊情况，请先选择生活安排');
    let days;
    try {
      const dates = {};
      days = this.data.days.map((day, index) => {
        const minutes = Number(day.minutes);
        const hasDuration = (typeof day.minutes === 'number' || typeof day.minutes === 'string') && String(day.minutes).trim() !== '';
        if (!validDate(day.date)) throw new Error('第 ' + (index + 1) + ' 件事的日期无效');
        if (dates[day.date]) throw new Error('同一天的安排请合并在一条日程里：' + day.date);
        dates[day.date] = true;
        if (!String(day.title || '').trim()) throw new Error('为第 ' + (index + 1) + ' 件事写一个名字');
        if (!hasDuration || !Number.isFinite(minutes) || minutes < 0 || minutes > 240) throw new Error('第 ' + (index + 1) + ' 件事请填写 0–240 分钟；休息日可填 0');
        return Object.assign({}, day, {title: String(day.title).trim(), minutes, done: !!day.done});
      }).sort((a, b) => a.date.localeCompare(b.date));
    } catch (error) { return ui.error(error); }
    this.setData({saving: true});
    try {
      if (this._id && !store.getPlans().some((p) => p.id === this._id)) throw new Error('原计划已被删除，请返回后新建计划');
      const patch = {title, type: this.data.type, goal: this.data.goal.trim(), source: this.data.source, days, note: this.data.note.trim()};
      if (this._id) patch.id = this._id;
      const saved = store.savePlan(patch);
      this._id = saved.id; this._dirty = false;
      ui.toast('计划已保存');
      const pages = getCurrentPages();
      if (pages.length > 1) wx.navigateBack();
      else wx.redirectTo({url: '/pages/plans/index'});
    } catch (error) { ui.error(error); }
    finally { if (!this._unloaded) this.setData({saving: false}); }
  },
  backToPlans() { wx.redirectTo({url: '/pages/plans/index'}); }
});
