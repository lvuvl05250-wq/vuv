const store = require('../../services/store');
const api = require('../../services/api');
const ui = require('../../services/ui');
const {nutritionSummary} = require('../../services/nutrition-summary');
const recipes = require('../../services/recipes');
const companion = require('../../services/companion');
const MACROS = [{key: 'protein', label: '蛋白质', color: '#93C94B'}, {key: 'carbs', label: '碳水', color: '#FFB185'}, {key: 'fat', label: '脂肪', color: '#FFE49B'}];

function formatNumber(value) {
  return Math.round(value * 10) / 10;
}

Page({
  data: {
    date: '', meals: [], favorites: [], savedRecipes: [], mealCompanion: {image: '', name: ''},
    favoriteOpen: false, reviewOpen: false, reviewBusy: false,
    review: null, reviewError: '', loadError: '', totals: null, nutrition: null, macroRows: [], showEnergyInfo: false,
    reviewPhase: 'ongoing'
  },
  onLoad() { this.setData({ date: store.today() }); },
  onShow() {
    ui.setTab(this, 1);
    this.reload();
  },
  onReady() { this.drawNutrition(); },
  onUnload() { this._gone = true; },
  reload() {
    try {
      const date = store.today();
      const meals = store.getMeals(date).slice().sort((a, b) => a.time.localeCompare(b.time));
      const totals = { kcal: 0, protein: 0, carbs: 0, fat: 0, known: 0, total: meals.length };
      meals.forEach((meal) => {
        if (meal.kcal !== null && meal.kcal !== undefined) totals.known += 1;
        ['kcal', 'protein', 'carbs', 'fat'].forEach((key) => {
          if (typeof meal[key] === 'number') totals[key] += meal[key];
        });
      });
      ['kcal', 'protein', 'carbs', 'fat'].forEach((key) => { totals[key] = formatNumber(totals[key]); });
      const favorites = store.getMeals().filter((meal) => (meal.tags || []).indexOf('喜欢') !== -1);
      const savedRecipes = recipes.filterRecipes({savedIds: store.getSettings().savedRecipes || [], favoritesOnly: true});
      const signature = store.getNamespace() + JSON.stringify(meals);
      const nutrition = nutritionSummary(store.getProfile(), meals, date);
      const day = store.getDay(date);
      const mealCompanion = companion.getCompanionPresentation({companionKey: store.getSettings().companion, date, actions: day.actions, meals: meals.filter(meal => meal.confirmed === true), note: day.note, scene: 'meal'});
      const macroRows = MACROS.map(row => Object.assign({}, row, {grams: nutrition.macros.grams[row.key], percentage: nutrition.macros.percentages[row.key], recorded: nutrition.macros.coverage[row.key].recorded}));
      const patch = {
        date,
        meals, favorites, savedRecipes, totals, nutrition, macroRows, mealCompanion, loadError: ''
      };
      if (this._signature !== signature) { patch.review = null; patch.reviewError = ''; this._reviewVersion = (this._reviewVersion || 0) + 1; }
      this._signature = signature;
      this.setData(patch, () => this.drawNutrition());
    } catch (error) { this.setData({ loadError: error.message || '记录暂时没有读取成功。' }); }
  },
  drawNutrition() {
    if (this._gone || !wx.createSelectorQuery) return;
    wx.createSelectorQuery().in(this).select('#nutrition-ring').fields({node: true, size: true}).exec(result => {
      if (this._gone || !result || !result[0] || !result[0].node) return;
      const item = result[0], canvas = item.node, context = canvas.getContext('2d');
      if (!context || !item.width || !item.height) return;
      const ratio = wx.getWindowInfo ? wx.getWindowInfo().pixelRatio : 2;
      canvas.width = item.width * ratio; canvas.height = item.height * ratio;
      context.scale(ratio, ratio);
      const x = item.width / 2, y = item.height / 2, radius = Math.min(x, y) - 12;
      context.lineWidth = 18; context.strokeStyle = '#EDF1E6';
      context.beginPath(); context.arc(x, y, radius, 0, Math.PI * 2); context.stroke();
      let start = -Math.PI / 2;
      (this.data.macroRows || []).forEach(row => {
        if (typeof row.percentage !== 'number' || row.percentage <= 0) return;
        const angle = Math.PI * 2 * row.percentage / 100;
        const gap = Math.min(0.035, angle / 8);
        context.strokeStyle = row.color; context.beginPath(); context.arc(x, y, radius, start + gap, start + angle - gap); context.stroke();
        start += angle;
      });
    });
  },
  toggleEnergyInfo() { this.setData({showEnergyInfo: !this.data.showEnergyInfo}); },
  editProfile() { wx.navigateTo({url: '/pages/profile-edit/index'}); },
  newMeal() { wx.navigateTo({url: '/pages/meal-edit/index?date=' + store.today()}); },
  editMeal(event) {
    wx.navigateTo({ url: '/pages/meal-edit/index?id=' + encodeURIComponent(event.currentTarget.dataset.id) });
  },
  browseRecipes() { wx.navigateTo({url: '/pages/recipes/index'}); },
  openRecipe(event) { const id = event.currentTarget.dataset.id; if (recipes.getRecipe(id)) wx.navigateTo({url: '/pages/recipes/index?id=' + encodeURIComponent(id)}); },
  toggleFavorites() { this.setData({ favoriteOpen: !this.data.favoriteOpen }); },
  chooseReviewPhase(event) {
    if (this.data.reviewBusy) return;
    this.setData({ reviewPhase: event.currentTarget.dataset.phase, review: null });
    this.reviewDay();
  },
  closeReview() { this.setData({ reviewOpen: false }); },
  async reviewDay() {
    if (this.data.reviewBusy) return;
    if (!this.data.meals.length) { ui.toast('先记下一餐，再一起回顾。'); return; }
    this.setData({ reviewOpen: true, reviewBusy: true, review: null, reviewError: '' });
    const version = this._reviewVersion;
    const date = this.data.date;
    const namespace = store.getNamespace();
    try {
      const result = await api.request('mealDayReview', { date, meals: store.getMeals(date), phase: this.data.reviewPhase, profile: store.getProfile() });
      if (this._gone || version !== this._reviewVersion || date !== this.data.date || namespace !== store.getNamespace()) return;
      const content = result && (result.summary || result.body || result.note) || '';
      if (!content) { this.setData({reviewError: '这次没有返回文字，已保存的餐食记录还在。'}); return; }
      this.setData({ review: {
        summary: content,
        suggestions: Array.isArray(result.suggestions) ? result.suggestions.filter((s) => typeof s === 'string') : [],
        note: typeof result.note === 'string' ? result.note : ''
      } });
    } catch (error) {
      if (!this._gone && version === this._reviewVersion) this.setData({ reviewError: error.message || '饮食回顾暂时不可用，已保存的记录仍在。' });
    } finally { if (!this._gone) this.setData({ reviewBusy: false }); }
  }
});
