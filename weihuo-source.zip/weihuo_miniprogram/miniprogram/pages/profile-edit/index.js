const store = require('../../services/store');
const api = require('../../services/api');
const {rememberFoodProfile}=require('../../services/profile-memory');
const ui = require('../../services/ui');
const {ageAt, isAdult} = require('../../services/age');

const restrictionLabels = {ankle: '脚踝', knee: '膝部', neck: '颈部', shoulder: '肩部', back: '腰背', wrist: '手腕', hip: '髋部', leg: '腿部', dizziness: '眩晕', headache: '头痛', pain: '疼痛', balance: '平衡不稳', recent_injury: '近期损伤', medical_restriction: '已有专业活动限制'};
const goalLabels = ['轻运动', '自我照顾', '饮食记录', '规律作息'];
const steps = [
  {number: '01', title: '先让我们认识你一点', subtitle: '称呼与出生日期 · 均可选填'},
  {number: '02', title: '你的日常是什么样的？', subtitle: '基础数据与活动习惯 · 均可选填'},
  {number: '03', title: '你想要怎样的节奏？', subtitle: '行动偏好与饮食偏好 · 均可选填'},
  {number: '04', title: '有哪些感受需要记住？', subtitle: '身体感受与活动限制 · 均可选填'}
];
function optionalNumber(value, min, max, label) {
  if (value === null || value === undefined || String(value).trim() === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number) || number < min || number > max) throw new Error(label + '请填写 ' + min + '–' + max + ' 之间的数字，或先留空');
  return number;
}
function draftFrom(profile) {
  const copy = Object.assign({birthDate: '', heightCm: null, weightKg: null, bodyFatPercent: null, exerciseHabit: '', avoidedActivities: '', bodyNotes: '', healthSummary: ''}, profile);
  ['heightCm', 'weightKg', 'bodyFatPercent'].forEach(key => { copy[key] = copy[key] === null || copy[key] === undefined ? '' : String(copy[key]); });
  copy.bodyNotes = copy.bodyNotes || copy.notes || '';
  return copy;
}

Page({
  data: {onboarding: false, step: 0, stepInfo: steps[0], stepNumber: 1, progress: 25,
    draft: {}, birthdayMax: '', ageText: '', saving: false, aiBusy: false,
    contentHeight: 570, keyboardHeight: 0, scrollTarget: '',
    aiError: '', error: '', candidate: null, candidateRestrictions: '', aiConfigured: false, reportCount: 0,
    habitOptions: ['久坐为主', '偶尔活动', '经常活动', '活动量较高'], goalOptions: [], restrictionOptions: []},
  onLoad(query) {
    this.setData({onboarding: query.onboarding === '1'});
    this.updateViewport();
    this._keyboardListener = event => this.keyboardChanged(event);
    if (wx.onKeyboardHeightChange) wx.onKeyboardHeightChange(this._keyboardListener);
  },
  onShow() {
    this._pageVisible = true;
    try {
      const namespace = store.getNamespace();
      const changedAccount = this._namespace && this._namespace !== namespace;
      if (!this._loaded || this._reportPending || changedAccount) {
        this._namespace = namespace; this._reportPending = false; this._loaded = true;
        const profile = store.getProfile();
        const draft = draftFrom(profile);
        this.setData({draft, birthdayMax: store.today(),
          candidate: null, error: changedAccount ? '账号已变化，已载入当前账号的档案。' : ''});
        this.refreshChoices(); this.refreshAge();
      }
      this.setData({aiConfigured: api.status().configured, reportCount: store.getReports().length});
    } catch (error) { this.setData({error: error.message}); }
  },
  onHide() { this.keyboardChanged({height: 0}); this._pageVisible = false; },
  onUnload() {
    this._unloaded = true;
    if (this._keyboardListener && wx.offKeyboardHeightChange) wx.offKeyboardHeightChange(this._keyboardListener);
  },
  updateViewport() {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : {};
    this._windowHeight = info.windowHeight || 640;
    this._windowWidth = info.windowWidth || 375;
    this._safeBottom = info.safeArea ? Math.max(0, (info.screenHeight || info.windowHeight) - info.safeArea.bottom) : 0;
    this.keyboardChanged({height: 0});
  },
  keyboardChanged(event) {
    if (this._unloaded || (this._pageVisible === false && Number(event.height) > 0)) return;
    const keyboardHeight = Math.max(0, Number(event.height) || 0);
    const footerHeight = Math.ceil((this._windowWidth || 375) * 140 / 750) + (keyboardHeight ? 0 : (this._safeBottom || 0));
    const contentHeight = Math.max(100, (this._windowHeight || 640) - keyboardHeight - footerHeight);
    this.setData({keyboardHeight, contentHeight, scrollTarget: ''}, () => {
      if (keyboardHeight && this._focusedField && !this._unloaded) this.setData({scrollTarget: 'profile-field-' + this._focusedField});
    });
  },
  focusField(e) {
    this._focusedField = e.currentTarget.dataset.field;
    if (this.data.keyboardHeight) this.keyboardChanged({height: this.data.keyboardHeight});
  },
  showError(error) {
    this.setData({error: error.message || '暂时未能保存，请重试', scrollTarget: ''}, () => this.setData({scrollTarget: 'profile-error'}));
  },
  refreshChoices() {
    const draft = this.data.draft;
    this.setData({goalOptions: goalLabels.map(label => ({label, selected: (draft.goals || []).indexOf(label) !== -1})),
      restrictionOptions: Object.keys(restrictionLabels).map(id => ({id, label: restrictionLabels[id], selected: (draft.restrictions || []).indexOf(id) !== -1}))});
  },
  refreshAge() {
    if (!this.data.draft.birthDate) return this.setData({'draft.adult': false, ageText: ''});
    try {
      const age = ageAt(this.data.draft.birthDate, store.today());
      this.setData({'draft.adult': age >= 18, ageText: age + ' 岁'});
    } catch (error) { this.setData({ageText: '', error: error.message}); }
  },
  field(e) {
    if (this.data.aiBusy || this.data.saving) return;
    const field = e.currentTarget.dataset.field;
    if (['name', 'birthDate', 'heightCm', 'weightKg', 'bodyFatPercent', 'allergies', 'avoidedActivities', 'bodyNotes', 'healthSummary'].indexOf(field) === -1) return;
    this.setData({['draft.' + field]: e.detail.value, error: '', candidate: null});
    if (field === 'birthDate') this.refreshAge();
  },
  clearBirth() { if (!this.data.aiBusy && !this.data.saving) this.setData({'draft.birthDate': '', 'draft.adult': false, ageText: '', candidate: null}); },
  habit(e) { if (!this.data.aiBusy) this.setData({'draft.exerciseHabit': e.currentTarget.dataset.value, candidate: null}); },
  goal(e) {
    if (this.data.aiBusy) return;
    const label = e.currentTarget.dataset.value;
    if (goalLabels.indexOf(label) === -1) return;
    const goals = (this.data.draft.goals || []).slice(), index = goals.indexOf(label);
    if (index === -1) goals.push(label); else goals.splice(index, 1);
    this.setData({'draft.goals': goals, candidate: null}); this.refreshChoices();
  },
  restriction(e) {
    if (this.data.aiBusy) return;
    const id = e.currentTarget.dataset.value;
    if (!restrictionLabels[id]) return;
    const restrictions = (this.data.draft.restrictions || []).slice(), index = restrictions.indexOf(id);
    if (index === -1) restrictions.push(id); else restrictions.splice(index, 1);
    this.setData({'draft.restrictions': restrictions, candidate: null}); this.refreshChoices();
  },
  special(e) { if (!this.data.aiBusy) this.setData({'draft.specialCondition': e.currentTarget.dataset.value === 'yes', candidate: null}); },
  validateStep(step) {
    const draft = this.data.draft;
    if (step === 0) {
      if (String(draft.name || '').trim().length > 60) throw new Error('称呼请控制在 60 字以内');
      if (draft.birthDate) ageAt(draft.birthDate, store.today());
    }
    if (step === 1) {
      optionalNumber(draft.heightCm, 30, 300, '身高');
      optionalNumber(draft.weightKg, 1, 700, '体重');
      optionalNumber(draft.bodyFatPercent, 0, 100, '体脂率');
    }
  },
  moveStep(step) {
    if (wx.hideKeyboard) wx.hideKeyboard();
    this._focusedField = '';
    this.setData({step, stepInfo: steps[step], stepNumber: step + 1, progress: (step + 1) * 25, error: '', scrollTarget: ''}, () => this.setData({scrollTarget: 'profile-top'}));
  },
  next() {
    if (this.data.aiBusy || this.data.saving) return;
    try { this.validateStep(this.data.step); this.moveStep(Math.min(3, this.data.step + 1)); }
    catch (error) { this.showError(error); }
  },
  previous() { if (!this.data.aiBusy && !this.data.saving && this.data.step > 0) this.moveStep(this.data.step - 1); },
  toProfilePatch(finalize) {
    this.validateStep(0); this.validateStep(1);
    const draft = this.data.draft;
    const textLimits = {allergies: 1000, avoidedActivities: 4000, bodyNotes: 4000, healthSummary: 8000};
    Object.keys(textLimits).forEach(key => { if (String(draft[key] || '').length > textLimits[key]) throw new Error('这段文字较长，请缩短后保存'); });
    const saved = store.getProfile();
    return Object.assign({}, draft, {
      name: String(draft.name || '').trim(), birthDate: draft.birthDate || '',
      adult: isAdult(draft.birthDate, store.today()),
      heightCm: optionalNumber(draft.heightCm, 30, 300, '身高'), weightKg: optionalNumber(draft.weightKg, 1, 700, '体重'),
      bodyFatPercent: optionalNumber(draft.bodyFatPercent, 0, 100, '体脂率'), exerciseHabit: draft.exerciseHabit || '',
      goals: draft.goals || [], restrictions: draft.restrictions || [], allergies: String(draft.allergies || '').trim(),
      bodyNotes: String(draft.bodyNotes || '').trim(), notes: String(draft.bodyNotes || '').trim().slice(0, 2000),
      avoidedActivities: String(draft.avoidedActivities || '').trim(), healthSummary: String(draft.healthSummary || '').trim(),
      specialCondition: !!draft.specialCondition, safetyAnswered: finalize ? true : saved.safetyAnswered,
      onboarded: finalize ? true : saved.onboarded
    });
  },
  assertAccount() { if (store.getNamespace() !== this._namespace) throw new Error('账号已变化，请重新进入档案页后保存'); },
  save() {
    if (this.data.saving || this.data.aiBusy) return;
    this.setData({saving: true, error: ''});
    try {
      this.assertAccount(); store.saveProfile(this.toProfilePatch(true));
      rememberFoodProfile();
      ui.toast('档案已保存');
      wx.switchTab({url: this.data.onboarding ? '/pages/today/index' : '/pages/archive/index'});
    } catch (error) { this.showError(error); }
    finally { this.setData({saving: false}); }
  },
  addReport() {
    if (this.data.saving || this.data.aiBusy) return;
    try {
      this.assertAccount(); store.saveProfile(this.toProfilePatch(false));
      this._reportPending = true;
      wx.navigateTo({url: '/pages/report/index?mode=photo', fail: () => { this._reportPending = false; this.showError(new Error('暂时无法打开资料页，已填写的档案草稿已保存。')); }});
    } catch (error) { this.showError(error); }
  },
  async summarize() {
    if (this.data.aiBusy || this.data.saving) return;
    let profile;
    try { this.assertAccount(); profile = this.toProfilePatch(false); }
    catch (error) { return this.showError(error); }
    this.setData({aiBusy: true, aiError: '', candidate: null});
    const namespace = this._namespace;
    try {
      const result = await api.request('summarizeProfile', {profile});
      if (this._unloaded) return;
      if (store.getNamespace() !== namespace) throw new Error('账号已变化，本次整理结果未采用');
      const text = value => typeof value === 'string' ? value.trim() : '';
      const raw = result && typeof result === 'object' && !Array.isArray(result) ? result : {};
      const summary = [raw.summary, raw.body, raw.text, raw.content, typeof result === 'string' ? result : ''].map(text).find(Boolean);
      if (!summary) { this.setData({aiError: '这次没有返回整理文字，已填写的内容仍保留。'}); return; }
      const requested = Array.isArray(raw.restrictions) ? raw.restrictions : [];
      const supported = id => typeof id === 'string' && Object.prototype.hasOwnProperty.call(restrictionLabels, id);
      let omitted = false;
      const evidence = (Array.isArray(raw.restrictionEvidence) ? raw.restrictionEvidence : []).filter(item => {
        const valid = item && supported(item.tag) && text(item.text) && requested.indexOf(item.tag) !== -1
          && (profile.bodyNotes.indexOf(item.text) !== -1 || profile.avoidedActivities.indexOf(item.text) !== -1);
        if (!valid) omitted = true;
        return valid;
      }).map(item => ({tag: item.tag, label: restrictionLabels[item.tag], text: item.text}));
      const restrictions = requested.filter(id => {
        const valid = supported(id) && (profile.restrictions.indexOf(id) !== -1 || evidence.some(item => item.tag === id));
        if (!valid) omitted = true;
        return valid;
      });
      const candidate = {summary: summary.slice(0, 8000), restrictions: Array.from(new Set(restrictions)), restrictionEvidence: evidence,
        allergies: typeof raw.allergies === 'string' && raw.allergies.length <= 1000 ? raw.allergies : profile.allergies,
        avoidedActivities: typeof raw.avoidedActivities === 'string' && raw.avoidedActivities.length <= 4000 ? raw.avoidedActivities : profile.avoidedActivities};
      this.setData({candidate, candidateRestrictions: candidate.restrictions.map(id => restrictionLabels[id]).join('、'),
        aiError: omitted ? '部分活动限制缺少你填写的原文依据，已省略；整理文字仍可核对。' : ''});
    } catch (error) { if (!this._unloaded) this.setData({aiError: error.message || '整理尚未完成，请重试'}); }
    finally { if (!this._unloaded) this.setData({aiBusy: false}); }
  },
  adoptSummary() {
    if (!this.data.candidate) return;
    try {
      this.assertAccount(); const candidate = this.data.candidate;
      const restrictions = Array.from(new Set((this.data.draft.restrictions || []).concat(candidate.restrictions)));
      const merge = (existing, suggested) => !suggested.trim() || existing.indexOf(suggested.trim()) !== -1 ? existing : existing.trim() ? existing.trim() + '\n' + suggested.trim() : suggested.trim();
      const allergies = merge(this.data.draft.allergies || '', candidate.allergies);
      const avoided = merge(this.data.draft.avoidedActivities || '', candidate.avoidedActivities);
      if (allergies.length > 1000 || avoided.length > 4000) throw new Error('合并后的内容较长，请先精简已填写内容，再采用整理结果');
      this.setData({'draft.healthSummary': candidate.summary, 'draft.restrictions': restrictions,
        'draft.allergies': allergies, 'draft.avoidedActivities': avoided, candidate: null, aiError: ''});
      this.refreshChoices(); ui.toast('已采用到档案草稿，记得保存');
    } catch (error) { this.setData({aiError: error.message}); }
  },
  dismissSummary() { this.setData({candidate: null}); }
});
