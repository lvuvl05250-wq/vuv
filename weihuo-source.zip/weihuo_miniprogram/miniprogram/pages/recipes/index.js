const store = require('../../services/store');
const ui = require('../../services/ui');
const recipes = require('../../services/recipes');
const {rememberFoodProfile}=require('../../services/profile-memory');

Page({
  data: {query: '', tags: [], avoid: [], tagOptions: [], filtersOpen: false, favoritesOnly: false, savedIds: [], items: [], activeId: '', drawn: false, resultLabel: '', error: '', mode: 'recommend', preferences: {}, preferenceSummary: '', quizOpen: true, questionIndex: 0, questionCount: recipes.PREFERENCE_QUESTIONS.length, question: {}, preferenceOptions: []},
  onLoad(options) { options = options || {}; this._requestedRecipeId = recipes.getRecipe(options.id) ? options.id : ''; this.setData({favoritesOnly: options.favorites === '1', activeId: this._requestedRecipeId, quizOpen: !options.id && options.favorites !== '1'}); },
  onShow() {
    const namespace = store.getNamespace();
    if (this._namespace && this._namespace !== namespace) { this._drawnIds = null; this.setData({activeId: '', query: '', tags: [], questionIndex: 0}); }
    this._namespace = namespace; this.reload();
    rememberFoodProfile().then(updated => { if(updated && store.getNamespace()===this._namespace) this.refresh(); });
  },
  reload() {
    try {
      const settings = store.getSettings();
      this.setData({savedIds: settings.savedRecipes || [], preferences: recipes.normalizePreferences(settings.foodPreferences), avoid: (settings.foodAvoid || []).filter(id => recipes.ALLERGENS.some(item => item.id === id)), error: ''}); this.refresh();
      const requested = recipes.getRecipe(this._requestedRecipeId);
      if (requested && (recipes.excludedByProfile(requested,store.getProfile()) || requested.allergens.some(id => this.data.avoid.includes(id)))) this.setData({activeId: '', error: '「' + requested.title + '」含有档案中记下需要避开的食材，暂时没有列出。'});
      this._requestedRecipeId = '';
    } catch (error) { this.setData({error: error.message || '收藏暂时没有读取成功。'}); }
  },
  refresh() {
    const savedIds = this.data.savedIds;
    const filtered = recipes.filterRecipes({query: this.data.query, tags: this.data.tags, avoid: this.data.avoid, profile: store.getProfile(), savedIds, favoritesOnly: this.data.favoritesOnly});
    this._filtered = filtered;
    const ranked = recipes.rankRecipes(filtered, this.data.preferences);
    const pool = this._drawnIds && this.data.mode === 'recommend' ? ranked : filtered;
    let selected = this._drawnIds ? pool.filter(item => this._drawnIds.includes(item.id)) : filtered;
    if (this._drawnIds) selected.sort((a, b) => this._drawnIds.indexOf(a.id) - this._drawnIds.indexOf(b.id));
    else if (this.data.activeId) selected.sort((a, b) => Number(b.id === this.data.activeId) - Number(a.id === this.data.activeId));
    const dayActions = store.getDay().actions, question = recipes.PREFERENCE_QUESTIONS[this.data.questionIndex];
    this.setData({items: selected.map(item => {
      const action = dayActions.find(action => (action.tags || []).includes(item.id) && (action.tags || []).includes('food_discovery') && action.status !== 'skipped');
      return Object.assign(recipes.decorate(item, savedIds), {actionId: action ? action.id : '', actionCompleted: Boolean(action && action.status === 'completed')});
    }), drawn: Boolean(this._drawnIds), resultLabel: this._drawnIds ? (this.data.mode === 'recommend' ? '按偏好挑了 ' : '随机抽到 ') + selected.length + ' 道' : filtered.length + ' 道可以看看',
    question, preferenceSummary: recipes.preferenceLabels(this.data.preferences).join(' · '), preferenceOptions: question.options.map(option => Object.assign({}, option, {selected: this.data.preferences[question.key] === option.id})),
    tagOptions: recipes.TAGS.map(item => Object.assign({}, item, {selected: this.data.tags.includes(item.id)}))});
  },
  canWrite() {
    if (store.getNamespace() === this._namespace) return true;
    this.setData({error: '账号已变化，请重新打开食谱页后继续。'}); return false;
  },
  chooseMode(event) {
    const mode = event.currentTarget.dataset.mode; if (!['recommend', 'random'].includes(mode)) return;
    this._drawnIds = null; this.setData({mode, activeId: ''}); this.refresh();
  },
  toggleQuiz() { this.setData({quizOpen: !this.data.quizOpen}); },
  choosePreference(event) {
    if (!this.canWrite()) return;
    const question = recipes.PREFERENCE_QUESTIONS[this.data.questionIndex], id = event.currentTarget.dataset.id;
    if (!question.options.some(option => option.id === id)) return;
    const preferences = Object.assign({}, this.data.preferences, {[question.key]: this.data.preferences[question.key] === id ? '' : id});
    try { store.saveSettings({foodPreferences: preferences}); this._drawnIds = null; this.setData({preferences, error: ''}); this.refresh(); }
    catch (error) { this.setData({error: error.message || '偏好没有保存成功，请重试。'}); }
  },
  previousQuestion() { this.setData({questionIndex: Math.max(0, this.data.questionIndex - 1)}); this.refresh(); },
  nextQuestion() {
    if (this.data.questionIndex === recipes.PREFERENCE_QUESTIONS.length - 1) this.setData({quizOpen: false});
    else this.setData({questionIndex: this.data.questionIndex + 1});
    this.refresh();
  },
  search(event) { this._drawnIds = null; this.setData({query: event.detail.value}); this.refresh(); },
  toggleFilters() { this.setData({filtersOpen: !this.data.filtersOpen}); },
  toggleTag(event) { this.toggleChoice('tags', event.currentTarget.dataset.id, recipes.TAGS); },
  toggleChoice(field, id, choices) {
    if (!choices.some(item => item.id === id)) return;
    const values = this.data[field]; this._drawnIds = null;
    this.setData({[field]: values.includes(id) ? values.filter(value => value !== id) : values.concat(id), activeId: ''}); this.refresh();
  },
  toggleFavoritesOnly() { this._drawnIds = null; this.setData({favoritesOnly: !this.data.favoritesOnly, activeId: ''}); this.refresh(); },
  clearPreferences() {
    if (!this.canWrite()) return;
    const preferences = recipes.normalizePreferences({});
    try { store.saveSettings({foodPreferences: preferences}); this._drawnIds = null; this.setData({preferences, query: '', tags: [], favoritesOnly: false, activeId: '', error: ''}); this.refresh(); }
    catch (error) { this.setData({error: error.message || '偏好没有清除成功，请重试。'}); }
  },
  showAll() { this._drawnIds = null; this.refresh(); },
  draw(event) {
    const count = Number(event.currentTarget.dataset.count) === 3 ? 3 : 1;
    const picked = this.data.mode === 'recommend' ? recipes.recommendRecipes(this._filtered, this.data.preferences, count) : recipes.pickRecipes(this._filtered, count);
    this._drawnIds = picked.map(item => item.id); this.setData({activeId: count === 1 && picked.length ? picked[0].id : '', quizOpen: false}); this.refresh();
    if (!picked.length) { ui.toast('暂时没有匹配的食谱，可调整偏好或换随机抽取。'); return; }
    if (picked.length < count) ui.toast('符合条件的只有 ' + picked.length + ' 道，都在这里。');
  },
  draftMeal(event) {
    if (!this.canWrite()) return;
    const recipe = recipes.getRecipe(event.currentTarget.dataset.id); if (!recipe) return;
    wx.navigateTo({url: '/pages/meal-edit/index?recipeId=' + recipe.id, fail: () => this.setData({error: '记餐页没有打开，请重试。'})});
  },
  addTasting(event) {
    if (this._adding || !this.canWrite()) return;
    const recipe = recipes.getRecipe(event.currentTarget.dataset.id); if (!recipe) return;
    if (recipes.excludedByProfile(recipe,store.getProfile()) || recipe.allergens.some(id => this.data.avoid.includes(id))) { this.setData({error: '这道食谱含有档案中记下需要避开的食材，换一道吧。'}); return; }
    this._adding = true;
    try {
      const existing = store.getDay().actions.find(action => (action.tags || []).includes('food_discovery') && (action.tags || []).includes(recipe.id) && action.status !== 'skipped');
      if (existing) { wx.navigateTo({url: '/pages/action/index?id=' + existing.id, fail: () => this.setData({error: '行动页没有打开，请重试。'})}); return; }
      const base = store.getCatalog().find(action => action.id === 'senses_first_bite');
      const template = recipes.tastingTemplate(recipe.id, base);
      if (!store.isActionEligible(template)) throw new Error('这条品尝行动与你填写的身体边界冲突，请换一个活动。');
      let custom = store.getCustomActions().find(action => action.title === template.title && (action.tags || []).includes('food_discovery') && (action.tags || []).includes(recipe.id));
      if (!custom) custom = store.saveCustomAction(template);
      store.addAction(custom.id, store.today()); this.setData({error: ''}); this.refresh(); ui.toast('已加入今日行动，等准备好再开始。');
    } catch (error) { this.setData({error: error.message || '行动没有加入成功，请重试。'}); }
    finally { this._adding = false; }
  },
  openRecipe(event) { const id = event.currentTarget.dataset.id; if (!recipes.getRecipe(id)) return; this.setData({activeId: this.data.activeId === id ? '' : id}); },
  toggleSaved(event) {
    if (!this.canWrite()) return;
    try {
      const id = event.currentTarget.dataset.id, savedIds = recipes.toggleFavoriteIds(store.getSettings().savedRecipes || [], id);
      store.saveSettings({savedRecipes: savedIds}); this.setData({savedIds, error: ''}); this.refresh();
    } catch (error) { this.setData({error: error.message || '收藏没有保存成功，请重试。'}); }
  },

});
