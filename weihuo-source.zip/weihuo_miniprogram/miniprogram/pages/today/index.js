const store=require('../../services/store');
const ui=require('../../services/ui');
const {getCompanionPresentation}=require('../../services/companion');
const {buildDiary}=require('../../services/diary');
Page({
  data:{date:'',done:0,mealCount:0,hasNote:false,ticket:null,diary:null,companion:null,error:''},
  onShow(){if(store.getNamespace()==='local'||!store.getProfile().onboarded){wx.reLaunch({url:'/pages/welcome/index'});return;}ui.setTab(this,2);this.reload();},
  reload(){try{
    const date=store.today(),day=store.getDay(date),settings=store.getSettings(),profile=store.getProfile();
    const meals=store.getMeals(date).filter(m=>m.confirmed===true),actions=day.actions.filter(a=>a.status==='completed'),ticket=store.getTicket(date);
    const draft=ticket||{date,actions,meals,note:day.note,mood:day.mood};
    this.setData({date:ui.dateLabel(date),done:actions.length,mealCount:meals.length,hasNote:!!day.note,ticket,
      diary:buildDiary(draft,{name:profile.name,companionKey:settings.companion}),
      companion:getCompanionPresentation({date,actions,meals,note:day.note,companionKey:settings.companion,scene:'hero'}),error:''});
  }catch(e){this.setData({error:e.message});}},
  ticket(){wx.navigateTo({url:'/pages/ticket/index?date='+store.today()});},
  seal(){this.ticket();}
});
