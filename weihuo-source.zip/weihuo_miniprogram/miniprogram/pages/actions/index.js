const store = require('../../services/store');
const ui = require('../../services/ui');
const api = require('../../services/api');
const {getCompanionPresentation} = require('../../services/companion');

const statusLabels = {planned: '可以随时停下', completed: '已完成', skipped: '今天先放下'};
const categories = [{value: 'movement', label: '轻运动'}, {value: 'relaxation', label: '放松'}, {value: 'meditation', label: '冥想'},
  {value: 'focus', label: '专注'}, {value: 'nature', label: '自然'}, {value: 'senses', label: '感官照顾'}, {value: 'care', label: '日常照顾'}];
const customDraftSignature = data => JSON.stringify([data.customId, data.customNeed, data.customTitle, data.customMinutes, data.customSteps, data.customCategory, data.customWhy]);

Page({
  data: {
    filter: 'all', actions: [], plannedActions: [], completedActions: [], skippedActions: [], suggestions: [],
    stateText: '', companionImage:'/assets/xiaowei-checkin-v2.png', catalogOpen: false, celebrationOpen:false, celebrationCount:0, reduceMotion:false,
    catalog: [], search: '', category: 'all', catalogCount: 0, restrictionCount: 0, customLibrary: [],
    categories: [{value: 'all', label: '全部'}].concat(categories), customCategories: categories,
    showCustom: false, customId: '', customNeed: '', customTitle: '', customMinutes: '3', customSteps: '', customCategory: 'care', customWhy: '', customAiBody: '', customError: '', customGenerating: false, saving: false
  },
  onShow() {
    this._pageVisible = true; ui.setTab(this, 0); this.setCustomTabHidden(this.data.showCustom || this.data.celebrationOpen); this.reload();
    if(!this._unsubscribe&&store.subscribe)this._unsubscribe=store.subscribe(()=>{if(this._pageVisible)this.reload();});
    api.refreshCatalogInBackground();
  },
  stopListening(){if(this._unsubscribe){this._unsubscribe();this._unsubscribe=null;}},
  onHide() { this._pageVisible = false; this.cancelCustomGeneration(); this.stopListening(); this.setCustomTabHidden(false); },
  onUnload() { this._unloaded = true; this._customRequest = (this._customRequest || 0) + 1; this._pageVisible = false; this.stopListening(); this.setCustomTabHidden(false); },
  setCustomTabHidden(hidden) {
    const tab = typeof this.getTabBar === 'function' && this.getTabBar();
    if (tab && typeof tab.setData === 'function') tab.setData({hiddenForModal: !!hidden});
  },
  beginCustomDraft(draft) {
    this._customNamespace = store.getNamespace();
    this._customRequest = (this._customRequest || 0) + 1;
    const complete = Object.assign({customNeed: '', customWhy: '', customAiBody: '', customError: '', customGenerating: false}, draft);
    this._customInitial = customDraftSignature(complete);
    this.setData(Object.assign({showCustom: true}, complete));
    if (this._pageVisible !== false) this.setCustomTabHidden(true);
  },
  reload() {
    try {
      const day = store.getDay();
      const companion = getCompanionPresentation({companionKey: store.getSettings().companion, date: day.date,
        actions: day.actions, meals: store.getMeals(day.date).filter(meal => meal.confirmed === true), note: day.note});
      const profile = store.getProfile();
      const restrictions = profile.restrictions || [];
      const actions = day.actions.map((a, i) => Object.assign({}, a, {number: String(i + 1).padStart(2, '0'), statusLabel: statusLabels[a.status] || '等待开始'}));
      const plannedActions = actions.filter(a => a.status === 'planned');
      const completedActions = actions.filter(a => a.status === 'completed');
      const skippedActions = actions.filter(a => a.status === 'skipped');
      const added = day.actions.map((a) => a.actionId);
      const categoryLabel = a => (categories.find(c => c.value === a.category) || {label: a.kind === 'movement' ? '轻运动' : '日常照顾'}).label;
      const suggestions = store.recommend(2).map(a => Object.assign({}, a, {categoryLabel: categoryLabel(a)}));
      const customLibrary = store.getCustomActions().map((a) => Object.assign({}, a, {
        categoryLabel: (categories.find(c => c.value === a.category) || {label: '日常照顾'}).label,
        added: added.indexOf(a.id) !== -1, eligible: store.isActionEligible(a)
      }));
      const search = this.data.search.trim().toLowerCase();
      const catalog = store.getCatalog().filter((a) => {
        const prohibited = (a.avoidWhen || []).some((tag) => restrictions.indexOf(tag) !== -1);
        const unsafeMovement = a.kind === 'movement' && profile.specialCondition;
        const eligible = !store.isActionEligible || store.isActionEligible(a);
        const manual = a.source === 'manual';
        const sourceMatch = this.data.filter === 'all' || (this.data.filter === 'manual' ? manual : !manual);
        return sourceMatch && (manual || (eligible && !prohibited && !unsafeMovement)) && (this.data.category === 'all' || (a.category || (a.kind === 'movement' ? 'movement' : 'care')) === this.data.category)
          && (!search || [a.title].concat(a.tags || []).join(' ').toLowerCase().indexOf(search) !== -1);
      }).map((a) => Object.assign({}, a, {added: added.indexOf(a.id) !== -1, categoryLabel: categoryLabel(a), eligible: store.isActionEligible(a)}));
      const snapshot={date:day.date,namespace:store.getNamespace(),count:completedActions.length};
      const previous=this._completionSnapshot;this._completionSnapshot=snapshot;
      if(previous&&(previous.date!==snapshot.date||previous.namespace!==snapshot.namespace)){this.setData({celebrationOpen:false});this.setCustomTabHidden(this.data.showCustom);}
      if(previous&&previous.date===snapshot.date&&previous.namespace===snapshot.namespace&&snapshot.count>previous.count&&!plannedActions.length){this.setData({celebrationOpen:true,celebrationCount:snapshot.count,reduceMotion:!!store.getSettings().reduceMotion});this.setCustomTabHidden(true);}
      this.setData({actions, plannedActions, completedActions, skippedActions, suggestions, catalog, customLibrary, catalogCount: catalog.length,
        restrictionCount: restrictions.length, companionImage: companion.image,
        stateText: (day.mood || '精力 ' + day.energy + '/5') + ' · ' + day.minutes + ' 分钟'});
    } catch (error) { ui.error(error); }
  },
  setFilter(e) { this.setData({filter: e.currentTarget.dataset.value}); this.reload(); },
  setCategory(e) { this.setData({category: e.currentTarget.dataset.value}); this.reload(); },
  searchInput(e) { this.setData({search: e.detail.value}); this.reload(); },
  openState() { wx.navigateTo({url: '/pages/state/index'}); },
  openPlans() { wx.navigateTo({url: '/pages/plans/index'}); },
  openAction(e) { wx.navigateTo({url: '/pages/action/index?id=' + encodeURIComponent(e.currentTarget.dataset.id)}); },
  toggleCatalog() { this.setData({catalogOpen: !this.data.catalogOpen}); this.reload(); },
  showToday() { if (wx.pageScrollTo) wx.pageScrollTo({scrollTop: 0, duration: 200}); },
  addSuggestion(e) {
    if (this._adding) return;
    this._adding = true;
    try { store.addAction(e.currentTarget.dataset.id); this.reload(); this.showToday(); ui.toast('已加入今天的待办'); }
    catch (error) { ui.error(error); }
    finally { this._adding = false; }
  },
  closeCelebration(){this.setData({celebrationOpen:false});this.setCustomTabHidden(this.data.showCustom);},
  seeToday(){this.closeCelebration();wx.switchTab({url:'/pages/today/index'});},
  completeAction(e) {
    try {
      store.setActionStatus(e.currentTarget.dataset.id, 'completed');
      this.reload(); ui.toast('已记为完成');
    } catch (error) { ui.error(error); }
  },
  moreAction(e) {
    const id = e.currentTarget.dataset.id;
    wx.showActionSheet({itemList: ['从今天移除'], success: result => {
      if (!this._unloaded && result.tapIndex === 0) this.removeToday({currentTarget: {dataset: {id}}});
    }});
  },
  async removeToday(e) {
    if (this._removing) return;
    this._removing = true;
    const id = e.currentTarget.dataset.id, namespace = store.getNamespace();
    try {
      const record = store.getDay().actions.find(item => item.id === id);
      if (!record) throw new Error('这件行动已不在今天的清单里');
      if (!await ui.confirm('从今天的待办移除？', '只移除今天的这条记录' + (record.timer ? '和计时' : '') + '，个人行动库会保留。')) return;
      if (this._unloaded || store.getNamespace() !== namespace) return;
      store.removeAction(id); this.reload(); ui.toast('已从今天移除');
    } catch (error) { if (!this._unloaded) ui.error(error); }
    finally { this._removing = false; }
  },
  openCustom() {
    if (this.data.showCustom || this.data.saving || this._customClosePending) return;
    this.beginCustomDraft({customId: '', customTitle: '', customMinutes: '3', customSteps: '', customCategory: 'care'});
  },
  editCustom(e) {
    if (this.data.showCustom || this.data.saving || this._customClosePending) return;
    try {
      const action = store.getCustomActions().find(a => a.id === e.currentTarget.dataset.id);
      if (!action) throw new Error('这件行动已经不在个人库里');
      this.beginCustomDraft({customId: action.id, customTitle: action.title,
        customMinutes: String(action.durationMinutes), customSteps: (action.steps || []).join('\n'), customCategory: action.category || (action.kind === 'movement' ? 'movement' : 'care'), customWhy: action.knowledgeCard ? action.knowledgeCard.body : ''});
    } catch (error) { ui.error(error); }
  },
  async deleteCustom(e) {
    const id = e.currentTarget.dataset.id;
    if (!await ui.confirm('从个人行动库移除？', '已经留下的行动记录会保留。')) return;
    try { store.deleteCustomAction(id); this.reload(); ui.toast('已从个人行动库移除'); }
    catch (error) { ui.error(error); }
  },
  async closeCustom() {
    if (!this.data.showCustom || this.data.saving || this._customClosePending) return;
    this._customClosePending = true;
    try {
      const changed = customDraftSignature(this.data) !== this._customInitial;
      if (changed && !await ui.confirm('放下这次未保存的修改？', '已经收进个人行动库的内容会保留，这次填写的修改不会保存。')) return;
      if (this._unloaded) return;
      this.cancelCustomGeneration();
      this.setData({showCustom: false});
      this._customInitial = '';
      this.setCustomTabHidden(false);
    } finally { this._customClosePending = false; }
  },
  noop() {},
  cancelCustomGeneration() {
    this._customRequest = (this._customRequest || 0) + 1;
    if (!this._unloaded && this.data.customGenerating) this.setData({customGenerating: false});
  },
  async generateCustom() {
    if (!this.data.showCustom || this.data.saving || this.data.customGenerating || this._customClosePending) return;
    if (this._customNamespace !== store.getNamespace()) return this.setData({customError: '账号已变化，请关闭后重新打开；这份草稿没有保存到其他账号。'});
    const text = this.data.customNeed.trim() || this.data.customTitle.trim();
    if (!text) return this.setData({customError: '先写下你想做的事，或希望解决的小需求。'});
    const namespace = store.getNamespace(), signature = customDraftSignature(this.data);
    const request = this._customRequest = (this._customRequest || 0) + 1;
    const draft = {title: this.data.customTitle, category: this.data.customCategory, durationMinutes: this.data.customMinutes, steps: this.data.customSteps, why: this.data.customWhy};
    this.setData({customGenerating: true, customError: '', customAiBody: ''});
    try {
      const result = await api.request('generateAction', {text, profile: store.getProfile(), day: store.getDay(), draft});
      if (this._unloaded || request !== this._customRequest || !this.data.showCustom) return;
      if (store.getNamespace() !== namespace) return this.setData({customError: '账号已变化，生成结果没有写入这份草稿。'});
      const body = [result.title, (result.steps || []).join('\n'), result.why, result.body].filter(Boolean).join('\n\n');
      if (signature !== customDraftSignature(this.data)) return this.setData({customAiBody: body, customError: '你刚修改了草稿，已保留你的填写；这次生成内容可在下方参考。'});
      const patch = {customAiBody: result.body || '', customError: ''};
      if (result.title) patch.customTitle = result.title;
      if (categories.some(c => c.value === result.category)) patch.customCategory = result.category;
      if (Number.isInteger(result.durationMinutes) && result.durationMinutes >= 1 && result.durationMinutes <= 120) patch.customMinutes = String(result.durationMinutes);
      if (Array.isArray(result.steps) && result.steps.length) patch.customSteps = result.steps.join('\n');
      if (typeof result.why === 'string') patch.customWhy = result.why;
      if (!result.title && !(result.steps || []).length) patch.customError = '这次返回了文字建议，你可以参考下方内容继续填写。';
      this.setData(patch);
    } catch (error) {
      if (!this._unloaded && request === this._customRequest && this.data.showCustom) this.setData({customError: (error.message || '暂时没有生成成功') + '；你填写的内容已保留，可以继续手动保存。'});
    } finally {
      if (!this._unloaded && request === this._customRequest) this.setData({customGenerating: false});
    }
  },
  customInput(e) {
    if (this.data.saving || this._customClosePending) return;
    const fields = {need: 'customNeed', title: 'customTitle', minutes: 'customMinutes', steps: 'customSteps', why: 'customWhy'};
    const key = fields[e.currentTarget.dataset.field];
    if (key) this.setData({[key]: e.detail.value});
  },
  customCategory(e) {
    if (this.data.saving || this._customClosePending) return;
    const category = e.currentTarget.dataset.value;
    if (categories.some(c => c.value === category)) this.setData({customCategory: category});
  },
  saveCustom(e) {
    if (this.data.saving || this._customClosePending) return;
    if (this._customNamespace !== store.getNamespace()) return this.setData({customError: '账号已变化，请关闭后重新打开；这份草稿没有保存到其他账号。'});
    const title = this.data.customTitle.trim();
    const durationMinutes = Number(this.data.customMinutes);
    const steps = this.data.customSteps.split('\n').map((s) => s.trim()).filter(Boolean);
    if (!title || title.length > 60) return ui.toast('为行动写一个 1–60 字的名字');
    if (!Number.isInteger(durationMinutes) || durationMinutes < 1 || durationMinutes > 120) return ui.toast('时长请填写 1–120 的整数');
    if (steps.length > 12 || steps.some((s) => s.length > 200)) return ui.toast('最多写 12 步，每步不超过 200 字');
    this.setData({saving: true});
    try {
      const patch = {title, durationMinutes, steps, kind: this.data.customCategory === 'movement' ? 'movement' : 'care', category: this.data.customCategory};
      const why = this.data.customWhy.trim();
      if (why.length > 1000) throw new Error('小提示请控制在 1000 字以内');
      const previous = this.data.customId && store.getCustomActions().find(a => a.id === this.data.customId);
      if (why) patch.knowledgeCard = previous && previous.knowledgeCard && previous.knowledgeCard.body === why ? previous.knowledgeCard : {title: '这件行动的小提示', body: why, sourceTitle: '', sourceUrl: ''};
      else if (previous && previous.knowledgeCard) patch.knowledgeCard = null;
      if (this.data.customId) patch.id = this.data.customId;
      const action = store.saveCustomAction(patch);
      this.cancelCustomGeneration();
      const addToday = e && e.currentTarget && e.currentTarget.dataset.today === 'yes';
      this.setData({showCustom: false, customId: '', customNeed: '', customTitle: '', customMinutes: '3', customSteps: '', customCategory: 'care', customWhy: '', customAiBody: '', customError: '', filter: 'manual', catalogOpen: !addToday});
      this._customInitial = '';
      this.setCustomTabHidden(false);
      this.reload();
      if (addToday) {
        try { store.addAction(action.id); this.reload(); this.showToday(); ui.toast('已保存，并加入今天的待办'); }
        catch (error) { throw new Error('已保存到个人行动库，但尚未加入今天：' + error.message); }
      } else ui.toast('已收进个人行动库');
    } catch (error) { ui.error(error); }
    finally { this.setData({saving: false}); }
  }
});
