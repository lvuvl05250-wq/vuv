const store = require('../../services/store');
const ui = require('../../services/ui');
const image = require('../../services/ticket-image');
const {buildDiary}=require('../../services/diary');
Page({
  data: {stamping:false,stampLanded:false,generating:false,aiText:'',content:null,diary:null,date: '', ticket: null, sealed: false, note: '', title: '', busy: false, error: '',
    companionImage:'', albumDenied: false, counts: {actions: 0, meals: 0, feedback: 0}, 
    saveProgress: ''},
  onLoad(query) { this.setData({date: query.date || store.today()}); this._namespace = store.getNamespace(); },
  onShow() {
    this.reload();
    const ticket=this.data.ticket;
    if(ticket&&(!ticket.diary||!ticket.diary.paragraphs.length))this.generate(false);
  },
  onUnload() { this._unloaded=true;clearTimeout(this._stampTimer);clearTimeout(this._impactTimer);if(this._sound)this._sound.destroy(); },
  reload(){try{
    const saved=store.getTicket(this.data.date),day=store.getDay(this.data.date);
    const ticket=saved||{date:this.data.date,title:'',note:'',actions:day.actions.filter(a=>a.status==='completed'),meals:store.getMeals(this.data.date).filter(m=>m.confirmed),mood:day.mood};
    const content=ticket.diary||{title:'',yi:'',paragraphs:[],quote:'',stickers:[]};
    const diary=buildDiary(ticket,{name:store.getProfile().name,companionKey:store.getSettings().companion});
    this.setData({ticket,diary,counts:image.stats(ticket),note:ticket.note||'',title:content.title||'',aiText:content.paragraphs.join('\n\n'),content,companionImage:diary.companion.image,sealed:!!saved,error:''});
  }catch(error){this.setData({error:error.message});}},
  editAI(){this.setData({editingAI:true});},finishEdit(){this.setData({editingAI:false});},
  field(e){const field=e.currentTarget.dataset.field;if(!['aiText','note'].includes(field))return;this._editVersion=(this._editVersion||0)+1;this.setData({[field]:e.detail.value});this.updateDiary();},
  updateDiary(){const content=Object.assign({},this.data.content,{paragraphs:(this.data.aiText||'').split(/\n+/).filter(Boolean)});const ticket=Object.assign({},this.data.ticket,{diary:content,note:this.data.note});this.setData({content,diary:buildDiary(ticket,{name:store.getProfile().name,companionKey:store.getSettings().companion})});},
  async generate(append){
    if(this.data.generating)return;
    const ns=store.getNamespace(),edit=this._editVersion||0,day=store.getDay(this.data.date),actions=day.actions.filter(a=>a.status==='completed'),meals=store.getMeals(this.data.date).filter(m=>m.confirmed);
    if(!actions.length&&!meals.length&&!day.note&&!this.data.note)return;
    this.setData({generating:true,error:''});
    try{
      const content=await require('../../services/diary-generation').generate(ns,{date:this.data.date,name:store.getProfile().name,actions,meals,mood:day.mood,note:[day.note,this.data.note].filter(Boolean).join('\n'),companionKey:store.getSettings().companion,previous:append?this.data.aiText:''});
      if(this._unloaded||ns!==store.getNamespace()||edit!==(this._editVersion||0))return;
      if(!content.paragraphs||!content.paragraphs.length)throw new Error('这次日记还没写好，可以稍后续写，或先写下自己的话。');
      this.setData({content,title:content.title,aiText:content.paragraphs.join('\n\n')});this.updateDiary();
    }catch(error){if(!this._unloaded&&ns===store.getNamespace())this.setData({error:error.message});}
    finally{if(!this._unloaded)this.setData({generating:false});}
  },
  continueDiary(){this.generate(true);},
  playStampSound(){
    if(!wx.createInnerAudioContext)return;
    try{
      if(!this._sound){this._sound=wx.createInnerAudioContext();this._sound.src='/assets/stamp.wav';this._sound.volume=.55;}
      this._sound.stop();this._sound.play();
    }catch(error){/* A muted or unavailable audio device must not affect a saved diary. */}
  },
  animateStamp(){
    clearTimeout(this._stampTimer);clearTimeout(this._impactTimer);
    const reduced=store.getSettings().reduceMotion;
    this.setData({stamping:!reduced,stampLanded:!!reduced});
    if(reduced){this.playStampSound();return;}
    this._impactTimer=setTimeout(()=>{if(!this._unloaded){this.setData({stampLanded:true});this.playStampSound();}},400);
    this._stampTimer=setTimeout(()=>{if(!this._unloaded)this.setData({stamping:false});},650);
  },
  seal(){
    if(this.data.busy)return;
    try{
      if(store.getNamespace()!==this._namespace)throw new Error('账号已变化，请重新打开这页日记');
      this.updateDiary();store.saveDiary(this.data.date,this.data.content,this.data.note);this.reload();
      this.animateStamp();
      ui.toast('今天这一页，收好啦');
    }catch(error){this.setData({error:error.message});}
  },
  async saveImage() {
    if (this.data.busy) return;
    this.setData({busy: true, error: '', albumDenied: false, saveProgress: '正在排版这页日记'});
    let savedCount = 0, total = 0;
    const namespace = store.getNamespace();
    try {
      if (namespace !== this._namespace) throw new Error('账号已变化，请重新打开这页日记');
      this.updateDiary();
      let ticket = store.getTicket(this.data.date);
      if(!ticket||ticket.note!==this.data.note||JSON.stringify(ticket.diary)!==JSON.stringify(this.data.content)){
        store.saveDiary(this.data.date,this.data.content,this.data.note);
        this.reload();ticket=store.getTicket(this.data.date);
      }
      const paths = await image.render(this, ticket, {companionImage:this.data.companionImage,companionKey:store.getSettings().companion,name:store.getProfile().name});
      if (!Array.isArray(paths) || !paths.length) throw new Error('日记图片没有生成，请重试');
      total = paths.length;
      for (let index = 0; index < paths.length; index += 1) {
        if (this._unloaded) throw new Error('已离开日记页，保存已停止');
        if (store.getNamespace() !== namespace) throw new Error('账号已变化，日记保存已停止');
        this.setData({saveProgress: total > 1 ? '完整内容分成 ' + total + ' 张，正在保存第 ' + (index + 1) + ' 张' : '正在保存到相册'});
        await new Promise((resolve, reject) => wx.saveImageToPhotosAlbum({filePath: paths[index], success: resolve, fail: error => {
          const denied = /auth|authorize|permission|deny|denied/i.test(error.errMsg || '');
          const failure = new Error(denied ? '微信尚未允许保存到相册。你可以在权限设置中允许后，再保存一次。' : '日记尚未完整保存到相册，请重试。');
          failure.albumDenied = denied; reject(failure);
        }})); savedCount += 1;
      }
      ui.toast(total > 1 ? total + ' 页日记图片已保存' : '日记已保存到相册');
    } catch (error) {
      if (!this._unloaded) this.setData({error: (savedCount ? '已保存 ' + savedCount + ' / ' + total + ' 张。' : '') + error.message, albumDenied: !!error.albumDenied});
    } finally { if (!this._unloaded) this.setData({busy: false, saveProgress: ''}); }
  },
  openSettings() {
    if (!this.data.albumDenied) return;
    wx.openSetting({success: result => { if (result.authSetting && result.authSetting['scope.writePhotosAlbum']) this.setData({albumDenied: false, error: ''}); },
      fail: () => this.setData({error: '暂时无法打开微信权限设置，请稍后重试。'})});
  }
});
