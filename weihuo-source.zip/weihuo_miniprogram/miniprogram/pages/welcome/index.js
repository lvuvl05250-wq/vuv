const store = require('../../services/store');
const api = require('../../services/api');
const {getCompanionPresentation} = require('../../services/companion');

Page({
  data: {busy: false, configured: false, error: '', reduceMotion: false, companionImage: '/assets/xiaowei-checkin-v2.png'},
  async onShow() {
    this._visible = true;
    try {
      const date = store.today(), day = store.getDay(date);
      const companion = getCompanionPresentation({companionKey: store.getSettings().companion, date, actions: day.actions,
        meals: store.getMeals(date).filter(meal => meal.confirmed === true), note: day.note});
      this.setData({configured: api.status().configured, reduceMotion: store.getSettings().reduceMotion, companionImage: companion.image});
      if (store.getNamespace() !== 'local') return await this.login();
    } catch (error) { this.setData({error: error.message}); }
  },
  onHide() { this._visible = false; },
  onUnload() { this._unloaded = true; },
  async login(event) {
    if (this.data.busy) return;
    this.setData({busy: true, error: ''});
    try {
      const identity = await api.connect();
      if (this._unloaded) return;
      if (!identity || !identity.openid || store.getNamespace() === 'local') throw new Error('尚未取得微信账号身份，请重试');
      if(event&&event.type==='tap')store.saveSettings({aiConsent:true});
      if (store.getProfile().onboarded) wx.switchTab({url: '/pages/today/index'});
      else wx.navigateTo({url: '/pages/profile-edit/index?onboarding=1'});
    } catch (error) {
      if (!this._unloaded) this.setData({error: error.message || '微信登录尚未完成，请重试'});
    } finally { if (!this._unloaded) this.setData({busy: false}); }
  },
  privacy() { if (!this.data.busy) wx.navigateTo({url: '/pages/settings/index?section=privacy'}); }
});
