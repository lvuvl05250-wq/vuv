const store = require('../../services/store');
const ui = require('../../services/ui');
const api = require('../../services/api');
const {getCompanionPresentation} = require('../../services/companion');
const scenes = [{id:'office',name:'办公桌旁'},{id:'classroom',name:'学校'},{id:'home',name:'家里'},{id:'dorm',name:'宿舍'},{id:'outdoor',name:'户外'},{id:'commute',name:'通勤路上'},{id:'any',name:'地点不固定'}];
const careLabel = value => value < 50 ? '偏向照顾自己' : value > 50 ? '偏向运动一下' : '照顾与运动都可以';
const sceneOptions = selected => scenes.map(item => Object.assign({}, item, {selected: selected.indexOf(item.id) !== -1}));
Page({
  data: {day:{}, scenes:[], careLabel:'', companionImage:'/assets/xiaowei-checkin-v2.png', minutes:[10,20,30,45,60,90], energies:[{value:1,label:'很低'},{value:2,label:'偏低'},{value:3,label:'一般'},{value:4,label:'不错'},{value:5,label:'充足'}], moods:['平静','愉快','有点烦','低落','紧张','慢慢来'], busy:false,error:''},
  onLoad() {
    this._namespace = store.getNamespace(); this._touched = {};
    const day = store.getDay();
    const date = store.today();
    const companion = getCompanionPresentation({companionKey: store.getSettings().companion, date, actions: day.actions,
      meals: store.getMeals(date).filter(meal => meal.confirmed === true), note: day.note});
    if (!day.scenes || !day.scenes.length) day.scenes = [day.scene || 'office'];
    if (typeof day.carePreference !== 'number') day.carePreference = 50;
    this.setData({day, scenes:sceneOptions(day.scenes), careLabel:careLabel(day.carePreference), companionImage:companion.image});
  },
  onUnload() { this._unloaded = true; },
  field(e) { if (this.data.busy) return; const key=e.currentTarget.dataset.field; if(key!=='note')return; this.setData({'day.note':e.detail.value}); },
  pick(e) {
    if (this.data.busy) return;
    const key=e.currentTarget.dataset.field;
    if(!['minutes','mood'].includes(key))return;
    const value=key==='minutes'?Number(e.currentTarget.dataset.value):e.currentTarget.dataset.value;
    if(key==='minutes'&&!this.data.minutes.includes(value))return;
    this._touched[key]=true; this.setData({['day.'+key]:value});
  },
  toggleScene(e) {
    if (this.data.busy) return;
    const value=e.currentTarget.dataset.value;
    if(!scenes.some(item=>item.id===value))return;
    let selected=this.data.day.scenes.slice();
    if(selected.includes(value)) {
      if(selected.length===1)return ui.toast('请至少保留一个地点');
      selected=selected.filter(id=>id!==value);
    } else selected=value==='any'?['any']:selected.filter(id=>id!=='any').concat(value);
    this._touched.scenes=true; this._touched.scene=true;
    this.setData({'day.scenes':selected,'day.scene':selected[0],scenes:sceneOptions(selected)});
  },
  energy(e) {
    if (this.data.busy) return;
    const value=Number(e.currentTarget&&e.currentTarget.dataset&&e.currentTarget.dataset.value!==undefined?e.currentTarget.dataset.value:e.detail.value);
    if(!Number.isInteger(value)||value<1||value>5)return;
    this._touched.energy=true; this.setData({'day.energy':value});
  },
  careChange(e) {
    if (this.data.busy) return;
    const value=Number(e.detail.value);
    if(!Number.isFinite(value)||value<0||value>100)return;
    this._touched.carePreference=true;
    this.setData({'day.carePreference':value,careLabel:careLabel(value)});
  },
  async save() {
    if(this.data.busy)return;
    this.setData({busy:true,error:''});
    let saved=false;
    try {
      if(store.getNamespace()!==this._namespace)throw new Error('账号已变化，请重新打开今日小问卷');
      const date=store.today(),day=store.saveDay(this.data.day,date),baseline=JSON.stringify(day); saved=true;
      if(day.note.trim()&&store.getSettings().aiConsent) {
        // Keep the user's words durable first. AI enrichment runs in the background,
        // and only merges while this exact saved snapshot is still current.
        api.request('parseState',{text:day.note}).then(result=>{
          if(store.getNamespace()!==this._namespace||!store.getSettings().aiConsent||JSON.stringify(store.getDay(date))!==baseline)return;
          const next=Object.assign({},day);
          ['energy','minutes','mood'].forEach(key=>{if(!this._touched[key]&&result[key]!==null&&result[key]!==undefined&&result[key]!=='')next[key]=result[key];});
          if(!this._touched.scenes&&!this._touched.scene&&result.scene) { next.scene=result.scene; next.scenes=[result.scene]; }
          store.saveDay(next,date);
        }).catch(()=>{});
      }
      this.setData({busy:false});
      if(!this._unloaded&&store.getNamespace()===this._namespace) {
        ui.toast('今天的状态已保存');
        wx.navigateBack();
      }
    } catch(error) { if(!this._unloaded)this.setData({error:saved?'原文已保存，请重新打开查看':error.message,busy:false}); }
  }
});
