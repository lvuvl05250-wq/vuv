const store = require('../../services/store');
const ui = require('../../services/ui');
const period = require('../../services/period');
const calendar = require('../../services/calendar-reminder');

function options() { return {today: store.today(), now: new Date().toISOString(), id: store.uid('period')}; }
function copy(value) { return JSON.parse(JSON.stringify(value)); }

Page({
  data: {today: '', month: '', monthLabel: '', selectedDate: '', selectedLabel: '', cells: [],
    weekdays: ['一', '二', '三', '四', '五', '六', '日'], canPrevious: true, canNext: false,
    records: [], history: [], currentId: '', intervalLabel: '', editStart: '', editEnd: '',
    feelings: [], feelingOptions: [], note: '', hasDayRecord: false, dirty: false,
    saving: false, confirming: false, error: '', loadError: '', canUndo: false, undoLabel: '',
    selectedFuture: false, maxMonth: '', forecast: {}, forecastLabel: '', forecastStatus: '', cycleBasis: '', durationBasis: '',
    settings: {}, settingsDraft: {}, settingsOpen: false, settingsDirty: false, settingsSaving: false, settingsError: '',
    reminderOpen: false, reminderDate: '', reminderTime: '09:00', reminderBusy: false, reminderError: '', reminderAdded: '', calendarToday: ''},
  onLoad(query) {
    this._namespace = store.getNamespace();
    const today = store.today();
    const date = query && period.validDate(query.date) && query.date <= today ? query.date : today;
    this.setData({today, month: date.slice(0, 7), selectedDate: date});
  },
  onShow() {
    if (store.getNamespace() !== this._namespace) {
      this._namespace = store.getNamespace(); this._undo = null; this._forecastKey = '';
      this.setData({settingsDirty: false, reminderError: '', reminderAdded: '', reminderTime: '09:00'});
      this.setData({dirty: false, canUndo: false, undoLabel: '', selectedDate: store.today(), month: store.today().slice(0, 7)});
    }
    this.reload(this.data.dirty);
  },
  onUnload() { this._gone = true; this._undo = null; },
  ensureAccount(namespace) {
    if (this._gone) throw new Error('页面已关闭，请重新进入经期日历');
    if (store.getNamespace() !== (namespace || this._namespace)) throw new Error('账号已变化，请重新打开经期日历后再操作');
  },
  reload(preserveDraft) {
    try {
      const today = store.today();
      const records = period.validateRecords(store.getPeriodRecords(), today);
      if (preserveDraft && this._snapshot && JSON.stringify(records) !== JSON.stringify(this._snapshot)) {
        this.setData({loadError: '记录已在别处更新。当前草稿还在；重新读取后再修改。'}); return;
      }
      this._snapshot = copy(records);
      const settings = period.validateSettings(store.getPeriodSettings());
      this.setData({settings});
      if (!this.data.settingsDirty) this.setData({settingsDraft: copy(settings)});
      this.refreshForecast(records, settings, today);
      this.setData({records, today, loadError: '', history: records.slice().reverse().map(record => ({
        id: record.id, date: record.startDate, label: ui.dateLabel(record.startDate) + (record.endDate ? ' — ' + ui.dateLabel(record.endDate) : ' · 结束未记录'),
        dayCount: record.days.length
      }))});
      this.renderCalendar();
      if (!preserveDraft) this.fillSelection(this.data.selectedDate || today);
    } catch (error) { this.setData({loadError: error.message || '记录读取失败，请重试'}); }
  },
  refreshForecast(records, settings, today) {
    const forecast = period.estimateNext(records, settings, today);
    const source = (kind, count, days, label) => kind === 'history' ? label + '：最近 ' + count + ' 次记录的中位数，' + days + ' 天' : label + '：' + (kind === 'manual' ? '你的设置 ' : '默认 ') + days + ' 天' + (settings.predictionMode === 'history' ? '（历史记录不足）' : '');
    const latest = records[records.length - 1];
    const key = this._namespace + ':period:' + (latest ? latest.id : 'empty') + ':' + forecast.lastStartDate + ':' + forecast.startDate + ':' + forecast.endDate;
    if (key !== this._forecastKey) {
      this._forecastKey = key;
      this.setData({reminderDate: forecast.startDate, reminderError: '', reminderAdded: ''});
    }
    const added = calendar.lastAdded(key);
    const status = forecast.status === 'no-records' ? '先记录一次实际开始日期，才有估计依据。'
      : forecast.status === 'conflict' ? '当前估计与实际结束日期或持续天数冲突，调整设置或核对实际日期后再估计。'
      : forecast.status === 'out-of-range' ? '估计日期超出日历可显示范围，请检查日期与设置。'
      : forecast.overdue ? '估计开始日已过，尚未记录新的实际开始。' : '这是日期估计，实际开始与结束由你记录。';
    const nextMonth = period.shiftMonth(today.slice(0, 7), 1);
    this.setData({forecast, forecastStatus: status, forecastLabel: forecast.startDate ? ui.dateLabel(forecast.startDate) + ' — ' + ui.dateLabel(forecast.endDate) : '暂时没有估计日期',
      cycleBasis: source(forecast.cycleSource, forecast.intervalCount, forecast.cycleLengthDays, '周期'),
      durationBasis: source(forecast.periodSource, forecast.durationCount, forecast.periodLengthDays, '持续'),
      maxMonth: forecast.endDate && forecast.endDate.slice(0, 7) > nextMonth ? forecast.endDate.slice(0, 7) : nextMonth,
      reminderAdded: added ? added.date + ' ' + added.time : '', calendarToday: calendar.localDate()});
  },
  renderCalendar() {
    const month = this.data.month || this.data.today.slice(0, 7);
    this.setData({month, monthLabel: month.slice(0, 4) + ' 年 ' + Number(month.slice(5)) + ' 月',
      canPrevious: month > '1900-01', canNext: month < this.data.maxMonth,
      cells: period.buildMonth(this.data.records, month, this.data.selectedDate, this.data.today, this.data.settings)});
  },
  fillSelection(date) {
    const future = date > this.data.today;
    const record = future ? null : period.recordForDate(this.data.records, date, this.data.today);
    const day = record && record.days.find(item => item.date === date);
    this.setData({selectedDate: date, selectedFuture: future, selectedLabel: ui.dateLabel(date), currentId: record ? record.id : '',
      intervalLabel: record ? ui.dateLabel(record.startDate) + (record.endDate ? ' — ' + ui.dateLabel(record.endDate) : ' · 结束未记录') : '',
      editStart: record ? record.startDate : date, editEnd: record ? record.endDate : '',
      feelings: day ? day.feelings.slice() : [], note: day ? day.note : '', hasDayRecord: !!day, dirty: false, error: ''});
    this.renderFeelings(); this.renderCalendar();
  },
  renderFeelings() { this.setData({feelingOptions: period.FEELINGS.map(item => Object.assign({}, item, {selected: this.data.feelings.indexOf(item.id) !== -1}))}); },
  busy() { return this.data.saving || this.data.confirming || this.data.settingsSaving || this.data.reminderBusy || !!this.data.loadError; },
  async mayDiscard() {
    if (!this.data.dirty) return true;
    this.setData({confirming: true});
    try { return await ui.confirm('放下未保存的修改？', '已经保存的日期和感受会保留，这次草稿会放下。'); }
    finally { if (!this._gone) this.setData({confirming: false}); }
  },
  async selectDate(date) {
    if (this.busy() || !period.validDate(date) || date.slice(0, 7) > this.data.maxMonth || date === this.data.selectedDate) return;
    const namespace = this._namespace;
    if (!await this.mayDiscard()) return;
    try {
      this.ensureAccount(namespace);
      this.setData({month: date.slice(0, 7)}); this.fillSelection(date);
    } catch (error) { if (!this._gone) this.setData({error: error.message}); }
  },
  chooseDay(e) { return this.selectDate(e.currentTarget.dataset.date); },
  chooseHistory(e) { return this.selectDate(e.currentTarget.dataset.date); },
  moveMonth(e) {
    if (this.busy()) return;
    const delta = Number(e.currentTarget.dataset.delta);
    if (delta !== -1 && delta !== 1) return;
    const month = period.shiftMonth(this.data.month, delta);
    if (month < '1900-01' || month > this.data.maxMonth) return;
    this.setData({month}); this.renderCalendar();
  },
  today() {
    if (this.busy()) return;
    if (this.data.selectedDate === this.data.today) {
      this.setData({month: this.data.today.slice(0, 7)}); this.renderCalendar(); return;
    }
    return this.selectDate(this.data.today);
  },
  showForecast() {
    if (this.busy() || !this.data.forecast.startDate) return;
    this.setData({month: this.data.forecast.startDate.slice(0, 7)}); this.renderCalendar();
  },
  toggleReminder() { if (!this.busy()) this.setData({reminderOpen: !this.data.reminderOpen}); },
  toggleSettings() { if (!this.busy()) this.setData({settingsOpen: !this.data.settingsOpen}); },
  settingsMode(e) {
    if (this.busy()) return;
    const value = e.currentTarget.dataset.value;
    if (['history', 'manual'].indexOf(value) === -1) return;
    this.setData({settingsDraft: Object.assign({}, this.data.settingsDraft, {predictionMode: value}), settingsDirty: true, settingsError: ''});
  },
  settingsField(e) {
    if (this.busy()) return;
    const field = e.currentTarget.dataset.field;
    if (['cycleLengthDays', 'periodLengthDays'].indexOf(field) === -1) return;
    this.setData({settingsDraft: Object.assign({}, this.data.settingsDraft, {[field]: e.detail.value}), settingsDirty: true, settingsError: ''});
  },
  saveSettings() {
    if (this.busy()) return;
    this.setData({settingsSaving: true, settingsError: ''});
    try {
      this.ensureAccount();
      const draft = this.data.settingsDraft;
      const next = period.validateSettings({predictionMode: draft.predictionMode, cycleLengthDays: Number(draft.cycleLengthDays), periodLengthDays: Number(draft.periodLengthDays), configured: true});
      store.savePeriodSettings(next);
      this.setData({settingsDirty: false}); this.reload(this.data.dirty); ui.toast('周期设置已保存');
    } catch (error) { if (!this._gone) this.setData({settingsError: error.message || '设置未保存，填写的内容还在'}); }
    finally { if (!this._gone) this.setData({settingsSaving: false}); }
  },
  reminderField(e) {
    if (this.busy()) return;
    const field = e.currentTarget.dataset.field;
    if (['reminderDate', 'reminderTime'].indexOf(field) !== -1) this.setData({[field]: e.detail.value, reminderError: ''});
  },
  async addReminder() {
    if (this.busy() || !this.data.forecast.startDate) return;
    const namespace = this._namespace, key = this._forecastKey;
    this.setData({reminderBusy: true, reminderError: ''});
    try {
      const input = () => {
        this.ensureAccount(namespace);
        const records = period.validateRecords(store.getPeriodRecords(), store.today());
        const forecast = period.estimateNext(records, store.getPeriodSettings(), store.today());
        const latest = records[records.length - 1];
        const currentKey = namespace + ':period:' + (latest ? latest.id : 'empty') + ':' + forecast.lastStartDate + ':' + forecast.startDate + ':' + forecast.endDate;
        if (currentKey !== key || !forecast.startDate) throw new Error('估计日期已变化，请重新查看后添加提醒');
        return {key, date: this.data.reminderDate, time: this.data.reminderTime, title: '查看自己的记录', durationMinutes: 5};
      };
      let request = input();
      const event = calendar.createCalendarEvent(request), previous = calendar.lastAdded(key);
      if (previous && previous.signature !== JSON.stringify(event)) {
        if (!await ui.confirm('再添加一条日历提醒？', '已添加的提醒不会自动更新。新提醒会另建一条，旧提醒可在手机日历修改或删除。')) return;
        request = input();
      }
      const result = await calendar.addReminder(request);
      if (this._gone || store.getNamespace() !== namespace) return;
      this.setData({reminderAdded: result.date + ' ' + result.time});
      ui.toast(result.status === 'already-added' ? '这条提醒已添加，请到手机日历查看' : '已添加，请到手机日历查看');
    } catch (error) { if (!this._gone && store.getNamespace() === namespace) this.setData({reminderError: error.message || '提醒尚未添加，请重试'}); }
    finally { if (!this._gone) this.setData({reminderBusy: false}); }
  },
  field(e) {
    if (this.busy()) return;
    const key = e.currentTarget.dataset.field;
    if (['editStart', 'editEnd', 'note'].indexOf(key) === -1) return;
    this.setData({[key]: e.detail.value, dirty: true, error: ''});
  },
  toggleFeeling(e) {
    if (this.busy()) return;
    const id = e.currentTarget.dataset.id;
    if (!period.FEELINGS.some(item => item.id === id)) return;
    const feelings = this.data.feelings.slice(), index = feelings.indexOf(id);
    if (index === -1) feelings.push(id); else feelings.splice(index, 1);
    this.setData({feelings, dirty: true, error: ''}); this.renderFeelings();
  },
  clearEnd() { if (!this.busy()) this.setData({editEnd: '', dirty: true, error: ''}); },
  buildEditorRecord(patch) {
    const record = this._snapshot.find(item => item.id === this.data.currentId);
    if (!record) throw new Error('这次记录已不存在，请重新读取');
    const days = record.days.filter(day => day.date !== this.data.selectedDate);
    if (this.data.feelings.length || this.data.note.trim()) days.push({date: this.data.selectedDate, feelings: this.data.feelings, note: this.data.note});
    return period.upsertRecord(this._snapshot, Object.assign({id: record.id, startDate: this.data.editStart, endDate: this.data.editEnd, days}, patch || {}), options());
  },
  commit(next, label) {
    this.ensureAccount();
    const before = copy(this._snapshot);
    this.setData({saving: true, error: ''});
    try {
      store.replacePeriodRecords(next, before);
      const after = period.validateRecords(store.getPeriodRecords(), store.today());
      this._undo = {before, after: copy(after), namespace: this._namespace};
      this.setData({dirty: false, canUndo: true, undoLabel: label});
      this.reload(false); ui.toast(label);
    } finally { if (!this._gone) this.setData({saving: false}); }
  },
  markStart() {
    if (this.busy()) return;
    try {
      const next = this.data.currentId
        ? this.buildEditorRecord({startDate: this.data.selectedDate})
        : period.upsertRecord(this._snapshot, {startDate: this.data.selectedDate, endDate: '', days: []}, options());
      this.commit(next, '开始日期已保存');
    } catch (error) { this.setData({error: error.message || '保存未完成，填写的内容还在'}); }
  },
  markEnd() {
    if (this.busy() || !this.data.currentId) return;
    try { this.commit(this.buildEditorRecord({endDate: this.data.selectedDate}), '结束日期已保存'); }
    catch (error) { this.setData({error: error.message || '保存未完成，填写的内容还在'}); }
  },
  save() {
    if (this.busy() || !this.data.currentId) return;
    try { this.commit(this.buildEditorRecord(), '这次修改已保存'); }
    catch (error) { this.setData({error: error.message || '保存未完成，填写的内容还在'}); }
  },
  clearDay() {
    if (this.busy() || !this.data.currentId) return;
    this.setData({feelings: [], note: '', dirty: true, error: ''}); this.renderFeelings();
  },
  async deleteCurrent() {
    if (this.busy() || !this.data.currentId) return;
    const namespace = this._namespace, id = this.data.currentId;
    this.setData({confirming: true});
    try {
      if (!await ui.confirm('删除这次经期记录？', '开始、结束日期和这次保存的日感受都会删除。可在本页撤销最近这一步。')) return;
      this.ensureAccount(namespace);
      this.commit(period.deleteRecord(this._snapshot, id, store.today()), '这次记录已删除');
    } catch (error) { if (!this._gone) this.setData({error: error.message}); }
    finally { if (!this._gone) this.setData({confirming: false}); }
  },
  async undo() {
    if (this.busy() || !this._undo) return;
    const undo = this._undo;
    if (this.data.dirty && !await this.mayDiscard()) return;
    if (this._gone) return;
    this.setData({saving: true, error: ''});
    try {
      this.ensureAccount(undo.namespace);
      store.replacePeriodRecords(undo.before, undo.after);
      this._undo = null; this.setData({dirty: false, canUndo: false, undoLabel: ''});
      this.reload(false); ui.toast('已撤销最近一步');
    } catch (error) { if (!this._gone) this.setData({error: error.message || '撤销未完成'}); }
    finally { if (!this._gone) this.setData({saving: false}); }
  },
  async retry() {
    if (this.data.saving || this.data.confirming) return;
    if (this.data.dirty && !await this.mayDiscard()) return;
    try {
      this.ensureAccount(); this._undo = null;
      this.setData({dirty: false, canUndo: false, undoLabel: '', error: ''}); this.reload(false);
    } catch (error) { if (!this._gone) this.setData({error: error.message}); }
  }
});
