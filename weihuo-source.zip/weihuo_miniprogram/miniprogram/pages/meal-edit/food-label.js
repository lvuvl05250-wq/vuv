const BASIS = ['unknown', 'per100g', 'per100ml', 'perServing'];
const BASIS_LABELS = ['基准还不清楚', '每 100 克', '每 100 毫升', '每份'];
const UNIT = { unknown: '', per100g: 'g', per100ml: 'ml', perServing: 'serving' };
const UNIT_LABEL = { unknown: '先核对标签基准', per100g: '克', per100ml: '毫升', perServing: '份' };
const NUMBERS = ['energyValue', 'protein', 'carbs', 'fat'];
function blank() {
  return { name: '', ingredients: '', servingBasis: 'unknown', servingSize: '', energyValue: '', energyUnit: '', protein: '', carbs: '', fat: '', actualQuantity: '', flags: [], uncertainFields: [], evidence: {} };
}
function form(value) {
  const result = Object.assign(blank(), value || {});
  NUMBERS.concat('actualQuantity').forEach(key => { result[key] = result[key] === null || result[key] === undefined ? '' : String(result[key]); });
  if (!result.energyUnit) result.energyUnit = '';
  return result;
}
function number(value, label, maximum) {
  const text = String(value === null || value === undefined ? '' : value).trim();
  if (!text) return null;
  if (!/^\d+(\.\d+)?$/.test(text) || !Number.isFinite(Number(text)) || Number(text) > maximum) throw new Error(label + '请填 0–' + maximum + ' 的数字，不确定可以留空。');
  return Number(text);
}
function confirm(input, name) {
  const value = form(input);
  if (!BASIS.includes(value.servingBasis)) throw new Error('请核对营养表的计算基准。');
  if (String(value.energyValue).trim() && !['kJ', 'kcal'].includes(value.energyUnit)) throw new Error('请选择标签上的能量单位，无法辨认时请清空能量。');
  const label = {
    source: 'label', name: String(name || value.name || '').trim(), ingredients: value.ingredients.trim(), servingBasis: value.servingBasis,
    servingSize: value.servingSize.trim(), energyValue: number(value.energyValue, '标签能量', 130000), energyUnit: value.energyUnit,
    protein: number(value.protein, '标签蛋白质', 3000), carbs: number(value.carbs, '标签碳水', 3000), fat: number(value.fat, '标签脂肪', 3000),
    actualQuantity: number(value.actualQuantity, '实际食用量', value.servingBasis === 'perServing' ? 1000 : 30000), actualUnit: UNIT[value.servingBasis],
    flags: value.flags.slice(), uncertainFields: value.uncertainFields.slice(), evidence: Object.assign({}, value.evidence)
  };
  if (label.energyValue === null) label.energyUnit = null;
  if (label.servingBasis === 'unknown' && label.actualQuantity !== null) throw new Error('标签基准还不清楚，先核对每 100 克、每 100 毫升或每份；也可以清空食用量，只保存标签原文。');
  if (label.ingredients.length > 4000 || label.servingSize.length > 200) throw new Error('标签文字过长，请精简后再试。');
  if (!label.ingredients && NUMBERS.every(key => label[key] === null)) throw new Error('先抄下配料表或营养表中的内容，再确认。');
  const nutrition = { kcal: null, protein: null, carbs: null, fat: null };
  const factor = label.actualQuantity === null || label.servingBasis === 'unknown' ? null : label.actualQuantity / (label.servingBasis === 'perServing' ? 1 : 100);
  if (factor !== null) {
    const round = number => Math.round((number + Number.EPSILON) * 100) / 100;
    nutrition.kcal = label.energyValue === null ? null : round(label.energyValue * factor / (label.energyUnit === 'kJ' ? 4.184 : 1));
    ['protein', 'carbs', 'fat'].forEach(key => { nutrition[key] = label[key] === null ? null : round(label[key] * factor); });
    if ((nutrition.kcal !== null && nutrition.kcal > 30000) || ['protein', 'carbs', 'fat'].some(key => nutrition[key] !== null && nutrition[key] > 3000)) throw new Error('换算结果超出记录范围，请检查标签基准和实际食用量。');
  }
  return { label, nutrition };
}
module.exports = { BASIS, BASIS_LABELS, UNIT_LABEL, blank, form, confirm };
