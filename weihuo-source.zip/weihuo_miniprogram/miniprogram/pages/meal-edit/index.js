const store = require('../../services/store');
const api = require('../../services/api');
const media = require('../../services/media');
const ui = require('../../services/ui');
const foodLabel = require('./food-label');
const recipes = require('../../services/recipes');

const TAG_GROUPS = [
  { name: '餐次', labels: ['早餐', '午餐', '晚餐', '加餐'] },
  { name: '口感与喜欢', labels: ['喜欢', '清爽', '软糯', '酥脆', '鲜香'] },
  { name: '饱足感', labels: ['刚刚好', '还想吃', '有点撑'] }
];
const NUMBERS = ['kcal', 'protein', 'carbs', 'fat'];
const ANALYSIS_TIMEOUT_MS = 10000;
function timeNow() { return new Date(Date.now() + 8 * 3600000).toISOString().slice(11, 16); }
function asNumber(value) { if (value === '' || value === null || value === undefined) return null; const number = Number(value); return Number.isFinite(number) && number >= 0 ? number : null; }
function numericText(value) {
  const number = asNumber(value);
  if (number === null) return '';
  const text = String(number);
  if (text.indexOf('e') === -1) return text;
  const parts = text.split('e');
  const coefficient = parts[0].split('.');
  const digits = coefficient.join('');
  const point = coefficient[0].length + Number(parts[1]);
  if (point <= 0) return '0.' + '0'.repeat(-point) + digits;
  if (point >= digits.length) return digits + '0'.repeat(point - digits.length);
  return digits.slice(0, point) + '.' + digits.slice(point);
}

Page({
  data: {
    id: '', date: '', today: '', time: '', name: '', note: '', photoPath: '', fromRecipe: false,
    kcal: '', protein: '', carbs: '', fat: '', nutritionSource: 'manual',
    tags: [], tagGroups: [], busy: false, saving: false, photoBusy: false,
    error: '', aiError: '', recognitionStatus: '', missing: false, updated: false, aiBody: '', estimateRange: '', aiNeedsRefresh: false, labelDetailsOpen: false,
    recordType: 'meal', labelPhotoPaths: [], labelForm: foodLabel.blank(), foodLabel: null,
    labelError: '', labelBasisOptions: foodLabel.BASIS_LABELS, labelBasisIndex: 0,
    labelAmountUnit: foodLabel.UNIT_LABEL.unknown, energyUnitOptions: ['请选择单位', 'kJ', 'kcal'], energyUnitIndex: 0
  },
  onLoad(options) {
    this._newPhotos = [];
    this._draftVersion = 0;
    this._analysisId = 0;
    this._namespace = store.getNamespace();
    this._initialMode = options.mode || '';
    this.setData({ id: options.id || '', date: options.date || store.today(), today: store.today(), time: timeNow() });
    const recipe = !options.id && recipes.getRecipe(options.recipeId);
    if (recipe) { this._initialMode = ''; this._dirty = true; this.setData({name: recipe.title, date: store.today(), fromRecipe: true}); }
    this.updateTags([]);
  },
  onShow() {
    try {
      this.setData({ today: store.today() });
      if (this.data.id && !this._dirty) {
        const record = store.getMeals().find((item) => item.id === this.data.id);
        if (!record) { this.setData({ missing: true, error: '这条记录已经不存在，请返回饮食手账。' }); return; }
        this._persistedPhoto = record.photoPath || '';
        this._persistedLabelPhotos = (record.labelPhotoPaths || []).slice();
        const patch = Object.assign({}, record, { error: '', missing: false });
        patch.labelPhotoPaths = (record.labelPhotoPaths || []).slice();
        patch.foodLabel = record.foodLabel || null;
        patch.recordType = record.foodLabel || patch.labelPhotoPaths.length ? 'packaged' : 'meal';
        patch.labelForm = foodLabel.form(record.foodLabel);
        patch.photoPath = record.photoPath || patch.labelPhotoPaths[0] || '';
        patch.labelDetailsOpen = false;
        patch.updated = record.nutritionSource === 'ai-estimate' || record.nutritionSource === 'label';
        patch.recognitionStatus = '';
        patch.labelBasisIndex = foodLabel.BASIS.indexOf(patch.labelForm.servingBasis);
        patch.labelAmountUnit = foodLabel.UNIT_LABEL[patch.labelForm.servingBasis];
        patch.energyUnitIndex = this.data.energyUnitOptions.indexOf(patch.labelForm.energyUnit) > 0 ? this.data.energyUnitOptions.indexOf(patch.labelForm.energyUnit) : 0;
        NUMBERS.forEach((key) => { patch[key] = numericText(record[key]); });
        this.setData(patch);
        this.updateTags(record.tags || []);
      }
    } catch (error) { this.setData({ error: error.message || '暂时无法读取这条记录。' }); }
  },
  onReady() { if (!this.data.id && this._initialMode === 'photo') this.choosePhoto(); },
  onUnload() {
    this._gone = true;
    (this._newPhotos || []).forEach((path) => {
      if (path !== this._persistedPhoto && (this._persistedLabelPhotos || []).indexOf(path) === -1) media.removePhoto(path).catch(() => {});
    });
  },
  updateTags(tags) {
    this.setData({
      tags,
      tagGroups: TAG_GROUPS.map((group) => ({ name: group.name, options: group.labels.map((label) => ({ label, selected: tags.indexOf(label) !== -1 })) }))
    });
  },
  canUseDraft() {
    if (this._gone) return false;
    if (store.getNamespace() === this._namespace) return true;
    this.setData({ error: '账号已变化，请返回饮食手账后重新打开。' });
    return false;
  },
  markDraftChanged() {
    this._draftVersion = (this._draftVersion || 0) + 1;
    this.setData({recognitionStatus: ''});
  },
  analysisIsCurrent(context) {
    if (!context || context.id !== this._analysisId || context.version !== this._draftVersion) return false;
    if (store.getNamespace() !== context.namespace) { this.canUseDraft(); return false; }
    return store.getSettings().aiConsent;
  },
  clearRecognition() {
    const patch = { foodLabel: null, labelForm: foodLabel.blank(), labelBasisIndex: 0, energyUnitIndex: 0, labelAmountUnit: foodLabel.UNIT_LABEL.unknown, labelError: '', aiError: '', recognitionStatus: '', aiBody: '', estimateRange: '', updated: false, aiNeedsRefresh: false };
    if (this.data.nutritionSource !== 'manual') { patch.nutritionSource = 'manual'; NUMBERS.forEach(key => { patch[key] = ''; }); }
    return patch;
  },
  async changeRecordType(event) {
    if (this.data.busy || this.data.saving || this.data.photoBusy || !this.canUseDraft()) return;
    const recordType = event.currentTarget.dataset.type;
    if (!['meal', 'packaged'].includes(recordType) || recordType === this.data.recordType) return;
    this.markDraftChanged();
    this._dirty = true;
    this.setData(Object.assign(this.clearRecognition(), {recordType, labelPhotoPaths: recordType === 'packaged' && this.data.photoPath ? [this.data.photoPath] : []}));
    if (this.data.photoPath) await this.analyze();
  },
  onField(event) {
    if (this.data.saving || this.data.busy || !this.canUseDraft()) return;
    const field = event.currentTarget.dataset.field;
    if (!['name', 'note', 'date', 'time'].concat(NUMBERS).includes(field)) return;
    this.markDraftChanged();
    this._dirty = true;
    const patch = {[field]: event.detail.value};
    if ((field === 'name' || field === 'note') && this.data.nutritionSource === 'ai-estimate') {
      NUMBERS.forEach(key => { patch[key] = ''; });
      Object.assign(patch, {nutritionSource: 'manual', updated: false, estimateRange: '', aiNeedsRefresh: true});
    }
    if (NUMBERS.includes(field)) patch.nutritionSource = 'manual';
    this.setData(patch);
  },
  onLabelField(event) {
    if (this.data.saving || this.data.busy || !this.canUseDraft()) return;
    const field = event.currentTarget.dataset.field;
    if (!['ingredients', 'servingSize', 'energyValue', 'protein', 'carbs', 'fat', 'actualQuantity', 'servingBasis', 'energyUnit'].includes(field)) return;
    let value = event.detail.value;
    if (field === 'servingBasis') value = foodLabel.BASIS[Number(value)];
    if (field === 'energyUnit') value = Number(value) === 0 ? '' : this.data.energyUnitOptions[Number(value)];
    if (value === undefined) return;
    this.markDraftChanged();
    const form = Object.assign({}, this.data.labelForm, {[field]: value});
    form.uncertainFields = (form.uncertainFields || []).filter(key => key !== field);
    form.evidence = Object.assign({}, form.evidence);
    if (Object.hasOwn(form.evidence, field)) form.evidence[field] = '';
    if (field === 'servingBasis') form.actualQuantity = '';
    this._dirty = true;
    this.setLabelForm(form);
    this.recalculateLabel();
  },
  setLabelForm(form) {
    this.setData({labelForm: form, labelBasisIndex: Math.max(0, foodLabel.BASIS.indexOf(form.servingBasis)), labelAmountUnit: foodLabel.UNIT_LABEL[form.servingBasis] || foodLabel.UNIT_LABEL.unknown, energyUnitIndex: Math.max(0, this.data.energyUnitOptions.indexOf(form.energyUnit))});
  },
  toggleLabelDetails() { this.setData({labelDetailsOpen: !this.data.labelDetailsOpen}); },
  recalculateLabel() {
    const form = this.data.labelForm;
    const hasContent = String(form.ingredients || '').trim() || ['energyValue', 'protein', 'carbs', 'fat'].some(key => String(form[key] || '').trim());
    if (!hasContent) { const patch = {foodLabel: null, labelError: ''}; if (this.data.nutritionSource === 'label') { patch.nutritionSource = 'manual'; NUMBERS.forEach(key => { patch[key] = ''; }); } this.setData(patch); return; }
    try {
      const result = foodLabel.confirm(form, this.data.name);
      const patch = {foodLabel: result.label, nutritionSource: 'label', labelError: ''};
      NUMBERS.forEach(key => { patch[key] = numericText(result.nutrition[key]); });
      this.setData(patch);
    } catch (error) {
      const patch = {foodLabel: null, labelError: error.message || '请核对标签数值。', nutritionSource: 'manual'};
      NUMBERS.forEach(key => { patch[key] = ''; });
      this.setData(patch);
    }
  },
  async persistLateLabel(context, safe) {
    const saved = this._savedDuringAnalysis;
    if (!saved || saved.analysisId !== context.id || saved.version !== context.version) return false;
    const current = store.getMeals().find(item => item.id === saved.record.id);
    if (!current || JSON.stringify(current) !== saved.serialized || current.foodLabel) return false;
    const form = foodLabel.form(safe);
    form.actualQuantity = context.labelForm.actualQuantity || '';
    const name = current.name === '包装食品' && typeof safe.name === 'string' && safe.name.trim() ? safe.name.trim() : current.name;
    const confirmed = foodLabel.confirm(form, name);
    const next = Object.assign({}, current, {foodLabel: confirmed.label, nutritionSource: 'label'});
    if (name !== current.name) next.name = name;
    NUMBERS.forEach(key => { if (current[key] === null && confirmed.nutrition[key] !== null) next[key] = confirmed.nutrition[key]; });
    store.saveMeal(next);
    return true;
  },
  persistLateMealEstimate(context, currentValues, estimate) {
    const saved = this._savedDuringAnalysis;
    if (!saved || saved.analysisId !== context.id || saved.version !== context.version) return false;
    const current = store.getMeals().find(item => item.id === saved.record.id);
    if (!current || JSON.stringify(current) !== saved.serialized) return false;
    const patch = {};
    if (current.name === '照片餐食' && estimate.name) patch.name = estimate.name;
    NUMBERS.forEach(key => { if (current[key] === null && currentValues[key] !== null) patch[key] = currentValues[key]; });
    if (NUMBERS.some(key => patch[key] !== undefined)) patch.nutritionSource = 'ai-estimate';
    if (Object.keys(patch).length) store.saveMeal(Object.assign({}, current, patch));
    return true;
  },
  async analyzeFoodLabel(context) {
    if (!context.note && !context.labelPhotoPaths.length) return false;
    const result = await api.request('analyzeFoodLabel', {name: context.name, text: context.note, photoPaths: context.labelPhotoPaths.slice()});
    if (!this.analysisIsCurrent(context)) return false;
    const safe = result && typeof result === 'object' ? result : {};
    if (this._savedDuringAnalysis && this._savedDuringAnalysis.analysisId === context.id) return this.persistLateLabel(context, safe);
    if (this._gone) return false;
    const form = foodLabel.form(safe);
    form.actualQuantity = context.labelForm.actualQuantity || '';
    this.setLabelForm(form);
    const patch = {updated: true, aiNeedsRefresh: false, aiError: '', recognitionStatus: '', aiBody: safe.body || safe.note || '', labelDetailsOpen: form.servingBasis === 'unknown'};
    if (typeof safe.name === 'string' && safe.name.trim()) patch.name = safe.name.trim();
    this.setData(patch);
    this.recalculateLabel();
    this._dirty = true;
    return true;
  },
  toggleTag(event) {
    if (this.data.saving || this.data.busy) return;
    const tag = event.currentTarget.dataset.tag;
    let tags = this.data.tags.slice();
    if (tags.indexOf(tag) !== -1) tags = tags.filter((item) => item !== tag);
    else {
      const groups = [['早餐', '午餐', '晚餐', '加餐'], ['刚刚好', '还想吃', '有点撑']];
      groups.forEach((group) => { if (group.indexOf(tag) !== -1) tags = tags.filter((item) => group.indexOf(item) === -1); });
      tags.push(tag);
    }
    this.markDraftChanged(); this._dirty = true;
    this.updateTags(tags);
  },
  async choosePhoto() {
    if (this.data.photoBusy || this.data.busy || this.data.saving || !this.canUseDraft()) return;
    this.setData({photoBusy: true, error: ''});
    let selected = false;
    try {
      const path = await media.choosePhoto();
      if (!this.canUseDraft()) { if (path) media.removePhoto(path).catch(() => {}); return; }
      if (!path) return;
      this._newPhotos.push(path); this.markDraftChanged(); this._dirty = true; selected = true;
      this.setData(Object.assign(this.clearRecognition(), {photoPath: path, labelPhotoPaths: this.data.recordType === 'packaged' ? [path] : []}));
    } catch (error) {
      if (!this._gone && !/cancel|取消/i.test(error.message || error.errMsg || '')) this.setData({error: error.message || '没有选好照片，请检查相机或相册权限。'});
    } finally { if (!this._gone) this.setData({photoBusy: false}); }
    if (selected && this.canUseDraft()) await this.analyze();
  },
  previewPhoto() {
    const urls = this.data.recordType === 'packaged' && this.data.labelPhotoPaths.length ? this.data.labelPhotoPaths : [this.data.photoPath].filter(Boolean);
    if (urls.length) wx.previewImage({urls, current: this.data.photoPath || urls[0]});
  },
  removePhoto() {
    if (this.data.busy || this.data.saving || this.data.photoBusy || !this.canUseDraft()) return;
    this.markDraftChanged(); this._dirty = true;
    this.setData(Object.assign(this.clearRecognition(), {photoPath: '', labelPhotoPaths: []}));
  },
  async analyze() {
    if (this.data.busy || this.data.saving || this.data.photoBusy || !this.canUseDraft()) return;
    if (!this.data.name.trim() && !this.data.note.trim() && !this.data.photoPath) return;
    const context = {
      id: ++this._analysisId,
      version: this._draftVersion || 0,
      namespace: this._namespace,
      recordType: this.data.recordType,
      name: this.data.name.trim(),
      note: this.data.note.trim(),
      photoPath: this.data.photoPath,
      labelPhotoPaths: this.data.labelPhotoPaths.slice(),
      labelForm: JSON.parse(JSON.stringify(this.data.labelForm))
    };
    this._activeAnalysis = context;
    this._savedDuringAnalysis = null;
    this.setData({busy: true, error: '', aiError: '', recognitionStatus: '', labelError: ''});
    const work = (async () => {
      try {
        if (context.recordType === 'packaged') await this.analyzeFoodLabel(context);
        else {
          const result = await api.request('analyzeMeal', {name: context.name, text: [context.name, context.note].filter(Boolean).join('；'), note: context.note, photoPath: context.photoPath});
          if (!this.analysisIsCurrent(context)) return;
          const safe = result && typeof result === 'object' ? result : {};
          const min = asNumber(safe.kcalMin), max = asNumber(safe.kcalMax);
          const ranged = min !== null && max !== null && max >= min;
          const currentValues = {};
          NUMBERS.forEach(key => { currentValues[key] = asNumber(key === 'kcal' ? ranged ? Math.round((min + max) / 2) : safe.kcal : safe[key]); });
          const estimate = {name: typeof safe.name === 'string' ? safe.name.trim() : ''};
          if (this._savedDuringAnalysis && this._savedDuringAnalysis.analysisId === context.id) {
            this.persistLateMealEstimate(context, currentValues, estimate);
          } else if (!this._gone) {
            const patch = {nutritionSource: 'ai-estimate', updated: true, aiNeedsRefresh: false, aiError: '', recognitionStatus: '', aiBody: safe.body || safe.note || '', estimateRange: ranged ? min + '–' + max : ''};
            if (estimate.name) patch.name = estimate.name;
            NUMBERS.forEach(key => { patch[key] = numericText(currentValues[key]); });
            this.setData(patch);
            this._dirty = true;
          }
        }
      } catch (error) {
        if (context.id === this._analysisId && context.version === this._draftVersion && store.getNamespace() === context.namespace && !this._gone) this.setData({aiError: error.message || '这次没有识别成功，可以直接填写并保存。', recognitionStatus: ''});
      } finally {
        if (this._activeAnalysis && this._activeAnalysis.id === context.id) {
          this._activeAnalysis = null;
          if (!this._gone) this.setData({busy: false});
        }
      }
    })();
    let timeoutId;
    const timeout = new Promise(resolve => { timeoutId = setTimeout(() => resolve('timeout'), ANALYSIS_TIMEOUT_MS); });
    const outcome = await Promise.race([work.then(() => 'complete'), timeout]);
    if (timeoutId !== undefined) clearTimeout(timeoutId);
    if (outcome === 'timeout' && this.analysisIsCurrent(context) && !this._gone && this.data.busy) {
      this.setData({busy: false, recognitionStatus: '还在整理；当前照片和填写内容可以先保存。'});
    }
    return outcome;
  },
  async save() {
    if (this._savePending || this._confirmPending || this.data.saving || this.data.photoBusy || this.data.missing || !this.canUseDraft()) return;
    this.setData({ error: '' });
    const name = this.data.name.trim() || (this.data.photoPath ? this.data.recordType === 'packaged' ? '包装食品' : '照片餐食' : '');
    if (!name) { this.setData({ error: '请给这一餐写个名字，方便以后找到。' }); return; }
    const patch = { date: this.data.date, time: this.data.time, name, note: this.data.note.trim(), photoPath: this.data.photoPath, tags: this.data.tags, nutritionSource: this.data.nutritionSource, confirmed: true,
      foodLabel: this.data.recordType === 'packaged' ? this.data.foodLabel : null, labelPhotoPaths: this.data.recordType === 'packaged' ? this.data.labelPhotoPaths.slice() : [] };
    if (this.data.id) patch.id = this.data.id;
    for (const key of NUMBERS) {
      const value = this.data[key].trim();
      if (value !== '' && (!/^\d+(\.\d+)?$/.test(value) || asNumber(value) === null || Number(value) > (key === 'kcal' ? 30000 : 3000))) { this.setData({ error: '热量请填 0–30000，三大营养请填 0–3000 的数字；不确定时可以留空。' }); return; }
      patch[key] = value === '' ? null : Number(value);
    }
    if (this.data.labelError) { this.setData({error: this.data.labelError}); return; }
    this._savePending = true;
    this.setData({ saving: true });
    try {
      const saved = store.saveMeal(patch);
      if (this._activeAnalysis && this._activeAnalysis.version === (this._draftVersion || 0)) {
        this._savedDuringAnalysis = {analysisId: this._activeAnalysis.id, version: this._activeAnalysis.version, record: saved, serialized: JSON.stringify(saved)};
      }
      const previousPhoto = this._persistedPhoto;
      this._persistedPhoto = saved.photoPath || '';
      const previousLabelPhotos = this._persistedLabelPhotos || [];
      this._persistedLabelPhotos = (saved.labelPhotoPaths || []).slice();
      previousLabelPhotos.forEach(path => { if (this._persistedLabelPhotos.indexOf(path) === -1) media.removePhoto(path).catch(() => {}); });
      if (previousPhoto && previousPhoto !== this._persistedPhoto) media.removePhoto(previousPhoto).catch(() => {});
      this._dirty = false;
      ui.toast('这一餐已经记下。');
      this.back();
    } catch (error) { this._savePending = false; this.setData({ error: error.message || '没有保存成功，填写的内容还在。', saving: false }); }
  },
  async deleteRecord() {
    if (!this.data.id || this._confirmPending || this._savePending || this.data.saving || this.data.busy || this.data.photoBusy || !this.canUseDraft()) return;
    this._confirmPending = true;
    const accepted = await ui.confirm('删除这条饮食记录？', '删除后无法恢复。已经保存的日记仍保留原文，你可以再去补充。');
    this._confirmPending = false;
    if (!accepted || !this.canUseDraft()) return;
    this.setData({ saving: true });
    try { store.deleteMeal(this.data.id); if (this._persistedPhoto) media.removePhoto(this._persistedPhoto).catch(() => {}); (this._persistedLabelPhotos || []).forEach(path => media.removePhoto(path).catch(() => {})); ui.toast('这条记录已删除。'); this.back(); }
    catch (error) { this.setData({ error: error.message || '删除没有完成，请重试。', saving: false }); }
  },
  async cancelEdit() {
    if (this._confirmPending || this._savePending || this.data.saving || this.data.busy || this.data.photoBusy) return;
    this._confirmPending = true;
    const accepted = !this._dirty || await ui.confirm('放下这次未保存的修改？', '已保存的饮食记录会保留，这次填写的内容不会保存。');
    this._confirmPending = false;
    if (accepted && !this._gone) this.back();
  },
  back() { wx.navigateBack({ delta: 1, fail: () => wx.switchTab({ url: '/pages/meals/index' }) }); }
});
