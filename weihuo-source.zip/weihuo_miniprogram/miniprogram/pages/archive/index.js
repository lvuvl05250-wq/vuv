const store=require('../../services/store');const ui=require('../../services/ui');const {buildCalendar,shift}=require('../../services/activity-calendar');
const labels={ankle:'脚踝',knee:'膝部',neck:'颈部',shoulder:'肩部',back:'腰背',wrist:'手腕',hip:'髋部',leg:'腿部',dizziness:'眩晕',headache:'头痛',pain:'疼痛',balance:'平衡不稳',recent_injury:'近期损伤',medical_restriction:'已有专业活动限制'};
Page({data:{date:'',calendar:null,anchor:'',weekdays:['一','二','三','四','五','六','日'],mode:'tickets',period:'月',periods:['周','月','年','全部'],tickets:[],reports:[],profile:{},boundaries:[],goals:['轻运动','自我照顾','饮食记录','规律作息'],goalOptions:[],measurements:[],error:''},
 onShow(){ui.setTab(this,3);this.reload();},
 reload(){try{const p=store.getProfile(),s=store.getState(),now=store.today(),calendar=buildCalendar(s,this.data.period,this.data.anchor||now,now);this.setData({date:ui.dateLabel(now),calendar,tickets:store.getTickets().filter(t=>t.date>=calendar.start&&t.date<=calendar.end&&t.date<=now),reports:store.getReports(),measurements:store.getMeasurements().slice(0,5),profile:p,boundaries:Object.keys(labels).map(id=>({id,label:labels[id],active:p.restrictions.includes(id)})),goalOptions:this.data.goals.map(label=>({label,active:p.goals.includes(label)})),error:''});}catch(e){this.setData({error:e.message});}},
 move(e){const delta=Number(e.currentTarget.dataset.delta);if(delta>0&&!this.data.calendar.canNext)return;this.setData({anchor:shift(this.data.anchor||store.today(),this.data.period,delta)});this.reload();},
 calendarDay(e){const date=e.currentTarget.dataset.date;if(!date||date>store.today())return;wx.navigateTo({url:'/pages/ticket/index?date='+date});},
 zoom(e){this.setData({period:e.currentTarget.dataset.mode,anchor:e.currentTarget.dataset.date});this.reload();},
 mode(e){this.setData({mode:e.currentTarget.dataset.value});},
 period(e){this.setData({period:e.currentTarget.dataset.value});this.reload();},
 ticket(e){wx.navigateTo({url:'/pages/ticket/index?date='+e.currentTarget.dataset.date});},
 report(e){wx.navigateTo({url:'/pages/report/index'+(e.currentTarget.dataset.id?'?id='+e.currentTarget.dataset.id:'' )});},periodCalendar(){wx.navigateTo({url:'/pages/period/index'});},plans(){wx.navigateTo({url:'/pages/plans/index'});},edit(){wx.navigateTo({url:'/pages/profile-edit/index'});},measurements(){wx.navigateTo({url:'/pages/measurements/index'});}});
