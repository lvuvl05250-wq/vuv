// The timestamp is persisted by the shared store; UI intervals only redraw it.
function elapsed(timer, now) {
  if (!timer) return 0;
  const saved = Math.max(0, Number(timer.elapsedSeconds) || 0);
  const delta = timer.running && timer.startedAt ? Math.max(0, (now - timer.startedAt) / 1000) : 0;
  return Math.min(timer.durationSeconds, saved + delta);
}
function display(seconds) {
  const whole = Math.max(0, Math.ceil(seconds));
  return String(Math.floor(whole / 60)).padStart(2, '0') + ':' + String(whole % 60).padStart(2, '0');
}
module.exports = {elapsed, display};
