const store = require('../../services/store');
const ui = require('../../services/ui');
const clock = require('./timer');
const actionVideo = require('../../services/action-video');
const {getCompanionPresentation} = require('../../services/companion');

Page({
  data: {action: null, missing: false, companionImage: '/assets/xiaowei-checkin-v2.png', companionName: '小微', isRecord: false, clockText: '00:00', timer: null, hasTimer: false,
    remaining: 0, saving: false, blocked: '', selectedMode: 'full', statusLabel: '', feedback: '',
    hasVideo: false, videoBusy: false, videoError: '', videoHint: '', videoMethod: '', videoIntensity: '', videoPlatform: '',
    hasAudio: false, audioPlaying: false, audioLoading: false, audioError: '', audioPosition: '00:00', audioDuration: '', showTranscript: false, feedbackLabels: [
      {value: 'comfortable', label: '更舒服'}, {value: 'neutral', label: '差不多'}, {value: 'uncomfortable', label: '有些不适'}
    ]},
  onLoad(query) { this._id = query.id || ''; this._videoNamespace = store.getNamespace(); },
  onShow() { this.reload(); this.stopTick(); this._interval = setInterval(() => this.tick(), 500); },
  onHide() { this.stopTick(); this.pauseAudio(); },
  onUnload() { this.stopTick(); this._unloaded = true; this.destroyAudio(); },
  stopTick() { if (this._interval) clearInterval(this._interval); this._interval = null; },
  reload() {
    try {
      const record = store.getAction(this._id);
      const catalog = store.getCatalog();
      const action = record || catalog.find((a) => a.id === this._id);
      if (!action) return this.setData({missing: true, action: null});
      const original = catalog.find((a) => a.id === (record ? action.actionId : action.id));
      const resolved = Object.assign({}, original || {}, action);
      // Missing video in an old record means no video was saved at that time.
      // Never acquire a new library resource through the display-time merge.
      if (record) resolved.video = record.video || null;
      const videoTarget = resolved.video ? actionVideo.destination(resolved.video) : null;
      if(resolved.knowledge)resolved.knowledgeCard=resolved.knowledge;
      const hasAudio = !!(resolved.audio && typeof resolved.audio.url === 'string' && resolved.audio.url.trim());
      const profile = store.getProfile();
      let blocked = '';
      if ((resolved.avoidWhen || []).some((t) => (profile.restrictions || []).indexOf(t) !== -1)) blocked = '这件行动与已确认的活动限制不一致，今天先换一件小事。';
      else if (resolved.kind === 'movement' && profile.specialCondition) blocked = '你记录了不适合一般运动的特殊情况，先选择生活照顾类行动。';
      else if (store.isActionEligible && !store.isActionEligible(resolved)) blocked = '这件行动与你填写的偏好或近期身体反馈不一致，今天先换一件小事。';
      const date = store.today();
      const day = store.getDay(date);
      const companion = getCompanionPresentation({
        companionKey: store.getSettings().companion,
        date,
        actions: day.actions,
        meals: store.getMeals(date).filter(meal => meal.confirmed === true),
        note: day.note
      });
      this.setData({action: resolved, missing: false, isRecord: !!record, timer: record && record.timer || null,
        companionImage: companion.image, companionName: companion.name,
        hasTimer: !!(record && record.timer), blocked, feedback: action.feedback || '',
        statusLabel: action.status === 'completed' ? '已完成' : action.status === 'skipped' ? '今天先放下' : '可以随时停下',
        hasAudio, audioDuration: hasAudio && resolved.audio.durationSeconds ? clock.display(resolved.audio.durationSeconds) : '',
        hasVideo: !!videoTarget, videoMethod: videoTarget ? videoTarget.method : '', videoIntensity: videoTarget ? videoTarget.intensityLabel : '', videoPlatform: videoTarget ? videoTarget.platformLabel : '',
        selectedMode: record && record.timer ? record.timer.mode : this.data.selectedMode});
      this.tick();
    } catch (error) { ui.error(error); }
  },
  tick() {
    const action = this.data.action;
    if (!action || this._unloaded) return;
    const timer = this.data.timer;
    const duration = timer ? timer.durationSeconds : this.data.selectedMode === 'minimum' ? Math.min(60, action.durationMinutes * 60) : action.durationMinutes * 60;
    const remaining = timer ? Math.max(0, timer.durationSeconds - clock.elapsed(timer, Date.now())) : duration;
    this.setData({clockText: clock.display(remaining), remaining});
    if (timer && timer.running && remaining <= 0 && !this._ending) {
      this._ending = true;
      try {
        const paused = Object.assign({}, timer, {running: false, startedAt: 0, elapsedSeconds: timer.durationSeconds});
        store.saveActionTimer(this._id, paused);
        this.setData({timer: paused});
        this.pauseAudio();
        ui.toast('时间到了，感受一下自己现在的状态');
      } catch (error) { this.stopTick(); ui.error(error); }
      finally { this._ending = false; }
    }
  },
  ensureRecord() {
    const record = store.getAction(this._id);
    if (record) return record;
    const added = store.addAction(this._id);
    this._id = added.id;
    this.setData({isRecord: true});
    return added;
  },
  addToToday() {
    if (this.data.saving) return;
    this.setData({saving: true});
    try { this.ensureRecord(); this.reload(); ui.toast('已添进今天'); }
    catch (error) { ui.error(error); }
    finally { this.setData({saving: false}); }
  },
  chooseMode(e) { if (!this.data.hasTimer) { this.setData({selectedMode: e.currentTarget.dataset.mode}); this.tick(); } },
  start() {
    if (this.data.saving || this.data.blocked) return;
    this.setData({saving: true});
    try {
      const record = this.ensureRecord();
      if (record.status !== 'planned') store.setActionStatus(record.id, 'planned');
      const existing = this.data.timer;
      const durationSeconds = this.data.selectedMode === 'minimum' ? Math.min(60, this.data.action.durationMinutes * 60) : this.data.action.durationMinutes * 60;
      const timer = existing && clock.elapsed(existing, Date.now()) < existing.durationSeconds
        ? Object.assign({}, existing, {running: true, startedAt: Date.now()})
        : {running: true, startedAt: Date.now(), elapsedSeconds: 0, durationSeconds, mode: this.data.selectedMode};
      store.saveActionTimer(record.id, timer);
      this.reload();
    } catch (error) { ui.error(error); }
    finally { this.setData({saving: false}); }
  },
  pause() {
    this.pauseAudio();
    if (!this.data.timer || this.data.saving) return;
    try {
      store.saveActionTimer(this._id, Object.assign({}, this.data.timer, {
        running: false, elapsedSeconds: clock.elapsed(this.data.timer, Date.now()), startedAt: 0
      }));
      this.reload();
    } catch (error) { ui.error(error); }
  },
  async resetTimer() {
    if (!this.data.timer || !await ui.confirm('重新计时？', '当前计时会清零，行动记录仍保留。')) return;
    try {
      store.saveActionTimer(this._id, {running: false, startedAt: 0, elapsedSeconds: 0,
        durationSeconds: this.data.timer.durationSeconds, mode: this.data.timer.mode});
      this.reload();
    } catch (error) { ui.error(error); }
  },
  complete() {
    if (this.data.saving || this.data.blocked) return;
    this.setData({saving: true});
    try { const record = this.ensureRecord(); store.setActionStatus(record.id, 'completed'); this.pauseAudio(); this.reload(); ui.toast('收好这一小步'); }
    catch (error) { ui.error(error); }
    finally { this.setData({saving: false}); }
  },
  async skip() {
    if (this.data.saving || !await ui.confirm('今天先放下？', '会记为跳过。愿意的时候，也可以再放回今天。')) return;
    this.setData({saving: true});
    try { const record = this.ensureRecord(); store.setActionStatus(record.id, 'skipped'); this.pauseAudio(); this.reload(); }
    catch (error) { ui.error(error); }
    finally { this.setData({saving: false}); }
  },
  restore() {
    try { store.setActionStatus(this._id, 'planned'); this.reload(); }
    catch (error) { ui.error(error); }
  },
  async stopForDiscomfort() {
    this.pause();
    if (!await ui.confirm('先停下来，照顾自己', '确认记录「有些不适」并停止这件行动？这个感受会保留在行动记录中。')) return;
    try { const record = this.ensureRecord(); store.setActionStatus(record.id, 'skipped', 'uncomfortable'); this.reload(); }
    catch (error) { ui.error(error); }
  },
  giveFeedback(e) {
    if (this.data.saving || !this.data.isRecord) return;
    try {
      const current = store.getAction(this._id);
      if (!current) throw new Error('这条行动记录已经不存在');
      store.setActionStatus(this._id, current.status, e.currentTarget.dataset.value);
      this.reload(); ui.toast('身体感受已记下');
    } catch (error) { ui.error(error); }
  },
  videoForInteraction() {
    if (this._unloaded) return null;
    if (store.getNamespace() !== this._videoNamespace) throw new Error('账号已变化，请返回行动清单后重新打开。');
    const record = store.getAction(this._id);
    const action = record || store.getCatalog().find(item => item.id === this._id);
    if (!action || !action.video) throw new Error('这件行动没有可用的视频资源，请返回行动清单。');
    const eligibility = Object.assign({}, action, {id: record ? action.actionId || action.id : action.id});
    if (!store.isActionEligible(eligibility)) {
      this.setData({blocked: '这件行动与你填写的活动限制、偏好或近期不适反馈不一致，今天先换一件小事。'});
      throw new Error('这件行动当前不适合开始，请先选择其他行动。');
    }
    return actionVideo.validateVideo(action.video);
  },
  async openVideo() { return this.useVideo(false); },
  async copyVideoLink() { return this.useVideo(true); },
  async useVideo(copyOnly) {
    if (this.data.videoBusy || this.data.saving || this._unloaded) return;
    this.setData({videoBusy: true, videoError: '', videoHint: ''});
    try {
      const video = this.videoForInteraction();
      if (!video) return;
      this.pauseAudio();
      const result = await (copyOnly ? actionVideo.copyVideo(video, wx) : actionVideo.openVideo(video, wx));
      if (this._unloaded || store.getNamespace() !== this._videoNamespace) return;
      this.setData({videoHint: result.message});
      // Opening/copying is not evidence of watching or completing an action.
    } catch (error) {
      if (!this._unloaded && !error.cancelled) this.setData({videoError: error.message || '视频暂时无法打开，请稍后重试。'});
    } finally { if (!this._unloaded) this.setData({videoBusy: false}); }
  },
  playAudio() {
    if (!this.data.hasAudio || this.data.audioLoading || this.data.blocked) return;
    if (this.data.audioPlaying) return this.pauseAudio();
    try {
      const source = this.data.action.audio.url;
      if (!this._audio || this._audioSource !== source) {
        this.destroyAudio();
        const player = wx.createInnerAudioContext();
        this._audio = player; this._audioSource = source;
        const active = () => !this._unloaded && this._audio === player;
        player.onPlay(() => { if (active()) this.setData({audioPlaying: true, audioLoading: false, audioError: ''}); });
        player.onPause(() => { if (active()) this.setData({audioPlaying: false, audioLoading: false}); });
        player.onStop(() => { if (active()) this.setData({audioPlaying: false, audioLoading: false, audioPosition: '00:00'}); });
        player.onEnded(() => { if (active()) this.setData({audioPlaying: false, audioLoading: false}); });
        player.onError(() => { if (active()) this.setData({audioPlaying: false, audioLoading: false, audioError: '这段音频暂时无法播放，请稍后重试。文字引导仍可阅读。'}); });
        player.onTimeUpdate(() => { if (active()) this.setData({audioPosition: clock.display(Math.floor(player.currentTime || 0)), audioDuration: player.duration ? clock.display(player.duration) : this.data.audioDuration}); });
        player.src = source;
      }
      this.setData({audioLoading: true, audioError: ''});
      this._audio.play();
    } catch (error) { this.setData({audioLoading: false, audioPlaying: false, audioError: '暂时无法播放这段音频，请稍后重试。'}); }
  },
  pauseAudio() { if (this._audio) { try { this._audio.pause(); } catch (error) { this.setData({audioPlaying: false, audioLoading: false}); } } },
  destroyAudio() {
    const player = this._audio; this._audio = null; this._audioSource = '';
    if (player) { try { player.destroy(); } catch (error) {} }
  },
  toggleTranscript() { this.setData({showTranscript: !this.data.showTranscript}); },
  copyReference() {
    const card = this.data.action && this.data.action.knowledgeCard;
    if (!card || !/^https?:\/\//.test(card.sourceUrl || '')) return;
    wx.setClipboardData({data: card.sourceUrl, success: () => ui.toast('参考链接已复制'), fail: () => ui.error(new Error('链接未复制，请重试'))});
  },
  openProfile() { wx.switchTab({url: '/pages/profile/index'}); },
  backToActions() { wx.switchTab({url: '/pages/actions/index'}); }
});
