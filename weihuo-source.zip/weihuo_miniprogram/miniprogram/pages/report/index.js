const store = require('../../services/store');
const api = require('../../services/api');
const media = require('../../services/media');
const ui = require('../../services/ui');

const RESTRICTION_LABELS = {
  ankle: '脚踝不适，避开相关活动', knee: '膝部不适，避开相关活动',
  neck: '颈部不适，避开相关活动', shoulder: '肩部不适，避开相关活动',
  back: '腰背不适，避开相关活动', wrist: '手腕不适，避开相关活动',
  hip: '髋部不适，避开相关活动', leg: '腿部不适，避开相关活动',
  dizziness: '有眩晕，减少相关活动', headache: '有头痛，减少相关活动',
  pain: '有疼痛，暂缓相关活动', balance: '站立不稳，避开平衡活动',
  recent_injury: '近期有损伤', medical_restriction: '已有专业人员告知的活动限制'
};
function text(value) { return typeof value === 'string' ? value : typeof value === 'number' && Number.isFinite(value) ? String(value) : ''; }
function resultBody(result) {
  if (typeof result === 'string') return result.trim().slice(0, 8000);
  return ['body', 'text', 'content', 'note'].map(key => text(result && result[key]).trim()).find(Boolean) || '';
}
function cleanMetric(metric) {
  return { _key: metric._key || store.uid('metric'), name: text(metric.name).slice(0, 100), value: text(metric.value).slice(0, 100), unit: text(metric.unit).slice(0, 50), reference: text(metric.reference).slice(0, 150) };
}

Page({
  data: {
    id: '', title: '', date: '', today: '', note: '', photoPath: '', metrics: [],
    restrictions: [], restrictionOptions: [], confirmed: false, dirty: false,
    busy: false, saving: false, photoBusy: false, applying: false,
    candidate: false, ocrNote: '', ocrError: '', error: '', savedMessage: '', missing: false
  },
  onLoad(options) {
    this._newPhotos = [];
    this._namespace = store.getNamespace();
    this.setData({ id: options.id || '', date: store.today(), today: store.today() });
  },
  onShow() {
    try {
      this.setData({ today: store.today() });
      if (this.data.id && !this.data.dirty) {
        const report = store.getReports().find((item) => item.id === this.data.id);
        if (!report) { this.setData({ missing: true, error: '这份资料已不存在，请回到个人档案。' }); return; }
        this._persistedPhoto = report.photoPath || '';
        this.setData(Object.assign({}, report, { metrics: (report.metrics || []).map(cleanMetric), missing: false }));
      }
      this.updateRestrictions(this.data.restrictions);
    } catch (error) { this.setData({ error: error.message || '资料暂时没有读取成功。' }); }
  },
  onUnload() {
    this._gone = true;
    (this._newPhotos || []).forEach((path) => { if (path !== this._persistedPhoto) media.removePhoto(path).catch(() => {}); });
  },
  isLocked() { return this.data.busy || this.data.saving || this.data.applying; },
  canUseDraft() {
    if (this._gone) return false;
    if (store.getNamespace() === this._namespace) return true;
    this.setData({ error: '账号已变化，请返回个人档案后重新打开。' });
    return false;
  },
  markDirty(patch) { this.setData(Object.assign({ dirty: true, savedMessage: '', error: '' }, patch)); },
  onField(event) {
    if (this.isLocked()) return;
    const field = event.currentTarget.dataset.field;
    if (['title', 'date', 'note'].indexOf(field) === -1) return;
    const patch = {}; patch[field] = event.detail.value;
    this.markDirty(patch);
  },
  addMetric() {
    if (this.isLocked()) return;
    if (this.data.metrics.length >= 80) { ui.toast('一份资料最多记录 80 项，请分开存档。'); return; }
    this.markDirty({ metrics: this.data.metrics.concat([cleanMetric({})]) });
  },
  editMetric(event) {
    if (this.isLocked()) return;
    const index = Number(event.currentTarget.dataset.index);
    const field = event.currentTarget.dataset.field;
    if (['name', 'value', 'unit', 'reference'].indexOf(field) === -1 || !this.data.metrics[index]) return;
    const metrics = this.data.metrics.map((metric) => Object.assign({}, metric));
    metrics[index][field] = event.detail.value;
    this.markDirty({ metrics });
  },
  removeMetric(event) {
    if (this.isLocked()) return;
    const index = Number(event.currentTarget.dataset.index);
    this.markDirty({ metrics: this.data.metrics.filter((_, itemIndex) => itemIndex !== index) });
  },
  async choosePhoto() {
    if (this.isLocked() || this.data.photoBusy) return;
    this.setData({ photoBusy: true, error: '' });
    try {
      const path = await media.choosePhoto();
      if (this._gone) { if (path) media.removePhoto(path).catch(() => {}); return; }
      if (!path) return;
      this._newPhotos.push(path);
      this.markDirty({ photoPath: path, ocrError: '' });
    } catch (error) {
      if (!this._gone && !/cancel|取消/i.test(error.message || error.errMsg || '')) this.setData({ error: error.message || '照片没有保存成功，请检查相机或相册权限。' });
    } finally { if (!this._gone) this.setData({ photoBusy: false }); }
  },
  previewPhoto() { if (this.data.photoPath) wx.previewImage({ current: this.data.photoPath, urls: [this.data.photoPath] }); },
  removePhoto() { if (!this.isLocked()) this.markDirty({ photoPath: '' }); },
  async extract() {
    if (this.isLocked() || this.data.photoBusy || !this.canUseDraft()) return;
    if (!this.data.photoPath) { ui.toast('先添加一张清晰的报告照片。'); return; }
    if (this.data.metrics.some((metric) => metric.name.trim() || metric.value.trim())) {
      if (!await ui.confirm('重新提取指标？', '新候选会接在已有指标后面，已填写的内容会保留。核对并保存前不会改变已存档的资料。')) return;
      if (this._gone) return;
    }
    this.setData({ busy: true, error: '', ocrError: '', savedMessage: '' });
    try {
      const result = await api.request('extractReport', { photoPath: this.data.photoPath, title: this.data.title, date: this.data.date });
      if (!this.canUseDraft()) return;
      const body = resultBody(result);
      const rows = result && Array.isArray(result.metrics) ? result.metrics : [];
      const metrics = rows.filter(metric => metric && typeof metric === 'object' && !Array.isArray(metric)).map(cleanMetric).filter(metric => metric.name.trim() || metric.value.trim());
      if (!metrics.length) {
        this.setData({ocrNote: [body, '暂未提取到可填入的指标；已填写内容保留，可以继续手动核对。'].filter(Boolean).join('\n\n')});
        return;
      }
      const signature = metric => JSON.stringify([metric.name, metric.value, metric.unit, metric.reference]);
      const seen = new Set(this.data.metrics.map(signature));
      const added = metrics.filter(metric => { const key = signature(metric); if (seen.has(key)) return false; seen.add(key); return true; });
      const room = Math.max(0, 80 - this.data.metrics.length), accepted = added.slice(0, room);
      const notes = [body];
      if (metrics.some(metric => !metric.name || !metric.value)) notes.push('部分指标信息不完整，请补齐后再确认；空白没有按 0 记录。');
      if (added.length > room) notes.push('当前最多编辑 80 项，超出的候选未填入。已有内容全部保留，请分开存档。');
      if (accepted.length) this.markDirty({metrics: this.data.metrics.concat(accepted), candidate: true, ocrNote: notes.filter(Boolean).join('\n\n')});
      else this.setData({ocrNote: notes.filter(Boolean).join('\n\n') || '识别内容已在当前指标中，原记录保留。'});
    } catch (error) { if (!this._gone) this.setData({ ocrError: error.message || '识别暂时不可用，照片仍在，可以手动填写或存为草稿。' }); }
    finally { if (!this._gone) this.setData({ busy: false }); }
  },
  updateRestrictions(selected) {
    const keys = [];
    store.getCatalog().forEach((action) => { (action.avoidWhen || []).forEach((key) => { if (keys.indexOf(key) === -1) keys.push(key); }); });
    this.setData({ restrictions: selected.slice(), restrictionOptions: keys.filter((key) => RESTRICTION_LABELS[key]).map((key) => ({ key, label: RESTRICTION_LABELS[key], selected: selected.indexOf(key) !== -1 })) });
  },
  toggleRestriction(event) {
    if (this.isLocked()) return;
    const key = event.currentTarget.dataset.key;
    const selected = this.data.restrictions.slice();
    const index = selected.indexOf(key);
    if (index === -1) selected.push(key); else selected.splice(index, 1);
    this.markDirty({});
    try { this.updateRestrictions(selected); } catch (error) { ui.error(error); }
  },
  async save(event) {
    if (this._savePending || this._confirmPending || this.isLocked() || this.data.photoBusy || this.data.missing || !this.canUseDraft()) return;
    const confirmed = event.currentTarget.dataset.confirmed === true || event.currentTarget.dataset.confirmed === 'true';
    const title = this.data.title.trim();
    if (!title) { this.setData({ error: '给这份资料写个标题，方便以后查找。' }); return; }
    const metrics = this.data.metrics.map((metric) => ({ name: metric.name.trim(), value: metric.value.trim(), unit: metric.unit.trim(), reference: metric.reference.trim() })).filter((metric) => metric.name || metric.value || metric.unit || metric.reference);
    if (!this.data.photoPath && !metrics.length && !this.data.note.trim()) { this.setData({ error: '添加照片、指标或备注后，再保存这份资料。' }); return; }
    if (confirmed && metrics.some((metric) => !metric.name || !metric.value)) { this.setData({ error: '请补齐每项指标的名称和原文数值，或删掉不需要的空行；也可以先存草稿。' }); return; }
    this._savePending = true;
    if (confirmed) {
      const accepted = await ui.confirm('确认存入个人档案', '请确认指标名称、数值和单位已与原件核对。这里仅记录资料，不判断数值是否正常。');
      if (!accepted || !this.canUseDraft()) { this._savePending = false; return; }
    }
    this.setData({ saving: true, error: '' });
    const report = { title, date: this.data.date, photoPath: this.data.photoPath, metrics, restrictions: this.data.restrictions.slice(), note: this.data.note.trim(), confirmed };
    if (this.data.id) report.id = this.data.id;
    try {
      const saved = store.saveReport(report);
      const previousPhoto = this._persistedPhoto;
      this._persistedPhoto = saved.photoPath || '';
      if (previousPhoto && previousPhoto !== this._persistedPhoto) media.removePhoto(previousPhoto).catch(() => {});
      this.setData({ id: saved.id, confirmed: saved.confirmed, candidate: false, dirty: false, metrics: saved.metrics.map(cleanMetric), saving: false, savedMessage: confirmed ? '已核对的资料已存入个人档案。' : '草稿已保存，尚未作为已确认资料。' });
      ui.toast(confirmed ? '资料已确认入档。' : '草稿已保存。');
    } catch (error) { this.setData({ error: error.message || '资料没有保存成功，填写内容还在。', saving: false }); }
    finally { this._savePending = false; }
  },
  async applyRestrictions() {
    if (this.isLocked() || this._confirmPending || !this.data.restrictions.length || !this.canUseDraft()) return;
    if (!this.data.confirmed || this.data.dirty) { ui.toast('先核对并保存这份资料，再应用活动限制。'); return; }
    const labels = this.data.restrictionOptions.filter((option) => option.selected).map((option) => option.label);
    this._confirmPending = true;
    const accepted = await ui.confirm('把所选限制用于行动推荐？', labels.join('；') + '。这些是你自己确认的限制，原有活动限制会保留。');
    this._confirmPending = false;
    if (!accepted || !this.canUseDraft()) return;
    this.setData({ applying: true, error: '' });
    try {
      const profile = store.getProfile();
      const restrictions = (profile.restrictions || []).slice();
      this.data.restrictions.forEach((key) => { if (restrictions.indexOf(key) === -1) restrictions.push(key); });
      store.saveProfile({ restrictions });
      this.setData({ savedMessage: '你确认的活动限制已记入个人信息，并用于筛选行动。', applying: false });
      ui.toast('活动限制已更新。');
    } catch (error) { this.setData({ applying: false, error: error.message || '活动限制没有更新成功，请重试。' }); }
  },
  async registerMeasurements() {
    if (this.isLocked() || this._registerPending || this._confirmPending || !this.canUseDraft()) return;
    if (!this.data.id || !this.data.confirmed || this.data.dirty) { ui.toast('先核对并保存资料，再登记指标。'); return; }
    if (!this.data.metrics.length) { ui.toast('这份资料还没有可登记的指标。'); return; }
    this._registerPending = true;
    try {
      const accepted = await ui.confirm('登记到个人档案？', '把已核对的 ' + this.data.metrics.length + ' 项原文数值登记到测量记录，保留报告来源与日期。已有相同登记不会重复添加。');
      if (!accepted || !this.canUseDraft()) return;
      this.setData({ applying: true, error: '' });
      const before = store.getMeasurements().filter((item) => item.reportId === this.data.id).length;
      store.importReportMeasurements(this.data.id);
      const after = store.getMeasurements().filter((item) => item.reportId === this.data.id).length;
      const added = Math.max(0, after - before);
      this.setData({ savedMessage: added ? '已登记 ' + added + ' 项指标到个人档案，可以在测量记录中继续查看和修改。' : '这份报告的指标已经登记，没有重复添加。', applying: false });
      ui.toast(added ? '指标已登记到个人档案。' : '已经登记，无需重复添加。');
    } catch (error) { this.setData({ applying: false, error: error.message || '登记没有完成，请重试。' }); }
    finally { this._registerPending = false; }
  },
  viewMeasurements() { wx.navigateTo({ url: '/pages/measurements/index' }); },
  async deleteReport() {
    if (!this.data.id || this._confirmPending || this._savePending || this.isLocked() || this.data.photoBusy || !this.canUseDraft()) return;
    this._confirmPending = true;
    const accepted = await ui.confirm('删除这份资料？', '原资料删除后无法恢复。已登记的测量记录和已采用的活动限制会保留，可在个人档案中分别修改或删除。');
    this._confirmPending = false;
    if (!accepted || !this.canUseDraft()) return;
    this.setData({ saving: true });
    try { store.deleteReport(this.data.id); if (this._persistedPhoto) media.removePhoto(this._persistedPhoto).catch(() => {}); ui.toast('资料已删除。'); this.back(); }
    catch (error) { this.setData({ saving: false, error: error.message || '资料没有删除成功，请重试。' }); }
  },
  async cancelEdit() {
    if (this._confirmPending || this._savePending || this.isLocked() || this.data.photoBusy) return;
    this._confirmPending = true;
    const accepted = !this.data.dirty || await ui.confirm('放下这次未保存的修改？', '已保存的资料会保留，这次填写和识别的候选不会保存。');
    this._confirmPending = false;
    if (accepted && !this._gone) this.back();
  },
  back() { wx.navigateBack({ delta: 1, fail: () => wx.switchTab({ url: '/pages/archive/index' }) }); }
});
