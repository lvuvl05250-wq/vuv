const store = require('../../services/store');
const ui = require('../../services/ui');
const calendar = require('../../services/calendar-reminder');

const typeLabels = {life: '生活安排', strength: '力量活动', aerobic: '有氧活动'};
Page({
  data: {plans: [], expandedId: '', today: '', reminderBusyKey: ''},
  onShow() { this.reload(); },
  onUnload() { this._gone = true; },
  reminderKey(id, date) { return (this._namespace || store.getNamespace()) + ':' + id + ':' + date; },
  reload() {
    try {
      const namespace = store.getNamespace();
      if (namespace !== this._namespace) { this._namespace = namespace; this._reminderTimes = {}; this._reminderErrors = {}; }
      const plans = store.getPlans().map((plan) => {
        const doneCount = plan.days.filter((d) => d.done).length;
        const days = plan.days.map(day => {
          const key = this.reminderKey(plan.id, day.date), added = calendar.lastAdded(key);
          return Object.assign({}, day, {reminderKey: key, reminderEligible: calendar.canRemindOnDate(day.date),
            reminderTime: this._reminderTimes && this._reminderTimes[key] || '', reminderError: this._reminderErrors && this._reminderErrors[key] || '',
            reminderAddedTime: added ? added.time : ''});
        });
        return Object.assign({}, plan, {days, doneCount, typeLabel: typeLabels[plan.type] || '生活安排',
          dayCount: plan.days.length, percent: plan.days.length ? Math.round(doneCount / plan.days.length * 100) : 0,
          dateRange: plan.days.length ? plan.days[0].date + ' — ' + plan.days[plan.days.length - 1].date : ''});
      });
      this.setData({plans, today: calendar.localDate()});
    } catch (error) { ui.error(error); }
  },
  addPlan() { wx.navigateTo({url: '/pages/plan-edit/index'}); },
  editPlan(e) { wx.navigateTo({url: '/pages/plan-edit/index?id=' + encodeURIComponent(e.currentTarget.dataset.id)}); },
  toggleExpand(e) { this.setData({expandedId: this.data.expandedId === e.currentTarget.dataset.id ? '' : e.currentTarget.dataset.id}); },
  reminderTime(e) {
    if (this.data.reminderBusyKey) return;
    const key = this.reminderKey(e.currentTarget.dataset.id, e.currentTarget.dataset.date);
    if (!this._reminderTimes) this._reminderTimes = {};
    if (!this._reminderErrors) this._reminderErrors = {};
    this._reminderTimes[key] = e.detail.value; this._reminderErrors[key] = ''; this.reload();
  },
  async addReminder(e) {
    if (this.data.reminderBusyKey) return;
    const namespace = this._namespace || store.getNamespace();
    const id = e.currentTarget.dataset.id, date = e.currentTarget.dataset.date, key = this.reminderKey(id, date);
    if (!this._reminderErrors) this._reminderErrors = {};
    this.setData({reminderBusyKey: key}); this._reminderErrors[key] = ''; this.reload();
    try {
      const readInput = () => {
        if (this._gone || store.getNamespace() !== namespace) throw new Error('账号或页面已变化，请重新打开计划后添加');
        const plan = store.getPlans().find(item => item.id === id);
        const day = plan && plan.days.find(item => item.date === date);
        if (!day) throw new Error('这一天的计划已变化，请重新选择');
        return {key, date, title: day.title, durationMinutes: day.minutes, time: this._reminderTimes && this._reminderTimes[key] || ''};
      };
      let input = readInput();
      const event = calendar.createCalendarEvent(input);
      const previous = calendar.lastAdded(key);
      if (previous && previous.signature !== JSON.stringify(event)) {
        if (!await ui.confirm('再添加一条日历提醒？', '之前添加的提醒不会自动更新。新提醒会另建一条，旧提醒请到手机日历修改或删除。')) return;
        input = readInput();
      }
      const result = await calendar.addReminder(input);
      if (this._gone || store.getNamespace() !== namespace) return;
      this._reminderErrors[key] = '';
      ui.toast(result.status === 'already-added' ? '这条提醒已添加，请到手机日历查看' : '已添加，请到手机日历查看');
    } catch (error) {
      if (!this._gone && store.getNamespace() === namespace) this._reminderErrors[key] = error.message || '提醒尚未添加，请重试';
    } finally {
      if (!this._gone) { this.setData({reminderBusyKey: ''}); this.reload(); }
    }
  },
  toggleDay(e) {
    try {
      const plan = store.getPlans().find((p) => p.id === e.currentTarget.dataset.id);
      if (!plan) throw new Error('这个计划已经不存在');
      const index = Number(e.currentTarget.dataset.index);
      if (!plan.days[index]) throw new Error('这一天的安排已经不存在，请重新打开计划');
      plan.days[index].done = !plan.days[index].done;
      store.savePlan(plan);
      this.reload();
      ui.toast(plan.days[index].done ? '这一小步已经记下' : '已取消完成标记');
    } catch (error) { ui.error(error); this.reload(); }
  },
  async deletePlan(e) {
    const id = e.currentTarget.dataset.id;
    const plan = store.getPlans().find((p) => p.id === id);
    if (!plan || !await ui.confirm('删除这个计划？', '「' + plan.title + '」及它的完成标记会一并删除。已经加入手机日历的事项需在手机日历另行删除。')) return;
    try { store.deletePlan(id); this.reload(); ui.toast('计划已删除'); }
    catch (error) { ui.error(error); }
  }
});
