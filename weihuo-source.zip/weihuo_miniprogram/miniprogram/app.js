const store=require('./services/store');
const config=require('./config');
App({
  globalData:{storageError:''},
  onShow(options){
    const api=require('./services/api');
    if((options||{}).path!=='pages/welcome/index'&&!api.isAuthenticated())wx.reLaunch({url:'/pages/welcome/index'});
    if(api.isAuthenticated())api.refreshCatalogInBackground();
  },
  onLaunch(){
    if(config.cloudEnv&&wx.cloud)wx.cloud.init({env:config.cloudEnv,traceUser:false});
    try{store.init();}catch(e){this.globalData.storageError=e.message;wx.showModal({title:'记录需要恢复',content:e.message,showCancel:false});}
  }
});
