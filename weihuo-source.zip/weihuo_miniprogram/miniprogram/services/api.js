const config=require('../config');
const store=require('./store');
const media=require('./media');
const ui=require('./ui');
const {connectionError}=require('./cloud-errors');
let connected=false,serviceError='',identity='',busy=false;
let catalogPending=null,catalogCheckedAt=0,catalogRetryAt=0,catalogError='';
const CATALOG_REFRESH_MS=5*60*1000;
function status(){return {configured:!!config.cloudEnv,connected,label:!config.cloudEnv?'云服务尚未配置':connected?'云服务已连接':'云服务待连接',error:serviceError,catalogError,catalogCheckedAt};}
async function call(task,payload,options){
  const trackStatus=!(options&&options.background);
  if(!config.cloudEnv)throw new Error('云端服务尚未连接。你可以继续手动记录；完成云环境授权和部署后，就能使用 AI 与文字识别。');
  if(!wx.cloud)throw new Error('请升级微信以使用云服务');
  try{const response=await wx.cloud.callFunction({name:config.cloudFunction,data:{task,payload:payload||{}}});const r=response.result;
    if(!r||typeof r.ok!=='boolean')throw new Error('云服务返回格式不正确，请检查部署版本');
    if(!r.ok){const e=new Error(r.error.message||'云端未完成请求');e.code=r.error.code;e.details=r.error.details;e.retryable=r.error.retryable;throw e;}
    if(trackStatus){connected=true;serviceError='';}return r.data;
  }catch(e){const publicError=e.code?e:connectionError(e);if(trackStatus){serviceError=publicError.message;if(!e.code)connected=false;}throw publicError;}
}
const FIELDS={generateDiary:['date','name','actions','meals','mood','note','companionKey','previous'],analyzeFoodLabel:['name','text'],summarizeProfile:['profile'],extractFoodPreferences:['profile'],parseState:['text'],explainActions:['text','day','actions','profile'],generateAction:['text','day','draft','profile'],analyzeMeal:['text','name','note','profile'],extractReport:['text'],generatePlan:['actions','type','goal','startDate','dayCount','minutes','constraints','preferences','context','profile'],generateTicketTitle:['date','actions','meals','mood'],mealDayReview:['date','meals','phase','profile']};
async function request(task,payload){
  const requestNamespace=store.getNamespace();
  if(!FIELDS[task])throw new Error('不支持的 AI 功能');
  if(!config.cloudEnv)return call(task,{});
  if(!store.getSettings().aiConsent){const yes=await ui.confirm('使用 AI 整理本次内容？','你主动提交的文字、照片和相关档案将发送到已配置的云端 AI 服务，用于本次识别或生成。结果需要你核对；可在设置随时关闭。');if(!yes)throw new Error('已取消 AI 处理，记录没有上传');if(store.getNamespace()!==requestNamespace)throw new Error('AI 处理已取消：账号发生变化');store.saveSettings({aiConsent:true});}
  const data={consent:true};payload=payload||{};FIELDS[task].forEach(k=>{if(payload[k]!==undefined)data[k]=payload[k];});
  if(task==='generatePlan'&&!data.actions)data.actions=store.getPlanningCandidates().map(a=>({id:a.id,title:a.title,durationMinutes:a.durationMinutes,kind:a.kind,category:a.category,steps:a.steps,avoidWhen:a.avoidWhen}));
  if(task==='mealDayReview'&&data.meals)data.meals=data.meals.map(m=>({date:m.date,confirmed:m.confirmed,name:m.name,note:m.note,kcal:m.kcal,protein:m.protein,carbs:m.carbs,fat:m.fat}));
  if(task==='generateTicketTitle'){data.actions=(data.actions||[]).map(a=>typeof a==='string'?a:a.title);data.meals=(data.meals||[]).map(m=>typeof m==='string'?m:m.name);}
  if(task==='analyzeFoodLabel'&&payload.photoPaths){
    if(!Array.isArray(payload.photoPaths)||payload.photoPaths.length>2||payload.photoPaths.some(p=>typeof p!=='string'||!p))throw new Error('标签照片最多两张');
    data.images=[];
    for(const path of payload.photoPaths){
      const compressed=await new Promise((resolve,reject)=>wx.compressImage({src:path,quality:65,compressedWidth:1024,success:r=>resolve(r.tempFilePath),fail:()=>reject(new Error('图片压缩失败，请重新选择照片'))}));
      const imageBase64=await media.readBase64(compressed),mimeType=imageBase64.indexOf('iVBORw0KGgo')===0?'image/png':imageBase64.indexOf('/9j/')===0?'image/jpeg':'';
      if(!mimeType)throw new Error('请使用 JPEG 或 PNG 图片');
      if(imageBase64.length>340000)throw new Error('标签照片较大，请裁剪到文字区域后重试');
      data.images.push({imageBase64,mimeType});
    }
  }else if(payload.photoPath){
    const compressed=await new Promise((resolve,reject)=>wx.compressImage({src:payload.photoPath,quality:65,compressedWidth:1280,success:r=>resolve(r.tempFilePath),fail:()=>reject(new Error('图片压缩失败，请重新选择照片'))}));
    data.imageBase64=await media.readBase64(compressed);data.mimeType=data.imageBase64.indexOf('iVBORw0KGgo')===0?'image/png':data.imageBase64.indexOf('/9j/')===0?'image/jpeg':'';if(!data.mimeType)throw new Error('请使用 JPEG 或 PNG 图片');
    if(data.imageBase64.length>680000)throw new Error('照片内容较大，请裁剪到需要识别的区域后重试');
  }
  if(store.getNamespace()!==requestNamespace||!store.getSettings().aiConsent)throw new Error('AI 处理已取消：账号或授权状态发生变化');
  return call(task,data);
}
function versionKey(account){return 'weihuo:cloudVersion:'+(account||identity);}
function accountScope(){const scope={identity,namespace:store.getNamespace()};assertAccountScope(scope);return scope;}
function assertAccountScope(scope){if(!scope.identity||scope.namespace!=='account:'+scope.identity||identity!==scope.identity||store.getNamespace()!==scope.namespace)throw new Error('账号状态已变化，请重新连接后核对云端状态');}
async function connect(){
  const auth=await call('auth',{});if(!auth.openid)throw new Error('没有取得微信账号身份');
  const current=store.getNamespace(),backup=store.exportData();
  store.switchAccount(auth.openid);identity=auth.openid;
  if(current==='local'&&store.isPristine()){
    const previous=JSON.parse(backup).state;
    if(previous.profile.onboarded||previous.profile.name||previous.profile.measurements.length||previous.customActions.length||(previous.periodRecords||[]).length||previous.meals.length||previous.reports.length||previous.plans.length||Object.keys(previous.days).length){
      const revision=store.getRevision(),ns=store.getNamespace();if(await ui.confirm('迁入本机记录？','将这台设备的本地记录复制到当前微信账号下。当前步骤不会上传云端。')){if(store.getRevision()!==revision||store.getNamespace()!==ns)throw new Error('本机记录发生变化，请重新连接');store.restoreData(backup);}
    }
  }
  refreshCatalogInBackground();
  return auth;
}
async function cloudConsent(){if(!identity||store.getNamespace()!=='account:'+identity)await connect();const scope=accountScope();if(!store.getSettings().cloudConsent){const allowed=await ui.confirm('允许云端保存个人记录？','文字档案、行动、饮食、经期记录、报告文字与日记会上传云端，供账号备份。原始照片留在本机。AI 处理另行授权。');assertAccountScope(scope);if(!allowed)throw new Error('已取消云备份');store.saveSettings({cloudConsent:true});}assertAccountScope(scope);return scope;}
function stripLocal(state){const copy=JSON.parse(JSON.stringify(state));copy.profile.avatarPath='';Object.keys(copy.days).forEach(d=>copy.days[d].actions.forEach(a=>delete a.timer));copy.meals.forEach(m=>{m.photoPath='';m.labelPhotoPaths=[];});copy.reports.forEach(r=>r.photoPath='');copy.tickets.forEach(t=>{t.meals.forEach(m=>{m.photoPath='';m.labelPhotoPaths=[];});t.actions.forEach(a=>delete a.timer);});return copy;}
async function syncPush(){if(busy)throw new Error('正在同步，请稍等');busy=true;try{const scope=await cloudConsent();assertAccountScope(scope);const result=await call('syncPush',{consent:true,baseVersion:wx.getStorageSync(versionKey(scope.identity))||0,state:stripLocal(store.getState())});assertAccountScope(scope);wx.setStorageSync(versionKey(scope.identity),result.version);return result;}finally{busy=false;}}
async function syncPull(){if(busy)throw new Error('正在同步，请稍等');busy=true;try{const scope=await cloudConsent();assertAccountScope(scope);const revision=store.getRevision();const result=await call('syncPull',{consent:true});assertAccountScope(scope);if(store.getRevision()!==revision)throw new Error('本机记录已变化，请重新读取云端，避免覆盖新内容');if(!result.state){wx.setStorageSync(versionKey(scope.identity),result.version);return {empty:true};}const accepted=await ui.confirm('用云端记录恢复本机？','这会替换当前账号在本机的文字记录。建议先导出备份；原始照片不会从云端恢复。');assertAccountScope(scope);if(!accepted)return {cancelled:true};if(store.getRevision()!==revision)throw new Error('本机记录已变化，请重新读取云端');store.replaceFromCloud(result.state);wx.setStorageSync(versionKey(scope.identity),result.version);return result;}finally{busy=false;}}
async function deleteCloudData(){if(busy)throw new Error('正在同步，请稍等');busy=true;try{if(!identity||store.getNamespace()!=='account:'+identity)await connect();const scope=accountScope();const current=await call('syncPull',{consent:true});assertAccountScope(scope);const accepted=await ui.confirm('删除云端备份？','这会删除当前微信账号的云端个人记录，本机记录保留。');assertAccountScope(scope);if(!accepted)return false;const result=await call('deleteCloudData',{baseVersion:current.version,confirm:true});assertAccountScope(scope);wx.setStorageSync(versionKey(scope.identity),result.version);store.saveSettings({cloudConsent:false});return true;}finally{busy=false;}}
function isAuthenticated(){return !!identity&&store.getNamespace()==='account:'+identity;}
function refreshCatalog(options){
  if(catalogPending)return catalogPending;
  const background=!!(options&&options.background),stamp=Date.now();
  if(background&&(!isAuthenticated()||!config.cloudEnv||stamp<catalogRetryAt||(catalogCheckedAt&&stamp-catalogCheckedAt<CATALOG_REFRESH_MS)))return Promise.resolve({skipped:true});
  catalogPending=(async()=>{
    try{
      const result=await call('getCatalog',{}, {background:true});
      store.updateCloudCatalog(result);
      catalogCheckedAt=Date.now();catalogRetryAt=0;catalogError='';
      return result;
    }catch(error){
      catalogError='行动库暂未更新，正在使用已保存的内容';
      catalogRetryAt=Date.now()+60*1000;
      throw error;
    }finally{catalogPending=null;}
  })();
  return catalogPending;
}
function refreshCatalogInBackground(){return refreshCatalog({background:true}).catch(()=>({updated:false,error:catalogError}));}
module.exports={status,request,refreshCatalog,refreshCatalogInBackground,isAuthenticated,connect,syncPush,syncPull,deleteCloudData,stripLocal};
