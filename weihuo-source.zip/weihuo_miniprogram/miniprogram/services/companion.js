'use strict';

const COMPANIONS = [
  {
    key: 'xiaowei', name: '小微', image: '/assets/xiaowei-checkin-v2.png',
    waitingImage: '/assets/xiaowei-checkin-v2.png', happyImage: '/assets/xiaowei-checkin-v2.png', mealImage: '/assets/xiaowei-meal-v2.png'
  },
  {
    key: 'cat', name: '团团', image: '/assets/companion-cat-waiting.png',
    waitingImage: '/assets/companion-cat-waiting.png', happyImage: '/assets/companion-cat-happy.png', welcomeImage:'/assets/companion-cat-welcome.png', mealImage:'/assets/companion-cat-meal.png', restImage:'/assets/companion-cat-rest.png'
  },
  {
    key: 'dachshund', name: '卷卷', image: '/assets/companion-dachshund-waiting.png',
    waitingImage: '/assets/companion-dachshund-waiting.png', happyImage: '/assets/companion-dachshund-happy.png', welcomeImage:'/assets/companion-dog-welcome.png', mealImage:'/assets/companion-dog-meal.png', restImage:'/assets/companion-dog-rest.png'
  }
];

const WORDS = {
  waiting: {
    xiaowei: ['我把本子摊好了，等你留一笔。', '今天想先挑哪件小事？我陪你一起看。'],
    cat: ['喵，今天想先做哪一件？', '我蹲在旁边，陪你看看今天有什么小发现。'],
    dachshund: ['汪，要不要一起看看今天的小事？', '我把耳朵竖起来啦，想聊哪件都行。']
  },
  present: {
    xiaowei: ['一餐或一句话留了下来，我看见了。', '今天的生活，已经留下一个小小印记。'],
    cat: ['我闻到今天有一点点生活气味。', '这点日常我替你收好了。'],
    dachshund: ['今天留下的记录，我替你看好啦。', '今天留住了一点点日常，我收好啦。']
  },
  happyOne: {
    xiaowei: ['一件小事收好了，贴一枚完成贴纸。', '看，今天留住了一个小小的完成。'],
    cat: ['一件小事完成啦，给你留个爪印。', '喵，今天有一件事被你好好做完了。'],
    dachshund: ['你完成了一件小事，尾巴摇起来啦。', '一件小事收好了，给你一个小爪印。']
  },
  happyMore: {
    xiaowei: ['今天做完了 {count} 件小事，慢慢累积也很好。', '有 {count} 件小事被你好好完成了。'],
    cat: ['今天完成了 {count} 件，爪印给你排成一串。', '喵，{count} 件小事都收好啦。'],
    dachshund: ['今天有 {count} 件小事完成，我的尾巴停不下来。', '{count} 件都完成啦，我把爪印盖在这里。']
  }
};

function normalizeCompanionKey(value) {
  return COMPANIONS.some(companion => companion.key === value) ? value : 'xiaowei';
}

function hash(value) {
  let result = 0;
  for (let i = 0; i < value.length; i++) result = (result * 31 + value.charCodeAt(i)) >>> 0;
  return result;
}

function deriveTodayCompanion(input) {
  const data = input && typeof input === 'object' ? input : {};
  const companionKey = normalizeCompanionKey(data.companionKey);
  const companion = COMPANIONS.find(item => item.key === companionKey);
  const actions = Array.isArray(data.actions) ? data.actions : [];
  const meals = Array.isArray(data.meals) ? data.meals : [];
  const completedCount = actions.filter(action => action && action.status === 'completed').length;
  const recordedMealCount = meals.filter(meal => meal && meal.confirmed === true).length;
  const hasNote = typeof data.note === 'string' && !!data.note.trim();
  const hasRecord = completedCount > 0 || recordedMealCount > 0 || hasNote;
  const status = completedCount > 0 ? 'happy' : hasRecord ? 'present' : 'waiting';
  const wordGroup = status === 'happy'
    ? completedCount === 1 ? 'happyOne' : 'happyMore'
    : status;
  const variants = WORDS[wordGroup][companionKey];
  const date = typeof data.date === 'string' ? data.date : '';
  const index = hash([date, companionKey, completedCount, recordedMealCount, Number(hasNote)].join('|')) % variants.length;
  const message = variants[index].replace('{count}', String(completedCount));
  const isAnimal = companionKey !== 'xiaowei';
  const pawCount = isAnimal ? status === 'happy' ? Math.min(completedCount, 3) : hasRecord ? 1 : 0 : 0;
  const stickerImage = companionKey === 'xiaowei'
    ? hasRecord ? '/assets/sticker-ticket.png' : '/assets/sticker-notebook.png'
    : '';

  return {
    companionKey,
    name: companion.name,
    sealImage:isAnimal?'/assets/'+(companionKey==='cat'?'cat':'dog')+'-paw.svg':'/assets/xiaowei-seal.png',
    pawImage:isAnimal?'/assets/'+(companionKey==='cat'?'cat':'dog')+'-paw.svg':'',
    faceImage:isAnimal?(companionKey==='cat'?'/assets/companion-cat-face.png':'/assets/companion-dog-face.png'):companion.image,
    image: status === 'happy' ? companion.happyImage : companion.waitingImage,
    selectionImage: companion.image,
    status,
    completedCount,
    recordedMealCount,
    hasNote,
    message,
    stickerId: status === 'waiting' ? 'quiet' : status === 'present' ? 'mark' : completedCount === 1 ? 'paw' : 'paws',
    stickerText: status === 'waiting' ? '我在这里' : status === 'present' ? '日常小印记' : completedCount === 1 ? '一件完成' : `完成 ${completedCount} 件`,
    showPawprint: isAnimal && hasRecord,
    showSticker: true,
    stickerImage,
    paws: Array.from({ length: pawCount }, (_, index) => ({ id: `paw-${index + 1}` })),
    joyLevel: Math.min(completedCount, 3)
  };
}

function getCompanionPresentation(input) {
  const data = input && typeof input === 'object' ? input : {};
  const derived = deriveTodayCompanion(data);
  const companion = COMPANIONS.find(item => item.key === derived.companionKey);
  const scene = ['meal','welcome','rest'].includes(data.scene)?data.scene:'hero';
  const image=scene==='meal'?companion.mealImage||derived.image:scene==='rest'?companion.restImage||derived.image:scene==='welcome'||derived.status==='waiting'?companion.welcomeImage||derived.image:derived.image;
  return Object.assign({},derived,{image,scene});
}

module.exports = { COMPANIONS, normalizeCompanionKey, deriveTodayCompanion, getCompanionPresentation };
