function choosePhoto(){return new Promise((resolve,reject)=>wx.chooseMedia({count:1,mediaType:['image'],sourceType:['album','camera'],sizeType:['compressed'],success:r=>{const file=r.tempFiles[0];if(file.size>5*1024*1024){reject(new Error('请使用小于 5 MB 的照片'));return;}wx.saveFile({tempFilePath:file.tempFilePath,success:s=>resolve(s.savedFilePath),fail:()=>reject(new Error('照片保存失败，请检查本机空间'))});},fail:e=>{const error=new Error((e.errMsg||'').indexOf('cancel')>=0?'已取消选择':'无法打开相册或相机，请检查微信权限');error.cancelled=(e.errMsg||'').indexOf('cancel')>=0;reject(error);}}));}
function removePhoto(path){return new Promise((resolve,reject)=>{
  if(!path){resolve();return;}
  const states=[require('./store').getState()];
  try{if(wx.getStorageInfoSync){wx.getStorageInfoSync().keys.filter(k=>k.indexOf('weihuo:v1:')===0).forEach(k=>{const row=wx.getStorageSync(k);if(!row||!row.state)throw new Error('Unreadable storage');states.push(row.state);});}
    if(states.some(s=>(s.profile&&s.profile.avatarPath===path)||s.meals.concat(s.reports).some(x=>(x.photoPath===path||(x.labelPhotoPaths||[]).includes(path)))||s.tickets.some(t=>t.meals.some(m=>(m.photoPath===path||(m.labelPhotoPaths||[]).includes(path)))))){resolve();return;}
  }catch(e){resolve();return;}
  wx.removeSavedFile({filePath:path,success:()=>{const pending=wx.getStorageSync('weihuo:photoCleanup')||[];wx.setStorageSync('weihuo:photoCleanup',pending.filter(p=>p!==path));resolve();},fail:e=>{if(/not exist|no such/i.test(e.errMsg||'')){resolve();return;}const pending=wx.getStorageSync('weihuo:photoCleanup')||[];if(pending.indexOf(path)<0)pending.push(path);try{wx.setStorageSync('weihuo:photoCleanup',pending);}catch(error){}reject(new Error('文字记录已处理，但部分本机照片删除失败。请在隐私与数据中重试清理。'));}});
});}
function readBase64(path){return new Promise((resolve,reject)=>wx.getFileSystemManager().readFile({filePath:path,encoding:'base64',success:r=>resolve(r.data),fail:()=>reject(new Error('无法读取这张照片，请重新选择'))}));}
async function retryCleanup(){const pending=wx.getStorageSync('weihuo:photoCleanup')||[];for(const path of pending)await removePhoto(path);}
module.exports={choosePhoto,removePhoto,readBase64,retryCleanup};
