'use strict';

const PAL_MIN = 1.40;
const PAL_MAX = 1.69;
const MACRO_FACTORS = { protein: 4, carbs: 4, fat: 9 };
const MACRO_KEYS = Object.keys(MACRO_FACTORS);

function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(value + 'T00:00:00Z');
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function round1(value) {
  return Math.round((value + Number.EPSILON) * 10) / 10;
}

function round10(value) {
  return Math.round(value / 10) * 10;
}

function unavailableExpenditure(status, reason) {
  return {
    status,
    minKcal: null,
    maxKcal: null,
    label: '日常消耗估算',
    assumption: null,
    reason
  };
}

function ageAt(birthDate, date) {
  if (!validDate(birthDate) || birthDate > date) return null;
  let age = Number(date.slice(0, 4)) - Number(birthDate.slice(0, 4));
  if (date.slice(5) < birthDate.slice(5)) age -= 1;
  return age;
}

function expenditureFor(profile, date) {
  const p = profile && typeof profile === 'object' ? profile : {};
  const age = ageAt(p.birthDate, date);
  if (age === null) {
    return unavailableExpenditure('unavailable', '补充有效的出生日期、身高和体重后，可查看估算范围。');
  }
  if (age < 18) {
    return unavailableExpenditure('minor', '未成年人这里先展示已记录的饮食信息。');
  }
  if (age < 19 || age > 78) {
    return unavailableExpenditure('out_of_range', '目前采用的公式研究对象为19至78岁，这里先不生成消耗估算。');
  }
  if (!Number.isFinite(p.heightCm) || p.heightCm < 30 || p.heightCm > 300 ||
      !Number.isFinite(p.weightKg) || p.weightKg < 1 || p.weightKg > 700) {
    return unavailableExpenditure('unavailable', '补充有效的身高和体重后，可查看估算范围。');
  }

  // Mifflin–St Jeor REE equation: retain both published sex coefficients
  // as the endpoints instead of assigning a coefficient to the user.
  const base = 10 * p.weightKg + 6.25 * p.heightCm - 5 * age;
  const reeMin = base - 161;
  const reeMax = base + 5;
  if (!Number.isFinite(reeMin) || !Number.isFinite(reeMax) || reeMin <= 0) {
    return unavailableExpenditure('unavailable', '目前的资料无法形成有效估算范围。');
  }

  return {
    status: 'estimated',
    minKcal: round10(reeMin * PAL_MIN),
    maxKcal: round10(reeMax * PAL_MAX),
    label: '日常消耗估算',
    assumption: '静坐或轻活动生活方式范围（PAL 1.40–1.69）；按两组公式系数给出区间。',
    reason: null
  };
}

function blankMacroSummary(dateMealCount) {
  const empty = () => ({ protein: null, carbs: null, fat: null });
  const coverage = {};
  MACRO_KEYS.forEach(key => { coverage[key] = { recorded: 0, total: dateMealCount }; });
  return {
    status: 'no_data',
    confirmedMealCount: dateMealCount,
    kcal: Object.assign(empty(), { total: null }),
    grams: empty(),
    percentages: empty(),
    coverage
  };
}

function macroSummary(meals, date) {
  const selected = (Array.isArray(meals) ? meals : []).filter(meal =>
    meal && meal.date === date && meal.confirmed === true
  );
  const summary = blankMacroSummary(selected.length);
  if (!selected.length) return summary;

  const grams = {};
  const kcal = {};
  let hasAnyMacro = false;
  let coverageComplete = true;
  MACRO_KEYS.forEach(key => {
    const values = selected.map(meal => meal[key]).filter(value =>
      typeof value === 'number' && Number.isFinite(value) && value >= 0
    );
    summary.coverage[key] = { recorded: values.length, total: selected.length };
    if (values.length !== selected.length) coverageComplete = false;
    if (!values.length) {
      grams[key] = null;
      kcal[key] = null;
      return;
    }
    hasAnyMacro = true;
    grams[key] = round1(values.reduce((sum, value) => sum + value, 0));
    kcal[key] = round1(grams[key] * MACRO_FACTORS[key]);
  });

  if (!hasAnyMacro) return summary;
  const knownEnergy = round1(MACRO_KEYS.reduce((sum, key) => sum + (kcal[key] === null ? 0 : kcal[key]), 0));
  const percentages = {};
  MACRO_KEYS.forEach(key => {
    percentages[key] = kcal[key] === null || knownEnergy <= 0 ? null : round1(kcal[key] / knownEnergy * 100);
  });
  if (knownEnergy > 0) {
    const presentKeys = MACRO_KEYS.filter(key => percentages[key] !== null);
    const largest = presentKeys.reduce((best, key) => percentages[key] > percentages[best] ? key : best, presentKeys[0]);
    const roundedTotal = presentKeys.reduce((sum, key) => sum + percentages[key], 0);
    percentages[largest] = round1(percentages[largest] + 100 - roundedTotal);
  }

  summary.status = coverageComplete ? 'available' : 'partial';
  summary.grams = grams;
  summary.kcal = Object.assign(kcal, { total: knownEnergy });
  summary.percentages = percentages;
  return summary;
}

function nutritionSummary(profile, meals, date) {
  if (!validDate(date)) throw new TypeError('date must be a valid YYYY-MM-DD date');
  return {
    date,
    expenditure: expenditureFor(profile, date),
    macros: macroSummary(meals, date)
  };
}

module.exports = { nutritionSummary };
