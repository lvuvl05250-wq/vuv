'use strict';

let pending = false;
const completed = new Map();
function failure(code, message) { const error = new Error(message); error.code = code; return error; }
function localDate(nowMs) {
  const date = new Date(nowMs === undefined ? Date.now() : nowMs);
  if (!Number.isFinite(date.getTime())) throw failure('INVALID_DATE', '手机当前时间无效，请检查系统时间');
  return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
}
function dateParts(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw failure('INVALID_DATE', '计划日期无效，请先修改计划');
  const parts = value.split('-').map(Number);
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
  if (parts[0] < 1900 || parts[0] > 2200 || date.toISOString().slice(0, 10) !== value) throw failure('INVALID_DATE', '计划日期无效，请先修改计划');
  return parts;
}
function localTimestamp(date, time) {
  const parts = dateParts(date);
  if (typeof time !== 'string' || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)) throw failure('INVALID_TIME', '请先选择具体提醒时间');
  const clock = time.split(':').map(Number);
  // Numeric construction uses the phone's local timezone, never parses a date as UTC.
  const value = new Date(parts[0], parts[1] - 1, parts[2], clock[0], clock[1], 0, 0);
  if (value.getFullYear() !== parts[0] || value.getMonth() !== parts[1] - 1 || value.getDate() !== parts[2]
    || value.getHours() !== clock[0] || value.getMinutes() !== clock[1]) throw failure('INVALID_LOCAL_TIME', '这个时间在手机当前时区不存在，请选择另一个时间');
  return value.getTime();
}
function canRemindOnDate(date, nowMs) {
  try {
    const now = nowMs === undefined ? Date.now() : nowMs;
    return date >= localDate(now) && localTimestamp(date, '23:59') > now;
  } catch (_) { return false; }
}
function createCalendarEvent(input, nowMs) {
  const now = nowMs === undefined ? Date.now() : nowMs;
  if (!Number.isFinite(now)) throw failure('INVALID_DATE', '手机当前时间无效，请检查系统时间');
  if (!input || typeof input.title !== 'string' || !input.title.trim() || input.title.length > 300) throw failure('INVALID_TITLE', '行动标题为空或过长，请先修改计划');
  const start = localTimestamp(input.date, input.time);
  if (start <= now) throw failure('PAST_TIME', '这个时间已经过去，请选择之后的时间');
  if (typeof input.durationMinutes !== 'number' || !Number.isFinite(input.durationMinutes) || input.durationMinutes < 0 || input.durationMinutes > 600) throw failure('INVALID_DURATION', '计划时长无效，请先修改计划');
  const startTime = Math.floor(start / 1000);
  return {title: '微活 · ' + input.title.replace(/\s+/g, ' ').trim(), startTime,
    endTime: String(startTime + Math.round(input.durationMinutes * 60)), allDay: false, alarm: true, alarmOffset: 0};
}
function mappedError(error) {
  const raw = error && error.errMsg || error && error.message || '';
  if (/cancel|取消/i.test(raw)) return failure('CALENDAR_CANCELLED', '已取消，未添加手机日历提醒');
  if (/auth(?:orize)?\s*(?:deny|denied)|permission|授权.*拒绝|无权限/i.test(raw)) return failure('CALENDAR_DENIED', '尚未添加。请在微信或手机系统设置中允许日历权限后，再点一次添加');
  if (/not support|unsupported|不支持|api not found/i.test(raw)) return failure('CALENDAR_UNSUPPORTED', '当前微信或设备不支持此功能，请在手机日历中手动添加');
  return failure('CALENDAR_FAILED', '暂未添加到手机日历，请稍后重试或手动添加');
}
function lastAdded(key) { const value = completed.get(key); return value ? Object.assign({}, value) : null; }
function addReminder(input) {
  let event;
  try {
    event = createCalendarEvent(input);
    if (typeof input.key !== 'string' || !input.key || input.key.length > 500) throw failure('INVALID_KEY', '提醒信息已变化，请重新打开计划');
    if (typeof wx.addPhoneCalendar !== 'function' || (typeof wx.canIUse === 'function' && !wx.canIUse('addPhoneCalendar'))) throw failure('CALENDAR_UNSUPPORTED', '当前微信或设备不支持此功能，请在手机日历中手动添加');
    if (pending) throw failure('CALENDAR_BUSY', '请先完成当前的系统日历操作');
    const previous = completed.get(input.key);
    const signature = JSON.stringify(event);
    if (previous && previous.signature === signature) return Promise.resolve({status: 'already-added', time: previous.time, date: previous.date});
    pending = true;
    return new Promise((resolve, reject) => {
      let settled = false;
      const fail = error => { if (settled) return; settled = true; pending = false; reject(mappedError(error)); };
      const success = () => {
        if (settled) return;
        settled = true; pending = false;
        completed.set(input.key, {signature, date: input.date, time: input.time});
        if (completed.size > 200) completed.delete(completed.keys().next().value);
        resolve({status: 'added', date: input.date, time: input.time});
      };
      try { wx.addPhoneCalendar(Object.assign({}, event, {success, fail})); } catch (error) { fail(error); }
    });
  } catch (error) { return Promise.reject(error); }
}

module.exports = {localDate, localTimestamp, canRemindOnDate, createCalendarEvent, addReminder, lastAdded};
