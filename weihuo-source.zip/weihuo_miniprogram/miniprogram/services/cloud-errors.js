// Return a useful public message without leaking SDK request details or tokens.
function connectionError(cause) {
  const detail = String(cause && cause.errMsg || '');
  const nested = detail.match(/errCode:\s*(-?\d+)/);
  const code = nested ? Number(nested[1]) : Number(cause && cause.errCode);
  const error = new Error('暂时连不上微信账号服务，请稍后再试。');
  error.code = 'CLOUD_CONNECTION_FAILED';
  error.retryable = true;
  if (code === -601034) {
    error.message = '微信账号服务还差最后一步开通，完成后就能开始记录了。';
    error.code = 'CLOUD_NOT_ACTIVATED';
    error.retryable = false;
  } else if (code === -601012) {
    error.message = '微信账号服务尚未关联这个小程序，请联系维护者完成连接。';
    error.code = 'CLOUD_ENV_NOT_BOUND';
    error.retryable = false;
  }
  return error;
}

module.exports = {connectionError};
