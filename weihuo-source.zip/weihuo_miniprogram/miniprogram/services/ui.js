const toast = message => wx.showToast({title:String(message),icon:'none',duration:2300});
const error = e => wx.showModal({title:'暂时没有完成',content:(e&&e.message)||'请稍后再试',showCancel:false});
const confirm = (title,content) => new Promise(resolve=>wx.showModal({title,content,confirmColor:'#465578',success:r=>resolve(r.confirm),fail:()=>resolve(false)}));
const dateLabel = date => date.replace(/-/g,'.');
const setTab = (page,index) => {if(page.getTabBar&&page.getTabBar())page.getTabBar().setData({selected:index});};
module.exports={toast,error,confirm,dateLabel,setTab};
