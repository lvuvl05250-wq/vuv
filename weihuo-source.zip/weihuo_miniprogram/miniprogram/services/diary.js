'use strict';
const {getCompanionPresentation}=require('./companion');
const clip=(text,max)=>{const chars=Array.from(String(text||'').trim());return chars.length>max?chars.slice(0,max-1).join('')+'…':chars.join('');};
function hash(text){return Array.from(String(text)).reduce((n,c)=>(n*31+c.charCodeAt(0))>>>0,0);}
function buildDiary(ticket, options){
  options=options||{};
  const actions=(ticket.actions||[]).filter(a=>a.status==='completed');
  const meals=(ticket.meals||[]).filter(m=>m.confirmed===true);
  const seed=hash(ticket.date);
  const companion=getCompanionPresentation({companionKey:options.companionKey||ticket.companionKey,date:ticket.date,actions,meals,note:ticket.note,scene:'rest'});
  const dateParts=String(ticket.date||'').split('-');
  const dateLabel=dateParts.length===3?`${dateParts[0]} 年 ${Number(dateParts[1])} 月 ${Number(dateParts[2])} 日`:String(ticket.date||'');
  const auspices=['快乐','自在','慢慢喜欢今天','收集小确幸','给生活加点甜','把喜欢的事做一遍'];
  const content=ticket.diary?require('./diary-content').normalizeDiary(ticket.diary,companion.companionKey):null;
  const paragraphs=content?content.paragraphs:[];
  const highlights=actions.slice(0,3).map(a=>({text:'✓ '+clip(a.title,22),tone:'green'}));
  if(actions.length>3)highlights.push({text:`还有 ${actions.length-3} 件已完成`,tone:'green'});
  if(meals.length)highlights.push({text:`记下 ${meals.length} 餐`,tone:'orange'});
  const known=meals.filter(m=>['protein','carbs','fat'].every(k=>typeof m[k]==='number'&&Number.isFinite(m[k])));
  const nutrition=known.length?`${known.length} 餐记有蛋白质、碳水和脂肪${known.length<meals.length?'；其余待补充':''}`:'';
  if(nutrition)highlights.push({text:nutrition,tone:'purple'});
  const tastes=Array.from(new Set(meals.flatMap(m=>m.tags||[]))).filter(t=>['喜欢','清爽','软糯','酥脆','鲜香','刚刚好','还想吃','有点撑'].includes(t));
  if(tastes.length)highlights.push({text:'吃起来 · '+tastes.slice(0,3).join(' / '),tone:'orange'});
  const customTitle=ticket.title&&ticket.title!=='这一点点，也算数。'?clip(ticket.title,200):'';
  const model={date:ticket.date,dateLabel,yi:'宜 '+(content&&content.yi||auspices[seed%auspices.length]),title:content&&content.title||customTitle||'把今天夹进本子里',paragraphs,highlights,personalNote:ticket.note||'',quote:content&&content.quote||'',stickers:(content&&content.stickers.length?content.stickers:[{kind:'face',side:seed%2?'left':'right'}]).map((sticker,index)=>Object.assign({},sticker,{id:index,image:sticker.kind==='paw'?companion.pawImage:sticker.kind==='face'?companion.faceImage:sticker.kind==='flower'?'/assets/sticker-recipe.png':sticker.kind==='heart'?'/assets/sticker-food.png':'/assets/welcome-fireworks.png',rotation:(seed+index)%2?-7:6})),companion,rotation:seed%2?'-6':'5',sealed:!!ticket.createdAt,signature:companion.companionKey==='xiaowei'?'小微':companion.name+'的小爪印',counts:{actions:actions.length,meals:meals.length}};
  model.blocks=paragraphs.map((text,index)=>({text,sticker:model.stickers[index]||null}));
  model.showFooterFriend=!model.blocks.some(block=>block.sticker&&block.sticker.kind==='face');return model;
}
module.exports={buildDiary,clip};
