'use strict';

const {normalizeFoodExclusions}=require('./food-exclusions');
const TAGS = [
  {id: 'breakfast', label: '早餐'}, {id: 'main', label: '一碗主食'},
  {id: 'side', label: '下饭菜'}, {id: 'vegetarian', label: '不含肉鱼'},
  {id: 'quick', label: '15分钟左右'}, {id: 'make_ahead', label: '提前准备'}
];
const ALLERGENS = [
  {id: 'milk', label: '奶'}, {id: 'egg', label: '蛋'}, {id: 'soy', label: '大豆'},
  {id: 'gluten', label: '含麸质谷物'}, {id: 'tree_nuts', label: '树坚果'},
  {id: 'peanut', label: '花生'}, {id: 'sesame', label: '芝麻'},
  {id: 'fish', label: '鱼'}, {id: 'shellfish', label: '虾蟹贝类'}
];
const PREFERENCE_QUESTIONS = [
  {key: 'taste', title: '今天想吃什么味道？', options: [{id: 'light', label: '清淡一点'}, {id: 'savory', label: '鲜香'}, {id: 'tangy', label: '酸酸甜甜'}, {id: 'sweet', label: '一点甜味'}]},
  {key: 'color', title: '哪种颜色让你有胃口？', options: [{id: 'red', label: '红色'}, {id: 'orange', label: '橙黄色'}, {id: 'green', label: '绿色'}, {id: 'purple', label: '紫色'}]},
  {key: 'texture', title: '更想要哪种口感？', options: [{id: 'fresh', label: '清爽'}, {id: 'soft', label: '软糯'}, {id: 'crisp', label: '酥脆'}, {id: 'chewy', label: '有嚼劲'}]},
  {key: 'temperature', title: '什么温度更有胃口？', options: [{id: 'hot', label: '热乎'}, {id: 'warm', label: '温热'}, {id: 'room', label: '常温'}, {id: 'cool', label: '冰凉'}]},
  {key: 'scene', title: '这次想怎么吃？', options: [{id: 'alone', label: '一个人慢慢吃'}, {id: 'break', label: '工作间隙'}, {id: 'together', label: '和朋友一起'}, {id: 'packed', label: '带一份出门'}]}
];
// Descriptive cooking attributes, not nutritional or health claims. A recipe can
// match some preferences without matching all; the UI names only actual matches.
const DISCOVERY = {
  recipe_tomato_egg: {taste: ['tangy', 'savory'], color: ['red', 'orange'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'break', 'together']},
  recipe_garlic_mushrooms: {taste: ['savory'], color: ['orange'], texture: ['chewy'], temperature: ['hot', 'warm'], scene: ['alone', 'together']},
  recipe_corn_tofu_pork: {taste: ['light', 'savory'], color: ['orange'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'together', 'packed']},
  recipe_pumpkin_rice: {taste: ['savory', 'sweet'], color: ['orange'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'together', 'packed']},
  recipe_tomato_chicken_congee: {taste: ['light', 'tangy'], color: ['red'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'together']},
  recipe_tropical_oats: {taste: ['sweet', 'tangy'], color: ['orange'], texture: ['soft', 'fresh'], temperature: ['cool'], scene: ['alone', 'break', 'packed']},
  recipe_banana_walnut_oats: {taste: ['sweet'], color: ['orange'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'break']},
  recipe_vegetable_egg_rice: {taste: ['savory'], color: ['green', 'orange'], texture: ['chewy'], temperature: ['hot', 'warm'], scene: ['alone', 'together', 'packed']},
  recipe_tofu_corn_carrot: {taste: ['light', 'savory'], color: ['orange'], texture: ['soft'], temperature: ['hot', 'warm'], scene: ['alone', 'together']},
  recipe_tomato_beef_pasta: {taste: ['tangy', 'savory'], color: ['red'], texture: ['chewy'], temperature: ['hot', 'warm'], scene: ['alone', 'together']}
};
const hk = id => ({title: '香港卫生署 · 幼营喜动食谱平台', url: 'https://www.startsmart.gov.hk/tc/photogalleryDetail.aspx?RecipeID=' + id});
const us = path => ({title: 'USDA · MyPlate 食谱', url: 'https://www.myplate.gov/recipes/' + path});
// Short household adaptations, not nutrient calculations. Sources were read on 2026-10-05.
const RECIPES = [
  {id: 'recipe_tomato_egg', title: '番茄炒蛋', description: '番茄的酸甜汁水，拌米饭刚好。', servings: '约2人份', time: '约15分钟', tags: ['side', 'vegetarian', 'quick'], allergens: ['egg'], ingredients: ['番茄2个', '鸡蛋2个', '番茄膏1茶匙', '菜籽油1茶匙', '盐少许、清水适量'], steps: ['番茄洗净切块；鸡蛋加一小勺水打散。', '热锅放油，炒蛋至基本凝固后盛出。', '番茄加少量水煮软，拌入番茄膏和盐，再放回鸡蛋，炒至鸡蛋完全熟透。'], tip: '用番茄本身的汁水拌匀，不必加很多酱料。', source: hk(50)},
  {id: 'recipe_garlic_mushrooms', title: '蒜香双菇', description: '两种蘑菇和一点蒜香，配一盘彩色蔬菜。', servings: '约2人份配菜', time: '约30–35分钟', tags: ['side', 'vegetarian'], allergens: ['soy', 'gluten'], ingredients: ['蘑菇与草菇共200克', '玉米笋4根', '胡萝卜半根', '蒜1瓣', '菜籽油1茶匙、酱油半茶匙'], steps: ['蘑菇、草菇、玉米笋和胡萝卜洗净切小块。', '蔬菜入沸水焯3–5分钟，捞出沥干。', '锅里放油和蒜末炒香，再下蔬菜翻炒至熟，用少量酱油拌匀。'], tip: '先沥干水，炒出来不容易变成一锅汤。', source: hk(48)},
  {id: 'recipe_corn_tofu_pork', title: '玉米豆腐蒸肉饼', description: '豆腐揉进肉末里，口感柔软，蒸一盘就好。', servings: '约2人份', time: '约35分钟', tags: ['side', 'make_ahead'], allergens: ['soy'], ingredients: ['瘦猪肉末150克', '豆腐150克', '玉米粒60克', '盐少许'], steps: ['豆腐压碎，玉米粒洗净沥水。', '与肉末和少量盐充分拌匀，摊入浅盘，厚薄尽量一致。', '水开后上锅蒸约20分钟；确认肉饼中心完全熟透，再取出。'], tip: '肉饼摊薄一些更容易熟透；厚盘或加量时需要延长时间。', source: hk(41)},
  {id: 'recipe_pumpkin_rice', title: '南瓜肉末杂粮饭', description: '一勺软南瓜，把米饭和肉末裹在一起。', servings: '约2人份', time: '约30–40分钟，使用熟饭', tags: ['main'], allergens: ['soy', 'gluten'], ingredients: ['熟杂粮饭2碗', '南瓜200克', '瘦猪肉末100克', '酱油半茶匙、淀粉半茶匙', '菜籽油1茶匙、清水适量'], steps: ['南瓜去皮切薄片，肉末与酱油、淀粉拌匀，放置约10分钟。', '热锅放油，将肉末炒散，再加南瓜和少量清水煮软。', '加入熟杂粮饭，翻拌到整锅热透，确认肉末完全熟透后盛出。'], tip: '优先用现煮米饭；冷藏熟饭也要加热到整份热透。', source: hk(103)},
  {id: 'recipe_tomato_chicken_congee', title: '番茄鸡肉粥', description: '慢慢煮的一锅粥，留一点番茄的清爽味。', servings: '约2人份', time: '约60–70分钟', tags: ['main', 'make_ahead'], allergens: [], ingredients: ['大米80克', '去皮鸡肉100克', '番茄1个', '清水约800毫升，可按稠度补充', '盐少许'], steps: ['大米洗净；番茄去皮切碎，鸡肉另用干净砧板切细。', '米加清水煮开，转小火煮至米粒软开，间中搅拌。', '加入番茄和鸡肉，继续煮约30分钟，确认鸡肉彻底熟透，按喜欢的稠度补水调味。'], tip: '锅盖留一点缝，并留意粥是否溢出或粘底。', source: hk(51)},
  {id: 'recipe_tropical_oats', title: '香蕉菠萝隔夜燕麦', description: '晚上拌好，早上加水果和杏仁片。', servings: '2人份', time: '准备约5分钟，另需冷藏过夜', tags: ['breakfast', 'vegetarian', 'make_ahead'], allergens: ['milk', 'gluten', 'tree_nuts'], ingredients: ['原味燕麦片2/3杯', '牛奶2/3杯', '原味酸奶2/3杯', '菠萝块1杯、香蕉1根', '杏仁片2汤匙；1杯约240毫升'], steps: ['把燕麦、牛奶和酸奶分装到两个干净有盖容器里，拌匀。', '盖好后放入冰箱冷藏过夜，不放在室温。', '食用前加入洗切好的菠萝、香蕉和杏仁片。'], tip: '需要提前一晚准备；燕麦和乳制品按包装保存要求处理。', source: us('tropical-overnight-oatmeal')},
  {id: 'recipe_banana_walnut_oats', title: '香蕉核桃热燕麦', description: '熟香蕉压成泥，拌进热热的燕麦里。', servings: '约2人份', time: '约10分钟', tags: ['breakfast', 'vegetarian', 'quick'], allergens: ['milk', 'gluten', 'tree_nuts'], ingredients: ['快熟燕麦1杯', '牛奶1杯、清水约1又1/3杯', '熟香蕉1根', '核桃碎1汤匙；1杯约240毫升'], steps: ['牛奶和清水放小锅中，温热后倒入燕麦。', '按燕麦包装时间煮熟，期间轻搅，避免粘底。', '离火后拌入压碎的香蕉，分碗撒上核桃碎。'], tip: '原食谱另加枫糖浆，这个家庭版用香蕉提供甜味。', source: us('supplemental-nutrition-assistance-program-snap/banana-walnut-oatmeal')},
  {id: 'recipe_vegetable_egg_rice', title: '豌豆胡萝卜蛋焖饭', description: '米饭和蔬菜先焖好，再把蛋液轻轻拌熟。', servings: '约2人份', time: '约35–40分钟', tags: ['main', 'vegetarian'], allergens: ['egg', 'milk', 'soy', 'gluten'], ingredients: ['生米半杯、清水1杯', '洋葱末1汤匙、胡萝卜丁半根', '豌豆半杯、鸡蛋2个', '牛奶2汤匙、酱油半茶匙', '菜籽油1茶匙；1杯约240毫升'], steps: ['锅里放油，将米、洋葱和胡萝卜略炒，再倒入清水。', '加盖转小火焖约20分钟，确认米饭熟软；水量按米的种类调整。', '鸡蛋与牛奶、豌豆和酱油拌匀，倒入饭中翻拌加热，直到鸡蛋完全凝固、豌豆熟透。'], tip: '这是从生米开始的焖饭，预留足够煮饭时间。', source: us('supplemental-nutrition-assistance-program-snap/flavorful-fried-rice')},
  {id: 'recipe_tofu_corn_carrot', title: '豆腐玉米煮胡萝卜', description: '一锅轻轻煮，豆腐保持完整，玉米留点甜。', servings: '约2人份配菜', time: '约30–40分钟', tags: ['side', 'vegetarian'], allergens: ['soy', 'gluten'], ingredients: ['豆腐200克', '玉米粒80克', '胡萝卜半根', '菜籽油1茶匙、酱油半茶匙', '淀粉半茶匙、清水适量'], steps: ['胡萝卜切小丁后焯水；豆腐切块，玉米粒洗净。', '锅内放油炒胡萝卜约2分钟，再加玉米和少量清水煮约5分钟。', '放入豆腐和酱油，小火煮至食材熟透；淀粉兑水后少量加入，轻轻推匀。'], tip: '豆腐下锅后用锅铲推拌，少翻动就不容易碎。', source: hk(39)},
  {id: 'recipe_tomato_beef_pasta', title: '苹果番茄牛肉意面', description: '苹果蓉和番茄一起熬成酱，味道自然酸甜。', servings: '约2人份', time: '约40分钟，含腌制', tags: ['main'], allergens: ['gluten'], ingredients: ['干意面150克（选择不含蛋的款式）', '牛肉末100克', '番茄2个、苹果半个', '干葱1粒、鲜橙汁1汤匙', '菜籽油1茶匙、盐少许'], steps: ['牛肉末拌橙汁和少量油，腌约30分钟；期间将番茄切碎，苹果去皮去芯打成蓉。', '意面按包装煮熟；另起锅炒香干葱，加入牛肉末炒散。', '放番茄、少量水和苹果蓉煮成酱，确认牛肉完全熟透，再拌入意面。'], tip: '意面配方可能含蛋，挑选时核对包装配料。', source: hk(2)}
];
RECIPES.forEach(recipe => { Object.freeze(recipe.tags); Object.freeze(recipe.allergens); Object.freeze(recipe.ingredients); Object.freeze(recipe.steps); Object.freeze(recipe.source); Object.freeze(recipe); });
Object.freeze(RECIPES);
const clone = value => JSON.parse(JSON.stringify(value));
function getRecipe(id) { const item = RECIPES.find(recipe => recipe.id === id); return item ? clone(item) : null; }
function excludedByProfile(recipe, profile) {
  const terms = normalizeFoodExclusions(profile, profile && profile.foodExclusions).map(item => item.name);
  const aliases = {milk:['奶','乳制品','乳糖'], egg:['蛋','鸡蛋','蛋清','蛋黄'], soy:['大豆','黄豆','豆制品','豆腐'], gluten:['麸质','小麦'], tree_nuts:['坚果'], peanut:['花生'], sesame:['芝麻'], fish:['鱼'], shellfish:['海鲜','贝类','虾','蟹']};
  const contents = [recipe.title].concat(recipe.ingredients || []).join(' ');
  return terms.some(term => contents.includes(term) || (recipe.allergens || []).some(id => (aliases[id] || []).includes(term)));
}
function filterRecipes(options) {
  const opts = options || {}, tags = Array.isArray(opts.tags) ? opts.tags : [], avoid = Array.isArray(opts.avoid) ? opts.avoid : [];
  const saved = new Set(Array.isArray(opts.savedIds) ? opts.savedIds : []), query = typeof opts.query === 'string' ? opts.query.trim().toLowerCase() : '';
  return RECIPES.filter(recipe => !excludedByProfile(recipe, opts.profile) && tags.every(tag => recipe.tags.includes(tag)) && !recipe.allergens.some(item => avoid.includes(item)) && (!opts.favoritesOnly || saved.has(recipe.id)) && (!query || [recipe.title, recipe.description].concat(recipe.ingredients).join(' ').toLowerCase().includes(query))).map(clone);
}
function pickRecipes(recipes, count, random) {
  const pool = Array.isArray(recipes) ? recipes.slice() : [], rng = typeof random === 'function' ? random : Math.random;
  const limit = count === 3 ? 3 : 1, chosen = [];
  while (pool.length && chosen.length < limit) {
    const value = Number(rng()), bounded = Number.isFinite(value) ? Math.min(0.999999, Math.max(0, value)) : 0;
    chosen.push(pool.splice(Math.floor(bounded * pool.length), 1)[0]);
  }
  return chosen.map(clone);
}
function normalizePreferences(value) {
  const input = value && typeof value === 'object' ? value : {}, result = {};
  PREFERENCE_QUESTIONS.forEach(question => { result[question.key] = question.options.some(option => option.id === input[question.key]) ? input[question.key] : ''; });
  return result;
}
function preferenceLabels(value) {
  const preferences = normalizePreferences(value);
  return PREFERENCE_QUESTIONS.flatMap(question => question.options.filter(option => option.id === preferences[question.key]).map(option => option.label));
}
function rankRecipes(pool, value) {
  const preferences = normalizePreferences(value), hasPreferences = Object.values(preferences).some(Boolean);
  return (Array.isArray(pool) ? pool : []).map(recipe => {
    const attributes = DISCOVERY[recipe.id] || {}, matches = PREFERENCE_QUESTIONS.filter(question => preferences[question.key] && (attributes[question.key] || []).includes(preferences[question.key]));
    return Object.assign(clone(recipe), {matchLabels: matches.map(question => question.options.find(option => option.id === preferences[question.key]).label), matchScore: matches.reduce((sum, question) => sum + (['taste', 'texture', 'temperature'].includes(question.key) ? 2 : 1), 0)});
  }).filter(recipe => !hasPreferences || recipe.matchScore > 0).sort((a, b) => b.matchScore - a.matchScore);
}
function recommendRecipes(pool, preferences, count) { return rankRecipes(pool, preferences).slice(0, count === 3 ? 3 : 1); }
function tastingTemplate(recipeId, catalogAction) {
  const recipe = getRecipe(recipeId); if (!recipe) throw new Error('这道食谱暂时不存在。');
  const base = catalogAction || {};
  return {title: '尝一口 · ' + recipe.title, kind: 'care', category: 'senses', durationMinutes: 2, source: 'manual', scenes: ['any'], energyLevels: ['low', 'medium', 'high'], priority: 2,
    tags: [...new Set((base.tags || []).concat(['food_discovery', recipe.id]))], avoidWhen: (base.avoidWhen || []).slice(),
    steps: ['等' + recipe.title + '准备好、确认食材适合自己，再找个能坐稳的地方。看一眼：你先注意到哪种颜色？', '尝一小口：温度和口感是什么样？顺着平常的节奏咀嚼、咽下，不需要刻意放慢。', '这一口里，你最喜欢什么味道？按自己的胃口决定要不要继续，不必吃完。'],
    minimumVersion: base.minimumVersion || '留意一口食物的温度',
    stopSignal: '吞咽困难、恶心、明显腹痛或其他不适时停下。' + (base.stopSignal || '不想继续也可以随时结束。')};
}
function toggleFavoriteIds(ids, id) {
  if (!getRecipe(id)) throw new Error('这道食谱暂时不存在。');
  const previous = [...new Set(Array.isArray(ids) ? ids : [])];
  if (previous.includes(id)) return previous.filter(value => value !== id);
  if (previous.length >= 100) throw new Error('已收藏100道食谱，先移除一些再收藏。');
  return previous.concat(id);
}
function decorate(recipe, savedIds) {
  return Object.assign({}, recipe, {saved: (savedIds || []).includes(recipe.id), tagLabels: recipe.tags.map(id => TAGS.find(tag => tag.id === id).label), allergenLabels: recipe.allergens.map(id => ALLERGENS.find(item => item.id === id).label)});
}
module.exports = {RECIPES, TAGS, ALLERGENS, PREFERENCE_QUESTIONS, getRecipe, excludedByProfile, filterRecipes, pickRecipes, normalizePreferences, preferenceLabels, rankRecipes, recommendRecipes, tastingTemplate, toggleFavoriteIds, decorate};
