'use strict';
const store=require('./store');
const api=require('./api');
const {normalizeFoodExclusions}=require('./food-exclusions');
const attempts=new Map();
const signature=p=>JSON.stringify([p.allergies||'',p.bodyNotes||'',p.notes||'']);

async function rememberFoodProfile() {
  const namespace=store.getNamespace(),profile=store.getProfile(),key=signature(profile);
  if(!store.getSettings().aiConsent || ![profile.allergies,profile.bodyNotes,profile.notes].some(value=>value&&value.trim()) || attempts.get(namespace)===key) return false;
  attempts.set(namespace,key);
  try {
    const result=await api.request('extractFoodPreferences',{profile});
    if(store.getNamespace()!==namespace || !store.getSettings().aiConsent || signature(store.getProfile())!==key) return false;
    store.saveProfile({foodExclusions:normalizeFoodExclusions(profile,result.foodExclusions)});
    return true;
  } catch(error) {
    attempts.delete(namespace);
    // The original profile and explicit exclusions remain saved. Reopening the
    // profile/recipe page can retry enrichment; never report fabricated success.
    return false;
  }
}
module.exports={rememberFoodProfile};
