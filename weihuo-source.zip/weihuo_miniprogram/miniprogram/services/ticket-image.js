const WIDTH = 360, MAX_HEIGHT = 1200, SCALE = 3;
const INK = '#242622', MUTED = '#677361', ACCENT = '#57793F', PAPER = '#FFFEFA';
function stats(ticket) {
  const actions = ticket.actions || [], meals = ticket.meals || [];
  return {actions: actions.length, meals: meals.length, feedback: actions.filter(action => !!action.feedback).length};
}
function fallbackWidth(text, size) {
  return Array.from(text).reduce((sum, character) => sum + (/^[\x00-\x7f]$/.test(character) ? size * 0.6 : size), 0);
}
function wrapText(text, width, size, measure) {
  const lines = [];
  String(text === null || text === undefined ? '' : text).replace(/\r\n?/g, '\n').split('\n').forEach(paragraph => {
    let line = '';
    Array.from(paragraph).forEach(character => {
      const candidate = line + character;
      if (line && measure(candidate, size) > width) {
        const chars=Array.from(line);
        if(/[，。！？、；：）】》”’]/.test(character)&&chars.length>1){const last=chars.pop();lines.push(chars.join(''));line=last+character;}
        else{lines.push(line);line=character;}
      }
      else line = candidate;
    });
    lines.push(line);
  });
  return lines;
}
function buildLayout(ticket, measure, options) {
  if (!ticket || !Array.isArray(ticket.actions) || !Array.isArray(ticket.meals)) throw new Error('日记内容不完整，请重新打开后再保存');
  measure = measure || fallbackWidth;
  const diary = require('./diary').buildDiary(ticket, options);
  const lines=[];
  const add=(text,type,size,color,height)=>wrapText(text,284,size,measure).forEach(text=>lines.push({type,text,size,color,height}));
  add(diary.title,'title',22,INK,32);
  diary.blocks.forEach(block=>{lines.push({type:'space',height:13});const sticker=block.sticker,paragraph=wrapText(block.text,sticker?204:284,17,measure);paragraph.forEach((text,index)=>lines.push({type:'text',text,size:17,color:INK,height:29,x:sticker&&sticker.side==='left'?116:36,sticker:index===0?sticker:null}));if(sticker&&paragraph.length*29<76)lines.push({type:'space',height:76-paragraph.length*29});});
  lines.push({type:'space',height:16});
  diary.highlights.forEach(item=>{add(item.text,'highlight',14,{green:'#42663D',orange:'#9B623E',purple:'#775A8A'}[item.tone],27);lines.push({type:'space',height:6});});
  const quoteLines=wrapText(diary.quote,diary.showFooterFriend?185:284,16,measure);
  lines.push({type:'ending',quoteLines,height:Math.max(diary.showFooterFriend?110:0,quoteLines.length*27+24)});
  if(diary.personalNote){lines.push({type:'space',height:22});add('我还想写','personal',14,'#5F744B',29);add(diary.personalNote,'personal',17,INK,29);}
  const headerHeight=128,footerHeight=70;
  const pages=[];let current=[],used=0;
  lines.forEach(line=>{if(current.length&&headerHeight+used+line.height+footerHeight>MAX_HEIGHT){pages.push({lines:current,height:headerHeight+used+footerHeight});current=[];used=0;}current.push(line);used+=line.height;});
  if(current.length)pages.push({lines:current,height:headerHeight+used+footerHeight});
  return {width:WIDTH,titleLines:wrapText(diary.title,284,22,measure),headerHeight,footerHeight,pages,stats:stats(ticket),date:ticket.date,diary};
}
function paper(ctx,height){
  ctx.setFillStyle('#F2F6E9');ctx.fillRect(0,0,WIDTH,height);
  ctx.setFillStyle('#E4EBD9');ctx.fillRect(15,19,WIDTH-28,height-30);
  ctx.setFillStyle('#FFFEF9');ctx.fillRect(10,12,WIDTH-28,height-30);
  ctx.setStrokeStyle('#DCE3D0');ctx.setLineWidth(.7);ctx.strokeRect(10,12,WIDTH-28,height-30);
  ctx.save();ctx.translate(42,13);ctx.rotate(-.07);ctx.setFillStyle('#D9E8B8');ctx.fillRect(0,-6,70,18);ctx.restore();
}
function paw(ctx,x,y,key){
  ctx.save();ctx.translate(x,y);ctx.rotate(-.18);ctx.setFillStyle('#242622');
  [[-10,-6,4],[-4,-12,4],[4,-12,4],[10,-6,4],[0,3,key==='cat'?8:10]].forEach(p=>{ctx.beginPath();ctx.arc(p[0],p[1],p[2],0,Math.PI*2);ctx.fill();});ctx.restore();
}
function drawPage(ctx,model,pageModel,number,characterPath){
  const h=pageModel.height,d=model.diary;
  paper(ctx,h);ctx.setTextAlign('left');ctx.setFillStyle(MUTED);ctx.setFontSize(13);ctx.fillText(d.dateLabel,34,55);
  ctx.save();ctx.translate(32,72);ctx.rotate(-.025);ctx.setFillStyle('#F4DEB0');ctx.fillRect(0,0,Math.min(240,fallbackWidth(d.yi,16)+24),30);ctx.setFillStyle(INK);ctx.setFontSize(16);ctx.fillText(d.yi,12,22);ctx.restore();
  let y=model.headerHeight;
  const personalIndex=pageModel.lines.findIndex(line=>line.type==='personal');
  if(personalIndex>=0){
    const top=model.headerHeight+pageModel.lines.slice(0,personalIndex).reduce((sum,line)=>sum+line.height,0)-10;
    ctx.setFillStyle('#E8F0D9');ctx.fillRect(11,top,331,h-18-top);
    ctx.setStrokeStyle('#9DAF86');ctx.beginPath();
    for(let x=12;x<340;x+=9){ctx.moveTo(x,top);ctx.lineTo(Math.min(x+5,340),top);}ctx.stroke();
  }
  pageModel.lines.forEach(line=>{
    if(line.type==='ending'){
      ctx.setFillStyle(INK);ctx.setFontSize(16);line.quoteLines.forEach((text,i)=>ctx.fillText(text,36,y+25+i*27));
      const ratio=Math.min(94/characterPath.width,94/characterPath.height),aw=characterPath.width*ratio,ah=characterPath.height*ratio;
      if(d.showFooterFriend)ctx.drawImage(characterPath.path,232+(94-aw)/2,y+(line.height-ah)/2,aw,ah);
    }else if(line.type!=='space'){
      if(line.type==='highlight'){ctx.setFillStyle({'#42663D':'#EAF2DE','#9B623E':'#FFF0DF','#775A8A':'#EFE9F5'}[line.color]||'#F0F3E9');ctx.fillRect(31,y-1,294,line.height);}
      if(line.sticker){const x=line.sticker.side==='left'?34:252;if(line.sticker.kind==='paw')paw(ctx,x+30,y+30,d.companion.companionKey);else if(characterPath.stickers&&characterPath.stickers[line.sticker.image])ctx.drawImage(characterPath.stickers[line.sticker.image],x,y,68,68);}
      ctx.setFillStyle(line.color);ctx.setFontSize(line.size);ctx.fillText(line.text,line.x||36,y+line.size);
    }
    y+=line.height;
  });
  ctx.setStrokeStyle('#DCE3D0');ctx.beginPath();ctx.moveTo(34,h-58);ctx.lineTo(324,h-58);ctx.stroke();
  if(d.companion.companionKey==='xiaowei'&&characterPath.seal){ctx.drawImage(characterPath.seal,32,h-64,48,48);}else paw(ctx,54,h-38,d.companion.companionKey);
  ctx.setFillStyle(MUTED);ctx.setFontSize(12);ctx.fillText('这一页，收好啦 · '+d.signature,98,h-31);if(model.pages.length>1){ctx.setFontSize(8);ctx.fillText(model.date+' · '+number+' / '+model.pages.length,36,h-20);}
}
// Offscreen rendering does not depend on whether a hidden page canvas is visible.
function drawingContext(context) {
  const adapter={
    setFontSize(size){context.font=size+'px sans-serif';},
    setFillStyle(value){context.fillStyle=value;},setStrokeStyle(value){context.strokeStyle=value;},
    setLineWidth(value){context.lineWidth=value;},setTextAlign(value){context.textAlign=value;}
  };
  ['measureText','fillRect','strokeRect','fillText','beginPath','moveTo','lineTo','closePath','fill','stroke','save','translate','rotate','arc','restore','drawImage'].forEach(key=>{adapter[key]=(...args)=>context[key](...args);});
  return adapter;
}
function loadImage(canvas,src) {
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('日记插图读取超时，请重试')),15000);
    const image=canvas.createImage();
    image.onload=()=>{clearTimeout(timer);resolve(image);};
    image.onerror=()=>{clearTimeout(timer);reject(new Error('日记插图读取失败，请重试'));};
    // getImageInfo resolves both packaged files and WeChat local file paths.
    wx.getImageInfo({src,success:result=>{image.src=/^assets\//.test(result.path)?'/'+result.path:result.path;},fail:()=>{clearTimeout(timer);reject(new Error('日记插图读取失败，请重试'));}});
  });
}
function exportCanvas(canvas,width,height){
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error('日记图片生成超时，请重试')),20000);
    wx.canvasToTempFilePath({canvas,x:0,y:0,width:width*SCALE,height:height*SCALE,destWidth:width*SCALE,destHeight:Math.ceil(height*SCALE),fileType:'png',
      success:result=>{clearTimeout(timer);result.tempFilePath?resolve(result.tempFilePath):reject(new Error('日记图片没有生成，请重试'));},
      fail:()=>{clearTimeout(timer);reject(new Error('日记图片生成失败，请重试'));}});
  });
}
async function render(page,ticket,options){
  if(typeof wx.createOffscreenCanvas!=='function')throw new Error('请更新微信后保存日记图片');
  const canvas=wx.createOffscreenCanvas({type:'2d',width:WIDTH*SCALE,height:600*SCALE});
  const native=canvas.getContext('2d'),ctx=drawingContext(native);
  const measure=(text,size)=>{ctx.setFontSize(size);const result=ctx.measureText(text);return result&&Number.isFinite(result.width)&&result.width>0?result.width:fallbackWidth(text,size);};
  const model=buildLayout(ticket,measure,options);
  const image=await loadImage(canvas,options&&options.companionImage||'/assets/sticker-ticket.png');
  const character={path:image,width:image.width||53,height:image.height||60,stickers:{}};
  for(const sticker of model.diary.stickers){if(sticker.image&&sticker.kind!=='paw'&&!character.stickers[sticker.image])character.stickers[sticker.image]=await loadImage(canvas,sticker.image);}
  if(model.diary.companion.companionKey==='xiaowei')character.seal=await loadImage(canvas,'/assets/xiaowei-seal.png');
  const paths=[];
  for(let index=0;index<model.pages.length;index++){
    if(page&&page._unloaded)throw new Error('已离开日记页，保存已停止');
    const part=model.pages[index];canvas.width=WIDTH*SCALE;canvas.height=Math.ceil(part.height*SCALE);native.scale(SCALE,SCALE);
    drawPage(ctx,model,part,index+1,character);
    paths.push(await exportCanvas(canvas,WIDTH,part.height));
  }
  return paths;
}
module.exports = {render, buildLayout, wrapText, stats};
