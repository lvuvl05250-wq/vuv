'use strict';

function currentDate() { return new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10); }
function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(value + 'T00:00:00Z');
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
function ageAt(birthDate, today) {
  if (birthDate === '' || birthDate === null || birthDate === undefined) return null;
  const date = today === undefined ? currentDate() : today;
  if (!validDate(birthDate) || !validDate(date) || birthDate > date) throw new Error('出生日期无效或晚于今天');
  let age = Number(date.slice(0, 4)) - Number(birthDate.slice(0, 4));
  if (date.slice(5) < birthDate.slice(5)) age -= 1;
  return age;
}
function isAdult(birthDate, today) { const age = ageAt(birthDate, today); return age !== null && age >= 18; }

module.exports = {ageAt, isAdult};
