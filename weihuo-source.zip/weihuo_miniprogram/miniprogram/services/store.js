'use strict';

const catalog = require('./catalog');
const age = require('./age');
const period = require('./period');
const {normalizeFoodExclusions}=require('./food-exclusions');
const {validateMealLabel}=require('./saved-food-label');
const {validateVideo}=require('./action-video');
const PREFIX = 'weihuo:v1:';
let namespace = 'local', state = null, revision = 0, namespaceLoaded = false;
const listeners = [];
const clone = value => JSON.parse(JSON.stringify(value));
const fail = message => { throw new Error(message); };
const now = () => new Date().toISOString();
function today() { return new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10); }
function uid(prefix) { return (prefix || 'item') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10); }
function date(value) { if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || new Date(value + 'T00:00:00Z').toISOString().slice(0,10) !== value) fail('日期无效'); return value; }
function str(value, max, required) { if (typeof value !== 'string' || value.length > max || (required && !value.trim())) fail('文字内容为空或过长'); return value; }
function num(value, max) { if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > max) fail('数值超出有效范围'); return value; }
function bool(value) { if (typeof value !== 'boolean') fail('开关数据无效'); return value; }
function list(value, max) { if (!Array.isArray(value) || value.length > max) fail('列表数据无效或过多'); return value; }
function strings(value, max, length) { return list(value,max).map(v => str(v,length)); }
function choice(value, allowed) { if (allowed.indexOf(value) < 0) fail('选项无效'); return value; }
function object(value) { if (!value || typeof value !== 'object' || Array.isArray(value)) fail('记录格式无效'); return value; }
function ids(items) { const seen = {}; items.forEach(v => { str(v.id,100,true); if (seen[v.id]) fail('记录编号重复'); seen[v.id] = true; }); }
function defaultProfile(){return {name:'',avatarPath:'',adult:false,safetyAnswered:false,specialCondition:false,restrictions:[],allergies:'',foodExclusions:[],notes:'',goals:[],onboarded:false,birthDate:'',heightCm:null,weightKg:null,bodyFatPercent:null,exerciseHabit:'',avoidedActivities:'',bodyNotes:'',healthSummary:'',measurements:[]};}
function blank() { return {profile:defaultProfile(),periodRecords:[],periodSettings:{predictionMode:'history',cycleLengthDays:28,periodLengthDays:5,configured:false},days:{},customActions:[],meals:[],plans:[],reports:[],tickets:[],settings:{aiConsent:false,cloudConsent:false,reduceMotion:false,companion:'xiaowei',savedRecipes:[],foodPreferences:{taste:'',color:'',texture:'',temperature:'',scene:''},foodAvoid:[]}}; }
function dayDefault(d) { return {date:d,energy:3,scene:'office',scenes:['office'],minutes:20,carePreference:50,mood:'平静',note:'',actions:[]}; }
function validateAction(a) {
  object(a); strings(a.tags||[],30,80);strings(a.avoidWhen||[],30,80);str(a.minimumVersion,1000);str(a.stopSignal,1000);str(a.actionId,100);choice(a.source,['manual','catalog','ai','rule']);str(a.createdAt,40,true); str(a.id,100,true); str(a.title,200,true); date(a.date); num(a.durationMinutes,1440); strings(a.steps,30,1000);
  choice(a.status,['planned','completed','skipped']); choice(a.kind,['movement','care']);
  if(a.category!==undefined)choice(a.category,categories);if(a.audio)validateAudio(a.audio);if(a.video!==undefined&&a.video!==null)validateVideo(a.video);
  if(a.feedback) choice(a.feedback,['comfortable','neutral','uncomfortable']);
  if(a.timer) { bool(a.timer.running); num(a.timer.startedAt,1e14); num(a.timer.elapsedSeconds,86400); num(a.timer.durationSeconds,86400); choice(a.timer.mode,['full','minimum']); }
}
function validateMeal(m) { object(m); str(m.id,100,true); date(m.date); str(m.name,200,true); str(m.note,4000); str(m.photoPath,1000); if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(m.time)) fail('时间无效'); ['kcal','protein','carbs','fat'].forEach(k => { if(m[k]!==null) num(m[k],k==='kcal'?30000:3000); }); strings(m.tags,30,80); bool(m.confirmed); choice(m.nutritionSource,['manual','ai-estimate','label']);strings(m.labelPhotoPaths||[],2,1000);validateMealLabel(m); }
const categories=['movement','relaxation','meditation','focus','nature','senses','care'];
function publicHttps(value){str(value,2000,true);const match=/^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?#]|$)/i.exec(value);if(!match||/[\s\\#]/.test(value)||!match[1].includes('.')||/^\d+(?:\.\d+)*$/.test(match[1])||/(?:^|\.)(?:localhost|local|internal)$/.test(match[1]))fail('请使用公开的HTTPS资源地址');return value;}
function validateAudio(audio){object(audio);publicHttps(audio.url);num(audio.durationSeconds,7200);if(audio.durationSeconds<1)fail('音频时长无效');str(audio.transcript,12000);}
function validateTemplate(a){object(a);str(a.id,100,true);str(a.title,200,true);num(a.durationMinutes,180);if(a.durationMinutes<1)fail('行动至少1分钟');strings(a.steps,30,1000);choice(a.kind,['movement','care']);choice(a.category,categories);str(a.minimumVersion,1000);str(a.stopSignal,1000);strings(a.tags,30,80);strings(a.avoidWhen,30,80);list(a.scenes,7).forEach(v=>choice(v,['office','home','outdoor','commute','classroom','dorm','any']));list(a.energyLevels,3).forEach(v=>choice(v,['low','medium','high']));num(a.priority,5);if(a.priority<1)fail('行动权重无效');if(a.audio)validateAudio(a.audio);if(a.video!==undefined&&a.video!==null)validateVideo(a.video);[a.knowledgeCard,a.knowledge].filter(Boolean).forEach(k=>{str(k.title,200);str(k.body,5000);if(k.sourceTitle!==undefined)str(k.sourceTitle,300);if(k.sourceUrl)publicHttps(k.sourceUrl);});return a;}
function validateCloudCatalog(data){if(!data||typeof data.version!=='string'||!data.version||!Array.isArray(data.items)||!data.items.length)fail('云端行动库尚未发布');list(data.items,1000).forEach(validateTemplate);ids(data.items);if(JSON.stringify(data).length>700*1024)fail('云端行动库过大');return data;}
function getCatalog(){
  const cached=wx.getStorageSync('weihuo:catalog');let base=catalog;
  if(cached){try{base=validateCloudCatalog(cached).items;}catch(error){console.warn('Invalid shared catalog cache; using bundled actions');}}
  return clone(base.concat(getState().customActions));
}
function updateCloudCatalog(data){
  validateCloudCatalog(data);
  const cached=wx.getStorageSync('weihuo:catalog');
  if(cached&&JSON.stringify(cached)===JSON.stringify(data))return false;
  wx.setStorageSync('weihuo:catalog',clone(data));emit();return true;
}
function getCustomActions(){return getState().customActions;}
function validateCustom(a){validateTemplate(a);choice(a.source,['manual']);if(!Number.isInteger(a.priority))fail('行动权重无效');['tags','avoidWhen','scenes','energyLevels'].forEach(k=>{if(new Set(a[k]).size!==a[k].length)fail('行动选项重复');});const cached=wx.getStorageSync('weihuo:catalog');if(catalog.concat(cached&&Array.isArray(cached.items)?cached.items:[]).some(item=>item.id===a.id))fail('个人行动编号与共享库重复');}
function saveCustomAction(patch){return update(s=>{const old=patch.id&&s.customActions.find(a=>a.id===patch.id);if(patch.id&&!old)fail('这条个人行动已不存在');const a=Object.assign({id:uid('custom'),title:'',durationMinutes:3,steps:[],minimumVersion:'先做其中的一小步，就已经开始了',stopSignal:'如果感觉不舒服，随时停下',kind:'care',category:'care',tags:[],avoidWhen:[],scenes:['any'],energyLevels:['low','medium','high'],priority:3,source:'manual',createdAt:now()},old||{},patch,{updatedAt:now()});if(old)s.customActions[s.customActions.indexOf(old)]=a;else s.customActions.push(a);return a;});}
function hash(text){let value=0;for(let i=0;i<text.length;i++)value=(value*31+text.charCodeAt(i))>>>0;return value;}
function validateMeasurement(m){object(m);str(m.id,100,true);str(m.name,100,true);str(m.value,100,true);str(m.unit,60);date(m.date);choice(m.source,['manual','report']);str(m.reportId,100);if(m.sourceMetricKey===undefined)m.sourceMetricKey='';str(m.sourceMetricKey,600);if(m.source==='report'&&!m.reportId)fail('报告来源信息缺失');str(m.createdAt,40,true);}
function validate(s) {
  object(s); object(s.profile);s.profile=Object.assign(defaultProfile(),s.profile);const p=s.profile; str(p.name,60);str(p.avatarPath,1000); ['adult','safetyAnswered','specialCondition','onboarded'].forEach(k=>bool(p[k])); strings(p.restrictions,30,80); strings(p.goals,15,200); str(p.allergies,1000); str(p.notes,2000);
  if(p.birthDate){date(p.birthDate);if(p.birthDate>today())fail('出生日期不能晚于今天');}str(p.birthDate,10);p.adult=age.isAdult(p.birthDate,today());[['heightCm',30,300],['weightKg',1,700],['bodyFatPercent',0,100]].forEach(([k,min,max])=>{if(p[k]!==null){num(p[k],max);if(p[k]<min)fail('身体数据超出输入范围');}});str(p.exerciseHabit,2000);str(p.avoidedActivities,4000);str(p.bodyNotes,4000);str(p.healthSummary,8000);list(p.measurements,1000).forEach(validateMeasurement);ids(p.measurements);
  p.foodExclusions=normalizeFoodExclusions(p,p.foodExclusions);
  s.periodRecords=period.validateRecords(s.periodRecords,today());
  s.periodSettings=period.validateSettings(s.periodSettings);
  if(s.customActions===undefined)s.customActions=[];list(s.customActions,300).forEach(validateCustom);ids(s.customActions);
  object(s.days); if(Object.keys(s.days).length>730) fail('超过两年的记录，请先导出存档');
  const actionIds=[];
  Object.keys(s.days).forEach(k=>{ const d=object(s.days[k]); date(k); if(d.date!==k) fail('日记录日期不一致'); num(d.energy,5); if(d.energy<1) fail('精力无效'); choice(d.scene,['office','home','outdoor','commute','classroom','dorm','any']);if(d.scenes===undefined)d.scenes=[d.scene];list(d.scenes,7).forEach(x=>choice(x,['office','home','outdoor','commute','classroom','dorm','any']));if(!d.scenes.length||new Set(d.scenes).size!==d.scenes.length)fail('请选择活动涉及的地点');num(d.minutes,1440); if(d.carePreference!==undefined)num(d.carePreference,100); str(d.mood,100); str(d.note,4000); list(d.actions,100).forEach(a=>{validateAction(a);if(a.date!==k)fail('行动日期不一致');actionIds.push(a);}); }); ids(actionIds);
  list(s.meals,2000).forEach(validateMeal); ids(s.meals);
  list(s.plans,100).forEach(p=>{object(p);str(p.title,200,true);choice(p.type,['life','strength','aerobic']);choice(p.source,['manual','ai']);str(p.goal,2000);str(p.note,8000);const dates={};list(p.days,60).forEach(d=>{date(d.date);if(dates[d.date])fail('计划中日期重复');dates[d.date]=true;str(d.title,300,true);num(d.minutes,600);bool(d.done);str(d.details,5000);if(d.actionIds===undefined)d.actionIds=[];strings(d.actionIds,10,100);});});ids(s.plans);
  list(s.reports,100).forEach(r=>{object(r);date(r.date);str(r.title,200,true);str(r.note,4000);str(r.photoPath,1000);bool(r.confirmed);strings(r.restrictions,30,80);list(r.metrics,100).forEach(m=>{str(m.name,100,r.confirmed);str(m.value,100,r.confirmed);str(m.unit,60);str(m.reference,150);});});ids(s.reports);
  const dates={};list(s.tickets,730).forEach(t=>{object(t);date(t.date);if(dates[t.date])fail('票根日期重复');dates[t.date]=true;str(t.title,200,true);str(t.note,8000);str(t.mood,100);if(t.diary)t.diary=require('./diary-content').normalizeDiary(t.diary,t.companionKey);list(t.actions,100).forEach(a=>{validateAction(a);if(a.date!==t.date)fail('票根行动日期不一致');});list(t.meals,100).forEach(m=>{validateMeal(m);if(m.date!==t.date)fail('票根饮食日期不一致');});});ids(s.tickets);
  ['aiConsent','cloudConsent','reduceMotion'].forEach(k=>bool(s.settings[k]));
  if(s.settings.companion===undefined)s.settings.companion='xiaowei';choice(s.settings.companion,['xiaowei','cat','dachshund']);
  if(s.settings.savedRecipes===undefined)s.settings.savedRecipes=[];strings(s.settings.savedRecipes,100,100);if(new Set(s.settings.savedRecipes).size!==s.settings.savedRecipes.length)fail('收藏食谱重复');
  if(s.settings.foodPreferences===undefined)s.settings.foodPreferences={};object(s.settings.foodPreferences);
  ['taste','color','texture','temperature','scene'].forEach(k=>{if(s.settings.foodPreferences[k]===undefined)s.settings.foodPreferences[k]='';str(s.settings.foodPreferences[k],80);});
  if(s.settings.foodAvoid===undefined)s.settings.foodAvoid=[];strings(s.settings.foodAvoid,30,80);if(new Set(s.settings.foodAvoid).size!==s.settings.foodAvoid.length)fail('饮食避开选项重复');
  if(JSON.stringify(s).length>2500000) fail('记录容量较大，请先导出存档');
  return s;
}
function key() { return PREFIX + namespace; }
function init() {
  if(state) return;
  if(!namespaceLoaded){const active=wx.getStorageSync('weihuo:activeNamespace');if(typeof active==='string'&&/^account:[A-Za-z0-9_-]{1,128}$/.test(active))namespace=active;namespaceLoaded=true;}
  const stored = wx.getStorageSync(key());
  if (!stored) {state=blank();revision=0;return;}
  try { if(stored.schema!==1)fail('版本不兼容'); state=validate(stored.state); revision=stored.revision||0; }
  catch(e) { state=null;fail('本机记录读取失败，原数据已保留。请先在设置中导出原始记录，再恢复备份。'); }
}
function emit() { listeners.slice().forEach(fn=>{try{fn();}catch(e){console.warn('View refresh failed');}}); }
function commit(next) { validate(next); const nextRevision=revision+1; try {wx.setStorageSync(key(),{schema:1,state:next,revision:nextRevision});}catch(e){fail('保存失败，可能本机空间不足。本次修改未保存，请导出记录后重试。');} state=next;revision=nextRevision;emit(); }
function update(fn) { init();const next=clone(state);const result=fn(next);commit(next);return clone(result===undefined?next:result); }
function getState(){init();return clone(state);}
function getProfile(){const p=getState().profile;p.adult=age.isAdult(p.birthDate,today());return p;}
function saveProfile(patch){return update(s=>{Object.assign(s.profile,patch);s.profile.adult=age.isAdult(s.profile.birthDate,today());return s.profile;});}
function getPeriodSettings(){return getState().periodSettings;}
function savePeriodSettings(patch){return update(s=>{s.periodSettings=period.validateSettings(Object.assign({},s.periodSettings,patch));return s.periodSettings;});}
function getPeriodRecords(){return getState().periodRecords;}
function replacePeriodRecords(next,expected){return update(s=>{const current=period.validateRecords(s.periodRecords,today()),previous=period.validateRecords(expected,today());if(JSON.stringify(current)!==JSON.stringify(previous))fail('经期记录已变化，请重新打开后再修改');s.periodRecords=period.validateRecords(next,today());return s.periodRecords;});}
function getDay(d){d=date(d||today());const s=getState();return s.days[d]||dayDefault(d);}
function saveDay(patch,d){d=date(d||today());return update(s=>{const current=s.days[d]||dayDefault(d);const safe=Object.assign({},patch);delete safe.actions;delete safe.date;if(safe.scenes!==undefined){safe.scene=safe.scenes[0];}else if(safe.scene!==undefined){safe.scenes=[safe.scene];}s.days[d]=Object.assign(current,safe);return s.days[d];});}
function eligible(action,s){
  if(action.kind==='movement'&&s.profile.specialCondition)return false;
  if((action.avoidWhen||[]).some(t=>s.profile.restrictions.indexOf(t)>=0))return false;
  const avoided=s.profile.avoidedActivities||'',content=[action.title].concat(action.tags||[]).join(' ');
  const families=[['跑步','慢跑','跑动'],['跳跃','跳绳','开合跳'],['深蹲','蹲起'],['瑜伽'],['冥想'],['散步','走路','步行'],['拉伸','伸展'],['俯卧撑'],['游泳'],['骑行','自行车']];
  if((avoided&&avoided.includes(action.title))||families.some(words=>words.some(w=>avoided.includes(w))&&words.some(w=>content.includes(w))))return false;
  const cutoff=new Date(Date.now()-7*86400000).toISOString().slice(0,10);
  const recent=Object.keys(s.days).filter(d=>d>=cutoff).reduce((all,d)=>all.concat(s.days[d].actions),[]);
  return !recent.some(a=>a.feedback==='uncomfortable'&&(a.actionId===action.id||(a.tags||[]).some(t=>(action.tags||[]).indexOf(t)>=0)));
}
function recommend(count){
 const s=getState(),d=getDay(),energy=d.energy<=2?'low':d.energy>=4?'high':'medium',pool=getCatalog();
 const candidates=pool.filter(a=>eligible(a,s)&&!d.actions.some(r=>r.actionId===a.id)&&a.durationMinutes<=d.minutes&&((d.scenes||[d.scene]).some(scene=>a.scenes.indexOf(scene)>=0)||a.scenes.indexOf('any')>=0)&&a.energyLevels.indexOf(energy)>=0);
 const score=a=>{const preferred=a.kind==='movement'?d.carePreference/100:1-d.carePreference/100;return hash(today()+a.id+namespace)%1000/1000+preferred*.8+(a.source==='manual'?.25:0);};
 candidates.sort((a,b)=>score(b)-score(a));const chosen=[],seen={};for(const a of candidates){if(!seen[a.category]){chosen.push(a);seen[a.category]=true;}if(chosen.length>=(count||3))break;}for(const a of candidates){if(chosen.length>=(count||3))break;if(!chosen.some(x=>x.id===a.id))chosen.push(a);}return clone(chosen);
}
function getPlanningCandidates(){const s=getState(),pool=getCatalog().filter(a=>eligible(a,s));const rank=(a,b)=>(hash(today()+b.id+namespace)%10000)-(hash(today()+a.id+namespace)%10000);const personal=pool.filter(a=>a.source==='manual').sort(rank).slice(0,20);const shared=pool.filter(a=>a.source!=='manual').sort(rank).slice(0,80-personal.length);return clone(personal.concat(shared));}
function addAction(action,d){d=date(d||today());const all=getCatalog();const input=typeof action==='string'?all.find(a=>a.id===action):action;if(!input)fail('找不到这条行动');return update(s=>{const fromCatalog=input.id&&all.find(a=>a.id===input.id);const a=fromCatalog||input;if(!eligible(a,s))fail('这条行动与已填写的身体边界或近期不适反馈冲突，请换一条');const day=s.days[d]||(s.days[d]=dayDefault(d));const existing=day.actions.find(r=>r.actionId===a.id&&r.status==='planned');if(existing)return existing;const r={id:uid('action'),actionId:fromCatalog?a.id:'',title:a.title,durationMinutes:Number(a.durationMinutes),steps:a.steps||[],minimumVersion:a.minimumVersion||'做到你愿意的程度即可',stopSignal:a.stopSignal||'感觉不舒服时随时停下',kind:a.kind||'care',category:a.category||(a.kind==='movement'?'movement':'care'),tags:a.tags||[],avoidWhen:a.avoidWhen||[],status:'planned',feedback:'',createdAt:now(),date:d,source:fromCatalog&&a.source!=='manual'?'catalog':'manual'};if(a.audio)r.audio=clone(a.audio);r.video=a.video?validateVideo(a.video):null;day.actions.push(r);return r;});}
function locate(s,id){for(const d of Object.keys(s.days)){const a=s.days[d].actions.find(r=>r.id===id);if(a)return a;}fail('这条行动已不存在');}
function removeAction(id){return update(s=>{const a=locate(s,id);s.days[a.date].actions=s.days[a.date].actions.filter(item=>item.id!==id);return a;});}
function getAction(id){try{return clone(locate(getState(),id));}catch(e){return null;}}
function setActionStatus(id,status,feedback){return update(s=>{const a=locate(s,id);choice(status,['planned','completed','skipped']);a.status=status;a.feedback=feedback||'';if(status!=='planned')delete a.timer;return a;});}
function saveActionTimer(id,timer){return update(s=>{const a=locate(s,id);if(a.status!=='planned')fail('已结束的行动不能继续计时');if(timer.running&&!eligible(a,s))fail('当前身体边界或近期不适反馈不适合继续这条行动，请换一条');a.timer=clone(timer);return a;});}
function getMeasurements(){return getProfile().measurements.slice().sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt.localeCompare(a.createdAt));}
function saveMeasurement(patch){return update(s=>{const arr=s.profile.measurements;const old=patch.id&&arr.find(m=>m.id===patch.id);if(patch.id&&!old)fail('这条测量记录已不存在');const m=Object.assign({id:uid('measurement'),name:'',value:'',unit:'',date:today(),source:'manual',reportId:'',sourceMetricKey:'',createdAt:now()},old||{},patch);m.value=String(m.value);if(old)arr[arr.indexOf(old)]=m;else arr.push(m);return m;});}
function deleteMeasurement(id){return update(s=>{s.profile.measurements=s.profile.measurements.filter(m=>m.id!==id);});}
function importReportMeasurements(id){return update(s=>{const report=s.reports.find(r=>r.id===id);if(!report||!report.confirmed)fail('请先核对并确认报告，再登记到个人档案');const added=[];report.metrics.forEach(metric=>{const sourceMetricKey=JSON.stringify([id,metric.name,metric.value,metric.unit,report.date]);if(s.profile.measurements.some(m=>m.sourceMetricKey===sourceMetricKey||(!m.sourceMetricKey&&m.reportId===id&&m.name===metric.name&&m.value===metric.value&&m.unit===metric.unit&&m.date===report.date)))return;const m={id:uid('measurement'),name:metric.name,value:metric.value,unit:metric.unit,date:report.date,source:'report',reportId:id,sourceMetricKey,createdAt:now()};s.profile.measurements.push(m);added.push(m);});return added;});}
function getMeals(d){return getState().meals.filter(m=>!d||m.date===d).sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));}
function saveMeal(patch){return update(s=>{const old=patch.id&&s.meals.find(m=>m.id===patch.id);if(patch.id&&!old)fail('这条饮食记录已不存在');const m=Object.assign({id:uid('meal'),date:today(),time:new Date(Date.now()+8*3600000).toISOString().slice(11,16),name:'',note:'',photoPath:'',labelPhotoPaths:[],foodLabel:null,kcal:null,protein:null,carbs:null,fat:null,nutritionSource:'manual',tags:[],confirmed:true,createdAt:now()},old||{},patch,{updatedAt:now()});if(old)s.meals[s.meals.indexOf(old)]=m;else s.meals.push(m);return m;});}
function remove(collection,id){return update(s=>{if(!s[collection].some(x=>x.id===id))fail('这条记录已不存在');s[collection]=s[collection].filter(x=>x.id!==id);});}
function savePlan(patch){return update(s=>{const old=patch.id&&s.plans.find(p=>p.id===patch.id);if(patch.id&&!old)fail('计划已不存在');const p=Object.assign({id:uid('plan'),title:'',type:'life',goal:'',source:'manual',days:[],note:'',createdAt:now()},old||{},patch);p.days=p.days.map(d=>Object.assign({done:false,details:'',actionIds:[]},d));if(old)s.plans[s.plans.indexOf(old)]=p;else s.plans.push(p);return p;});}
function saveReport(patch){return update(s=>{const old=patch.id&&s.reports.find(r=>r.id===patch.id);if(patch.id&&!old)fail('报告已不存在');const r=Object.assign({id:uid('report'),title:'我的记录',date:today(),photoPath:'',confirmed:false,metrics:[],restrictions:[],note:'',createdAt:now()},old||{},patch,{updatedAt:now()});r.metrics=r.metrics.map(m=>({name:m.name,value:String(m.value),unit:m.unit||'',reference:m.reference||''}));if(old)s.reports[s.reports.indexOf(old)]=r;else s.reports.push(r);return r;});}
function sealTicket(d,note,title){d=date(d||today());return update(s=>{const old=s.tickets.find(t=>t.date===d);if(old)return old;const day=s.days[d]||dayDefault(d);const actions=day.actions.filter(a=>a.status==='completed');const meals=s.meals.filter(m=>m.date===d&&m.confirmed);if(!actions.length&&!meals.length&&!day.note&&!note)fail('先留下一条行动、饮食或感受，再收进日记吧');const t={id:uid('ticket'),date:d,title:title||'这一点点，也算数。',note:note||day.note,actions:clone(actions),meals:clone(meals),mood:day.mood,authorName:s.profile.name,companionKey:s.settings.companion,createdAt:now()};s.tickets.push(t);return t;});}
function saveDiary(d,diary,note){d=date(d||today());return update(s=>{const day=s.days[d]||dayDefault(d),old=s.tickets.find(t=>t.date===d);const content=require('./diary-content').normalizeDiary(diary,s.settings.companion);if(!content.paragraphs.length&&!String(note||'').trim())fail('先写下一句日记吧');const t=Object.assign({},old||{id:uid('ticket'),date:d,createdAt:now()},{title:content.title||'今天的日记',note:String(note||''),diary:content,actions:clone(day.actions.filter(a=>a.status==='completed')),meals:clone(s.meals.filter(m=>m.date===d&&m.confirmed)),mood:day.mood,authorName:s.profile.name,companionKey:s.settings.companion,updatedAt:now()});if(old)s.tickets[s.tickets.indexOf(old)]=t;else s.tickets.push(t);return t;});}
function getTickets(){return getState().tickets.sort((a,b)=>b.date.localeCompare(a.date));}
function getWeekActivity(reference){const current=date(reference||today()),s=getState(),first=new Date(current+'T00:00:00Z');first.setUTCDate(first.getUTCDate()-((first.getUTCDay()+6)%7));const labels=['一','二','三','四','五','六','日'];return labels.map((label,index)=>{const d=new Date(first);d.setUTCDate(d.getUTCDate()+index);const key=d.toISOString().slice(0,10),day=s.days[key],ticket=s.tickets.find(t=>t.date===key);const actions=day?day.actions.filter(a=>a.status==='completed').length:0,meals=s.meals.filter(m=>m.date===key&&m.confirmed).length,note=!!((day&&day.note)||(ticket&&ticket.note));const count=actions+meals+(note?1:0);return {date:key,label,number:d.getUTCDate(),actions,meals,count,level:Math.min(3,count),stamped:count>0,isToday:key===today(),future:key>today(),sealed:!!ticket};});}
function getTicket(d){return getTickets().find(t=>t.date===(d||today()))||null;}
function getSettings(){return getState().settings;}
function saveSettings(patch){return update(s=>{Object.assign(s.settings,patch);return s.settings;});}
function exportData(){return JSON.stringify({app:'weihuo',schema:1,exportedAt:now(),state:getState()},null,2);}
function restoreData(text){let data;try{data=JSON.parse(text);}catch(e){fail('不是有效的 JSON 备份');}if(data.app!=='weihuo'||data.schema!==1)fail('请使用微活原生小程序导出的备份');const restored=validate(data.state);restored.settings.aiConsent=false;restored.settings.cloudConsent=false;commit(clone(restored));}
function switchAccount(openid){if(!/^[A-Za-z0-9_-]{1,128}$/.test(openid))fail('账号标识无效');const old={namespace,state,revision};namespace='account:'+openid;namespaceLoaded=true;state=null;try{init();wx.setStorageSync('weihuo:activeNamespace',namespace);}catch(e){namespace=old.namespace;state=old.state;revision=old.revision;throw e;}emit();}
function useLocal(){const old={namespace,state,revision};namespace='local';namespaceLoaded=true;state=null;try{init();wx.setStorageSync('weihuo:activeNamespace',namespace);}catch(e){namespace=old.namespace;state=old.state;revision=old.revision;throw e;}emit();}
function replaceFromCloud(next){const local=getState();const copy=clone(next);copy.profile.avatarPath=local.profile.avatarPath||'';['meals','reports'].forEach(k=>copy[k].forEach(item=>{const old=local[k].find(x=>x.id===item.id);item.photoPath=old?old.photoPath:'';if(k==='meals')item.labelPhotoPaths=old?(old.labelPhotoPaths||[]).slice():[];}));copy.tickets.forEach(t=>{const old=local.tickets.find(x=>x.id===t.id);t.meals.forEach(m=>{const original=old&&old.meals.find(x=>x.id===m.id);m.photoPath=original?original.photoPath||'':'';m.labelPhotoPaths=original?(original.labelPhotoPaths||[]).slice():[];});});copy.settings.aiConsent=local.settings.aiConsent;copy.settings.cloudConsent=local.settings.cloudConsent;commit(copy);}
module.exports={init,today,uid,getState,getProfile,saveProfile,getPeriodRecords,getPeriodSettings,savePeriodSettings,replacePeriodRecords,getMeasurements,saveMeasurement,deleteMeasurement,importReportMeasurements,isPristine:()=>JSON.stringify(getState())===JSON.stringify(blank()),getDay,saveDay,getCatalog,getPlanningCandidates,getCustomActions,saveCustomAction,deleteCustomAction:id=>remove('customActions',id),updateCloudCatalog,isActionEligible:a=>eligible(a,getState()),recommend,addAction,getAction,removeAction,setActionStatus,saveActionTimer,getMeals,saveMeal,deleteMeal:id=>remove('meals',id),getPlans:()=>getState().plans.slice().reverse(),savePlan,deletePlan:id=>remove('plans',id),getReports:()=>getState().reports.slice().sort((a,b)=>b.date.localeCompare(a.date)),saveReport,deleteReport:id=>remove('reports',id),sealTicket,saveDiary,getWeekActivity,getTickets,getTicket,deleteTicket:d=>{const t=getTicket(d);if(t)remove('tickets',t.id);},getSettings,saveSettings,clearAll:()=>commit(blank()),exportData,restoreData,subscribe:fn=>{listeners.push(fn);return()=>{const i=listeners.indexOf(fn);if(i>=0)listeners.splice(i,1);};},switchAccount,useLocal,replaceFromCloud,getRevision:()=>revision,getNamespace:()=>namespace,validate,exportRaw:()=>JSON.stringify(wx.getStorageSync(key()))};
