// Editorial content: durations are optional estimates, never minimum quotas.
module.exports = [
  {
    "id": "office_water_window_break",
    "title": "喝水看窗外三分钟",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "拿起水杯，小口喝几口，不用一次喝完",
      "让视线越过屏幕，找窗外最远的一处轮廓",
      "剩下的时间看看那里，自然眨眼，想回到工作时就回来"
    ],
    "minimumVersion": "喝一口水，看一眼窗外也算",
    "stopSignal": "若吞咽不适、头晕或身体感觉变差，立即停下并坐稳",
    "tags": [
      "hydration",
      "eye-rest",
      "quiet"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_office_water_window_break",
      "topic": "action",
      "title": "饮水可以分散在一天里",
      "body": "NHS 建议在一天里规律饮水。这里的一小口是日常补水的一部分，不需要在这次停顿里喝完一整杯。",
      "sourceRefs": [
        "office_water_window_break"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NHS · Water, drinks and hydration",
      "sourceUrl": "https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/water-drinks-nutrition/"
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "office_shoulder_release",
    "title": "工位肩颈放松",
    "actionKind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "双脚踩地，手臂放在身体两侧",
      "肩膀轻轻提起约两秒，再放下，慢慢做五次",
      "下巴留在自然位置，停一会儿感受肩膀有没有松一点"
    ],
    "minimumVersion": "轻轻提肩再放下一次",
    "stopSignal": "出现刺痛、麻木、眩晕或颈部不适加重时立刻停止",
    "tags": [
      "neck-care",
      "shoulder-care",
      "seated"
    ],
    "avoidWhen": [
      "neck",
      "shoulder"
    ],
    "priority": 2,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_office_shoulder_release",
      "topic": "action",
      "title": "一个小窍门",
      "body": "手臂不用跟着用力；想象只是把肩膀放回舒服的位置。",
      "sourceRefs": [
        "office_shoulder_release"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "office_corridor_walk",
    "title": "久坐后走三分钟",
    "actionKind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "离开椅子，挑一段没有杂物、不会挡人的过道",
      "按能轻松说话的速度走，两三分钟内都可以折返",
      "回到座位，双脚放稳，再决定接着做什么"
    ],
    "minimumVersion": "站起来，走十步就回来",
    "stopSignal": "膝踝疼痛、胸闷、气短、头晕或步伐不稳时立即停止并休息",
    "tags": [
      "walk",
      "circulation",
      "standing"
    ],
    "avoidWhen": [
      "knee",
      "ankle",
      "dizziness"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_office_corridor_walk",
      "topic": "action",
      "title": "走一小段也计入活动",
      "body": "WHO 说任何量的身体活动都比完全不动好，活动可以累计。走到过道再回来，是今天的一小段活动，不用把三分钟当门槛。",
      "sourceRefs": [
        "office_corridor_walk"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "office_screen_reset",
    "title": "让眼睛离开屏幕一分钟",
    "actionKind": "nourishment",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "双手离开键盘，把目光送到窗外或房间较远处",
      "轻轻看二十秒，让眼睛自然眨动",
      "把屏幕反光或亮度调到舒服的位置，再回来"
    ],
    "minimumVersion": "从屏幕上移开目光二十秒",
    "stopSignal": "视物模糊、头痛明显或眼部疼痛时停止并休息",
    "tags": [
      "eye-rest",
      "screen-break",
      "seated"
    ],
    "avoidWhen": [
      "headache"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_office_screen_reset",
      "topic": "action",
      "title": "给近距离用眼一个停顿",
      "body": "看屏幕时，人常常眨眼更少。AAO 建议规律休息；这次把目光从近处移开，也给自然眨眼留一点时间。",
      "sourceRefs": [
        "office_screen_reset"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "AAO · Digital eye strain",
      "sourceUrl": "https://aao.org/eye-health/tips-prevention/blue-light-digital-eye-strain"
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "office_desk_breath",
    "title": "腹式呼吸三次",
    "actionKind": "nourishment",
    "durationMinutes": 1,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐着或靠着，一只手轻放腹部，不往下压",
      "观察三次平常的呼吸，看看手有没有随之轻轻起伏",
      "呼吸保持原来的大小，结束后把手放回腿上"
    ],
    "minimumVersion": "只留意一次呼吸",
    "stopSignal": "出现胸闷、憋气、头晕、麻木或不适加重时立即停止，恢复平常呼吸",
    "tags": [
      "breath",
      "quiet",
      "seated"
    ],
    "avoidWhen": [
      "dizziness",
      "pain"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_office_desk_breath",
      "topic": "action",
      "title": "呼吸不必用力做大",
      "body": "NHS 的呼吸练习强调轻柔、舒适，不强迫自己吸得很深。观察腹部起伏即可，不需要压住手掌或憋气。",
      "sourceRefs": [
        "office_desk_breath"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NHS · Breathing exercises for stress",
      "sourceUrl": "https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/"
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "classroom_ankle_pump",
    "title": "课桌下脚踝活动",
    "actionKind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐在椅子上，一只脚往前挪一点，脚跟轻落地",
      "脚尖向前再回勾，慢慢做六次，幅度小也可以",
      "换另一只脚做六次，然后把双脚放回地面"
    ],
    "minimumVersion": "每只脚各活动一次",
    "stopSignal": "脚踝疼痛、麻木、肿胀或活动受限时停止",
    "tags": [
      "ankle-care",
      "seated",
      "quiet"
    ],
    "avoidWhen": [
      "ankle"
    ],
    "priority": 2,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_classroom_ankle_pump",
      "topic": "action",
      "title": "一个小窍门",
      "body": "让脚踝活动，膝盖不必跟着来回晃；鞋子卡住时就缩小幅度。",
      "sourceRefs": [
        "classroom_ankle_pump"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "classroom_posture_note",
    "title": "把本子挪到顺手的位置",
    "actionKind": "nourishment",
    "durationMinutes": 2,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "把正在用的本子挪到看得清、手够得到的地方",
      "双脚放到舒服的位置；想靠一会儿时，就让椅背托住身体",
      "在这一页圈一个接下来想听懂的词，先到这里"
    ],
    "minimumVersion": "先把本子往自己这边挪一点",
    "stopSignal": "颈背疼痛或麻木加重时停止调整并告诉老师或身边的人",
    "tags": [
      "posture",
      "neck-care",
      "back-care",
      "seated"
    ],
    "avoidWhen": [
      "neck",
      "back"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_classroom_posture_note",
      "topic": "action",
      "title": "一个小窍门",
      "body": "只调整正在用的这一本，眼前要看的内容更顺手；整张桌子不用跟着一起重排。",
      "sourceRefs": [
        "classroom_posture_note"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "focus",
    "source": "catalog"
  },
  {
    "id": "classroom_aisle_walk",
    "title": "课间走一小圈",
    "actionKind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "课间到了，挑教室外侧不拥挤的一小段路",
      "走出去看看另一边的光线，慢慢走一圈",
      "上课前回来，给自己留几秒坐稳"
    ],
    "minimumVersion": "走到教室门口再回来",
    "stopSignal": "膝踝疼痛、胸闷、气短或头晕时立即停下并求助",
    "tags": [
      "walk",
      "circulation",
      "standing"
    ],
    "avoidWhen": [
      "knee",
      "ankle",
      "dizziness"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_classroom_aisle_walk",
      "topic": "action",
      "title": "走路也算身体活动",
      "body": "WHO 提到，各种活动都计入累计。课间走到门口再回来，就是一段走路；回来还能留几秒坐稳，不必赶路。",
      "sourceRefs": [
        "classroom_aisle_walk"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "classroom_eye_distance",
    "title": "课间看远处",
    "actionKind": "nourishment",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把目光从课本或投影上移开",
      "看看窗外或教室另一头，停留二十秒",
      "自然眨眨眼，再翻回刚刚读到的地方"
    ],
    "minimumVersion": "看教室另一头一小会儿",
    "stopSignal": "头痛、眼痛或视物异常时停止并休息",
    "tags": [
      "eye-rest",
      "screen-break",
      "quiet"
    ],
    "avoidWhen": [
      "headache"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_classroom_eye_distance",
      "topic": "action",
      "title": "一个小窍门",
      "body": "远眺时不用找字读，把视线留给较远的大轮廓。",
      "sourceRefs": [
        "classroom_eye_distance"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "classroom_quiet_breath",
    "title": "在座位上留意几口呼吸",
    "actionKind": "nourishment",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "双脚落地，手放在腿上；眼睛睁着或轻轻垂下都可以",
      "留意四次自然呼吸；走神了，就从下一口接着看",
      "再听一下教室里的声音，回到接下来的课堂"
    ],
    "minimumVersion": "留意一次呼吸，再听一个声音",
    "stopSignal": "头晕、胸闷、呼吸不适或焦虑加重时立即停止并恢复平常呼吸",
    "tags": [
      "breath",
      "quiet",
      "seated"
    ],
    "avoidWhen": [
      "dizziness",
      "pain"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_classroom_quiet_breath",
      "topic": "action",
      "title": "注意当下，不必清空脑袋",
      "body": "NCCIH 把呼吸列为冥想可以专注的感受之一，也把正念描述为留意当下、不急着评判。走神时回到一口呼吸即可。",
      "sourceRefs": [
        "classroom_quiet_breath"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NCCIH · Meditation and mindfulness",
      "sourceUrl": "https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety"
    },
    "category": "meditation",
    "source": "catalog"
  },
  {
    "id": "dorm_bed_stretch",
    "title": "床边轻轻伸展",
    "actionKind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐在床沿，双脚踩地，给手臂留一点空间",
      "双手缓缓向前伸，到舒服的位置就收回来",
      "做两次自然呼吸，手臂垂下休息"
    ],
    "minimumVersion": "双手往前伸一下就收回",
    "stopSignal": "腰背、颈部或肩部出现疼痛、麻木、眩晕时立即停止",
    "tags": [
      "stretch",
      "seated",
      "gentle"
    ],
    "avoidWhen": [
      "back",
      "neck",
      "shoulder"
    ],
    "priority": 2,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_dorm_bed_stretch",
      "topic": "action",
      "title": "一个小窍门",
      "body": "伸手时不用含胸追得更远，手指能到哪里就停在哪里。",
      "sourceRefs": [
        "dorm_bed_stretch"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "alwaysPresent": true,
    "habitTemplate": "wake",
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "dorm_tidy_small_zone",
    "title": "整理一个小角落",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "挑床头或桌面巴掌大的一块地方",
      "从里面选五件东西，逐件放回常用的位置",
      "剩下没整理的先留着，看看刚空出的这一小块"
    ],
    "minimumVersion": "只收好一件东西",
    "stopSignal": "弯腰不适、膝背疼痛、气短或头晕时停止并坐下",
    "tags": [
      "tidy",
      "standing",
      "small-step"
    ],
    "avoidWhen": [
      "back",
      "knee",
      "dizziness"
    ],
    "priority": 1,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_dorm_tidy_small_zone",
      "topic": "action",
      "title": "一个小窍门",
      "body": "给这次整理画一个边界，比临时把全部东西翻出来更容易结束。",
      "sourceRefs": [
        "dorm_tidy_small_zone"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "dorm_laundry_fold",
    "title": "坐着叠三件衣物",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "挑三件准备收起来的衣物，放在身前",
      "按自己习惯的方式一件件叠好，手腕不必绷直",
      "把它们放到之后拿取方便的地方"
    ],
    "minimumVersion": "叠好一件就停",
    "stopSignal": "肩腕疼痛、麻木或疲劳明显时停止，剩下的下次再做",
    "tags": [
      "tidy",
      "seated",
      "gentle"
    ],
    "avoidWhen": [
      "shoulder",
      "wrist"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_dorm_laundry_fold",
      "topic": "action",
      "title": "一个小窍门",
      "body": "常用衣物放在容易拿到的位置，叠法不需要统一成展示柜。",
      "sourceRefs": [
        "dorm_laundry_fold"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "dorm_window_air",
    "title": "开一道窗，听听室外",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "先看看天气、室外空气和窗户条件；合适时把窗开一小道缝",
      "坐在旁边，听听窗外有没有鸟声、车声，感觉一下风从哪边来",
      "留一两分钟；冷了、吵了或空气不舒服，就把窗关小"
    ],
    "minimumVersion": "不方便开窗，就隔窗听一听外面的声音",
    "stopSignal": "头晕、胸闷、过冷过热或环境不安全时立即停止并关窗",
    "tags": [
      "air",
      "quiet",
      "reset"
    ],
    "avoidWhen": [
      "dizziness",
      "pain"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_dorm_window_air",
      "topic": "action",
      "title": "一个小窍门",
      "body": "风和声音都是现成的观察线索；挑一样留意，就能给这次换景一个具体落点。",
      "sourceRefs": [
        "dorm_window_air"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "nature",
    "source": "catalog"
  },
  {
    "id": "dorm_wall_push",
    "title": "墙边轻推",
    "actionKind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "面向稳固墙面，双手放在胸口高度",
      "保持舒服的斜站姿，轻轻推墙三次，呼吸照常",
      "慢慢回到站直的位置，让手臂垂下来"
    ],
    "minimumVersion": "轻推一次墙，再站稳",
    "stopSignal": "手腕、肩膀疼痛，胸闷或头晕时立即停止并坐下",
    "tags": [
      "strength",
      "standing",
      "gentle"
    ],
    "avoidWhen": [
      "wrist",
      "shoulder",
      "dizziness"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_dorm_wall_push",
      "topic": "action",
      "title": "墙推是一段小小的活动",
      "body": "WHO 将身体产生能量消耗的动作都算作身体活动；几下墙推也给久坐的身体一个换换方向的小机会。",
      "sourceRefs": [
        "dorm_wall_push"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "home_kitchen_water",
    "title": "倒一杯水",
    "actionKind": "nourishment",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "拿一个容易握住的杯子，倒入温度合适的水",
      "慢慢喝几口，想停就停",
      "把杯子放在伸手可取、不会碰倒的位置"
    ],
    "minimumVersion": "倒一点水，喝一口",
    "stopSignal": "吞咽不适、头晕或站立不稳时立即坐下并停止",
    "tags": [
      "hydration",
      "small-step",
      "quiet"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_home_kitchen_water",
      "topic": "action",
      "title": "一个小窍门",
      "body": "杯子不用倒满，留一点空位，拿取时就不容易洒出来。",
      "sourceRefs": [
        "home_kitchen_water"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "home_legs_up",
    "title": "靠坐放松双腿",
    "actionKind": "nourishment",
    "durationMinutes": 2,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "找个有靠背的位置坐下，让背部有所支撑",
      "把双腿放在舒服的高度，脚能落地也很好",
      "停留一两分钟，留意五次自然呼吸后慢慢起身"
    ],
    "minimumVersion": "靠住椅背，歇一小会儿",
    "stopSignal": "腰髋疼痛、麻木、呼吸不适或头晕时立即恢复舒服的坐姿",
    "tags": [
      "rest",
      "seated",
      "gentle"
    ],
    "avoidWhen": [
      "hip",
      "back",
      "dizziness"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_home_legs_up",
      "topic": "action",
      "title": "一个小窍门",
      "body": "不用把腿举高；脚下有舒服的落点，比追求某个姿势更实用。",
      "sourceRefs": [
        "home_legs_up"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "home_room_walk",
    "title": "饭后慢走一圈",
    "actionKind": "movement",
    "durationMinutes": 5,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "饭后如果身体愿意动，就沿室内空着的通道出发",
      "用能聊天的速度走几分钟，转弯时放慢一点",
      "走回起点；饱胀或不想继续就提前坐下"
    ],
    "minimumVersion": "走到房间另一头就回来",
    "stopSignal": "腹部明显不适、头晕、胸闷、气短或疼痛时立即停止，坐到安全处",
    "tags": [
      "walk",
      "circulation",
      "standing"
    ],
    "avoidWhen": [
      "knee",
      "ankle",
      "dizziness"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_home_room_walk",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把路线留在近处，随时能坐下，才不用为了走满时间勉强自己。",
      "sourceRefs": [
        "home_room_walk"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "home_table_reset",
    "title": "清出一块桌面",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在桌面选一块下一次真会用到的地方",
      "把那里三件暂时不用的物品归位",
      "擦一下或直接留空，让这块位置准备好"
    ],
    "minimumVersion": "把一件不常用的东西挪开",
    "stopSignal": "弯腰不适、肩背疼痛、气短或头晕时停止并休息",
    "tags": [
      "tidy",
      "small-step",
      "standing"
    ],
    "avoidWhen": [
      "back",
      "shoulder",
      "dizziness"
    ],
    "priority": 1,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_home_table_reset",
      "topic": "action",
      "title": "一个小窍门",
      "body": "留白不一定要大，能放下一只杯子或一本书就已经够用。",
      "sourceRefs": [
        "home_table_reset"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "home_music_move",
    "title": "跟一首歌轻轻动",
    "actionKind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在自己常用的播放器选一首短歌，脚边留出空间",
      "听着歌轻摆手臂或轻轻换重心，不用跟上每一拍",
      "听到约三分钟或歌曲结束就停，坐着晃晃手也可以"
    ],
    "minimumVersion": "只跟一小段旋律动一动",
    "stopSignal": "疼痛、胸闷、心慌、头晕或失去平衡时立即停止并坐下",
    "tags": [
      "music",
      "movement",
      "joy"
    ],
    "avoidWhen": [
      "knee",
      "ankle",
      "dizziness",
      "pain"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_home_music_move",
      "topic": "action",
      "title": "一个小窍门",
      "body": "动作可以跟不上音乐，也可以只动手指；不需要跳成完整舞步。",
      "sourceRefs": [
        "home_music_move"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "outdoor_sunlight_stand",
    "title": "看看阳光落在哪里",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "outdoor",
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "找一处明亮但不刺眼、旁边有阴凉可退的位置",
      "看看光落在墙上、地面或树叶上，坐着站着都行",
      "待一会儿；觉得热或眼睛不舒服，就回阴凉处"
    ],
    "minimumVersion": "隔着窗，找一块被光照亮的地方",
    "stopSignal": "皮肤灼热、头晕、恶心、眼睛刺痛或体温不适时立即离开日光并休息",
    "tags": [
      "light",
      "quiet",
      "reset"
    ],
    "avoidWhen": [
      "dizziness",
      "headache"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_outdoor_sunlight_stand",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把目光放在被照亮的物体上，既能看看光影，也不用盯着太阳。",
      "sourceRefs": [
        "outdoor_sunlight_stand"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "nature",
    "source": "catalog"
  },
  {
    "id": "outdoor_slow_walk",
    "title": "户外慢走十二分钟",
    "actionKind": "movement",
    "durationMinutes": 12,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "选一条熟悉平坦、随时方便折返的路",
      "轻松走约六分钟，再按自己的节奏慢慢走回",
      "十二分钟只是参考，想提前回去就折返"
    ],
    "minimumVersion": "只走到第一个熟悉的路口",
    "stopSignal": "膝踝疼痛、胸闷、气短、头晕或环境变化不安全时立即停止并求助",
    "tags": [
      "walk",
      "outdoor",
      "circulation"
    ],
    "avoidWhen": [
      "knee",
      "ankle",
      "back",
      "dizziness"
    ],
    "priority": 1,
    "kind": "movement",
    "knowledgeCard": {
      "id": "knowledge_outdoor_slow_walk",
      "topic": "action",
      "title": "活动可以从自己愿意的量开始",
      "body": "WHO把步行列入身体活动，也指出活动可以累计。挑一条熟悉的小路，按自己的节奏走到喜欢的地方。",
      "sourceRefs": [
        "outdoor_slow_walk"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "outdoor_bench_breath",
    "title": "和熟人线下见面聊一会儿",
    "actionKind": "nourishment",
    "durationMinutes": 5,
    "scenes": [
      "outdoor",
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "身边正好有愿意聊聊的熟人时，问她现在方便坐一会儿吗",
      "聊一个最近的小发现，也可以并排安静坐着",
      "五分钟左右看看彼此是否还想继续，想结束就告个别"
    ],
    "minimumVersion": "打个招呼，交换一句近况",
    "stopSignal": "感到被迫、不安全或情绪明显变差时结束见面，回到安全处并联系信任的人",
    "tags": [
      "rest",
      "outdoor",
      "quiet"
    ],
    "avoidWhen": [
      "dizziness",
      "pain"
    ],
    "priority": 3,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_outdoor_bench_breath",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先问对方有没有空，聊天就不用从猜测她忙不忙开始。",
      "sourceRefs": [
        "outdoor_bench_breath"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "outdoor_leaf_observe",
    "title": "给喜欢的叶子取个名字",
    "actionKind": "nourishment",
    "durationMinutes": 3,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "看看附近能找到几种叶子，不用摘下来，选一片想多看几眼的",
      "挑一个最喜欢的颜色：它像嫩豆芽、青苹果，还是你想到的别的东西？",
      "沿着叶缘看一圈，再找找叶脉；给这片叶子起个自己的名字"
    ],
    "minimumVersion": "只挑一片叶子，说出它的颜色",
    "stopSignal": "颈部不适、头晕、过热或环境不安全时立即停止并回到安全处",
    "tags": [
      "sensory",
      "outdoor",
      "quiet"
    ],
    "avoidWhen": [
      "neck",
      "dizziness"
    ],
    "priority": 2,
    "kind": "care",
    "knowledgeCard": {
      "id": "knowledge_outdoor_leaf_observe",
      "topic": "action",
      "title": "自然与注意的实验线索",
      "body": "两项实验发现，自然环境散步或看自然图片后，参与者在定向注意测验上的表现有所改善。看叶缘和叶脉时，也可以把目光落在一个具体细节上。",
      "sourceRefs": [
        "outdoor_leaf_observe"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "Berman 等 · 自然环境与注意实验（2008）",
      "sourceUrl": "https://pubmed.ncbi.nlm.nih.gov/19121124/"
    },
    "category": "nature",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_01",
    "title": "靠墙站立重心转换",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "在墙边站好，手可以轻扶墙，双脚不用并紧",
      "重量缓缓移向左边，再回到中间",
      "换到右边后回中间，各做一两次就好"
    ],
    "minimumVersion": "扶着墙，轻轻换一次重心",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "脚掌稳稳落在地面，重心轻轻从一侧移到另一侧，慢一点更容易感受身体的变化。",
      "sourceRefs": [
        "reviewed_office_movement_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_02",
    "title": "打印机旁小步走",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "打印还要等一会儿，就走到不挡人的过道边",
      "在打印机附近慢慢来回走两趟，不追着出纸声赶路",
      "打印完成或两分钟到了，就停稳取走文件"
    ],
    "minimumVersion": "离开原地，走几步再回来",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "等候时的小路线最好能看见机器，也别挡住别人取纸。",
      "sourceRefs": [
        "reviewed_office_movement_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_03",
    "title": "坐姿脚踝泵动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "坐着把脚放平，先不急着抬整条腿",
      "一只脚的脚跟落地，脚尖轻抬再放下，做四五次",
      "换脚试试，最后让两只脚都落回地面"
    ],
    "minimumVersion": "左右脚各抬放一次脚尖",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "脚尖不用勾到最尽头，鞋内能轻轻活动就够了。",
      "sourceRefs": [
        "reviewed_office_movement_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_04",
    "title": "工位前抬臂伸展",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "离键盘稍远一点，双手放在身侧",
      "把手臂缓缓向前抬到舒服的高度，再轻轻落下",
      "重复两三次，最后让手掌回到腿上"
    ],
    "minimumVersion": "抬起一只手臂，再放下",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "肩膀可以一直低低的；抬臂高度由舒服程度决定，不必越过头顶。",
      "sourceRefs": [
        "reviewed_office_movement_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_05",
    "title": "会议间隙摆臂",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "会议间隙，把手里的杯子和文件先放下",
      "双臂贴近身体小幅前后摆动几次，不碰到旁人",
      "停下时让手臂自然垂着，再回到下一件事"
    ],
    "minimumVersion": "轻摆手臂两次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "手里不拿东西，摆臂就不需要额外抓紧；附近人多时可以坐着做。",
      "sourceRefs": [
        "reviewed_office_movement_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_06",
    "title": "桌边提踵",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "双脚平行站在桌边，手轻扶不会滑动的桌面",
      "脚跟缓缓抬起，停一拍，再慢慢放下，做三到五次",
      "双脚踩稳，手放松，歇一会儿"
    ],
    "minimumVersion": "扶着桌边，只提起一次脚跟",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "脚跟落地也慢一点，不用把身体突然往下一丢。",
      "sourceRefs": [
        "reviewed_office_movement_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_07",
    "title": "走廊转身放松",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "在走廊挑两个相距几步、不挡路的点",
      "从一个点走到另一个点，用小步转身，别猛扭腰",
      "慢慢来回两趟，再回到原来的方向"
    ],
    "minimumVersion": "走几步，用小步转过身",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "转身时让双脚一起带路，比脚不动只扭上半身更好控制。",
      "sourceRefs": [
        "reviewed_office_movement_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_movement_08",
    "title": "站立髋部活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "站在稳固椅背旁，一只手轻扶住",
      "把重量小幅移到一条腿上，再回到两脚之间",
      "左右交替两三次，不把髋部推到很远"
    ],
    "minimumVersion": "扶稳后轻换一次重心",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_movement_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "不需要画大圈；能稳稳回到中间，就是合适的幅度。",
      "sourceRefs": [
        "reviewed_office_movement_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_01",
    "title": "工位喝水看远处",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把水杯拿到手边，喝一两口温度合适的水",
      "放下杯子，望向工位之外最远的一处轮廓",
      "看一小会儿再回来，水和远处都不用一次看够"
    ],
    "minimumVersion": "喝一口，抬眼看一下远处",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把喝水与短暂看远放在同一个停顿里，结束后再拿回键盘。",
      "sourceRefs": [
        "reviewed_office_care_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_02",
    "title": "屏幕间隙自然眨眼",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "暂停滚动页面，望向屏幕外",
      "轻轻眨眼几次，让眼皮完整合上再自然睁开",
      "看看远处二十秒，再接着读"
    ],
    "minimumVersion": "轻轻眨几下眼就好",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "眨眼不用挤眉弄眼，轻轻合上眼皮即可。",
      "sourceRefs": [
        "reviewed_office_care_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_03",
    "title": "桌面整理一个角落",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "只看键盘旁边这一小块桌面",
      "挑出两件暂时用不到的东西，放回固定位置",
      "把正在用的笔或杯子留在顺手处"
    ],
    "minimumVersion": "放好一支笔就停",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "给常用物品一个固定小位置，下次收拾就少一个决定。",
      "sourceRefs": [
        "reviewed_office_care_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_04",
    "title": "暂停一下，听听工位周围",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "暂时摘下耳机，或把播放暂停",
      "听听附近有什么声音：键盘、脚步、空调，任选一个",
      "听半分钟到一分钟，再决定要不要戴回耳机"
    ],
    "minimumVersion": "暂停十秒，找出一个声音",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "不用等到办公室完全安静；从近处或远处挑一个声音，听它的节奏就够了。",
      "sourceRefs": [
        "reviewed_office_care_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_05",
    "title": "现在补几口水",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "忙到现在，看看水杯还在不在手边",
      "倒一点水，按口渴和舒服程度喝几口",
      "放回眼睛容易看到的位置，下一次休息再想起它"
    ],
    "minimumVersion": "这次只补一口水",
    "stopSignal": "吞咽困难、恶心、头晕或喝水后感觉变差时立即停止并寻求帮助",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_05",
      "topic": "action",
      "title": "规律补水，不用一次完成",
      "body": "NHS 把规律饮水放在一天的日常安排中。把水留在手边、分散喝几口，比给这张卡设置一次喝完的目标更合适。",
      "sourceRefs": [
        "reviewed_office_care_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NHS · Water, drinks and hydration",
      "sourceUrl": "https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/water-drinks-nutrition/"
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_06",
    "title": "把肩膀放回原位",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "把前臂放在桌面或腿上，让它们有个落点",
      "留意肩膀是不是一直耸着，让它慢慢松下来",
      "手不忙着做事，停留两三次自然呼吸"
    ],
    "minimumVersion": "让一侧肩膀松下来",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先让前臂有所支撑，肩膀就不用一直悬着托住双手。",
      "sourceRefs": [
        "reviewed_office_care_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_office_care_07",
    "title": "窗边看一眼，跟一口自然呼吸",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "在窗边坐下，视线落在一处不刺眼的颜色上",
      "让呼吸照原来的节奏走，留意一口吸气怎样自然呼出去",
      "走神时看看窗边的颜色，再留意下一口；不想继续就停"
    ],
    "minimumVersion": "只看一眼窗边的颜色也可以",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "office",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_office_care_07",
      "topic": "action",
      "title": "呼吸轻柔就好",
      "body": "NHS 建议让呼吸保持轻柔、舒服的幅度。窗边的颜色也能成为这一刻看得见的注意落点。",
      "sourceRefs": [
        "reviewed_office_care_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NHS · Breathing exercises for stress",
      "sourceUrl": "https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/"
    },
    "category": "meditation",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_01",
    "title": "课间走到饮水处",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "课间拿起水杯，沿不拥挤的路线走向饮水处",
      "接水时站稳，杯子不用装得太满",
      "慢慢走回教室，到座位再喝，别边走边烫到自己"
    ],
    "minimumVersion": "走到门口，看看现在适不适合去接水",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把接水和走回座位算在同一段间隙里，路上不用边走边喝。",
      "sourceRefs": [
        "reviewed_classroom_movement_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_02",
    "title": "课桌旁小腿泵动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "坐在课桌旁，把双脚从椅腿边挪出来",
      "脚跟抬一点再放下，脚掌仍留在地面，慢慢做四次",
      "停住，感觉一下小腿，再把脚放舒服"
    ],
    "minimumVersion": "脚跟轻抬轻放一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "桌下空间不够时先挪开书包；幅度小，鞋底也能找到落点。",
      "sourceRefs": [
        "reviewed_classroom_movement_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_03",
    "title": "椅旁肩胛收放",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "坐在椅边，手臂垂在身侧，不夹紧腋下",
      "肩胛轻轻向中间靠一点，再放回去，做三次",
      "胸口不用挺很高，回到自然坐姿休息"
    ],
    "minimumVersion": "肩胛轻轻靠近一下再放松",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把“轻轻靠近”当成小动作，不需要用力夹住背后的想象物品。",
      "sourceRefs": [
        "reviewed_classroom_movement_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_04",
    "title": "走廊慢步回座",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "下课后沿走廊走到一个近处的标记，比如下一扇窗",
      "路上保持轻松速度，人多时让一让",
      "在铃声前慢慢走回座位，不需要赶完路线"
    ],
    "minimumVersion": "走到教室门外再回来",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把回程时间也留出来，这样散步不会变成赶路。",
      "sourceRefs": [
        "reviewed_classroom_movement_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_05",
    "title": "坐姿脚背活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "坐着把一只脚稍稍向前放，脚跟落地",
      "脚尖轻轻向前伸再收回，做四五次",
      "换另一只脚，最后把两脚放平"
    ],
    "minimumVersion": "一只脚尖轻伸轻收一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "如果鞋面抵住脚背，就减小幅度，不用硬顶着鞋子继续。",
      "sourceRefs": [
        "reviewed_classroom_movement_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_06",
    "title": "课间伸展手臂",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "课间坐好或站好，双臂与邻座留出距离",
      "双手向前伸一点，停一口呼吸再收回",
      "做两次后松开手指，让手回到身侧"
    ],
    "minimumVersion": "伸出双手再收回一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "伸手前看看左右空间，比追求手臂伸得更直更重要。",
      "sourceRefs": [
        "reviewed_classroom_movement_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_07",
    "title": "站起坐下两次",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "选不带滚轮、不会滑走的椅子，双脚踩地",
      "慢慢站起来，站稳后像坐回椅子那样缓缓落下",
      "再做一次就结束；需要时用手扶稳"
    ],
    "minimumVersion": "只站起、坐下各一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_07",
      "topic": "action",
      "title": "慢慢站起、坐回也算动一动",
      "body": "WHO 说任何量的身体活动都比完全不动好。站起再坐回是一段日常身体活动，节奏放慢，也不用把次数加上去。",
      "sourceRefs": [
        "reviewed_classroom_movement_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_movement_08",
    "title": "教室后方轻踏步",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "课间到教室后方空着的位置，别挡住出口",
      "双脚交替轻轻踏地，像走得很慢，做半分钟",
      "歇一会儿，愿意再踏半分钟也可以，再走回座位"
    ],
    "minimumVersion": "原地轻踏十步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_movement_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "脚不必抬高，鞋底离地一点就可以，声音也能轻一些。",
      "sourceRefs": [
        "reviewed_classroom_movement_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_01",
    "title": "课间喝两口水",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把杯子拿到身前，看看水温是否合适",
      "在课间慢慢喝两口，咽完再继续",
      "杯盖拧好，放回不会碰倒的位置"
    ],
    "minimumVersion": "喝一口就可以",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "盖好杯盖再收进包里，下一堂课就少担心一次洒水。",
      "sourceRefs": [
        "reviewed_classroom_care_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_02",
    "title": "把视线移到教室远处",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "暂时把书合到手指夹着的那一页",
      "目光落到教室另一端的墙面或窗外二十秒",
      "轻轻眨眼，再打开刚刚那页"
    ],
    "minimumVersion": "抬眼看看另一头",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "用手指夹住读到的位置，眼睛休息回来就不用重新找行。",
      "sourceRefs": [
        "reviewed_classroom_care_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_03",
    "title": "整理课桌一小块",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "圈定课桌上一本书大小的地方",
      "把不用的试卷叠成一摞，笔收到一边",
      "留出写下一行字的空间，其他地方先不管"
    ],
    "minimumVersion": "只叠好两张纸",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这一轮先让桌面能用，不必顺便给所有资料重新分类。",
      "sourceRefs": [
        "reviewed_classroom_care_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_04",
    "title": "课间听一听近处和远处",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "课间暂停耳机里的内容",
      "先听一个近处的声音，再听一个远一点的",
      "各用一个词形容它们，比如轻、闷或断断续续，然后结束"
    ],
    "minimumVersion": "听见一个声音就算",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "按远近或节奏来分辨声音，不必猜出是谁发出的；这样更容易从一个小细节开始。",
      "sourceRefs": [
        "reviewed_classroom_care_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_05",
    "title": "让肩膀自然下沉",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "把书本放下，前臂搭在桌面或腿上",
      "看看肩膀有没有靠近耳朵，让它轻轻落回去",
      "嘴巴和手指也不必攥紧，停一小会儿"
    ],
    "minimumVersion": "手放腿上，松一侧肩膀",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "让肩膀自然落回一点，留个放松的位置；前臂也可以继续搭在桌边。",
      "sourceRefs": [
        "reviewed_classroom_care_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_06",
    "title": "数三次自然呼吸",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐在座位上，眼睛可以继续看着桌面",
      "留意三次自然呼吸，不数秒，也不憋住",
      "第三次结束，看看手边接下来准备做什么"
    ],
    "minimumVersion": "留意一口气就结束",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_06",
      "topic": "action",
      "title": "轻柔比数拍更重要",
      "body": "NHS 建议呼吸保持轻柔、舒服的幅度；数到三，再把注意力放回桌边下一件要做的事。",
      "sourceRefs": [
        "reviewed_classroom_care_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NHS · Breathing exercises for stress",
      "sourceUrl": "https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/"
    },
    "category": "meditation",
    "source": "catalog"
  },
  {
    "id": "reviewed_classroom_care_07",
    "title": "换个舒服的坐姿",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "classroom"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "看看现在坐得最别扭的是哪一处",
      "只调整一件事：挪挪脚、靠上椅背，或把本子移近",
      "坐几秒试试看，不舒服就换回来"
    ],
    "minimumVersion": "只换一下双脚的位置",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "classroom",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_classroom_care_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "一次只改一处，比较容易知道哪一个调整真的顺手。",
      "sourceRefs": [
        "reviewed_classroom_care_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_01",
    "title": "床边站立提踵",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "站在床边，手扶住稳固家具，不扶会滑动的床垫",
      "脚跟慢慢抬起再放下，做三次",
      "踩稳后歇一下，再决定要不要继续"
    ],
    "minimumVersion": "扶稳，做一次提踵",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "扶手选择不会移动的地方，让手只帮忙保持稳定。",
      "sourceRefs": [
        "reviewed_dorm_movement_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_02",
    "title": "房间内慢走一圈",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "从床边走到门口，沿房间里空着的通道",
      "慢慢绕回桌边，转角时用小步带过去",
      "一两圈就回来，想坐就坐"
    ],
    "minimumVersion": "从床边走到桌边",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_02",
      "topic": "action",
      "title": "日常走路也计入活动",
      "body": "WHO 把日常活动和走路都算作身体活动；在房间里绕一圈，让走路嵌进当下生活，不用特意换衣准备。",
      "sourceRefs": [
        "reviewed_dorm_movement_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_03",
    "title": "墙边手臂伸展",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "侧身站在墙边，手能轻轻触到墙面",
      "一只手向前抬到舒服高度，再慢慢落下",
      "换另一只手各做两次，不把肩膀挤向耳朵"
    ],
    "minimumVersion": "一只手抬一下、放下",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "墙只提供位置参照，手臂不必沿墙硬往上推。",
      "sourceRefs": [
        "reviewed_dorm_movement_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_04",
    "title": "椅旁抬膝活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "一手扶住稳固椅背，先站稳",
      "一侧膝盖抬到低处再放下，脚尖不必绷紧",
      "左右各三次，中间想停就停"
    ],
    "minimumVersion": "左右各轻抬一次脚",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "膝盖抬得低也算，能稳定落回原处更重要。",
      "sourceRefs": [
        "reviewed_dorm_movement_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_05",
    "title": "地面小范围踏步",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在房间里空出两只脚能舒展开的位置",
      "左右脚交替小步踏地，半分钟后歇一下",
      "再踏半分钟，慢慢停下来，不必跟固定节拍"
    ],
    "minimumVersion": "轻轻踏十步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "不需要把小范围踏步做成跑步，脚下能轻轻落地就够了。",
      "sourceRefs": [
        "reviewed_dorm_movement_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_06",
    "title": "阳台来回走动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "阳台地面干燥、不拥挤时，在远离栏杆的内侧走动",
      "沿短短一段路来回走，转弯放慢",
      "两分钟内随时回屋，冷、热或地滑就不做"
    ],
    "minimumVersion": "在阳台门内走几步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "路线留在栏杆以内，阳台太窄就改在房间里走。",
      "sourceRefs": [
        "reviewed_dorm_movement_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_07",
    "title": "坐姿腿部伸展",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐到稳固椅子上，双脚先放平",
      "一条腿向前轻轻伸一点，再收回，不锁死膝盖",
      "换另一条腿，各做两三次"
    ],
    "minimumVersion": "伸一条腿，再把脚放回去",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "伸到膝盖还舒服的位置就行，不需要把脚尖够向更远处。",
      "sourceRefs": [
        "reviewed_dorm_movement_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_movement_08",
    "title": "床尾髋部转移",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "坐在床尾边缘，双脚都踩到地面",
      "重量轻轻移到一侧坐骨，再回中间",
      "换另一侧，各试两次，不用左右大幅摇摆"
    ],
    "minimumVersion": "轻轻换一次坐骨受力",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_movement_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "床垫太软、脚够不到地时，换稳固椅子会更容易控制。",
      "sourceRefs": [
        "reviewed_dorm_movement_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_01",
    "title": "床边喝一口温水",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把床边的水杯拿稳，先试试温度",
      "慢慢喝一口，吞咽舒服再决定要不要继续",
      "杯子放回床头稳固处，不放在被褥上"
    ],
    "minimumVersion": "喝一小口",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "水温以自己舒服为准，不需要特意烫着喝。",
      "sourceRefs": [
        "reviewed_dorm_care_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_02",
    "title": "开窗听听风的声音",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "空气与天气合适时，开一小道窗缝",
      "听听窗外和室内的声音有什么不同，再感受一下风",
      "一两分钟后按冷暖决定把窗关小或留着"
    ],
    "minimumVersion": "只听窗内外的声音有什么不同",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "开窗前后先听一听，声音远近的变化就是线索；不想站着时，坐在原处也可以。",
      "sourceRefs": [
        "reviewed_dorm_care_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "nature",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_03",
    "title": "整理床头一小块",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "只整理床头伸手可及的那一点地方",
      "杯子放稳，线缆理到不绊手的位置，把一本书叠好",
      "留出晚上能轻松放下手机或眼镜的位置"
    ],
    "minimumVersion": "把水杯放稳就好",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先收好会碰倒、绊手的东西，比摆得对称更实用。",
      "sourceRefs": [
        "reviewed_dorm_care_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_04",
    "title": "午后休息20分钟（15点前）",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 20,
    "scenes": [
      "dorm",
      "home",
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "如果现在还没到下午三点，给自己设一个二十分钟提醒",
      "在能安心休息的位置躺下或靠坐，睡不着也不用催",
      "提醒响后先坐一会儿，清醒了再起身做下一件事"
    ],
    "minimumVersion": "靠坐休息一会儿，不要求睡着",
    "stopSignal": "若醒来后持续头晕、胸闷、明显不适或无法安全起身，停止并联系可信任的人",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "二十分钟是预留的休息时段，不是必须睡着的任务；没睡着也可以结束。",
      "sourceRefs": [
        "reviewed_dorm_care_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_05",
    "title": "让温水流过双手",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "dorm"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "把水调到舒服的温度，先用手背试一下；觉得烫就再调",
      "让温水流过双手，留意手心和指缝的触感",
      "关好水龙头、擦干手，这一分钟就停在这里"
    ],
    "minimumVersion": "用干毛巾轻轻包住双手",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_05",
      "topic": "action",
      "title": "皮肤如何感受温度与触碰",
      "body": "皮肤用不同类型的感受器传递触碰和温度线索；温水流过时，手上会同时感到水流接触与暖意。你可以挑其中一种感觉，慢慢留意几秒。",
      "sourceRefs": [
        "reviewed_dorm_care_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "NCBI Bookshelf · Physiology, Sensory Receptors",
      "sourceUrl": "https://www.ncbi.nlm.nih.gov/books/NBK539861/"
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_06",
    "title": "睡前主动放松",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "dorm",
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "把灯光和声音调到适合休息的程度",
      "从下颌、手掌到肩膀，逐处看看有没有多余的用力",
      "自然呼吸几次，换成愿意继续休息的姿势"
    ],
    "minimumVersion": "先松开一直攥着的手",
    "stopSignal": "放松过程中出现胸闷、头晕、疼痛或焦虑明显增加时停止，恢复熟悉的活动",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这一轮不用先用力绷紧再放松；注意到哪里紧，就先让那里歇一歇。",
      "sourceRefs": [
        "reviewed_dorm_care_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_dorm_care_07",
    "title": "睡前放下屏幕",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "dorm",
      "home"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把明早需要的闹钟先设好",
      "手机放到伸手之外，关掉这次不用的屏幕",
      "选一件短短的过渡小事：洗漱、翻两页纸书，或安静坐着"
    ],
    "minimumVersion": "先把屏幕扣下半分钟",
    "stopSignal": "如果环境变暗后感到头晕、焦虑或不安全，先恢复合适照明和必要联络",
    "tags": [
      "reviewed",
      "care",
      "dorm",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_dorm_care_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先安排闹钟，再放下设备，就少了一个重新拿起手机的理由。",
      "sourceRefs": [
        "reviewed_dorm_care_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "alwaysPresent": true,
    "habitTemplate": "sleep",
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_01",
    "title": "站立提踵",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "站在结实桌边或椅背旁，双脚平行",
      "手轻扶支撑，脚跟缓缓抬起再落下，做三到五次",
      "回到双脚平放，看看还想不想继续"
    ],
    "minimumVersion": "脚跟轻抬一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "抬起和放下都慢一点，让每一次动作有清楚的开始和结束。",
      "sourceRefs": [
        "reviewed_home_movement_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_02",
    "title": "客厅慢走一圈",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "从客厅的一端出发，把容易绊到的小物避开",
      "用轻松速度绕一小圈，顺便看看窗边和门口",
      "大约三分钟就回来；一圈后想停也可以"
    ],
    "minimumVersion": "从沙发走到门口再回去",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_02",
      "topic": "action",
      "title": "走路可以积成一小段",
      "body": "WHO 说身体活动可以累计，走路也算。室内的小圈从座位附近开始，想停时很快就能回到原处。",
      "sourceRefs": [
        "reviewed_home_movement_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_03",
    "title": "墙边胸口打开",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "背靠或站在墙边，双臂自然放下",
      "肩膀轻轻向后松一点，胸口不往前硬顶",
      "保持一口自然呼吸后放松，做两次"
    ],
    "minimumVersion": "肩膀向后轻松一次",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "胸口“打开”不需要大幅后仰，下巴和腰都留在舒服的位置。",
      "sourceRefs": [
        "reviewed_home_movement_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_04",
    "title": "桌边站立抬臂",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "在桌边站稳，放下手里的物品",
      "双手慢慢向前抬到舒服的位置，再放回身侧",
      "做两三次，最后把手轻搭桌边"
    ],
    "minimumVersion": "一只手抬起再放下",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "抬臂前先放下杯子，动作就不用同时兼顾抓握。",
      "sourceRefs": [
        "reviewed_home_movement_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_05",
    "title": "家务间隙小步走",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "家务做完一小段，先放好清洁工具",
      "沿家里干燥的一段通道走一两趟，不踩刚拖湿的地面",
      "回到工具旁边，决定继续还是休息"
    ],
    "minimumVersion": "离开原地走十步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这次走动留在干燥处，刚清洁过的地面可以等干了再走。",
      "sourceRefs": [
        "reviewed_home_movement_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_06",
    "title": "沙发旁腿部活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "坐在沙发靠边、脚能落地的位置",
      "一条腿向前挪一点，轻轻伸开再收回",
      "换腿各做两次，觉得沙发太软就换椅子"
    ],
    "minimumVersion": "把一只脚往前挪，再收回",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "脚能找到落点、坐面不让身体陷太深时，腿部动作更容易做得小而稳。",
      "sourceRefs": [
        "reviewed_home_movement_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_07",
    "title": "阳台轻踏步",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "在阳台靠屋内一侧站好，地面要干燥",
      "双脚轻轻交替踏地，做半分钟后停一停",
      "愿意就再来半分钟，再回到屋里"
    ],
    "minimumVersion": "阳台门内轻踏几步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这里不需要跳起来；邻居和自己都能享受轻一点的落脚声。",
      "sourceRefs": [
        "reviewed_home_movement_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_movement_08",
    "title": "玄关站立换重心",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在玄关把包放下，扶着稳固墙面或鞋柜",
      "双脚平放，重量从左脚轻轻移向右脚",
      "来回两次就停，别一边换鞋一边做"
    ],
    "minimumVersion": "放下包，站稳一小会儿",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_movement_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先把手上的重量卸下来，再试小幅换重心，步骤就简单一些。",
      "sourceRefs": [
        "reviewed_home_movement_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_01",
    "title": "随手喝两口水",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "路过水杯时停一下，拿稳杯子",
      "喝两口合适温度的水，咽完再动身",
      "杯子留在下次也容易拿到的位置"
    ],
    "minimumVersion": "喝一口就算完成",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "给水杯留一个顺手的固定位置，比临时到处找杯子省事。",
      "sourceRefs": [
        "reviewed_home_care_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_02",
    "title": "窗边看远处三分钟",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 3,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐在窗边，把手机先放下",
      "看看较远的屋顶、树或天空轮廓，不直视太阳",
      "让视线停留或轻轻游走，三分钟内想结束就结束"
    ],
    "minimumVersion": "看向远处二十秒",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_02",
      "topic": "action",
      "title": "把目光移到远处休息一下",
      "body": "AAO 建议在使用屏幕时安排规律的用眼休息。这次把目光放到较远处，也留意自然眨眼，不用继续寻找小字。",
      "sourceRefs": [
        "reviewed_home_care_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "AAO · Digital eye strain",
      "sourceUrl": "https://aao.org/eye-health/tips-prevention/blue-light-digital-eye-strain"
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_03",
    "title": "看看这一餐可以怎么搭配",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 3,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "看看这一餐有没有你平时愿意吃的蛋、奶、豆、鱼或肉；不必每样都有",
      "想加一点搭配时，选手边熟悉的一样；有过敏或饮食限制就照顾自己的需要",
      "放到餐盘边，按当下胃口吃；不想加也没关系，不必清盘"
    ],
    "minimumVersion": "只挑一种下次想搭配的食物",
    "stopSignal": "进食时出现吞咽困难、过敏样不适、恶心或身体感觉变差时停止并寻求帮助",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "蛋、奶、豆、鱼或肉都可以成为一餐里熟悉的搭配；就从手边现成、自己愿意吃的一样开始。",
      "sourceRefs": [
        "reviewed_home_care_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_04",
    "title": "关掉一盏刺眼的灯",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "找出现在最刺眼的那一处灯光",
      "把它调暗、转个方向或关掉，留够走路和看东西的光",
      "在原来的位置看几秒，舒服些就保持"
    ],
    "minimumVersion": "只转开一处反光",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "调整后从原来的位置再看一次，比站在灯旁边判断更接近实际感受。",
      "sourceRefs": [
        "reviewed_home_care_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_05",
    "title": "洗手时留意水温和触感",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "洗手时把水温调到自己觉得舒服的程度",
      "照平常方式洗手，留意水流经过手心和手背的感觉",
      "擦干时也感受一下毛巾，把这一分钟慢慢结束"
    ],
    "minimumVersion": "擦手时注意一下毛巾的触感",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先注意温度，再注意毛巾的质地；一次只挑一种感觉，就不用急着捕捉全部细节。",
      "sourceRefs": [
        "reviewed_home_care_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_06",
    "title": "挑一种声音，听听喜欢的音乐",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 3,
    "scenes": [
      "home"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐下来，在自己常用的播放器选一段喜欢的音乐",
      "把音量留在舒服、还能听见必要提醒的程度，挑一种乐器跟着听",
      "听一小段后，决定暂停还是继续"
    ],
    "minimumVersion": "听一个喜欢的前奏",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "从鼓点、低音或一种乐器开始听，会给耳朵一个具体线索；不必把整首歌听完。",
      "sourceRefs": [
        "reviewed_home_care_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_home_care_07",
    "title": "给早餐留一点时间",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 10,
    "scenes": [
      "dorm",
      "home",
      "office"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "早餐已经准备好时，找个能坐下来的地方",
      "先尝几口，留意温度和味道；不用边吃边催自己",
      "慢慢尝几口，再按今天的胃口决定要不要继续"
    ],
    "minimumVersion": "坐稳，只尝第一口",
    "stopSignal": "吞咽困难、恶心、明显腹痛或进食后不适加重时停止并寻求帮助",
    "tags": [
      "reviewed",
      "care",
      "home",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_home_care_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "坐下来尝两口，可以知道味道合不合今天的胃口；如果不饿或赶时间，也不用硬吃。",
      "sourceRefs": [
        "reviewed_home_care_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_01",
    "title": "树荫下缓慢踏步",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "走到树荫下平整、没有树根突起的地方",
      "轻轻交替踏步半分钟，脚抬得低一点",
      "停一停看看周围，再决定要不要再踏半分钟"
    ],
    "minimumVersion": "在树荫下轻踏十步",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "树荫里也可能有突起的根，挑平整的一小块就足够。",
      "sourceRefs": [
        "reviewed_outdoor_movement_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_02",
    "title": "公园长椅旁提踵",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在稳固长椅旁站好，手轻扶不会晃的椅背",
      "脚跟缓缓提起再落下，做三次",
      "双脚落稳，愿意就坐在长椅上歇一会儿"
    ],
    "minimumVersion": "提起一次脚跟再落下",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "长椅表面潮湿或松动时，就直接坐下休息，不必换一个难扶的位置继续。",
      "sourceRefs": [
        "reviewed_outdoor_movement_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_03",
    "title": "街区安全慢走",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 5,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "选人行道上熟悉的一小段路，避开车流密集处",
      "慢慢走到附近一个路标，路口先停下来观察通行情况",
      "五分钟左右折返或坐下，别为了计时赶路"
    ],
    "minimumVersion": "走到附近一个门牌再回来",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_03",
      "topic": "action",
      "title": "走路可以从熟悉路段开始",
      "body": "WHO 把走路纳入身体活动，也指出任何活动量都比完全不动好。选熟悉的一小段，来回节奏由你决定。",
      "sourceRefs": [
        "reviewed_outdoor_movement_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_04",
    "title": "户外肩臂活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "在不挡行人的位置站好，双手空出来",
      "一只手臂向前小幅抬起再放下，换另一只手",
      "左右各做两次，肩膀保持舒服"
    ],
    "minimumVersion": "轻轻抬放一只手臂",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "户外衣服厚时，幅度缩小一点就行，不需要把肩膀顶着衣料用力。",
      "sourceRefs": [
        "reviewed_outdoor_movement_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_05",
    "title": "草地旁扶稳抬膝",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在草地旁平整的硬地站好，一手扶稳固支撑",
      "像迈一个很低的小步，抬起一侧膝盖再落回原地",
      "换另一侧，各做三次，不走进不平的草地"
    ],
    "minimumVersion": "左右各轻抬一次膝盖",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这次用低低的抬脚就够了，不追求膝盖高度或迈得远。",
      "sourceRefs": [
        "reviewed_outdoor_movement_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_06",
    "title": "等车时脚踝活动",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "等车时如果有座位，就坐好，双脚落地",
      "脚尖轻抬再放下，左右脚各做几次",
      "车来或队伍移动时就停，先照顾上下车这件事"
    ],
    "minimumVersion": "坐着动一下脚尖",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "站着不方便保持稳定，就把这次留到坐下以后。",
      "sourceRefs": [
        "reviewed_outdoor_movement_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_07",
    "title": "小路来回散步",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 5,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "挑一条能看清路面、方便原路返回的小路",
      "走两分钟左右，看看有没有新的窗、花或门牌",
      "原路慢慢回来，整段约五分钟，累了就缩短"
    ],
    "minimumVersion": "从起点走到最近的一个小标记",
    "stopSignal": "出现疼痛、麻木、胸闷、气短或头晕时立即停止并休息",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "knee"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "用一个看得见的标记做折返点，返程就容易判断。",
      "sourceRefs": [
        "reviewed_outdoor_movement_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_movement_08",
    "title": "户外轻拉伸",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "在平整开阔、不挡人的地方站好",
      "双手向前轻伸，停一口呼吸再收回，接着轻轻抬放手臂",
      "每个动作做两次，腰不后仰，最后站稳休息"
    ],
    "minimumVersion": "只做一次向前轻伸",
    "stopSignal": "拉伸处出现刺痛、麻木、头晕、胸闷或失去平衡时立即停止并坐下或求助",
    "tags": [
      "reviewed",
      "movement",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness",
      "back"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_movement_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把动作分开做，一个结束再换下一个，比同时扭动很多部位更容易掌握。",
      "sourceRefs": [
        "reviewed_outdoor_movement_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_01",
    "title": "长椅上喝水休息",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "在长椅上坐好，把包放在不挡人的位置",
      "拿稳水杯，小口喝几口，再看看眼前的景色",
      "歇一两分钟，想继续走时慢慢起身"
    ],
    "minimumVersion": "坐下来喝一口水",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_01",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先坐定再开杯盖，包和杯子都不需要在膝上来回腾挪。",
      "sourceRefs": [
        "reviewed_outdoor_care_01"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_02",
    "title": "看树影怎么慢慢变",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 3,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "挑一处不刺眼的位置，看看远处的树影",
      "找一块最深的影子，再留意有没有一小片在风里摇动",
      "隔一会儿再看同一处：亮一点的边缘或位置有变化吗？"
    ],
    "minimumVersion": "找到一块会动的树影",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_02",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先选一块树影当参照，再看它有没有变化；不用一次看完整片风景。",
      "sourceRefs": [
        "reviewed_outdoor_care_02"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "nature",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_03",
    "title": "找一处安静地方坐下",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 3,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "找一个自己愿意停留、坐面稳固的地方",
      "背和脚找到舒服的支撑，把手里的事暂时放一边",
      "坐两三分钟，什么也不完成也可以"
    ],
    "minimumVersion": "坐下一小会儿就好",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_03",
      "topic": "action",
      "title": "一个小窍门",
      "body": "可以先把包放稳，让双手也拥有一段不用拿东西的时间。",
      "sourceRefs": [
        "reviewed_outdoor_care_03"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_04",
    "title": "停下来，听听风经过哪里",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "停稳休息时再摘下耳机；走路或过街时不做听声游戏",
      "找找风声、叶子声或远处的人声，选一种听一会儿",
      "再听听近处的声音，想戴回耳机时就结束"
    ],
    "minimumVersion": "停下来暂停耳机，听见一个声音",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_04",
      "topic": "action",
      "title": "一个小窍门",
      "body": "站定后听听风经过树叶、衣角或窗缝的声音；只留意差别，不必分辨对错。",
      "sourceRefs": [
        "reviewed_outdoor_care_04"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_05",
    "title": "跟着一次自然呼气",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "坐着或站稳，把注意力放到现在这一口气",
      "让呼气按原来的节奏出去，不推、不憋，也不刻意拉长",
      "下一口自然吸进来时，看看身边的一样东西就结束"
    ],
    "minimumVersion": "只注意一次平常的呼气",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_05",
      "topic": "action",
      "title": "一个小窍门",
      "body": "让呼吸照平常的节奏流动；顺畅地呼出去，再等下一口气自然进来就好。",
      "sourceRefs": [
        "reviewed_outdoor_care_05"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_06",
    "title": "感觉鞋底落在地面的地方",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "停在平整的地面，双脚保持现在舒服的站姿",
      "注意鞋底哪里碰到地面：脚跟、前掌，或某一边",
      "再看看眼前一处颜色，让注意力回到周围"
    ],
    "minimumVersion": "感觉一只脚踩着地面",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_06",
      "topic": "action",
      "title": "一个小窍门",
      "body": "这一步只观察鞋底已经接触地面的感觉；不必跺脚，也不用把重量刻意压向哪边。",
      "sourceRefs": [
        "reviewed_outdoor_care_06"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "senses",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_07",
    "title": "给饮酒留个缓冲",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 2,
    "scenes": [
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "下一杯酒到来前，给自己一个停顿",
      "看看此刻更想要水、无酒精饮品，还是直接结束",
      "提前选好回程方式；需要驾驶或操作设备时不饮酒"
    ],
    "minimumVersion": "换成一杯自己想喝的无酒精饮品",
    "stopSignal": "已经头晕、恶心、意识不清或无法保持安全时立即停止饮酒，联系可信任的人并远离驾驶和危险设备",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [
      "dizziness"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_07",
      "topic": "action",
      "title": "一个小窍门",
      "body": "可以预备一句简单的话：“我先喝这个就好。”暂停后不必一定再喝。",
      "sourceRefs": [
        "reviewed_outdoor_care_07"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "care",
    "source": "catalog"
  },
  {
    "id": "reviewed_outdoor_care_08",
    "title": "把肩膀放松下来",
    "actionKind": "nourishment",
    "kind": "care",
    "durationMinutes": 1,
    "scenes": [
      "outdoor"
    ],
    "energyLevels": [
      "low",
      "medium"
    ],
    "steps": [
      "站着休息时，把包换到稳固放置处，或让手臂有支撑",
      "肩膀不再忙着托东西，轻轻松开一口呼吸",
      "看看下颌和手指，愿意就也松一点"
    ],
    "minimumVersion": "只放松一侧肩膀",
    "stopSignal": "如果感到不适、头晕或情绪变差，立即停下并恢复自然状态",
    "tags": [
      "reviewed",
      "care",
      "outdoor",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_outdoor_care_08",
      "topic": "action",
      "title": "一个小窍门",
      "body": "手里拿着重物时，先安置物品，比一边提着一边要求自己放松更实际。",
      "sourceRefs": [
        "reviewed_outdoor_care_08"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "relaxation",
    "source": "catalog"
  },
  {
    "id": "reviewed_strength_wall_sit",
    "title": "靠墙静蹲",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 2,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "背部轻靠干燥不打滑的墙面，双脚与肩同宽，向前迈约半步",
      "膝盖朝向脚尖，缓缓下滑到能控制且没有疼痛的位置，不追求九十度",
      "先保持十到二十秒，自然呼吸，再沿墙慢慢站起，休息约一分钟"
    ],
    "minimumVersion": "只在较高、舒服的位置保持十秒",
    "stopSignal": "膝、腰、腿或脚踝出现疼痛、麻木、明显发抖、头晕或站不稳时立即停止；已有相关不适或被要求限制抗阻训练时改选其他行动",
    "tags": [
      "reviewed",
      "movement",
      "strength",
      "lower-body",
      "wall-support"
    ],
    "avoidWhen": [
      "knee",
      "back",
      "leg",
      "hip",
      "ankle",
      "pain",
      "dizziness",
      "balance",
      "recent_injury",
      "medical_restriction"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_strength_wall_sit",
      "topic": "action",
      "title": "一个小窍门",
      "body": "墙能提供支撑，深度就可以浅一些；留出缓慢站起的余地，比蹲低或撑到发抖更重要。",
      "sourceRefs": [
        "reviewed_strength_wall_sit"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "reviewed_strength_bodyweight_squat",
    "title": "舒服幅度深蹲",
    "actionKind": "movement",
    "kind": "movement",
    "durationMinutes": 3,
    "scenes": [
      "office",
      "classroom",
      "dorm",
      "home",
      "outdoor"
    ],
    "energyLevels": [
      "medium",
      "high"
    ],
    "steps": [
      "双脚略宽于肩，旁边放稳固椅子作参照，脚尖自然朝前或微向外",
      "像要坐到身后椅子一样，髋部向后、膝盖顺着脚尖方向弯曲，只到无痛且可控的幅度",
      "脚掌均匀着地，缓缓站回，先做五到十次，呼吸照常"
    ],
    "minimumVersion": "扶稳椅背，只做五次小幅度",
    "stopSignal": "膝、腰、腿、髋或脚踝出现疼痛、麻木、眩晕或失去平衡时立即停止；已有相关不适或被要求限制抗阻训练时改选其他行动",
    "tags": [
      "reviewed",
      "movement",
      "strength",
      "lower-body",
      "chair-option"
    ],
    "avoidWhen": [
      "knee",
      "back",
      "leg",
      "hip",
      "ankle",
      "pain",
      "dizziness",
      "balance",
      "recent_injury",
      "medical_restriction"
    ],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_reviewed_strength_bodyweight_squat",
      "topic": "action",
      "title": "一个小窍门",
      "body": "用身后的椅子提醒坐下方向，不需要真的蹲到很低才算完成。",
      "sourceRefs": [
        "reviewed_strength_bodyweight_squat"
      ],
      "source": "reviewedLibrary",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    },
    "category": "movement",
    "source": "catalog"
  },
  {
    "id": "mindful_one_minute",
    "title": "把注意力轻轻带回此刻",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "meditation",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "坐在愿意停留的位置，眼睛睁着或轻轻垂下都行",
      "选一口自然呼吸，或脚底接触地面的感觉，陪它一会儿",
      "念头来了不用赶走；注意到走神时，再回到刚才选的落点"
    ],
    "minimumVersion": "只注意一口呼吸也算",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "meditation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_mindful_one_minute",
      "topic": "action",
      "title": "注意力可以一次次回来",
      "body": "NCCIH 把呼吸列为可专注的感受之一；正念则是留意当下、尽量不作评判。发现走神，再把注意力带回来。",
      "sourceRefs": [
        "mindful_one_minute"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "NCCIH · Meditation and mindfulness",
      "sourceUrl": "https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety"
    }
  },
  {
    "id": "mindful_open_eyes",
    "title": "睁着眼睛看一小块颜色",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "meditation",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "挑面前一个不刺眼、不会移动太快的物体",
      "看看它的主色和旁边的颜色，让呼吸继续自己的节奏",
      "注意力飘开时再看看颜色；觉得不舒服，随时结束"
    ],
    "minimumVersion": "看一个颜色十秒",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "meditation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_mindful_open_eyes",
      "topic": "action",
      "title": "一个小窍门",
      "body": "睁眼也能停下来看一会儿；从一块大色彩开始，比盯着很小的细节省力。",
      "sourceRefs": [
        "mindful_open_eyes"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "mindful_name_thought",
    "title": "给刚才的念头取个普通名字",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "meditation",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "停一下，看看这会儿脑中绕着哪件事在想",
      "试着叫它“计划”“回忆”或“担心”，不急着评判",
      "先把这个名字放在一旁，再看看手边一件真实的东西"
    ],
    "minimumVersion": "给一个念头取个词就结束",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "meditation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_mindful_name_thought",
      "topic": "action",
      "title": "一个小窍门",
      "body": "用一个普通词称呼念头，能把它和下一步要做的事稍稍分开；不需要给自己下结论。",
      "sourceRefs": [
        "mindful_name_thought"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "mindful_contact_points",
    "title": "找一找身体接触到哪里",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "meditation",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "坐稳，先找脚底与地面的接触",
      "再试试手与腿、背与靠背；哪一处最容易感觉到？",
      "选一处舒服的落点停一会儿；不想留意身体就看看房间"
    ],
    "minimumVersion": "只感受手放在腿上",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "meditation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_mindful_contact_points",
      "topic": "action",
      "title": "一个小窍门",
      "body": "从最容易觉察的一处开始，少做几个选择；如果关注身体让你不舒服，就看看房间里的物品。",
      "sourceRefs": [
        "mindful_contact_points"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "focus_first_sentence",
    "title": "先写一句，之后再改",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "打开现在想写的那一页，先不整理全部材料",
      "写下一句能接着往下走的话，先允许它有点粗糙",
      "圈出一个下一句可以接上的词；停在这里也行"
    ],
    "minimumVersion": "只写下三个关键词",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "focus",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_first_sentence",
      "topic": "action",
      "title": "未完成的事与具体计划",
      "body": "几项实验发现，未完成目标会干扰无关阅读；为目标写下具体计划后，这类干扰减弱。把开头写成一句话，就是给写作目标留一个清楚的第一步。",
      "sourceRefs": [
        "focus_first_sentence"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Masicampo & Baumeister · 计划与未完成目标（2011）",
      "sourceUrl": "https://users.wfu.edu/masicaej/MasicampoBaumeister2011JPSP.pdf"
    }
  },
  {
    "id": "focus_five_minute_piece",
    "title": "给一件小事五分钟",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "挑一个五分钟内碰得到的小步骤，比如读一段或回一封草稿",
      "把暂时不用的窗口收起来，开始这一个步骤",
      "时间到先停一下，记下做到哪儿，再决定要不要继续"
    ],
    "minimumVersion": "从一分钟开始，也算做过一点",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "focus",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_five_minute_piece",
      "topic": "action",
      "title": "拆开任务后，估时会不同",
      "body": "三项时间安排实验中，人们给整项任务估的时间都少于把子任务分别估时后的总和。先把“读一段”从“大作业”里拎出来，时间预估会更细，也更容易看见下一小步。",
      "sourceRefs": [
        "focus_five_minute_piece"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Forsyth & Burt · 任务拆分与时间估计实验（2008）",
      "sourceUrl": "https://pubmed.ncbi.nlm.nih.gov/18604961/"
    }
  },
  {
    "id": "focus_read_for_joy",
    "title": "给喜欢的书十分钟",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 10,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "拿一本自己愿意读的书，翻到想看的地方",
      "给自己十分钟；不记笔记、跳过一段都可以",
      "结束时夹张便签，记住下次从哪里回来"
    ],
    "minimumVersion": "只读一小段",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "focus",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_read_for_joy",
      "topic": "action",
      "title": "一个小窍门",
      "body": "随手的便签也能帮你标出下次回来的页码，不用为了读书先准备一套工具。",
      "sourceRefs": [
        "focus_read_for_joy"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "focus_one_window",
    "title": "先留一个正在用的窗口",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "看看屏幕上现在真正要用的是哪一页",
      "把另外两三个暂时不用的窗口最小化，内容先留着",
      "回到这一页，写下接下来要做的一个动作"
    ],
    "minimumVersion": "只收起一个暂时不用的窗口",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "focus",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_one_window",
      "topic": "action",
      "title": "任务切换的实验线索",
      "body": "四项实验让参与者在几何分类或算术规则间切换，发现交替任务会多花时间；清楚的任务提示能缩小这项成本。开始前留一个正在用的窗口，再写出这一页接下来要做的动作。",
      "sourceRefs": [
        "focus_one_window"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Rubinstein 等 · 任务切换实验（2001）",
      "sourceUrl": "https://pubmed.ncbi.nlm.nih.gov/11518143/"
    }
  },
  {
    "id": "relax_jaw_and_hands",
    "title": "松开下颌和手心",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "relaxation",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "让双手停在腿上或桌上，不再抓紧东西",
      "留意牙齿有没有一直咬着，让下颌回到舒服的位置",
      "手指也松一点，自然呼吸一两次就结束"
    ],
    "minimumVersion": "先松开一只手",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "relaxation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_relax_jaw_and_hands",
      "topic": "action",
      "title": "一个小窍门",
      "body": "放松不需要把嘴张得很大；停止多余的抓握和咬紧就可以。",
      "sourceRefs": [
        "relax_jaw_and_hands"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "relax_hands_rest",
    "title": "让双手休息两分钟",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "relaxation",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "把手机和手里的物品放稳",
      "手心朝上或朝下放在舒服的位置，手指自然弯着",
      "停留一两分钟，看看哪一种放法更舒服"
    ],
    "minimumVersion": "放下手机十秒",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "relaxation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_relax_hands_rest",
      "topic": "action",
      "title": "一个小窍门",
      "body": "可以给前臂垫一块折好的毛巾，手就不用悬在桌边。",
      "sourceRefs": [
        "relax_hands_rest"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "relax_small_pause",
    "title": "五分钟，先不做什么",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "relaxation",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "挑一个不容易被打断的角落，坐着或靠着",
      "手边的事先放下，看看光线或听听声音都可以",
      "五分钟到了再选下一件事，这次不需要产出什么"
    ],
    "minimumVersion": "安静停留半分钟",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "relaxation",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_relax_small_pause",
      "topic": "action",
      "title": "一个小窍门",
      "body": "休息可以有边界，但不用有成绩；提醒只负责告诉你时间过去了。",
      "sourceRefs": [
        "relax_small_pause"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "nature_cloud_shapes",
    "title": "给一朵云取个名字",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "nature",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "在不刺眼的位置看云，目光避开太阳",
      "挑一片云：像小岛、鱼，还是揉皱的纸？",
      "过一小会儿再看，它的边缘有没有变"
    ],
    "minimumVersion": "挑一片云，给它起个名字",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "nature",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_nature_cloud_shapes",
      "topic": "action",
      "title": "一个小窍门",
      "body": "给云找个形状或名字，会让观察更具体；隔一会儿回来看，还能发现轮廓在变。",
      "sourceRefs": [
        "nature_cloud_shapes"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "nature_leaf_palette",
    "title": "找几种不一样的绿",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "nature",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "看看身边的植物，找几种不同的绿色，不摘叶子",
      "选一个最喜欢的，再找找旁边偏黄或偏蓝的绿",
      "给这些颜色起自己的名字；想不想拍下来由你决定"
    ],
    "minimumVersion": "找出两种不一样的绿",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "nature",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_nature_leaf_palette",
      "topic": "action",
      "title": "视觉搜索实验里的线索",
      "body": "视觉搜索实验中，找颜色和找“颜色+形状”的组合表现不同；作者提出组合搜索需要把注意逐个移到候选项上。先挑一种叶色再比深浅，眼前就有了一个具体观察线索。",
      "sourceRefs": [
        "nature_leaf_palette"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Treisman & Gelade · 视觉注意原始研究（1980）",
      "sourceUrl": "https://facultypsy.hope.edu/psychlabs/exp/visualsearch/readings/TreismanGelade_1980.pdf"
    }
  },
  {
    "id": "nature_light_edges",
    "title": "沿着光影边缘看一眼",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "nature",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "看看窗边或地面，有没有一块光与影相接的地方",
      "用目光沿着边缘走一小段，不用伸手去追",
      "再看一眼：哪段清楚，哪段有点模糊？"
    ],
    "minimumVersion": "找一块亮和暗交界的地方",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "nature",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_nature_light_edges",
      "topic": "action",
      "title": "一个小窍门",
      "body": "沿着明暗交界看一小段，注意力有了具体落点，也更容易发现边缘细微的不同。",
      "sourceRefs": [
        "nature_light_edges"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "senses_three_sounds",
    "title": "找出周围三种不同的声音",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "暂停手边的播放，先听听附近一个声音",
      "再找一个远一点的声音，以及一个断断续续的声音",
      "不用知道声音来自哪里，用三个词把它们区别开"
    ],
    "minimumVersion": "听一个声音十秒",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "senses",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_senses_three_sounds",
      "topic": "action",
      "title": "一个小窍门",
      "body": "用远近、长短或节奏来区分声音，给耳朵一个小任务；不用急着认出声源。",
      "sourceRefs": [
        "senses_three_sounds"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "senses_texture",
    "title": "摸摸熟悉物品的纹路",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "选手边干净、不会划伤的东西，比如衣袖或纸张",
      "用指腹轻轻摸一下：光滑、绒绒的，还是有细纹？",
      "换个方向再摸一遍，发现一处不同就可以结束"
    ],
    "minimumVersion": "摸一下自己的衣袖",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "senses",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_senses_texture",
      "topic": "action",
      "title": "一项触觉辨别实验",
      "body": "一项12人的实验让参与者用指尖分辨凸点表面的纹理变化；注意放在触感时，判断更快也更准。摸衣袖时先留意一条细纹或软硬变化，让触觉有个清楚目标。",
      "sourceRefs": [
        "senses_texture"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Zompa & Chapman · 触觉纹理辨别实验（1995）",
      "sourceUrl": "https://pubmed.ncbi.nlm.nih.gov/7502607/"
    }
  },
  {
    "id": "senses_first_bite",
    "title": "这一口，尝到什么？",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "选正在吃、自己熟悉且适合吃的一小口",
      "先留意温度，再挑口感或味道中的一项；不必刻意放慢咀嚼",
      "咽下后再决定要不要下一口，给刚才这一口想个形容词"
    ],
    "minimumVersion": "留意一口食物的温度",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "senses",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_senses_first_bite",
      "topic": "action",
      "title": "温度也会参与口感",
      "body": "一项感官实验请受训品评者给布丁和蛋黄酱打分；食物温度改变了一些风味和口感评分，口腔温度影响较小。吃一口时先留意温度、口感或味道中的一点，体验会更具体。",
      "sourceRefs": [
        "senses_first_bite"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Engelen 等 · 半固体食物温度与感官实验（2003）",
      "sourceUrl": "https://pubmed.ncbi.nlm.nih.gov/14637326/"
    }
  },
  {
    "id": "care_kind_sentence",
    "title": "留一句不催自己的话",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "想想今天有哪件事让自己费了点力气",
      "在便签里写一句愿意对朋友说的话，也把它留给自己",
      "放在下一次会看到的位置，不想公开就自己收着"
    ],
    "minimumVersion": "写下“先到这里也可以”",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_care_kind_sentence",
      "topic": "action",
      "title": "一个小窍门",
      "body": "一句具体的话比给自己列新要求更适合放在这张便签上。",
      "sourceRefs": [
        "care_kind_sentence"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "care_tomorrow_object",
    "title": "替明天放好一样东西",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "想一件明天出门或开工会用到的东西",
      "把它放到不易忘记、又不挡路的位置",
      "如果还差什么，写一行提示就收手，其他准备留到需要时再做"
    ],
    "minimumVersion": "只把钥匙放到固定处",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_care_tomorrow_object",
      "topic": "action",
      "title": "一个小窍门",
      "body": "把物品放到行动路径上，比如包旁边，比只在脑中提醒自己更方便发现。",
      "sourceRefs": [
        "care_tomorrow_object"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "care_support_draft",
    "title": "给想念的人留一句话",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": [
      "any"
    ],
    "energyLevels": [
      "low",
      "medium",
      "high"
    ],
    "steps": [
      "想一位自己愿意联系、也尊重彼此边界的人",
      "写一句近况或问候，先存草稿也可以",
      "看看现在愿不愿意发送，不发、晚点发都可以"
    ],
    "minimumVersion": "只写出想说的第一句",
    "stopSignal": "如果身体不舒服或心情变得更难受，随时停下，看看周围，换一件愿意做的事。",
    "tags": [
      "care",
      "gentle"
    ],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_care_support_draft",
      "topic": "action",
      "title": "一个小窍门",
      "body": "问候不必附带必须立刻回复的期待，给彼此留一点空间。",
      "sourceRefs": [
        "care_support_draft"
      ],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  }
  ,{
    "id": "focus_recall_one_idea",
    "title": "用2分钟回想刚读到的一点",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": ["classroom", "home", "office", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "读完一小段后，把书页或屏幕轻轻盖住",
      "不看原文，用一句话说出刚刚记得的一个点；写下来也行",
      "愿意的话再打开核对一眼，记不清也不必责怪自己"
    ],
    "minimumVersion": "只说出一个记得的词",
    "stopSignal": "如果开始着急或不自在，就停在这里，翻回原文或换一种做法。",
    "tags": ["focus", "recall", "gentle"],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_recall_one_idea",
      "topic": "action",
      "title": "回想也是一种练习",
      "body": "两项实验让学生读短文后进行自由回想；隔两天或一周再测时，先回想组记得更多。合上书用自己的话讲一遍，能把“我看过了”变成一次提取信息的练习。",
      "sourceRefs": ["focus_recall_one_idea"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Roediger & Karpicke · Test-Enhanced Learning (2006)",
      "sourceUrl": "https://www.psychologicalscience.org/journals/psychological-science/j.1467-9280.2006.01693.x/"
    }
  },
  {
    "id": "focus_return_marker",
    "title": "被打断前，留一句回来提示",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": ["classroom", "home", "office", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "要暂时离开一项读写任务时，在纸边写下回来后的第一个小动作",
      "把便签留在书页或笔记旁，写得具体一点，比如‘接着看第二题’",
      "回来时先照着这句话接上；中间改主意了，也可以重新选"
    ],
    "minimumVersion": "圈出自己停下的位置",
    "stopSignal": "写提示让你更烦时就收笔，直接去处理眼前需要做的事。",
    "tags": ["focus", "return-cue", "gentle"],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_focus_return_marker",
      "topic": "action",
      "title": "给回来时留个线索",
      "body": "两项任务中断实验发现，记住下一步和拥有清楚提示，会影响人能否接上原任务。写下一行继续做的小动作，就是给自己留一条看得见的回来线索。",
      "sourceRefs": ["focus_return_marker"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Dodhia & Dismukes · Interruptions create prospective memory tasks (2009)",
      "sourceUrl": "https://onlinelibrary.wiley.com/doi/10.1002/acp.1441"
    }
  },
  {
    "id": "focus_reading_question",
    "title": "读之前，写下一个好奇问题",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "focus",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": ["classroom", "home", "office", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "选一小段现在要读的内容，看看标题或第一句话",
      "在页边写一个自己真想知道的问题，不用问得很漂亮",
      "读一会儿，遇到线索就划一下；暂时没有答案也可以先留着"
    ],
    "minimumVersion": "写下一个想知道的词",
    "stopSignal": "想不出问题也没关系，直接开始读或到这里停下都可以。",
    "tags": ["focus", "curiosity", "gentle"],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_focus_reading_question",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先写一个想找的答案，就像给这一页放个小书签；暂时找不到也没关系，圈住问题留给以后。",
      "sourceRefs": ["focus_reading_question"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "senses_smell_familiar",
    "title": "闻一闻熟悉的食物气味",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "身边刚好有熟悉的水果或茶点时，保持正常距离闻一下",
      "留意香气更像清新、甜，还是你想到的别的词",
      "不喜欢或不舒服就离开；不找香水、清洁剂或不认识的植物来闻"
    ],
    "minimumVersion": "保持距离，轻轻闻一下熟悉食物",
    "stopSignal": "气味让你不舒服时就立刻离开，不用再试。",
    "tags": ["senses", "smell", "gentle"],
    "avoidWhen": ["scent_sensitivity"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_senses_smell_familiar",
      "topic": "action",
      "title": "气味怎样被闻见",
      "body": "气味分子会和鼻腔里的嗅觉受体结合，再把信号传入大脑。闻熟悉的果香时，可以试着分辨它偏甜、清新，还是带一点酸味。",
      "sourceRefs": ["senses_smell_familiar"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "NCBI Bookshelf · Physiology, Sensory Receptors",
      "sourceUrl": "https://www.ncbi.nlm.nih.gov/books/NBK539861/"
    }
  },
  {
    "id": "senses_notice_safe_temperature",
    "title": "摸摸杯子的温度和触感",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "找一个空的、干燥的常温杯子；热水杯和电器先不碰",
      "用指腹轻轻碰一下外壁，留意它偏凉、偏暖还是接近室温",
      "换一根手指再碰同一处，放回杯子就结束"
    ],
    "minimumVersion": "指腹轻碰常温杯壁一下",
    "stopSignal": "物品温度不确定或触感不舒服时，不碰它，换件熟悉的东西或结束。",
    "tags": ["senses", "temperature", "touch"],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_senses_notice_safe_temperature",
      "topic": "action",
      "title": "皮肤接收不止一种线索",
      "body": "皮肤里既有感受轻触、压力的机械感受器，也有感受温度的受体。指腹碰常温杯壁，可以同时留意材质触感和偏冷偏暖。",
      "sourceRefs": ["senses_notice_safe_temperature"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "NCBI Bookshelf · Physiology, Sensory Receptors",
      "sourceUrl": "https://www.ncbi.nlm.nih.gov/books/NBK539861/"
    }
  },
  {
    "id": "senses_follow_sound_shape",
    "title": "听一段声音的起落",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "senses",
    "source": "catalog",
    "durationMinutes": 1,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "找个坐稳、不会影响安全的小空档，选一个不刺耳的环境声",
      "听听它什么时候变响、变轻、停一下，或重复出现",
      "让这段声音过去，再看一眼手边正在做的事"
    ],
    "minimumVersion": "听一个声音的起伏几秒",
    "stopSignal": "环境声让你不舒服或此刻需要保持警觉时，就结束这次聆听。",
    "tags": ["senses", "listening", "gentle"],
    "avoidWhen": ["commute", "safety_attention"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_senses_follow_sound_shape",
      "topic": "action",
      "title": "声音会变成神经信号",
      "body": "内耳毛细胞会把声音振动转成神经信号。你可以听听声响何时变大、变小或暂停，再等它自然过去。",
      "sourceRefs": ["senses_follow_sound_shape"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "NCBI Bookshelf · Physiology, Sensory Receptors",
      "sourceUrl": "https://www.ncbi.nlm.nih.gov/books/NBK539861/"
    }
  },
  {
    "id": "care_share_small_discovery",
    "title": "分享今天的一个小发现",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "想一位熟悉、你愿意联系的人，先看看她现在是否方便",
      "分享一件今天注意到的小事，比如路边的颜色、一句有趣的话或一段旋律",
      "听听对方想不想接着聊；聊到这里就好，不需要等一个特别的回应"
    ],
    "minimumVersion": "先问一句“现在方便听我说件小事吗？”",
    "stopSignal": "对方不方便或你不想继续时，就收在这里，晚点再说也可以。",
    "tags": ["care", "connection", "gentle"],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_care_share_small_discovery",
      "topic": "action",
      "title": "连接是日常关系的一部分",
      "body": "美国公共卫生署长的咨询报告指出，社会连接与个人、社区和社会的健康福祉相关。分享一个日常小发现，也是和熟人开启交流的一种轻松方式。",
      "sourceRefs": ["care_share_small_discovery"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "HHS · Social Connection Advisory",
      "sourceUrl": "https://www.hhs.gov/surgeongeneral/reports-and-publications/connection/index.html"
    }
  },
  {
    "id": "care_listen_or_think_together",
    "title": "先问：想让我听听，还是一起想办法？",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "熟悉的人愿意聊一件事时，先问她现在方便说一会儿吗",
      "可以问：“你想让我听听，还是一起想办法？”",
      "按她的选择陪一小会儿；她不想聊时，就把空间还给彼此"
    ],
    "minimumVersion": "只问一句“现在想让我听听吗？”",
    "stopSignal": "对方不方便或你不想继续时，就停在这里，不必追问。",
    "tags": ["care", "listening", "connection"],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_care_listen_or_think_together",
      "topic": "action",
      "title": "一个小窍门",
      "body": "先问对方此刻更想被听听，还是一起想办法，给她一个选择；没空聊时就先停在这里。",
      "sourceRefs": ["care_listen_or_think_together"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "care_park_next_step",
    "title": "把一件惦记的事留条下一步",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "挑一件现在还没法处理、但总在脑中冒出来的事，写成短短一句",
      "在旁边补一个能开始的小动作，也可以写下打算什么时候再看它",
      "把便签放到之后找得到的地方，眼下不继续处理也可以"
    ],
    "minimumVersion": "只写下那件事的第一个小动作",
    "stopSignal": "越写越不舒服时就收笔，先做一件眼前愿意做的小事。",
    "tags": ["care", "rest", "planning"],
    "avoidWhen": [],
    "priority": 2,
    "knowledgeCard": {
      "id": "knowledge_care_park_next_step",
      "topic": "action",
      "title": "给未完成的事一个下一步",
      "body": "实验发现，为未完成目标列出具体计划后，它对无关阅读的干扰会减弱。把下一步写成一句具体的小动作，可以让你知道之后从哪里接起。",
      "sourceRefs": ["care_park_next_step"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Masicampo & Baumeister · Consider It Done! (2011)",
      "sourceUrl": "https://users.wfu.edu/masicaej/MasicampoBaumeister2011JPSP.pdf"
    }
  },
  {
    "id": "care_pause_one_notification",
    "title": "给一条非紧急提醒留3分钟空档",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "care",
    "source": "catalog",
    "durationMinutes": 3,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "挑一条此刻不急的应用提醒；正等重要消息时就跳过",
      "把这项提醒暂停三分钟，或将手机屏幕朝下放在手边稳妥处",
      "三分钟后按自己的需要恢复提醒，或再决定要不要继续暂停"
    ],
    "minimumVersion": "把手机屏幕朝下放半分钟",
    "stopSignal": "正在出行、需要等紧急消息或照顾安全时跳过；不想暂停也可以马上结束。",
    "tags": ["care", "rest", "digital-boundary"],
    "avoidWhen": ["urgent_alerts", "commute"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_care_pause_one_notification",
      "topic": "action",
      "title": "短暂停一停，给注意力留空档",
      "body": "22个独立样本的汇总发现，任务间短休息与活力略增、疲劳略减有关。把一条非紧急提醒稍后再看，可以少一条此刻跳出的提示。",
      "sourceRefs": ["care_pause_one_notification"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Albulescu et al. · Micro-breaks meta-analysis (2022)",
      "sourceUrl": "https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0272460"
    }
  },
  {
    "id": "relaxation_margin_doodle",
    "title": "画个五分钟不用完成的小涂鸦",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "relaxation",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "拿张废纸或草稿纸，在边角画几条弯线、圆圈或小格子",
      "挑一条线补个点或再绕一圈，看看笔尖怎么走",
      "画够五分钟或想停时就放下；留着或回收都由你决定"
    ],
    "minimumVersion": "只画一个圆圈或一条线",
    "stopSignal": "手眼不舒服或不想继续时就停，不用把图补完整。",
    "tags": ["relaxation", "creative", "gentle"],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_relaxation_margin_doodle",
      "topic": "action",
      "title": "短休息不必变成任务",
      "body": "这项元分析关注任务间十分钟以内的短休息；汇总结果显示，短休息与活力略升、疲劳感略降有关。随手画几笔，可以给一小段空档添个轻松内容。",
      "sourceRefs": ["relaxation_margin_doodle"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "Albulescu et al. · Micro-breaks meta-analysis (2022)",
      "sourceUrl": "https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0272460"
    }
  },
  {
    "id": "relaxation_hum_familiar_tune",
    "title": "哼一段熟悉旋律，想停就停",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "relaxation",
    "source": "catalog",
    "durationMinutes": 2,
    "scenes": ["home", "office", "dorm", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "想一段熟悉、听起来舒服的旋律，不用找音准",
      "环境合适时轻轻哼几句；需要安静时，在心里跟着旋律也行",
      "哼到想停的地方就结束，不用唱完整首"
    ],
    "minimumVersion": "在心里跟过一两句旋律",
    "stopSignal": "喉咙不舒服或环境需要安静时，停下发声或直接结束。",
    "tags": ["relaxation", "music", "gentle"],
    "avoidWhen": [],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_relaxation_hum_familiar_tune",
      "topic": "action",
      "title": "一个小窍门",
      "body": "哼到顺手的一小段就结束；如果周围需要安静，也可以在心里跟着旋律，不用唱准或唱完整首歌。",
      "sourceRefs": ["relaxation_hum_familiar_tune"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "nature_check_known_plant",
    "title": "看看熟悉的盆栽需要什么",
    "actionKind": "nourishment",
    "kind": "care",
    "category": "nature",
    "source": "catalog",
    "durationMinutes": 5,
    "scenes": ["home", "office", "dorm", "any"],
    "energyLevels": ["low", "medium", "high"],
    "steps": [
      "找一盆自己认识、平时会照料的植物；不认识的植物不用碰",
      "看看叶片和盆土表面，再想想它平时的光照与浇水习惯",
      "只做一个合适的小照料；拿不准时先观察，不必为了完成行动浇水"
    ],
    "minimumVersion": "看看这盆熟悉的植物现在是什么样",
    "stopSignal": "植物让你过敏、不自在或你不确定能否安全触碰时，只远远看看或结束。",
    "tags": ["nature", "care", "gentle"],
    "avoidWhen": ["unknown_plant", "allergy"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_nature_check_known_plant",
      "topic": "action",
      "title": "一个小窍门",
      "body": "不同植物的照料习惯各不相同；拿不准时先观察、查标签或问熟悉的人，不必为了完成这条行动而浇水。",
      "sourceRefs": ["nature_check_known_plant"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "微活生活实践",
      "sourceUrl": ""
    }
  },
  {
    "id": "movement_strength_explore_15",
    "title": "体验15分钟轻量力量活动",
    "actionKind": "movement",
    "kind": "movement",
    "category": "movement",
    "source": "catalog",
    "durationMinutes": 15,
    "scenes": ["home", "office", "classroom", "any"],
    "energyLevels": ["low", "medium"],
    "steps": [
      "在平整、不打滑的地方留出空间，身边放一把稳固椅子或选一面稳固墙",
      "挑两种自己熟悉的力量动作，比如轻推墙、从稳固椅子站起坐下；每次做一会儿后歇一歇",
      "按舒服的节奏活动到十五分钟；中间可以坐下休息或分几小段完成，最后放松一下"
    ],
    "minimumVersion": "挑一个喜欢的动作，做五分钟或更短",
    "stopSignal": "疼痛、头晕、胸闷或明显气短时停下休息。",
    "tags": ["movement", "strength", "gentle"],
    "avoidWhen": ["dizziness"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_movement_strength_explore_15",
      "topic": "action",
      "title": "力量活动也是身体活动",
      "body": "WHO把增强肌肉力量的活动也纳入身体活动。推墙或椅旁起身能让身体尝试出力，间隔休息、换成自己舒服的动作都可以。",
      "sourceRefs": ["movement_strength_explore_15"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "WHO · Physical Activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    }
  },
  {
    "id": "movement_walk_experience_20",
    "title": "按自己的节奏步行20分钟",
    "actionKind": "movement",
    "kind": "movement",
    "category": "movement",
    "source": "catalog",
    "durationMinutes": 20,
    "scenes": ["home", "outdoor", "any"],
    "energyLevels": ["low", "medium"],
    "steps": [
      "选一段熟悉、平坦、方便折返的路线；室内有空处也可以",
      "以还能轻松说话的节奏走五分钟，停一停，留意脚步和呼吸",
      "愿意的话再走几小段，合起来到二十分钟；中途可以坐下休息，也可以提前回头"
    ],
    "minimumVersion": "轻松走五分钟，或分几段走",
    "stopSignal": "疼痛、头晕、胸闷或明显气短时停下休息。",
    "tags": ["movement", "walking", "endurance", "gentle"],
    "avoidWhen": ["dizziness"],
    "priority": 1,
    "knowledgeCard": {
      "id": "knowledge_movement_walk_experience_20",
      "topic": "action",
      "title": "走路也属于身体活动",
      "body": "WHO将步行列入身体活动。按能舒服说话的节奏走，留意脚步、呼吸和沿途变化，慢慢找到适合自己的步行节奏。",
      "sourceRefs": ["movement_walk_experience_20"],
      "source": "catalog",
      "dismissible": true,
      "sourceTitle": "WHO · Physical activity",
      "sourceUrl": "https://www.who.int/news-room/fact-sheets/detail/physical-activity"
    }
  }
];
