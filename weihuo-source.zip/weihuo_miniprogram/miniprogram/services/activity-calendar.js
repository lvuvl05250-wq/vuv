'use strict';
const key=d=>d.toISOString().slice(0,10);
const parse=s=>new Date(s+'T00:00:00Z');
function shift(date,mode,delta){const d=parse(date);if(mode==='周')d.setUTCDate(d.getUTCDate()+7*delta);else if(mode==='月'){d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+delta);}else d.setUTCFullYear(d.getUTCFullYear()+delta);return key(d);}
function buildCalendar(state,mode,anchor,today){
  const d=parse(anchor||today),year=d.getUTCFullYear(),month=d.getUTCMonth();
  const counts={};Object.keys(state.days||{}).forEach(date=>{const day=state.days[date];counts[date]=(day.actions||[]).filter(a=>a.status==='completed').length+(day.note?1:0);});
  (state.meals||[]).filter(m=>m.confirmed).forEach(m=>counts[m.date]=(counts[m.date]||0)+1);
  (state.tickets||[]).forEach(t=>{counts[t.date]=Math.max(counts[t.date]||0,1);});
  function cell(date,inMonth){const value=counts[date]||0;return {date,number:parse(date).getUTCDate(),count:value,level:Math.min(3,value),stamped:value>0,isToday:date===today,future:date>today,inMonth};}
  function monthCells(y,m){const first=new Date(Date.UTC(y,m,1)),end=new Date(Date.UTC(y,m+1,0)),offset=(first.getUTCDay()+6)%7,total=Math.ceil((offset+end.getUTCDate())/7)*7;first.setUTCDate(1-offset);return Array.from({length:total},(_,i)=>{const x=new Date(first);x.setUTCDate(first.getUTCDate()+i);return cell(key(x),x.getUTCMonth()===m);});}
  let start,end,label,cells=[],months=[],years=[];
  if(mode==='周'){const first=new Date(d);first.setUTCDate(d.getUTCDate()-(d.getUTCDay()+6)%7);start=key(first);cells=Array.from({length:7},(_,i)=>{const x=new Date(first);x.setUTCDate(first.getUTCDate()+i);return cell(key(x),true);});end=cells[6].date;label=start.slice(5)+' — '+end.slice(5);}
  else if(mode==='月'){start=key(new Date(Date.UTC(year,month,1)));end=key(new Date(Date.UTC(year,month+1,0)));cells=monthCells(year,month);label=year+' 年 '+(month+1)+' 月';}
  else if(mode==='年'){start=year+'-01-01';end=year+'-12-31';label=year+' 年';months=Array.from({length:12},(_,m)=>{const date=key(new Date(Date.UTC(year,m,1))),items=monthCells(year,m);return {date,name:(m+1)+'月',cells:items,count:items.filter(c=>c.inMonth&&c.stamped).length,future:date>today};});}
  else{start='0000-01-01';end=today;label='所有日记';const nums=Array.from(new Set(Object.keys(counts).filter(k=>counts[k]>0&&k<=today).map(k=>k.slice(0,4)))).sort().reverse();years=nums.map(y=>({year:y,date:y+'-01-01',count:Object.keys(counts).filter(k=>k.startsWith(y)&&counts[k]>0&&k<=today).length}));}
  return {mode,start,end,label,cells,months,years,count:Object.keys(counts).filter(k=>k>=start&&k<=end&&k<=today&&counts[k]>0).length,canNext:mode!=='全部'&&end<today};
}
module.exports={buildCalendar,shift};
