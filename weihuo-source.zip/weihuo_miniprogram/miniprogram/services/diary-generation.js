const api=require('./api');
const pending=new Map(),cached=new Map();
function generate(namespace,payload){
  const key=namespace+'|'+JSON.stringify(payload);
  if(cached.has(key))return Promise.resolve(cached.get(key));
  if(pending.has(key))return pending.get(key);
  const promise=api.request('generateDiary',payload).then(result=>{if(result.paragraphs&&result.paragraphs.length){if(cached.size>8)cached.delete(cached.keys().next().value);cached.set(key,result);}return result;}).finally(()=>pending.delete(key));
  pending.set(key,promise);return promise;
}
module.exports={generate};
