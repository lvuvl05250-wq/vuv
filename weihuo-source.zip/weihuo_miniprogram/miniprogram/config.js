// Set to the CloudBase environment bound to this AppID after deployment.
// Credentials must only be configured in the cloud function environment.
module.exports = {cloudEnv:'weihuo-dev-d7gw5z8z79ca7a924',cloudFunction:'weihuoApi',version:'1.0.0'};
