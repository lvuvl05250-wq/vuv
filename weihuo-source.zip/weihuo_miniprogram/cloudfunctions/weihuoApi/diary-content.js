'use strict';
const clean=(value,max)=>typeof value==='string'?value.trim().slice(0,max):'';
function normalizeDiary(value,companionKey){
  const raw=value&&typeof value==='object'?value:{};
  const wrapped=raw.diary||raw.data||raw.result;
  const r=wrapped&&typeof wrapped==='object'&&!Array.isArray(wrapped)?Object.assign({},raw,wrapped):raw;
  const body=clean(r.text||r.body||r.content||r.summary,3500);
  const written=Array.isArray(r.paragraphs)?r.paragraphs:typeof r.paragraphs==='string'?r.paragraphs.split(/\n+/):[];
  const paragraphs=written.map(p=>clean(typeof p==='object'&&p?p.text||p.content:p,1200)).filter(Boolean).slice(0,8);
  if(!paragraphs.length&&body)paragraphs.push(...body.split(/\n+/).map(p=>clean(p,1200)).filter(Boolean).slice(0,8));
  const animal=companionKey==='cat'||companionKey==='dachshund';
  const allowed=animal?['face','paw','star','heart']:['face','flower','star','heart'];
  const stickers=(Array.isArray(r.stickers)?r.stickers:[]).filter(s=>s&&allowed.includes(s.kind)).slice(0,3).map(s=>({kind:s.kind,side:s.side==='left'?'left':'right'}));
  return {title:clean(r.title,100),yi:clean(r.yi,30).replace(/^今日宜\s*|^宜\s*/,''),paragraphs,quote:clean(r.quote,120),stickers,source:r.source==='manual'?'manual':'ai'};
}
module.exports={normalizeDiary};
