'use strict';

const SOURCES = ['allergies', 'bodyNotes', 'notes'];
const NEGATIVE = /(?:不|没|无)(?:会|有|存在)?(?:任何)?过敏|不过敏|不需要(?:避免|忌口)|没有忌口/;
const ALLERGY = /过敏/;
const AVOID = /不吃|不能吃|不喜欢吃|不爱吃|忌口|避免吃|吃不了|不耐受/;
const DIET_CONTEXT = /不喜欢|避开|避免/;
const splitNames = value => String(value || '').split(/、|，|,|和|及|与|还有|以及/).map(name => name.trim().replace(/^(?:我|本人|有|对|是|包括|食物|食品|吃|食用)+/, '').replace(/(?:等|这些|这一类|食物|食品|会|就会|容易)$/,'').trim()).filter(name => name && name.length <= 60 && !/喜欢|过敏|不能|没有|不吃|就是|如果/.test(name));

function evidenceValid(profile, item) {
  if (!item || typeof item !== 'object' || !SOURCES.includes(item.source) || !['allergy','avoid'].includes(item.kind)) return false;
  const source = typeof profile[item.source] === 'string' ? profile[item.source] : '';
  if (typeof item.name !== 'string' || !item.name.trim() || item.name.length > 60 || typeof item.evidence !== 'string' || !item.evidence || item.evidence.length > 300) return false;
  if (!source.includes(item.evidence) || !item.evidence.includes(item.name) || NEGATIVE.test(item.evidence)) return false;
  if (/(?:运动|跳跃|跑步|蹲|脚踝|膝盖|花粉|尘螨|药物)/.test(item.name)) return false;
  if (/(?:朋友|妈妈|家人|别人|她|他)(?:对|有|不能|不吃)/.test(item.evidence)) return false;
  return item.kind === 'allergy' ? ALLERGY.test(item.evidence) : AVOID.test(item.evidence) || (item.source === 'allergies' && DIET_CONTEXT.test(item.evidence));
}

function explicitExclusions(profile) {
  const items = [];
  SOURCES.forEach(source => {
    const text = typeof profile[source] === 'string' ? profile[source] : '';
    text.split(/[。；;\n，,]/).forEach(part => {
      const evidence = part.trim();
      if (!evidence || evidence.length > 300 || NEGATIVE.test(evidence)) return;
      let names, kind;
      const allergy = evidence.match(/^(?:我|本人)?(?:有点|会)?(?:对)?(.+?)(?:严重)?过敏/) || evidence.match(/过敏(?:原|食物)?[：:为是]+(.+)/);
      if (allergy) { names = splitNames(allergy[1]); kind = 'allergy'; }
      else {
        const avoid = evidence.match(/(?:不吃|不能吃|不喜欢吃?|不爱吃|忌口[：:]?|避开|避免吃?|吃不了)(.+)/) || evidence.match(/^(.+?)不耐受/);
        if (avoid) { names = splitNames(avoid[1]); kind = 'avoid'; }
      }
      (names || []).forEach(name => { const item={name,kind,source,evidence}; if(evidenceValid(profile,item)) items.push(item); });
    });
  });
  return items;
}

function normalizeFoodExclusions(profile, items) {
  const p = profile && typeof profile === 'object' ? profile : {};
  const result = [], seen = new Set();
  explicitExclusions(p).concat(Array.isArray(items) ? items : []).forEach(item => {
    if (result.length >= 50 || !evidenceValid(p,item)) return;
    const name=item.name.trim(), key=item.kind+':'+name;
    if(seen.has(key)) return;
    seen.add(key); result.push({name,kind:item.kind,source:item.source,evidence:item.evidence});
  });
  return result;
}

module.exports={normalizeFoodExclusions,explicitExclusions};
