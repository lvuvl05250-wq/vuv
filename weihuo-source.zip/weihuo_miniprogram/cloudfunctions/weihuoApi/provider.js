'use strict';

const { ApiError, fail } = require('./errors');
const {readContent}=require('./model-result');
const {generationOptions}=require('./generation-options');

function configFor(env,vision) {
  const endpoint=env.WEIHUO_AI_ENDPOINT;
  const apiKey=env.WEIHUO_AI_API_KEY;
  const model=vision ? env.WEIHUO_AI_VISION_MODEL : env.WEIHUO_AI_MODEL;
  if(!endpoint||!apiKey||!model)fail('SERVICE_NOT_CONFIGURED',vision?'图片识别服务尚未配置。':'AI 服务尚未配置。',false);
  let url;try{url=new URL(endpoint);}catch(_){fail('SERVICE_NOT_CONFIGURED','AI 服务地址配置不正确。',false);}
  if(url.protocol!=='https:'||url.username||url.password||url.hash||url.search||!/^[a-z0-9][a-z0-9.-]+\.[a-z]{2,}$/i.test(url.hostname)||['localhost','localhost.localdomain'].includes(url.hostname)||url.hostname.endsWith('.local'))fail('SERVICE_NOT_CONFIGURED','AI 服务必须使用受信任的 HTTPS 服务地址。',false);
  const timeout=Number(env.WEIHUO_AI_TIMEOUT_MS || 45000);
  if(!Number.isInteger(timeout)||timeout<1000||timeout>50000)fail('SERVICE_NOT_CONFIGURED','AI 超时配置不正确。',false);
  return {endpoint:url.toString(),apiKey,model,timeout};
}
function capability(env,vision) {try{configFor(env,vision);return true;}catch(_){return false;}}
async function readLimited(response,max) {
  if(response.body && typeof response.body.getReader==='function'){
    const reader=response.body.getReader();let length=0;const chunks=[];
    while(true){const part=await reader.read();if(part.done)break;length+=part.value.length;if(length>max){await reader.cancel();fail('PROVIDER_INVALID_RESPONSE','AI 返回内容过大，请缩短输入后重试。',true);}chunks.push(Buffer.from(part.value));}
    return Buffer.concat(chunks).toString('utf8');
  }
  const raw=await response.text();if(Buffer.byteLength(raw)>max)fail('PROVIDER_INVALID_RESPONSE','AI 返回内容过大。',true);return raw;
}
function createBaseProvider(env,fetchImpl,dependencies) {
  if(env.WEIHUO_AI_PROVIDER==='cloudbase')return require('./managed-provider').createManagedProvider(env,dependencies);
  const fetcher=fetchImpl || globalThis.fetch;
  return {
    configured(vision){return capability(env,vision);},
    assertConfigured(vision){return configFor(env,vision);},
    async generate(messages,vision,context) {
      const config=configFor(env,vision);
      if(typeof fetcher!=='function')fail('SERVICE_NOT_CONFIGURED','云函数需要支持 fetch 的 Node.js 运行时。',false);
      const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),config.timeout);
      try{
        const response=await fetcher(config.endpoint,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+config.apiKey},body:JSON.stringify({model:config.model,messages,temperature:0.35,...generationOptions(context),response_format:{type:'json_object'},stream:false}),signal:controller.signal,redirect:'error'});
        if(response.status===401||response.status===403)fail('PROVIDER_AUTH_FAILED','AI 服务凭据或访问权限需要检查。',false);
        if(response.status===402)fail('PROVIDER_QUOTA_EXCEEDED','AI 服务额度不足。',false);
        if(response.status===429)fail('PROVIDER_RATE_LIMITED','AI 服务暂时达到调用限制，请稍后再试。',true);
        if(response.status>=500)fail('PROVIDER_UNAVAILABLE','AI 服务暂时不可用，请稍后再试。',true);
        if(!response.ok)fail('PROVIDER_REQUEST_REJECTED','AI 服务不支持当前请求，请检查模型和接口配置。',false);
        const raw=await readLimited(response,128*1024);
        let envelope;try{envelope=JSON.parse(raw);}catch(_){fail('PROVIDER_INVALID_RESPONSE','AI 服务没有返回可读取的数据。',true);}
        const choice=envelope && envelope.choices && envelope.choices[0];
        if(!choice||!choice.message||typeof choice.message.content!=='string')fail('PROVIDER_INVALID_RESPONSE','AI 返回内容不完整，请重试。',true);
        return readContent(choice.message.content);
      }catch(error){
        if(error instanceof ApiError)throw error;
        if(controller.signal.aborted)fail('PROVIDER_TIMEOUT','AI 处理超时，请稍后重试。',true);
        fail('PROVIDER_NETWORK_ERROR','暂时无法连接 AI 服务，请稍后重试。',true);
      }finally{clearTimeout(timer);}
    }
  };
}

function createProvider(env,fetchImpl,dependencies) {
  const base=createBaseProvider(env,fetchImpl,dependencies);
  let tokenhub;
  function select(vision) {
    if(!vision||!env.WEIHUO_AI_VISION_PROVIDER)return base;
    if(env.WEIHUO_AI_VISION_PROVIDER!=='tokenhub')fail('SERVICE_NOT_CONFIGURED','图片识别服务类型配置不正确。',false);
    if(!tokenhub)tokenhub=require('./tokenhub-provider').createTokenHubProvider(env,fetchImpl,dependencies);
    return tokenhub;
  }
  return {
    configured(vision){try{return select(vision).configured(vision);}catch(_){return false;}},
    assertConfigured(vision){return select(vision).assertConfigured(vision);},
    async generate(messages,vision,context){
      const hasImage=Array.isArray(messages)&&messages.some(message=>message&&Array.isArray(message.content)&&message.content.some(part=>part&&part.type==='image_url'));
      return select(Boolean(vision||hasImage)).generate(messages,Boolean(vision||hasImage),context);
    }
  };
}

module.exports={createProvider,configFor,capability};
