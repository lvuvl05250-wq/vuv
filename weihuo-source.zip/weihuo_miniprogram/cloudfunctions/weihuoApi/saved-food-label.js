"use strict";
function validateFoodLabel(value) {
  if(value===null||value===undefined)return null;
  const fail=()=>{throw new Error('包装食品标签格式无效，请核对标签原值与食用量');};
  const fields=['source','name','ingredients','servingBasis','servingSize','energyValue','energyUnit','protein','carbs','fat','actualQuantity','actualUnit','flags','uncertainFields','evidence'];
  if(!value||Object.getPrototypeOf(value)!==Object.prototype||Object.keys(value).some(k=>!fields.includes(k)))fail();
  const text=(v,max)=>{if(typeof v!=='string'||v.length>max)fail();};
  const number=(v,max)=>{if(v!==null&&(typeof v!=='number'||!Number.isFinite(v)||v<0||v>max))fail();};
  const strings=(v,max,length)=>{if(!Array.isArray(v)||v.length>max)fail();v.forEach(x=>text(x,length));};
  if(value.source!=='label')fail();text(value.name,200);text(value.ingredients,4000);text(value.servingSize,200);
  const units={unknown:'',per100g:'g',per100ml:'ml',perServing:'serving'};
  if(!Object.prototype.hasOwnProperty.call(units,value.servingBasis)||value.actualUnit!==units[value.servingBasis])fail();
  number(value.energyValue,130000);['protein','carbs','fat'].forEach(k=>number(value[k],3000));
  if(value.energyValue===null?value.energyUnit!==null:!['kJ','kcal'].includes(value.energyUnit))fail();
  number(value.actualQuantity,value.servingBasis==='perServing'?1000:30000);
  if(value.servingBasis==='unknown'&&value.actualQuantity!==null)fail();
  strings(value.flags,20,200);strings(value.uncertainFields,10,40);
  const uncertain=['name','ingredients','servingBasis','servingSize','energyValue','energyUnit','protein','carbs','fat'];
  if(value.uncertainFields.some(k=>!uncertain.includes(k))||new Set(value.uncertainFields).size!==value.uncertainFields.length)fail();
  if(!value.evidence||Object.getPrototypeOf(value.evidence)!==Object.prototype||Object.keys(value.evidence).some(k=>!['servingBasis','energyValue','protein','carbs','fat'].includes(k)))fail();
  Object.values(value.evidence).forEach(v=>text(v,500));
  return JSON.parse(JSON.stringify(value));
}
function labelNutrition(label) {
  validateFoodLabel(label);
  const out={kcal:null,protein:null,carbs:null,fat:null};
  if(!label||label.actualQuantity===null||label.servingBasis==='unknown')return out;
  const factor=label.actualQuantity/(label.servingBasis==='perServing'?1:100);
  const round=v=>Math.round((v+Number.EPSILON)*100)/100;
  out.kcal=label.energyValue===null?null:round(label.energyValue*factor/(label.energyUnit==='kJ'?4.184:1));
  ['protein','carbs','fat'].forEach(k=>out[k]=label[k]===null?null:round(label[k]*factor));
  return out;
}
function validateMealLabel(meal){
  const label=validateFoodLabel(meal.foodLabel);
  if(meal.nutritionSource==='label'){
    if(!label)throw new Error('标签来源缺少已核对的标签');
    const nutrition=labelNutrition(label);
    Object.keys(nutrition).forEach(k=>{if(nutrition[k]!==meal[k])throw new Error('标签换算与记录不一致，请重新核对食用量');});
  }
  return label;
}
module.exports={validateFoodLabel,labelNutrition,validateMealLabel};
