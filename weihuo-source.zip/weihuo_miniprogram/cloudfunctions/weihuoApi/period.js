'use strict';

// This module has no platform or network dependencies. Keep the cloud copy identical.
const FEELINGS = [
  {id: 'pain', label: '疼痛'}, {id: 'tired', label: '疲惫'},
  {id: 'bloating', label: '腹胀'}, {id: 'backache', label: '腰酸'},
  {id: 'headache', label: '头痛'}, {id: 'low_mood', label: '情绪低落'}
];
const DAY_MS = 86400000;
function fail(message) { throw new Error(message); }
function plain(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype) fail(label + '格式无效');
  if (Object.keys(value).some(key => keys.indexOf(key) === -1)) fail(label + '包含不支持的内容');
}
function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || value < '1900-01-01' || value > '2200-12-31') return false;
  const parsed = new Date(value + 'T00:00:00Z');
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
const DEFAULT_SETTINGS = {predictionMode: 'history', cycleLengthDays: 28, periodLengthDays: 5, configured: false};
function validateSettings(input) {
  if (input === undefined) return Object.assign({}, DEFAULT_SETTINGS);
  plain(input, Object.keys(DEFAULT_SETTINGS), '周期设置');
  const settings = Object.assign({}, DEFAULT_SETTINGS, input);
  if (['history', 'manual'].indexOf(settings.predictionMode) === -1) fail('请选择根据历史或手动设置估计');
  if (!Number.isInteger(settings.cycleLengthDays) || settings.cycleLengthDays < 1 || settings.cycleLengthDays > 365) fail('周期请填写 1–365 天的整数');
  if (!Number.isInteger(settings.periodLengthDays) || settings.periodLengthDays < 1 || settings.periodLengthDays > 90) fail('持续时间请填写 1–90 天的整数');
  if (settings.periodLengthDays > settings.cycleLengthDays) fail('持续天数不能超过周期天数，请检查设置');
  if (typeof settings.configured !== 'boolean') fail('周期设置状态无效');
  return settings;
}
function dayDistance(start, end) { return Math.round((Date.parse(end + 'T00:00:00Z') - Date.parse(start + 'T00:00:00Z')) / DAY_MS); }
function addDateDays(date, count) {
  if (!validDate(date) || !Number.isInteger(count)) fail('估计日期无效');
  const value = new Date(Date.parse(date + 'T00:00:00Z') + count * DAY_MS).toISOString().slice(0, 10);
  return validDate(value) ? value : '';
}
function middleDay(values) {
  const ordered = values.slice().sort((a, b) => a - b), upper = Math.floor(ordered.length / 2);
  return Math.round(ordered.length % 2 ? ordered[upper] : (ordered[upper - 1] + ordered[upper]) / 2);
}
function estimateNext(records, settings, today) {
  const current = validateRecords(records, today), config = validateSettings(settings);
  const recent = current.slice(-7), intervals = [];
  for (let index = 1; index < recent.length; index += 1) intervals.push(dayDistance(recent[index - 1].startDate, recent[index].startDate));
  const durations = current.filter(record => record.endDate).slice(-6).map(record => dayDistance(record.startDate, record.endDate) + 1);
  const fromHistory = config.predictionMode === 'history';
  const cycleHistory = fromHistory && intervals.length >= 2, durationHistory = fromHistory && durations.length >= 2;
  const fallback = config.configured ? 'manual' : 'default';
  const cycleLengthDays = cycleHistory ? middleDay(intervals) : config.cycleLengthDays;
  const periodLengthDays = durationHistory ? middleDay(durations) : config.periodLengthDays;
  const output = {status: 'no-records', startDate: '', endDate: '', lastStartDate: '', cycleLengthDays, periodLengthDays,
    cycleSource: cycleHistory ? 'history' : fallback, periodSource: durationHistory ? 'history' : fallback,
    intervalCount: intervals.length, durationCount: durations.length,
    intervalMin: intervals.length ? Math.min.apply(null, intervals) : null, intervalMax: intervals.length ? Math.max.apply(null, intervals) : null,
    overdue: false};
  if (!current.length) return output;
  const latest = current[current.length - 1], startDate = addDateDays(latest.startDate, cycleLengthDays);
  const endDate = startDate && addDateDays(startDate, periodLengthDays - 1);
  output.lastStartDate = latest.startDate;
  if (!startDate || !endDate) return Object.assign(output, {status: 'out-of-range'});
  if (periodLengthDays > cycleLengthDays || (latest.endDate && latest.endDate >= startDate)) return Object.assign(output, {status: 'conflict'});
  // Calculate only from the last REAL start. An expired estimate never starts a new cycle.
  return Object.assign(output, {status: startDate < today ? 'past-estimate' : 'estimated', startDate, endDate, overdue: startDate < today});
}
function checkDate(value, today, label) {
  if (!validDate(value)) fail(label + '无效，请重新选择');
  if (value > today) fail('不能记录未来的日期');
  return value;
}
function checkToday(today) { if (!validDate(today)) fail('当前日期无效，请重新打开页面'); }
function checkTimestamp(value) {
  if (typeof value !== 'string' || value.length > 40 || !/^\d{4}-\d{2}-\d{2}T/.test(value) || !Number.isFinite(Date.parse(value))) fail('记录时间无效');
  return value;
}
function normalizeDays(value, start, end, today) {
  if (!Array.isArray(value) || value.length > 1000) fail('日感受记录过多或格式无效');
  const seen = new Set();
  const out = value.map(day => {
    plain(day, ['date', 'feelings', 'note'], '日感受');
    const date = checkDate(day.date, today, '感受日期');
    if (seen.has(date)) fail('同一天的感受请合并在一条记录里');
    seen.add(date);
    if (date < start || (end && date > end)) fail('日感受超出这次记录的起止日期，请先调整或删除对应日期的感受');
    if (!Array.isArray(day.feelings) || day.feelings.length > FEELINGS.length || new Set(day.feelings).size !== day.feelings.length
      || day.feelings.some(id => !FEELINGS.some(item => item.id === id))) fail('请选择列表中的日感受');
    if (typeof day.note !== 'string' || day.note.length > 500 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(day.note)) fail('备注最多 500 字');
    return {date, feelings: FEELINGS.filter(item => day.feelings.indexOf(item.id) !== -1).map(item => item.id), note: day.note.trim()};
  });
  return out.filter(day => day.feelings.length || day.note).sort((a, b) => a.date.localeCompare(b.date));
}
function validateRecords(input, today) {
  checkToday(today);
  if (input === undefined) return [];
  if (!Array.isArray(input) || input.length > 240) fail('经期记录过多或格式无效');
  const ids = new Set();
  let dayCount = 0;
  const records = input.map(record => {
    plain(record, ['id', 'startDate', 'endDate', 'days', 'createdAt', 'updatedAt'], '经期记录');
    if (typeof record.id !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(record.id) || ids.has(record.id)) fail('记录编号无效或重复');
    ids.add(record.id);
    const startDate = checkDate(record.startDate, today, '开始日期');
    const endDate = record.endDate === '' ? '' : checkDate(record.endDate, today, '结束日期');
    if (endDate && endDate < startDate) fail('结束日期不能早于开始日期');
    const days = normalizeDays(record.days, startDate, endDate, today);
    dayCount += days.length;
    return {id: record.id, startDate, endDate, days,
      createdAt: checkTimestamp(record.createdAt), updatedAt: checkTimestamp(record.updatedAt)};
  }).sort((a, b) => a.startDate.localeCompare(b.startDate));
  if (dayCount > 1000) fail('日感受记录较多，请先导出存档');
  for (let i = 1; i < records.length; i += 1) {
    const previous = records[i - 1];
    if (!previous.endDate) fail('还有一次记录未填写结束日期，请先补充结束日期后再新增');
    if (records[i].startDate <= previous.endDate) fail('这次日期与已有记录重叠，请调整起止日期');
  }
  return records;
}
function upsertRecord(records, patch, options) {
  const current = validateRecords(records, options.today);
  plain(patch, ['id', 'startDate', 'endDate', 'days'], '修改内容');
  const existing = patch.id ? current.find(record => record.id === patch.id) : null;
  if (patch.id && !existing) fail('这次记录已不存在，请重新读取');
  const record = Object.assign({id: options.id, startDate: '', endDate: '', days: [], createdAt: options.now}, existing || {}, patch, {updatedAt: options.now});
  const next = current.filter(item => item.id !== record.id).concat([record]);
  if (!existing && current.some(item => item.id === record.id)) fail('新记录编号与已有记录重复');
  return validateRecords(next, options.today);
}
function deleteRecord(records, id, today) {
  const current = validateRecords(records, today);
  if (!current.some(record => record.id === id)) fail('这次记录已不存在，请重新读取');
  return current.filter(record => record.id !== id);
}
function putDay(records, id, date, feelings, note, options) {
  const current = validateRecords(records, options.today);
  const record = current.find(item => item.id === id);
  if (!record) fail('这次记录已不存在，请重新读取');
  const days = record.days.filter(day => day.date !== date).concat([{date, feelings, note}]);
  return upsertRecord(current, {id, days}, options);
}
function recordForDate(records, date, today) {
  checkDate(date, today, '所选日期');
  return validateRecords(records, today).find(record => date >= record.startDate && date <= (record.endDate || today)) || null;
}
function shiftMonth(month, delta) {
  if (typeof month !== 'string' || !/^\d{4}-(0[1-9]|1[0-2])$/.test(month) || !Number.isInteger(delta)) fail('月份无效');
  const date = new Date(month + '-01T00:00:00Z');
  date.setUTCMonth(date.getUTCMonth() + delta);
  return date.toISOString().slice(0, 7);
}
function buildMonth(records, month, selectedDate, today, settings) {
  const current = validateRecords(records, today);
  const forecast = estimateNext(current, settings, today);
  if (!validDate(month + '-01')) fail('月份无效');
  const first = new Date(month + '-01T00:00:00Z');
  const mondayOffset = (first.getUTCDay() + 6) % 7;
  const firstTime = first.getTime() - mondayOffset * DAY_MS;
  return Array.from({length: 42}, (_, index) => {
    const date = new Date(firstTime + index * DAY_MS).toISOString().slice(0, 10);
    const record = current.find(item => date >= item.startDate && date <= (item.endDate || today));
    const day = record && record.days.find(item => item.date === date);
    let mark = '';
    if (record) {
      if (date === record.startDate && date === record.endDate) mark = 'both';
      else if (date === record.startDate) mark = 'start';
      else if (date === record.endDate) mark = 'end';
      else if (record.endDate) mark = 'range';
      else if (day) mark = 'noted';
    }
    const predicted = (!mark || mark === 'noted') && !!forecast.startDate && date >= forecast.startDate && date <= forecast.endDate;
    const predictionMark = predicted ? date === forecast.startDate ? 'start' : date === forecast.endDate ? 'end' : 'range' : '';
    const label = mark === 'both' ? '始/终' : mark === 'start' ? '开始' : mark === 'end' ? '结束' : '';
    return {date, number: Number(date.slice(8)), inMonth: date.slice(0, 7) === month, future: date > today,
      selected: date === selectedDate, isToday: date === today, mark, label, hasFeelings: !!day, predicted, predictionMark, predictionLabel: predicted ? '预计' : '',
      recordId: record ? record.id : '', accessibility: date + (label ? '，' + label : mark === 'range' ? '，已记录经期' : '') + (day ? '，有感受记录' : '') + (predicted ? '，预计经期，未记为实际' : '')};
  });
}
function getContext(records, date, today) {
  const record = recordForDate(records, date, today);
  const day = record && record.days.find(item => item.date === date);
  return {date, periodRecorded: !!(record && (record.endDate || record.startDate === date)),
    feelings: day ? day.feelings.slice() : []};
}

module.exports = {FEELINGS, validDate, validateSettings, estimateNext, addDateDays, validateRecords, upsertRecord, deleteRecord, putDay, recordForDate, shiftMonth, buildMonth, getContext};
