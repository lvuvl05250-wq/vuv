'use strict';

const v = require('./validation');
const { fail } = require('./errors');
const prompts = require('./prompts');
const BASIS = ['per100g', 'per100ml', 'perServing', 'unknown'];
const NUMERIC = ['energyValue', 'protein', 'carbs', 'fat'];
const FIELDS = ['name', 'ingredients', 'servingBasis', 'servingSize', 'energyValue', 'energyUnit', 'protein', 'carbs', 'fat', 'flags', 'uncertainFields', 'evidence'];
const UNCERTAIN = ['name', 'ingredients', 'servingBasis', 'servingSize', 'energyValue', 'energyUnit', 'protein', 'carbs', 'fat'];
const KEYS = { energyValue: /能量|热量|energy|calories/i, protein: /蛋白质|protein/i, carbs: /碳水|carbohydrate|carbs/i, fat: /脂肪|(?:^|\s)fat(?:\s|:|：|$)|total\s*fat/i };

function prepare(input) {
  const p = v.object(input, 'payload', ['consent', 'name', 'text', 'images', 'imageBase64', 'mimeType']);
  if (p.consent !== true) fail('AI_CONSENT_REQUIRED', '请先同意将本次标签用于 AI 处理。', false);
  const data = { name: v.text(p.name, 'name', 200), text: v.text(p.text, 'text', 12000) };
  if (p.images !== undefined && (p.imageBase64 !== undefined || p.mimeType !== undefined)) v.invalid('图片请使用一种提交方式');
  const images = p.images === undefined ? [] : v.list(p.images, 'images', 2, (item, field) => {
    v.object(item, field, ['imageBase64', 'mimeType']);
    const image = v.image(item); if (!image) v.invalid(field); return image;
  });
  if (p.imageBase64 !== undefined) images.push(v.image(p));
  if (p.mimeType !== undefined && p.imageBase64 === undefined) v.invalid('imageBase64');
  // A product name alone is not a nutrition label and cannot support lookup-like guesses.
  if (!data.text && !images.length) v.invalid('请提供标签文字或照片，不能仅凭商品名称识别');
  data.hasImages = images.length > 0;
  return { data, image: images[0] || null, images };
}

function containsQuantity(text, expected, unit) {
  const units = unit === 'kJ' ? '(?:k\\s*j|千焦)' : unit === 'kcal' ? '(?:kcal|千卡|大卡)' : '(?:g\\b|克)';
  const match = text.match(new RegExp('(\\d+(?:\\.\\d+)?)\\s*' + units, 'i'));
  return Boolean(match && Number(match[1]) === expected);
}
function validateResult(input, result) {
  try {
    v.size(result, 'result', 24000);
    const r = v.object(result, 'result', FIELDS);
    const evidenceInput = v.object(r.evidence || {}, 'evidence', ['servingBasis'].concat(NUMERIC));
    const evidence = {};
    ['servingBasis'].concat(NUMERIC).forEach(key => { evidence[key] = v.text(evidenceInput[key], 'evidence.' + key, 500); });
    const out = {
      name: v.text(r.name, 'name', 200), ingredients: v.text(r.ingredients, 'ingredients', 4000),
      servingBasis: v.choice(r.servingBasis, 'servingBasis', BASIS), servingSize: v.text(r.servingSize, 'servingSize', 200),
      energyValue: v.nullableNumber(r.energyValue, 'energyValue', 130000),
      energyUnit: r.energyUnit === null || r.energyUnit === undefined ? null : v.choice(r.energyUnit, 'energyUnit', ['kJ', 'kcal']),
      protein: v.nullableNumber(r.protein, 'protein', 3000), carbs: v.nullableNumber(r.carbs, 'carbs', 3000), fat: v.nullableNumber(r.fat, 'fat', 3000),
      flags: v.texts(r.flags, 'flags', 20, 200), uncertainFields: v.texts(r.uncertainFields, 'uncertainFields', 10, 40), evidence
    };
    if (new Set(out.uncertainFields).size !== out.uncertainFields.length || out.uncertainFields.some(key => !UNCERTAIN.includes(key))) v.invalid('uncertainFields');
    if ((out.energyValue === null) !== (out.energyUnit === null)) v.invalid('能量与单位必须同时明确');
    const suppliedText = input && input.text || '';
    const hasImages = Boolean(input && input.hasImages);
    for (const key of ['servingBasis'].concat(NUMERIC)) {
      const present = key === 'servingBasis' ? out.servingBasis !== 'unknown' : out[key] !== null;
      if (!present) continue;
      const raw = evidence[key];
      if (!raw || (!hasImages && !suppliedText.includes(raw))) v.invalid('缺少可回看的标签原文：' + key);
      if (out.uncertainFields.includes(key)) v.invalid('不确定的数值不能作为已识别值：' + key);
      if (key !== 'servingBasis') {
        if (!KEYS[key].test(raw) || !containsQuantity(raw, out[key], key === 'energyValue' ? out.energyUnit : 'g') || /[<>≤≥]|小于|大于|不足/.test(raw)) v.invalid('标签数值证据不匹配：' + key);
      }
    }
    if (out.servingBasis === 'per100g' && !/100\s*(?:g\b|克)/i.test(evidence.servingBasis)) v.invalid('每100克依据');
    if (out.servingBasis === 'per100ml' && !/100\s*(?:ml\b|毫升)/i.test(evidence.servingBasis)) v.invalid('每100毫升依据');
    if (out.servingBasis === 'perServing' && !/每\s*份|per\s*serving/i.test(evidence.servingBasis)) v.invalid('每份依据');
    if (out.uncertainFields.includes('energyUnit') && out.energyValue !== null) v.invalid('能量单位不确定');
    return out;
  } catch (_) {
    fail('PROVIDER_INVALID_RESPONSE', '标签识别结果缺少可靠依据，未填入或保存。请拍清营养表，或手动抄录。', true);
  }
}

function messagesFor(data, images) {
  const list = Array.isArray(images) ? images : (images ? [images] : []);
  const messages = prompts.messagesFor('analyzeFoodLabel', { name: data.name, text: data.text }, list[0] || null);
  list.slice(1).forEach(image => messages[1].content.push({ type: 'image_url', image_url: { url: 'data:' + image.mimeType + ';base64,' + image.imageBase64 } }));
  return messages;
}

module.exports = { prepare, validateResult, messagesFor };
