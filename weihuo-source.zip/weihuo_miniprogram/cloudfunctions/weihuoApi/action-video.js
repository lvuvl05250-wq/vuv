'use strict';

// Keep identical to cloudfunctions/weihuoApi/action-video.js.
const FIELDS = ['title', 'url', 'appId', 'path', 'intensity', 'equipment'];
const INTENSITY_LABELS = {light: '轻强度', moderate: '中等强度', vigorous: '较高强度'};
function invalid() { throw new Error('视频资源配置无效，请联系内容维护者。'); }
function text(value, maximum, required) {
  if (typeof value !== 'string' || value.length > maximum || /[\u0000-\u001f\u007f]/.test(value) || (required && !value.trim())) invalid();
  return value.trim();
}
function publicHttps(value) {
  const url = text(value, 2048, true);
  const match = /^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?][^\s\\#]*)?$/i.exec(url);
  if (!match) invalid();
  const host = match[1].toLowerCase();
  const labels = host.split('.');
  if (host.length > 253 || labels.length < 2 || !/^[a-z]{2,63}$/i.test(labels[labels.length - 1]) ||
      labels.some(label => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label)) ||
      /(?:^|\.)(?:localhost|local|internal)$/.test(host)) invalid();
  return url;
}
function validateVideo(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype || Object.keys(input).some(key => FIELDS.indexOf(key) === -1)) invalid();
  const video = {title: text(input.title, 200, true), url: publicHttps(input.url), intensity: input.intensity, equipment: text(input.equipment, 500, true)};
  if (!Object.prototype.hasOwnProperty.call(INTENSITY_LABELS, video.intensity)) invalid();
  const hasApp = input.appId !== undefined;
  const hasPath = input.path !== undefined;
  if (hasApp !== hasPath) invalid();
  if (hasApp) {
    video.appId = text(input.appId, 18, true);
    video.path = text(input.path, 1024, true);
    if (!/^wx[0-9a-f]{16}$/.test(video.appId) || !/^\/?[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*(?:\?[^\s\\#]*)?$/.test(video.path)) invalid();
  }
  return video;
}
function destination(input) {
  const video = validateVideo(input);
  const isBilibili = /^https:\/\/(?:[a-z0-9-]+\.)*bilibili\.com(?:[/:?]|$)|^https:\/\/b23\.tv(?:[/:?]|$)/i.test(video.url);
  return {
    method: video.appId && video.path ? 'miniProgram' : 'clipboard',
    appId: video.appId || '', path: video.path || '', url: video.url,
    intensityLabel: INTENSITY_LABELS[video.intensity],
    platformLabel: isBilibili ? '哔哩哔哩' : '对应视频平台',
    nextStep: isBilibili ? '链接已复制，请到哔哩哔哩或浏览器粘贴打开。' : '链接已复制，请到对应视频平台或浏览器粘贴打开。'
  };
}
function errorFrom(error, message) {
  const failure = new Error(message);
  failure.cancelled = /cancel|取消/i.test(error && error.errMsg || '');
  return failure;
}
function copyVideo(input, platform) {
  const target = destination(input);
  return new Promise((resolve, reject) => {
    if (!platform || typeof platform.setClipboardData !== 'function') { reject(new Error('当前微信无法复制链接，请升级后再试。')); return; }
    platform.setClipboardData({data: target.url, success: () => resolve({method: 'clipboard', message: target.nextStep}), fail: error => reject(errorFrom(error, '视频链接没有复制成功，请重试。'))});
  });
}
function openVideo(input, platform) {
  const target = destination(input);
  if (target.method === 'clipboard') return copyVideo(input, platform);
  return new Promise((resolve, reject) => {
    if (!platform || typeof platform.navigateToMiniProgram !== 'function') { reject(new Error('当前微信不能打开这个小程序，可以使用下方“复制视频链接”。')); return; }
    // Call directly from the tap handler; WeChat presents its own confirmation.
    platform.navigateToMiniProgram({appId: target.appId, path: target.path, envVersion: 'release',
      success: () => resolve({method: 'miniProgram', message: '返回微活后，再按实际完成情况记录。'}),
      fail: error => reject(errorFrom(error, '视频小程序暂时没有打开，可以复制链接到对应平台查看。'))});
  });
}

module.exports = {validateVideo, destination, openVideo, copyVideo};
