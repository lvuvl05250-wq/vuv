'use strict';

class ApiError extends Error {
  constructor(code, message, retryable, details) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.retryable = Boolean(retryable);
    if (details) this.details = details;
  }
}

function fail(code, message, retryable, details) {
  throw new ApiError(code, message, retryable, details);
}

module.exports = { ApiError, fail };
