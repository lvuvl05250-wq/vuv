'use strict';

// Bound short extraction output without truncating a complete multi-day plan.
const OUTPUT_TOKENS = Object.freeze({
  generateDiary: 1800, parseState: 256, generateTicketTitle: 256, explainActions: 1024,
  analyzeMeal: 768, analyzeFoodLabel: 1024, extractReport: 2048,
  summarizeProfile: 1536, mealDayReview: 1024, generateAction: 1536, extractFoodPreferences: 768
});
function generationOptions(context) {
  const options = context || {};
  if (options.task === 'generatePlan') {
    return {max_tokens: options.dayCount === 3 ? 1600 : options.dayCount === 7 ? 3200 : 6000};
  }
  return {max_tokens: OUTPUT_TOKENS[options.task] || 2048};
}
module.exports = {generationOptions};
