'use strict';

const v=require('./validation');

// These are the current catalog's avoidWhen tags. A summary cannot invent a
// new medical classification from a measurement or from an OCR number.
const TAG_KEYWORDS=Object.freeze({
  ankle:/脚踝|踝|ankle/i,back:/腰|后背|背部|back/i,balance:/平衡|站立不稳|balance/i,
  dizziness:/头晕|眩晕|晕眩|dizz/i,headache:/头痛|头疼|headache/i,hip:/髋|胯|hip/i,
  knee:/膝|knee/i,leg:/腿|下肢|leg/i,medical_restriction:/医生|医嘱|专业人员|医疗限制|medical restriction/i,
  neck:/颈|脖|neck/i,pain:/疼|痛|pain/i,recent_injury:/近期.{0,8}(伤|损伤)|刚.{0,6}(伤|扭)|最近.{0,8}(伤|损伤)|recent injury/i,
  shoulder:/肩|shoulder/i,wrist:/腕|wrist/i
});
const LIMIT_SIGNAL=/疼|痛|受伤|损伤|扭伤|不适|不能|不可|不宜|避免|避开|限制|不要|不做|站立不稳|头晕|眩晕|晕眩|pain|injur|avoid|cannot|restriction|dizz/i;
const NEGATED_SIGNAL=/没有.{0,6}(疼|痛|受伤|损伤|不适|限制|头晕|眩晕)|无.{0,4}(疼|痛|伤|不适|限制)|不再.{0,4}(疼|痛|不适)|已(?:经)?恢复|已痊愈|不疼|不痛|no (?:pain|injur|restriction)|not (?:hurt|injur)/i;

function explicitSource(profile,text){
  return [profile.bodyNotes,profile.avoidedActivities].some(source=>{
    let start=source.indexOf(text);
    while(start!==-1){
      // Check the surrounding original clause too: quoting "脚踝疼痛"
      // from "我没有脚踝疼痛" must not erase the user's negation.
      const before=source.slice(0,start).split(/[，,；;。.!！?？\n]/).pop();
      const after=source.slice(start+text.length).split(/[，,；;。.!！?？\n]/)[0];
      if(!NEGATED_SIGNAL.test(before+text+after))return true;
      start=source.indexOf(text,start+1);
    }
    return false;
  });
}

function validateSummary(input,result){
  const r=v.object(result,'result',['summary','restrictions','restrictionEvidence','allergies','avoidedActivities']);
  const summary=v.text(r.summary,'summary',8000,true);
  if(/偏高|偏低|超标|正常范围|风险分层|诊断为|疑似.{0,12}(病|症)|建议.{0,12}(检查|治疗|服用|用药)|药物剂量|补剂剂量|需要服用|应服用/.test(summary))v.invalid('summary不能包含医学解读或治疗建议');
  const existing=input.profile.restrictions.filter(tag=>Object.hasOwn(TAG_KEYWORDS,tag));
  const supplied=v.texts(r.restrictions,'restrictions',30,80);
  if(new Set(supplied).size!==supplied.length||supplied.some(tag=>!Object.hasOwn(TAG_KEYWORDS,tag)))v.invalid('restrictions');
  const found=new Set();
  const restrictionEvidence=v.list(r.restrictionEvidence===undefined?[]:r.restrictionEvidence,'restrictionEvidence',30,(item,field)=>{
    v.object(item,field,['tag','text']);const tag=v.text(item.tag,field+'.tag',80,true);const text=v.text(item.text,field+'.text',300,true);
    if(!Object.hasOwn(TAG_KEYWORDS,tag)||found.has(tag)||!supplied.includes(tag))v.invalid(field+'.tag');
    found.add(tag);
    const fromOriginal=explicitSource(input.profile,text);
    if(!fromOriginal||!TAG_KEYWORDS[tag].test(text)||!LIMIT_SIGNAL.test(text)||NEGATED_SIGNAL.test(text))v.invalid(field+'.text不是明确的用户原文限制');
    return {tag,text};
  });
  if(supplied.some(tag=>!existing.includes(tag)&&!found.has(tag)))v.invalid('新增限制缺少明确原文依据');
  const allergies=v.text(r.allergies,'allergies',1000);
  const avoidedActivities=v.text(r.avoidedActivities,'avoidedActivities',4000);
  if(allergies!==input.profile.allergies||avoidedActivities!==input.profile.avoidedActivities)v.invalid('不能新增未填写的过敏或不喜欢的活动');
  return {summary,restrictions:Array.from(new Set(existing.concat(supplied))),restrictionEvidence,allergies,avoidedActivities};
}
module.exports={TAG_KEYWORDS,validateSummary};
