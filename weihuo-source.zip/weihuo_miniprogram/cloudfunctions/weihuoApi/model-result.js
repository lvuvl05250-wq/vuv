'use strict';

const {normalizeFoodExclusions}=require('./food-exclusions');
const {validateSummary} = require('./profile-summary');
const text = (value, max = 4000) => typeof value === 'string' ? value.trim().slice(0, max) : typeof value === 'number' && Number.isFinite(value) ? String(value) : '';
const list = value => Array.isArray(value) ? value : [];
function number(value, max = 3000) {
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  const clean = typeof value === 'string' ? value.trim().replace(/\s*(分钟|分|千卡|kcal|千焦|kj|克|g)$/i, '').trim() : value;
  if (clean === '') return null;
  const n = typeof clean === 'number' ? clean : /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(clean) ? Number(clean) : NaN;
  return Number.isFinite(n) && n >= 0 && n <= max ? n : null;
}

// Model prose is a usable result. JSON is an optional structured projection of it.
function readContent(content) {
  const source = text(content, 64000);
  const clean = source.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  const parse = value => JSON.parse(value, (key, item) => ['__proto__', 'constructor', 'prototype'].includes(key) ? undefined : item);
  try {
    const value = parse(clean);
    if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  } catch (_) {}
  let attempts = 0;
  for (let start = 0; start < clean.length && attempts < 64; start += 1) {
    if (clean[start] !== '{') continue;
    attempts += 1;
    let depth = 0, quoted = false, escaped = false;
    for (let end = start; end < clean.length; end += 1) {
      const char = clean[end];
      if (quoted) {
        if (escaped) escaped = false;
        else if (char === '\\') escaped = true;
        else if (char === '"') quoted = false;
      } else if (char === '"') quoted = true;
      else if (char === '{') depth += 1;
      else if (char === '}' && --depth === 0) {
        try { return Object.assign(parse(clean.slice(start, end + 1)), {body: source.slice(0, 8000)}); } catch (_) { break; }
      }
    }
  }
  return {text: source};
}
function range(r, max) {
  let min = number(r.kcalMin, max), high = number(r.kcalMax, max);
  if (min === null && high !== null) min = high;
  if (high === null && min !== null) high = min;
  if (min !== null && min > high) [min, high] = [high, min];
  return {kcalMin: min, kcalMax: high};
}
function profileSummary(input, r, body) {
  const p = Object.assign({restrictions: [], allergies: '', avoidedActivities: '', bodyNotes: ''}, input.profile);
  const restrictions = [...new Set(list(p.restrictions))], restrictionEvidence = [];
  const requested = new Set(list(r.restrictions));
  for (const item of list(r.restrictionEvidence).slice(0, 30)) {
    if (!item || !requested.has(item.tag) || restrictionEvidence.some(e => e.tag === item.tag)) continue;
    try {
      // Reuse the source/negation check one label at a time; a bad label never hides the summary.
      const candidate = validateSummary({profile: p}, {summary: '用户填写的活动记录。', restrictions: [item.tag], restrictionEvidence: [{tag: item.tag, text: text(item.text, 300)}], allergies: p.allergies, avoidedActivities: p.avoidedActivities});
      restrictionEvidence.push(candidate.restrictionEvidence[0]);
      if (!restrictions.includes(item.tag)) restrictions.push(item.tag);
    } catch (_) {}
  }
  return {summary: text(r.summary || body, 8000), restrictions, restrictionEvidence, allergies: text(p.allergies, 1000), avoidedActivities: text(p.avoidedActivities, 4000)};
}
const LABEL_KEYS = {energyValue: /能量|热量|energy|calories/i, protein: /蛋白质|protein/i, carbs: /碳水(?:化合物)?|carbohydrates?|carbs/i, fat: /脂肪|(?:^|\s)fat\b|total\s*fat/i};
const BASIS = {per100g: /(?:每\s*)?100\s*(?:g\b|克)/i, per100ml: /(?:每\s*)?100\s*(?:ml\b|毫升)/i, perServing: /每\s*份|per\s*serving/i};
function labelResult(input, r) {
  const unit = /^(kj|千焦)$/i.test(text(r.energyUnit)) ? 'kJ' : /^(kcal|千卡|大卡)$/i.test(text(r.energyUnit)) ? 'kcal' : null;
  const basis = Object.hasOwn(BASIS, r.servingBasis) ? r.servingBasis : 'unknown';
  const allowed = ['name', 'ingredients', 'servingBasis', 'servingSize', 'energyValue', 'energyUnit', 'protein', 'carbs', 'fat'];
  const uncertain = new Set(list(r.uncertainFields).filter(key => allowed.includes(key)));
  const supplied = text(input.text, 12000);
  const ingredientsOnly = /^(?:配料(?:表)?|ingredients?)\s*[:：]?/i.test(supplied) && !/营养|nutrition|每\s*(?:100|份)|per\s*(?:100|serving)/i.test(supplied);
  const source = ingredientsOnly ? '' : supplied, compact = value => value.replace(/\s+/g, '');
  const evidence = {};
  const out = {name: text(r.name || input.name, 200), ingredients: text(r.ingredients, 4000), servingBasis: basis, servingSize: text(r.servingSize, 200), energyValue: null, energyUnit: null, protein: null, carbs: null, fat: null, flags: list(r.flags).map(x => text(x, 200)).filter(Boolean).slice(0, 20), uncertainFields: [], evidence};
  for (const key of ['servingBasis', 'energyValue', 'protein', 'carbs', 'fat']) {
    const given = text(r.evidence && r.evidence[key], 500);
    // Images can supply a transcription; text-only requests must point back to the supplied label.
    const grounded = given && (input.hasImages === true || compact(source).includes(compact(given))) ? given : '';
    const candidate = grounded || source;
    evidence[key] = grounded;
    if (key === 'servingBasis') {
      if (basis !== 'unknown' && (!BASIS[basis].test(candidate) || uncertain.has(key))) {
        out.servingBasis = 'unknown'; uncertain.add(key);
      } else if (basis !== 'unknown' && !evidence[key]) evidence[key] = (candidate.match(BASIS[basis]) || [''])[0];
      continue;
    }
    const value = number(r[key], key === 'energyValue' ? 130000 : 3000);
    if (value === null) { if (r[key] !== null && r[key] !== undefined && r[key] !== '') uncertain.add(key); continue; }
    const marker = LABEL_KEYS[key].exec(candidate);
    const row = marker ? candidate.slice(marker.index + marker[0].length).split(/\n|;|；|蛋白质|protein|碳水|carbohydrate|脂肪|total\s*fat|能量|热量|energy/i)[0] : '';
    const units = key === 'energyValue' ? unit === 'kJ' ? '(?:k\\s*j|千焦)' : unit === 'kcal' ? '(?:kcal|千卡|大卡)' : '(?!)' : '(?:g\\b|克)';
    const match = row.match(new RegExp('^\\s*[:：]?\\s*([<>≤≥]?\\s*\\d+(?:\\.\\d+)?)\\s*' + units, 'i'));
    const valid = match && Number(match[1]) === value && !/[<>≤≥]|小于|大于|不足/.test(row) && !uncertain.has(key) && !(key === 'energyValue' && uncertain.has('energyUnit'));
    if (!valid) { uncertain.add(key); continue; }
    out[key] = value;
    if (!evidence[key]) evidence[key] = marker[0] + match[0];
    if (key === 'energyValue') out.energyUnit = unit;
  }
  out.uncertainFields = [...uncertain];
  return out;
}
function normalizeAction(result) {
  const r = result && typeof result === 'object' && !Array.isArray(result) ? result : {};
  const duration = number(r.durationMinutes, 120);
  const categories = ['movement', 'relaxation', 'meditation', 'focus', 'nature', 'senses', 'care'];
  const steps = typeof r.steps === 'string' ? r.steps.split(/\r?\n/).map(step => step.replace(/^\s*(?:[-*•]|\d+[.、)])\s*/, '')) : list(r.steps);
  return {title: text(r.title, 60), category: categories.includes(r.category) ? r.category : '', durationMinutes: duration !== null && duration >= 1 ? Math.round(duration) : null, steps: steps.map(step => text(step, 200)).filter(Boolean).slice(0, 12), why: text(r.why, 1000)};
}
function normalizeResult(task, input = {}, result) {
  const raw = typeof result === 'string' ? readContent(result) : result;
  const r = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const prose = text(r.body || r.text || r.content, 8000);
  const body = prose || text(r.summary || r.note, 8000);
  const finish = value => prose ? Object.assign(value, {body: prose}) : value;
  if (task === 'parseState') {
    const energy = number(r.energy, 5), minutes = number(r.minutes, 1440), scene = text(r.scene, 80);
    const scenes = {家: 'home', 在家: 'home', 户外: 'outdoor', 办公室: 'office', 学校: 'classroom', 宿舍: 'dorm', 通勤: 'commute'};
    return finish({energy: energy !== null && energy >= 1 ? Math.round(energy) : null, scene: ['office', 'home', 'outdoor', 'commute', 'classroom', 'dorm', 'any'].includes(scene) ? scene : scenes[scene] || null, minutes: minutes === null ? null : Math.round(minutes), mood: text(r.mood, 100), note: text(r.note || body, 2000)});
  }
  if (task === 'generateDiary') return require('./diary-content').normalizeDiary(Object.assign({},r,{text:body}),input.companionKey);
  if (task === 'extractFoodPreferences') return {foodExclusions:normalizeFoodExclusions(input.profile,r.foodExclusions)};
  if (task === 'summarizeProfile') return finish(profileSummary(input, r, body));
  if (task === 'generateAction') return finish(normalizeAction(r));
  if (task === 'explainActions') {
    const allowed = new Set(list(input.actions).filter(Boolean).map(a => a.id)), seen = new Set();
    return finish({actions: list(r.actions).filter(a => a && allowed.has(a.id) && !seen.has(a.id) && seen.add(a.id)).slice(0, 10).map(a => ({id: a.id, reason: text(a.reason, 500)})), note: text(r.note || body, 2000)});
  }
  if (task === 'analyzeMeal') return finish({name: text(r.name, 200), candidates: list(r.candidates).map(x => text(x, 120)).filter(Boolean).slice(0, 30), ...range(r, 30000), protein: number(r.protein), carbs: number(r.carbs), fat: number(r.fat), note: text(r.note || body, 4000)});
  if (task === 'extractReport') return finish({metrics: list(r.metrics || r.items).slice(0, 100).filter(m => m && typeof m === 'object').map(m => ({name: text(m.name || m.item, 100), value: text(m.value, 100), unit: text(m.unit, 60), reference: text(m.reference || m.range, 150)})).filter(m => m.name || m.value), note: text(r.note || body, 2000)});
  if (task === 'generatePlan') {
    const allowed = new Set(list(input.actions).filter(Boolean).map(a => a.id));
    const start = new Date(text(input.startDate) + 'T00:00:00Z');
    const days = list(r.days).slice(0, number(input.dayCount, 14) || 14).filter(d => d && typeof d === 'object' && !Array.isArray(d)).map((d, i) => {
      const date = new Date(start.getTime()); date.setUTCDate(date.getUTCDate() + i);
      const ids = [...new Set(list(d.actionIds).filter(id => allowed.has(id)))].slice(0, 10);
      const minutes = number(d.minutes, 1440);
      return {date: Number.isFinite(date.getTime()) ? date.toISOString().slice(0, 10) : '', title: text(d.title, 300) || '当天安排', minutes: minutes === null ? null : Math.min(Math.round(minutes), number(input.minutes, 1440) || 120), details: text(d.details || d.description, 5000), actionIds: ids};
    });
    return finish({title: text(r.title, 200) || '我的生活计划', days, note: text(r.note || body, 8000)});
  }
  if (task === 'generateTicketTitle') return finish({title: text(r.title || body, 30), note: text(r.note, 500)});
  if (task === 'mealDayReview') return finish({summary: text(r.summary || body, 4000), suggestions: list(r.suggestions).map(x => text(x, 1000)).filter(Boolean).slice(0, 3), ...range(r, 60000), note: text(r.note, 2000)});
  if (task === 'analyzeFoodLabel') return finish(labelResult(input, r));
  return finish(r);
}
module.exports = {readContent, normalizeResult, normalizeAction};
