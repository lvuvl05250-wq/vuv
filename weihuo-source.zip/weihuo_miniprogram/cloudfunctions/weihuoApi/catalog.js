'use strict';

const v = require('./validation');
const {ApiError, fail} = require('./errors');
const {validateVideo} = require('./action-video');

const CATEGORIES = ['movement','relaxation','meditation','focus','nature','senses','care'];
const SCENES = ['office','classroom','dorm','home','outdoor','commute','any'];
const ENERGY_LEVELS = ['low','medium','high'];
const FIELDS = ['id','title','durationMinutes','steps','minimumVersion','stopSignal','kind','category','tags','avoidWhen','scenes','energyLevels','priority','source','createdAt','updatedAt','audio','video'];

function distinct(items, field) {
  if (new Set(items).size !== items.length) v.invalid(field + '重复');
  return items;
}

function httpsUrl(input, field) {
  const url = v.text(input, field, 2048, true);
  let parsed;
  try { parsed = new URL(url); } catch (_) { v.invalid(field); }
  const host = parsed.hostname.toLowerCase();
  // The cloud function never fetches this URL. Restrict links before exposing
  // them to the native audio player; the app's domain allowlist still applies.
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.hash ||
      /[\s\\]/.test(url) || !/^[a-z0-9.-]+$/.test(host) || !host.includes('.') ||
      /^\d+(?:\.\d+)*$/.test(host) || /(?:^|\.)(?:localhost|local|internal)$/.test(host) ||
      (parsed.port && parsed.port !== '443')) v.invalid(field);
  return url;
}

function audio(input, field) {
  const a = v.object(input, field, ['url','durationSeconds','transcript']);
  return {url:httpsUrl(a.url,field+'.url'), durationSeconds:v.number(a.durationSeconds, field + '.durationSeconds', 1, 7200, true), transcript:v.text(a.transcript, field + '.transcript', 12000)};
}

function video(input, field) {
  if (input === null) return null;
  try { return validateVideo(input); } catch (_) { v.invalid(field); }
}

function knowledgeCard(input, field) {
  const k=v.object(input,field,['id','topic','title','body','sourceRefs','source','dismissible','sourceTitle','sourceUrl']);
  const out={id:v.text(k.id,field+'.id',100,true),topic:v.text(k.topic,field+'.topic',80),title:v.text(k.title,field+'.title',200,true),body:v.text(k.body,field+'.body',5000,true),sourceRefs:v.texts(k.sourceRefs,field+'.sourceRefs',30,100),source:v.text(k.source,field+'.source',100),dismissible:v.boolean(k.dismissible,field+'.dismissible')};
  if(k.sourceTitle!==undefined)out.sourceTitle=v.text(k.sourceTitle,field+'.sourceTitle',200);
  if(k.sourceUrl!==undefined)out.sourceUrl=k.sourceUrl?httpsUrl(k.sourceUrl,field+'.sourceUrl'):v.text(k.sourceUrl,field+'.sourceUrl',2048);
  return out;
}

function knowledge(input, field) {
  const k=v.object(input,field,['title','body','sourceTitle','sourceUrl']);
  return {title:v.text(k.title,field+'.title',200,true),body:v.text(k.body,field+'.body',5000,true),sourceTitle:v.text(k.sourceTitle,field+'.sourceTitle',200),sourceUrl:k.sourceUrl?httpsUrl(k.sourceUrl,field+'.sourceUrl'):v.text(k.sourceUrl,field+'.sourceUrl',2048)};
}

function actionTemplate(input, field, source) {
  const publicItem = source === 'catalog';
  const a = v.object(input,field,publicItem ? FIELDS.concat(['actionKind','knowledgeCard','knowledge','alwaysPresent','habitTemplate']) : FIELDS.concat(['knowledgeCard']));
  const kind = v.choice(a.kind,field+'.kind',['movement','care']);
  const out = {
    id:v.text(a.id,field+'.id',100,true),title:v.text(a.title,field+'.title',200,true),
    durationMinutes:v.number(a.durationMinutes,field+'.durationMinutes',1,180),
    steps:v.texts(a.steps,field+'.steps',30,1000),minimumVersion:v.text(a.minimumVersion,field+'.minimumVersion',1000),stopSignal:v.text(a.stopSignal,field+'.stopSignal',1000),
    kind,category:v.choice(a.category===undefined&&publicItem ? (kind==='movement'?'movement':'care') : a.category,field+'.category',CATEGORIES),
    tags:distinct(v.texts(a.tags,field+'.tags',30,80),field+'.tags'),avoidWhen:distinct(v.texts(a.avoidWhen,field+'.avoidWhen',30,80),field+'.avoidWhen'),
    scenes:distinct(v.list(a.scenes,field+'.scenes',7,(x,f)=>v.choice(x,f,SCENES)),field+'.scenes'),
    energyLevels:distinct(v.list(a.energyLevels,field+'.energyLevels',3,(x,f)=>v.choice(x,f,ENERGY_LEVELS)),field+'.energyLevels'),
    priority:v.number(a.priority===undefined?3:a.priority,field+'.priority',1,5,true),source
  };
  if (a.source !== undefined && a.source !== source) v.invalid(field+'.source');
  if (!publicItem || a.createdAt!==undefined) out.createdAt=v.timestamp(a.createdAt,field+'.createdAt');
  if (!publicItem || a.updatedAt!==undefined) out.updatedAt=v.timestamp(a.updatedAt,field+'.updatedAt');
  if (a.audio!==undefined) out.audio=audio(a.audio,field+'.audio');
  if (a.video!==undefined) out.video=video(a.video,field+'.video');
  if (publicItem && a.actionKind!==undefined) out.actionKind=v.choice(a.actionKind,field+'.actionKind',['movement','nourishment']);
  if (a.knowledgeCard!==undefined) out.knowledgeCard=knowledgeCard(a.knowledgeCard,field+'.knowledgeCard');
  if (publicItem && a.knowledge!==undefined) out.knowledge=knowledge(a.knowledge,field+'.knowledge');
  if (publicItem && a.alwaysPresent!==undefined) out.alwaysPresent=v.boolean(a.alwaysPresent,field+'.alwaysPresent');
  if (publicItem && a.habitTemplate!==undefined) out.habitTemplate=v.choice(a.habitTemplate,field+'.habitTemplate',['wake','sleep']);
  return out;
}

function uniqueActions(items, field) {
  distinct(items.map(a=>a.id),field+'.id');
  return items;
}

function validateCatalog(row, now) {
  if (!row || !row.publishedAt) fail('CATALOG_NOT_CONFIGURED','云端行动库尚未发布，请稍后再试。',false);
  try {
    v.size(row,'catalog',700*1024);
    v.object(row,'catalog',['_id','version','publishedAt','items']);
    const version=v.text(row.version,'catalog.version',100,true);
    const publishedAt=v.timestamp(row.publishedAt,'catalog.publishedAt');
    if(Date.parse(publishedAt)>(now===undefined?Date.now():now))fail('CATALOG_NOT_CONFIGURED','云端行动库尚未到发布时间。',false);
    const items=uniqueActions(v.list(row.items,'catalog.items',1000,(a,f)=>actionTemplate(a,f,'catalog')),'catalog.items');
    if(!items.length)fail('CATALOG_NOT_CONFIGURED','云端行动库尚未发布内容。',false);
    return {version,publishedAt,items};
  } catch(error) {
    if(error instanceof ApiError && error.code==='CATALOG_NOT_CONFIGURED')throw error;
    fail('CATALOG_INVALID','云端行动库内容未通过校验，请联系维护者。',false);
  }
}

function planCandidates(input) {
  const items=uniqueActions(v.list(input,'actions',100,(a,f)=>{
    v.object(a,f,['id','title','durationMinutes','kind','category','steps','avoidWhen']);
    return {id:v.text(a.id,f+'.id',100,true),title:v.text(a.title,f+'.title',200,true),durationMinutes:v.number(a.durationMinutes,f+'.durationMinutes',1,180),kind:v.choice(a.kind,f+'.kind',['movement','care']),category:v.choice(a.category,f+'.category',CATEGORIES),steps:v.texts(a.steps,f+'.steps',30,1000),avoidWhen:v.texts(a.avoidWhen,f+'.avoidWhen',30,80)};
  }),'actions');
  if(!items.length)v.invalid('actions');
  v.size(items,'actions',120*1024);
  return items;
}

module.exports={CATEGORIES,audio,video,actionTemplate,uniqueActions,validateCatalog,planCandidates};
