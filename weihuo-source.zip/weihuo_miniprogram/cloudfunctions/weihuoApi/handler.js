'use strict';

const crypto=require('node:crypto');
const {ApiError,fail}=require('./errors');
const v=require('./validation');
const {validateState}=require('./state');
const {DEFINITIONS}=require('./prompts');
const {runAI}=require('./ai');

function identityFrom(event,wxContext,env){
  if(!event||typeof event!=='object'||Array.isArray(event))v.invalid('请求');
  if(['httpMethod','headers','requestContext','rawPath','body','path','queryStringParameters'].some(k=>Object.prototype.hasOwnProperty.call(event,k)))fail('NATIVE_CALL_REQUIRED','请从微活微信小程序调用。',false);
  // CloudBase adds transport metadata to native calls. Ignore those fields;
  // identity still comes exclusively from the SDK context below.
  v.object(event,'请求',['task','payload','TCB_CONTEXT','tcbContext','userInfo']);
  if(!env.WEIHUO_APPID)fail('SERVICE_NOT_CONFIGURED','云函数尚未绑定微信小程序。',false);
  const c=wxContext||{};
  if(typeof c.OPENID!=='string'||!/^[A-Za-z0-9_-]{8,128}$/.test(c.OPENID)||typeof c.APPID!=='string'||c.APPID!==env.WEIHUO_APPID)fail('UNAUTHENTICATED','没有取得当前微信用户身份，请重新打开小程序。',false);
  return {openid:c.OPENID,appid:c.APPID};
}
function createHandler(deps){
  return async function handle(event){
    const requestId=crypto.randomUUID();
    try{
      v.size(event,'请求',850*1024);
      const identity=identityFrom(event,deps.getWXContext(),deps.env);
      const task=v.text(event.task,'task',40,true);const payload=event.payload===undefined?{}:event.payload;
      let data;
      if(['auth','status','auth/status'].includes(task)){
        v.object(payload,'payload',[]);
        data={openid:identity.openid,appid:identity.appid,connected:true,configured:deps.provider.configured(false),visionConfigured:deps.provider.configured(true),syncSupported:true};
      }else if(task==='getCatalog'){
        v.object(payload,'payload',[]);
        data=await deps.storage.getCatalog();
      }else if(task==='syncPull'){
        v.object(payload,'payload',['consent']);if(payload.consent!==true)fail('CLOUD_CONSENT_REQUIRED','请先同意读取云端个人记录。',false);
        data=await deps.storage.pull(identity);
      }else if(task==='syncPush'){
        v.object(payload,'payload',['consent','baseVersion','state']);if(payload.consent!==true)fail('CLOUD_CONSENT_REQUIRED','请先同意保存云端个人记录。',false);
        const version=v.number(payload.baseVersion,'baseVersion',0,Number.MAX_SAFE_INTEGER-1,true);const state=validateState(payload.state);
        if(state.settings.cloudConsent!==true)fail('CLOUD_CONSENT_REQUIRED','当前设置未允许云同步。',false);
        data=await deps.storage.push(identity,version,state);
      }else if(task==='deleteCloudData'){
        v.object(payload,'payload',['baseVersion','confirm']);if(payload.confirm!==true)fail('DELETE_CONFIRMATION_REQUIRED','请先确认删除云端记录。',false);
        data=await deps.storage.erase(identity,v.number(payload.baseVersion,'baseVersion',0,Number.MAX_SAFE_INTEGER-1,true));
      }else if(DEFINITIONS[task]){
        const limit=Number(deps.env.WEIHUO_AI_DAILY_LIMIT||50);
        if(!Number.isInteger(limit)||limit<1||limit>500)fail('SERVICE_NOT_CONFIGURED','AI 每日额度配置不正确。',false);
        data=await runAI(task,payload,deps.provider,()=>deps.storage.reserveAI(identity,limit));
      }else fail('TASK_NOT_FOUND','找不到这项功能。',false);
      return {ok:true,data,requestId};
    }catch(error){
      if(error instanceof ApiError){const out={code:error.code,message:error.message,retryable:error.retryable};if(error.details)out.details=error.details;return {ok:false,error:out,requestId};}
      // No raw errors, prompts, image bytes, runtime context or credentials
      // are logged or returned. The request id is safe for operator tracing.
      return {ok:false,error:{code:'STORAGE_UNAVAILABLE',message:'云端数据暂时不可用，请检查集合配置或稍后重试。',retryable:true},requestId};
    }
  };
}
module.exports={createHandler,identityFrom};
