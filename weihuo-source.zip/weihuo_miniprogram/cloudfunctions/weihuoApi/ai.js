'use strict';

const v=require('./validation');
const {profile}=require('./state');
const {fail}=require('./errors');
const {DEFINITIONS,messagesFor}=require('./prompts');
const {planCandidates}=require('./catalog');
const foodLabel=require('./food-label');
const SCENES=['office','classroom','dorm','home','outdoor','commute','any'];
const EXTRA=['consent','profile'];
const FIELDS={
  generateDiary:['date','name','actions','meals','mood','note','companionKey','previous'],parseState:['text'],explainActions:['text','day','actions'],generateAction:['text','day','draft'],
  analyzeMeal:['text','name','note','imageBase64','mimeType'],extractReport:['text','imageBase64','mimeType'],
  generatePlan:['type','goal','startDate','minutes','dayCount','constraints','preferences','context','actions'],
  generateTicketTitle:['date','actions','meals','mood'],mealDayReview:['date','meals','phase'],summarizeProfile:[],extractFoodPreferences:[]
};
function compactMeal(m,f){v.object(m,f);return {name:v.text(m.name,f+'.name',200,true),note:v.text(m.note,f+'.note',2000),kcal:v.nullableNumber(m.kcal,f+'.kcal',30000),protein:v.nullableNumber(m.protein,f+'.protein',3000),carbs:v.nullableNumber(m.carbs,f+'.carbs',3000),fat:v.nullableNumber(m.fat,f+'.fat',3000)};}
function prepare(task,input){
  if(!DEFINITIONS[task])fail('TASK_NOT_FOUND','找不到这项 AI 功能。',false);
  if(task==='analyzeFoodLabel')return foodLabel.prepare(input);
  const p=v.object(input,'payload',FIELDS[task].concat(EXTRA));
  if(p.consent!==true)fail('AI_CONSENT_REQUIRED','请先同意将本次资料用于 AI 处理。',false);
  const data={};if(p.profile)data.profile=profile(p.profile);
  let image=null;
  if((task==='summarizeProfile'||task==='extractFoodPreferences')&&!data.profile)v.invalid('profile');
  if(task==='generateDiary'){
    data.date=v.date(p.date,'date');data.name=v.text(p.name,'name',60);data.note=v.text(p.note,'note',8000);data.mood=v.text(p.mood,'mood',100);
    data.companionKey=['cat','dachshund'].includes(p.companionKey)?p.companionKey:'xiaowei';
    data.allowedStickers=data.companionKey==='xiaowei'?['face','flower','star','heart']:['face','paw','star','heart'];
    data.actions=v.list(p.actions||[],'actions',100,(a,f)=>({title:v.text(a.title,f+'.title',200,true),durationMinutes:v.number(a.durationMinutes,f+'.durationMinutes',0,1440),feedback:v.text(a.feedback,f+'.feedback',100)}));
    data.meals=v.list(p.meals||[],'meals',100,(m,f)=>Object.assign(compactMeal(m,f),{tags:v.texts(m.tags||[],f+'.tags',30,80)}));
    data.previous=v.text(p.previous,'previous',6000);
  }
  if(task==='parseState')data.text=typeof p.text==='string'?p.text.slice(0,4000):p.text===undefined||p.text===null?'':String(p.text).slice(0,4000);
  if(task==='generateAction'){
    data.text=v.text(p.text,'text',4000,true);
    if(!data.profile)v.invalid('profile');
    if(p.day){v.object(p.day,'day');data.day={energy:v.number(p.day.energy,'energy',1,5,true),minutes:v.number(p.day.minutes,'minutes',0,1440),scene:v.choice(p.day.scene,'scene',SCENES),note:v.text(p.day.note,'note',4000),mood:v.text(p.day.mood,'mood',100)};}
    if(p.draft){const d=v.object(p.draft,'draft',['title','category','durationMinutes','steps','why']);data.draft={title:v.text(d.title,'draft.title',60),category:v.text(d.category,'draft.category',40),durationMinutes:v.text(d.durationMinutes,'draft.durationMinutes',20),steps:v.text(d.steps,'draft.steps',2400),why:v.text(d.why,'draft.why',1000)};}
  }
  if(task==='explainActions'){
    data.text=v.text(p.text,'text',4000);
    if(p.day){v.object(p.day,'day');data.day={energy:v.number(p.day.energy,'energy',1,5,true),minutes:v.number(p.day.minutes,'minutes',0,1440),scene:v.choice(p.day.scene,'scene',SCENES),note:v.text(p.day.note,'note',4000),mood:v.text(p.day.mood,'mood',100)};}
    const seen=new Set();
    data.actions=v.list(p.actions,'actions',30,(a,f)=>{v.object(a,f);const id=v.text(a.id,f+'.id',100,true);if(seen.has(id))v.invalid(f+'.id');seen.add(id);return {id,title:v.text(a.title,f+'.title',200,true),durationMinutes:v.number(a.durationMinutes,f+'.durationMinutes',0,1440),avoidWhen:v.texts(a.avoidWhen,f+'.avoidWhen',30,80)};});
    if(!data.actions.length)v.invalid('actions');
    const restrictions=data.profile?data.profile.restrictions:[];
    data.actions=data.actions.filter(a=>!a.avoidWhen.some(tag=>restrictions.includes(tag)));
    if(!data.actions.length)fail('NO_COMPATIBLE_ACTIONS','这些行动不适合已填写的活动限制，请换一批。',false);
  }
  if(task==='analyzeMeal'||task==='extractReport'){
    data.text=v.text(p.text,'text',12000);image=v.image(p);
    if(task==='analyzeMeal'){data.name=v.text(p.name,'name',200);data.note=v.text(p.note,'note',4000);}
    if(!data.text&&!image&&!data.name&&!data.note)v.invalid('请提供图片或文字');
  }
  if(task==='generatePlan'){
    data.type=v.choice(p.type,'type',['life','strength','aerobic']);data.goal=v.text(p.goal,'goal',2000,true);data.startDate=v.date(p.startDate,'startDate');
    data.dayCount=p.dayCount===undefined?7:v.choice(p.dayCount,'dayCount',[3,7,14]);
    data.minutes=p.minutes===undefined?30:v.number(p.minutes,'minutes',1,120,true);
    data.constraints=v.texts(p.constraints,'constraints',30,200);data.preferences=v.text(p.preferences,'preferences',2000);data.context=v.text(p.context,'context',4000);
    if(p.actions!==undefined)data.actions=planCandidates(p.actions);
    if(!data.profile)v.invalid('profile');
    // All plan types can include movement. Failing closed for an injury also
    // prevents changing type=life from bypassing the physical-plan boundary.
    if(data.profile.specialCondition||data.profile.restrictions.length)fail('PLAN_SAFETY_REVIEW_REQUIRED','你填写了特殊情况或活动限制。当前自动计划还不能可靠适配，请先取得适合自己的活动指导；仍可手动记录已确认的计划。',false);
    if(/疼|痛|受伤|孕|术后|胸闷|头晕|心脏病|高血压|pain|injur|pregnan|surg|dizz|medical/i.test(data.constraints.join(' ')+' '+data.context+' '+data.profile.notes+' '+data.profile.bodyNotes+' '+data.profile.avoidedActivities+' '+data.goal))fail('PLAN_SAFETY_REVIEW_REQUIRED','这份活动约束需要人工确认，暂不自动生成计划。',false);
  }
  if(task==='generateTicketTitle'){
    data.date=v.date(p.date,'date');data.mood=v.text(p.mood,'mood',100);
    data.actions=v.list(p.actions||[],'actions',100,(a,f)=>typeof a==='string'?v.text(a,f,200,true):v.text(a.title,f+'.title',200,true));
    data.meals=v.list(p.meals||[],'meals',100,(m,f)=>typeof m==='string'?v.text(m,f,200,true):v.text(m.name,f+'.name',200,true));
    if(!data.actions.length&&!data.meals.length&&!data.mood)v.invalid('尚无当天内容');
  }
  if(task==='mealDayReview'){
    data.date=v.date(p.date,'date');data.phase=p.phase===undefined?'ongoing':v.choice(p.phase,'phase',['ongoing','complete']);
    data.meals=v.list(p.meals,'meals',100,(m,f)=>{v.object(m,f);if(m.date!==data.date||m.confirmed!==true)v.invalid(f+'.日期或确认状态');return compactMeal(m,f);});
    if(!data.meals.length)v.invalid('meals');
  }
  return {data,image};
}
const {normalizeResult:validateResult}=require('./model-result');
async function runAI(task,payload,provider,beforeCall){
  const prepared=prepare(task,payload);if(task==='parseState'&&!prepared.data.text.trim())return validateResult(task,prepared.data,{});provider.assertConfigured(Boolean(prepared.image));await beforeCall();
  const messages=task==='analyzeFoodLabel'?foodLabel.messagesFor(prepared.data,prepared.images):messagesFor(task,prepared.data,prepared.image);
  messages[0].content+='\n年龄仅依据已填写的出生日期；未填写时年龄未知，不能把 adult=false 兼容字段当作未成年依据。未成年或未填写生日不构成拒绝日常行动和低强度生活计划的理由，也不要求另行确认成年。仍须遵守明确伤痛、活动禁忌、个人偏好和非医疗范围，不凭年龄推断疾病。';
  const result=await provider.generate(messages,Boolean(prepared.image),{task,dayCount:prepared.data.dayCount});return validateResult(task,prepared.data,result);
}
module.exports={prepare,validateResult,runAI};
