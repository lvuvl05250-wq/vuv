'use strict';

const cloud=require('wx-server-sdk');
const {createStorage}=require('./storage');
const {createProvider}=require('./provider');
const {createHandler}=require('./handler');

cloud.init({env:cloud.DYNAMIC_CURRENT_ENV});
const handler=createHandler({env:process.env,getWXContext:()=>cloud.getWXContext(),storage:createStorage(cloud.database()),provider:createProvider(process.env)});
exports.main=event=>handler(event);
