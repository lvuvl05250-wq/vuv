'use strict';

const { ApiError, fail } = require('./errors');
const {readContent}=require('./model-result');
const {generationOptions}=require('./generation-options');
const MAX_INPUT_BYTES = 1600 * 1024;
const MAX_RESPONSE_BYTES = 128 * 1024;

function configFor(env, vision) {
  const model = vision ? env.WEIHUO_AI_VISION_MODEL : env.WEIHUO_AI_MODEL;
  if (typeof model !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}$/.test(model)) {
    fail('SERVICE_NOT_CONFIGURED', vision ? '图片识别模型尚未配置，请先在腾讯云开通支持图片的模型。' : '腾讯云 AI 模型尚未配置。', false);
  }
  const timeout = Number(env.WEIHUO_AI_TIMEOUT_MS || 45000);
  if (!Number.isInteger(timeout) || timeout < 1000 || timeout > 50000) fail('SERVICE_NOT_CONFIGURED', 'AI 超时配置不正确。', false);
  return { model, timeout };
}

function mappedError(error) {
  if (error instanceof ApiError) return error;
  const e = error && typeof error === 'object' ? error : {};
  // Inspect only to classify. Never expose upstream text, response bodies, or credentials.
  const code = String(e.code || e.errorCode || '').slice(0, 200);
  const message = typeof e.message === 'string' ? e.message.slice(0, 4000) : '';
  const status = Number(e.statusCode || e.status || (/^\d{3}$/.test(code) ? code : 0));
  const marker = code + ' ' + message;
  const issue = (name, text, retryable) => new ApiError(name, text, retryable);
  if (/timeout|timed.?out|ETIMEDOUT|ESOCKETTIMEDOUT|AbortError|超时/i.test(marker)) return issue('PROVIDER_TIMEOUT', 'AI 处理超时，请稍后重试。', true);
  if (status === 402 || /insufficient[_ .-]*(quota|balance|resource)|quota[_ .-]*exceed|account.?arrears|resource.?exhaust|余额不足|额度不足|资源点不足|欠费/i.test(marker)) return issue('PROVIDER_QUOTA_EXCEEDED', '腾讯云 AI 可用额度不足，请检查当前环境资源点。', false);
  if (status === 429 || /rate[_ .-]*limit|request[_ .-]*limit|too.?many.?requests|频率|限流/i.test(marker)) return issue('PROVIDER_RATE_LIMITED', 'AI 服务暂时达到调用限制，请稍后再试。', true);
  if (/model.{0,30}(not.?found|not.?enabled|unavailable|unsupported)|模型.{0,20}(未开通|未启用|不存在|未上线)|not.{0,8}supported.{0,15}model/i.test(marker)) return issue('SERVICE_NOT_CONFIGURED', '所选腾讯云模型尚未启用或不支持本次输入，请检查环境模型开关。', false);
  if (status === 401 || status === 403 || /unauthori[sz]ed|forbidden|auth.?fail|permission.?denied|access.?denied|invalid.?credential|signature|无权限|没有权限|鉴权|未授权/i.test(marker)) return issue('PROVIDER_AUTH_FAILED', '腾讯云 AI 访问权限需要检查，请核对云函数身份和环境授权。', false);
  if (status >= 500 || /service.?unavailable|internal.?error|服务不可用/i.test(marker)) return issue('PROVIDER_UNAVAILABLE', '腾讯云 AI 服务暂时不可用，请稍后再试。', true);
  if (status >= 400 || /invalid.?parameter|invalid.?request|unsupported|不支持|参数/i.test(marker)) return issue('PROVIDER_REQUEST_REJECTED', '腾讯云模型不支持当前请求，请检查模型能力和配置。', false);
  return issue('PROVIDER_NETWORK_ERROR', '暂时无法连接腾讯云 AI 服务，请稍后重试。', true);
}

function jsonSize(value, max) {
  let encoded;
  try { encoded = JSON.stringify(value); } catch (_) { fail('PROVIDER_INVALID_RESPONSE', 'AI 返回格式不正确，请重试。', true); }
  if (typeof encoded !== 'string' || Buffer.byteLength(encoded) > max) fail('PROVIDER_INVALID_RESPONSE', 'AI 返回内容过大，请缩短输入后重试。', true);
}
function parseResult(result, step) {
  if (!result || typeof result !== 'object') fail('PROVIDER_INVALID_RESPONSE', 'AI 没有返回可读取的结果。', true);
  if (result.error) throw mappedError(result.error);
  if (!Array.isArray(result.rawResponses) || result.rawResponses.length !== 1) fail('PROVIDER_INVALID_RESPONSE', 'AI 返回内容不完整，请重试。', true);
  jsonSize(result.rawResponses, MAX_RESPONSE_BYTES);
  const raw = result.rawResponses[0];
  if (raw && raw.error) throw mappedError(raw.error);
  const choice = raw && Array.isArray(raw.choices) && raw.choices[0];
  const content=typeof result.text==='string'&&result.text.trim()?result.text:choice&&choice.message&&choice.message.content;
  return readContent(content);
}

function createManagedProvider(env, dependencies) {
  const deps = dependencies || {};
  let model;
  let modelTimeout;
  function getModel(config) {
    if (!model || modelTimeout !== config.timeout) {
      const sdk = deps.sdk || require('@cloudbase/node-sdk');
      // CloudBase supplies runtime identity; never read local keys or accept keys from a request.
      const app = sdk.init({ env: sdk.SYMBOL_CURRENT_ENV, timeout: config.timeout, debug: false });
      model = app.ai().createModel('cloudbase');
      modelTimeout = config.timeout;
    }
    return model;
  }
  return {
    configured(vision) { try { configFor(env, vision); return true; } catch (_) { return false; } },
    assertConfigured(vision) { return configFor(env, vision); },
    async generate(messages, vision, context) {
      const config = configFor(env, vision);
      let serialized;
      try { serialized = JSON.stringify(messages); } catch (_) { fail('INVALID_ARGUMENT', 'AI 输入格式不正确。', false); }
      if (!Array.isArray(messages) || !messages.length || typeof serialized !== 'string' || Buffer.byteLength(serialized) > MAX_INPUT_BYTES) fail('INVALID_ARGUMENT', 'AI 输入为空或过大，请缩短文字或裁剪图片。', false);
      // The SDK may append messages internally. Keep the caller's prompt immutable.
      const copy = JSON.parse(serialized);
      let timer;
      let step;
      try {
        const deadline = new Promise((resolve, reject) => {
          timer = setTimeout(() => reject(new ApiError('PROVIDER_TIMEOUT', 'AI 处理超时，请稍后重试。', true)), config.timeout);
        });
        const work = Promise.resolve().then(() => getModel(config).generateText({
          model: config.model, messages: copy, temperature: 0.35, ...generationOptions(context),
          // Hy3's documented direct-answer mode avoids unnecessary reasoning.
          ...(!vision && /^hy3(?:-preview)?$/.test(config.model) ? {thinking: {type: 'disabled'}} : {}),
          response_format: { type: 'json_object' }, maxSteps: 1,
          onStepFinish(value) { step = value; }
        }, { timeout: config.timeout }));
        const result = await Promise.race([work, deadline]);
        return parseResult(result, step);
      } catch (error) { throw mappedError(error); }
      finally { clearTimeout(timer); }
    }
  };
}

module.exports = { createManagedProvider, configFor, parseResult, mappedError };
