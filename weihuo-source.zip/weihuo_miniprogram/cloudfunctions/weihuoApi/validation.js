'use strict';

const { fail } = require('./errors');

function invalid(field) { fail('INVALID_ARGUMENT', '提交的数据格式不正确：' + field, false); }
function object(value, field, keys) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype) invalid(field);
  for (const key of Object.keys(value)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key) || (keys && !keys.includes(key))) invalid(field + '.' + key);
  }
  return value;
}
function text(value, field, max, required) {
  if (value === undefined && !required) return '';
  if (typeof value !== 'string' || value.length > max || (required && !value.trim()) || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value)) invalid(field);
  return value.trim();
}
function number(value, field, min, max, integer) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) invalid(field);
  return value;
}
function boolean(value, field) { if (typeof value !== 'boolean') invalid(field); return value; }
function choice(value, field, options) { if (!options.includes(value)) invalid(field); return value; }
function list(value, field, max, fn) {
  if (!Array.isArray(value) || value.length > max) invalid(field);
  return value.map((v, i) => fn(v, field + '[' + i + ']'));
}
function texts(value, field, maxItems, maxLength) { return list(value || [], field, maxItems, (v, f) => text(v, f, maxLength, true)); }
function date(value, field) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) invalid(field);
  const parsed = new Date(value + 'T00:00:00Z');
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value || value < '1900-01-01' || value > '2200-12-31') invalid(field);
  return value;
}
function dayOffset(value, offset) { const d = new Date(value + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + offset); return d.toISOString().slice(0, 10); }
function nullableNumber(value, field, max) { return value === null || value === undefined ? null : number(value, field, 0, max, false); }
function size(value, field, max) {
  let json;
  try { json = JSON.stringify(value); } catch (_) { invalid(field); }
  if (typeof json !== 'string' || Buffer.byteLength(json) > max) fail('PAYLOAD_TOO_LARGE', '数据较多，超出本次提交的容量限制。', false);
}
function timestamp(value, field) {
  const s = text(value, field, 40, true);
  if (!/^\d{4}-\d{2}-\d{2}T/.test(s) || !Number.isFinite(Date.parse(s))) invalid(field);
  return s;
}
function image(payload) {
  if (payload.imageBase64 === undefined) return null;
  const encoded = text(payload.imageBase64, 'imageBase64', 720 * 1024, true);
  choice(payload.mimeType, 'mimeType', ['image/jpeg', 'image/png', 'image/webp']);
  if (encoded.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) invalid('imageBase64');
  const bytes = Buffer.from(encoded, 'base64');
  if (bytes.length > 512 * 1024 || bytes.length < 12 || bytes.toString('base64') !== encoded) invalid('imageBase64');
  const jpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const png = bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const webp = bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP';
  if (!(payload.mimeType === 'image/jpeg' && jpeg) && !(payload.mimeType === 'image/png' && png) && !(payload.mimeType === 'image/webp' && webp)) invalid('mimeType');
  return { mimeType: payload.mimeType, imageBase64: encoded };
}

module.exports = { invalid, object, text, number, boolean, choice, list, texts, date, dayOffset, nullableNumber, size, timestamp, image };
