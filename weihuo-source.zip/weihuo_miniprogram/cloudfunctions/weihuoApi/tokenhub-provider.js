'use strict';

const {ApiError, fail} = require('./errors');
const {readContent} = require('./model-result');
const {image: validateImage} = require('./validation');

const ENDPOINT = 'https://tokenhub.tencentmaas.com/v1/chat/completions';
const MAX_INPUT_BYTES = 1600 * 1024;
const MAX_RESPONSE_BYTES = 128 * 1024;
const TASK_OUTPUT_LIMITS = Object.freeze({analyzeMeal: 512, analyzeFoodLabel: 768, extractReport: 1536});

function configFor(env) {
  if (env.WEIHUO_AI_VISION_ENDPOINT && env.WEIHUO_AI_VISION_ENDPOINT !== ENDPOINT) {
    fail('SERVICE_NOT_CONFIGURED', '图片识别仅支持已核验的腾讯 TokenHub 服务地址。', false);
  }
  const apiKey = env.WEIHUO_AI_VISION_API_KEY;
  if (typeof apiKey !== 'string' || apiKey.length < 8 || apiKey.length > 4096 || /\s|[^\x21-\x7e]/.test(apiKey) || /YOUR_|PLACEHOLDER|请填写|^<|^replace/i.test(apiKey)) {
    fail('SERVICE_NOT_CONFIGURED', '图片识别尚未配置 TokenHub API Key，请在云函数环境变量中填写。', false);
  }
  const model = env.WEIHUO_AI_VISION_MODEL;
  if (typeof model !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._/-]{0,199}$/.test(model)) fail('SERVICE_NOT_CONFIGURED', '请配置已开通且支持图片的 TokenHub 模型 ID。', false);
  const timeout = Number(env.WEIHUO_AI_VISION_TIMEOUT_MS || 45000);
  const maxTokens = Number(env.WEIHUO_AI_VISION_MAX_TOKENS || 2048);
  const jsonMode = env.WEIHUO_AI_VISION_JSON_MODE || 'text';
  const thinking = env.WEIHUO_AI_VISION_THINKING || '';
  const reasoningEffort = env.WEIHUO_AI_VISION_REASONING_EFFORT || (model === 'glm-5.3-flash' ? 'low' : '');
  if (!Number.isInteger(timeout) || timeout < 1000 || timeout > 50000 || !Number.isInteger(maxTokens) || maxTokens < 256 || maxTokens > 4096 || !['text', 'json_object'].includes(jsonMode) || !['', 'disabled'].includes(thinking) || !['', 'low', 'high', 'max'].includes(reasoningEffort) || (model === 'glm-5.3-flash' && thinking === 'disabled')) {
    fail('SERVICE_NOT_CONFIGURED', '图片识别的超时、输出长度或响应格式配置不正确。', false);
  }
  return {endpoint: ENDPOINT, apiKey, model, timeout, maxTokens, jsonMode, thinking, reasoningEffort};
}

function invalidInput() { fail('INVALID_ARGUMENT', '图片识别输入不正确，请重新选择清晰的图片。', false); }
function prepareMessages(messages) {
  let serialized;
  try { serialized = JSON.stringify(messages); } catch (_) { invalidInput(); }
  if (!Array.isArray(messages) || !messages.length || messages.length > 40 || !serialized || Buffer.byteLength(serialized) > MAX_INPUT_BYTES) {
    fail('PAYLOAD_TOO_LARGE', '图片和文字超出本次识别容量，请裁剪图片或减少文字。', false);
  }
  let images = 0;
  const copy = messages.map(message => {
    if (!message || !['system', 'user', 'assistant'].includes(message.role)) invalidInput();
    if (typeof message.content === 'string') return {role: message.role, content: message.content};
    if (message.role !== 'user' || !Array.isArray(message.content) || !message.content.length) invalidInput();
    const content = message.content.map(part => {
      if (part && part.type === 'text' && typeof part.text === 'string') return {type: 'text', text: part.text};
      if (!part || part.type !== 'image_url' || !part.image_url || typeof part.image_url.url !== 'string') invalidInput();
      const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+=*)$/.exec(part.image_url.url);
      // Only local bytes are accepted: no remote URL, redirect, file or video fetching.
      if (!match || ++images > 2) invalidInput();
      validateImage({mimeType: match[1], imageBase64: match[2]});
      return {type: 'image_url', image_url: {url: part.image_url.url}};
    });
    return {role: message.role, content};
  });
  if (!images) invalidInput();
  return copy;
}

function mappedError(status, envelope) {
  const error = envelope && typeof envelope === 'object' && (envelope.error || envelope.Error || envelope);
  const code = error && typeof error === 'object' ? String(error.code || error.Code || error.type || '').slice(0, 200) : '';
  const message = error && typeof error === 'object' && (error.message || error.Message);
  const marker = code + ' ' + (typeof message === 'string' ? message.slice(0, 2000) : '');
  const result = (name, text, retryable = false) => new ApiError(name, text, retryable);
  // Upstream fields are inspected only for classification; none are returned or logged.
  if (/401007|no.?free.?package|not.?open|not.?activat|not.?enable|未开通|未启用|后付费未|模型.{0,10}不存在|model.?not.?found/i.test(marker)) {
    return result('SERVICE_NOT_CONFIGURED', 'TokenHub 图片模型尚未开通或没有可用试用额度，请在 TokenHub 控制台启用该模型的按量后付费。');
  }
  if (status === 401 || status === 403 || /authentication|unauthori[sz]ed|invalid.?api.?key|permission|鉴权|无权限/i.test(marker)) {
    return result('PROVIDER_AUTH_FAILED', 'TokenHub 图片识别的 API Key 无效或未授权该模型，请检查云函数视觉密钥。');
  }
  if (/insufficient|arrears|balance|quota.?exceed|欠费|余额不足|额度不足/i.test(marker)) {
    return result('PROVIDER_QUOTA_EXCEEDED', 'TokenHub 图片识别额度不足，请检查该模型额度和账户余额。');
  }
  if (status === 402) return result('PROVIDER_QUOTA_EXCEEDED', 'TokenHub 图片识别暂不可计费，请检查该模型是否开通按量后付费以及账户余额。');
  if (status === 429 || /rate.?limit|too.?many|限流/i.test(marker)) return result('PROVIDER_RATE_LIMITED', '图片识别暂时达到调用限制，请稍后重试。', true);
  if (status === 408 || status === 504 || /timeout|timed.?out/i.test(marker)) return result('PROVIDER_TIMEOUT', '图片识别处理超时，请稍后重试。', true);
  if (status >= 500) return result('PROVIDER_UNAVAILABLE', 'TokenHub 图片识别暂时不可用，请稍后重试。', true);
  return result('PROVIDER_REQUEST_REJECTED', 'TokenHub 未接受本次图片请求，请检查图片格式和模型配置。');
}

async function readLimited(response) {
  const declared = Number(response.headers && response.headers.get('content-length'));
  if (declared > MAX_RESPONSE_BYTES) {
    if (response.body && response.body.cancel) await response.body.cancel();
    fail('PROVIDER_INVALID_RESPONSE', '图片识别返回内容过大，请裁剪图片后重试。', true);
  }
  if (!response.body || typeof response.body.getReader !== 'function') fail('PROVIDER_INVALID_RESPONSE', '图片识别没有返回可读取的数据。', true);
  const reader = response.body.getReader();
  const chunks = []; let size = 0;
  try {
    while (true) {
      const part = await reader.read(); if (part.done) break;
      size += part.value.byteLength;
      if (size > MAX_RESPONSE_BYTES) { await reader.cancel(); fail('PROVIDER_INVALID_RESPONSE', '图片识别返回内容过大，请裁剪图片后重试。', true); }
      chunks.push(Buffer.from(part.value));
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks).toString('utf8');
}

function createTokenHubProvider(env, fetchImpl, dependencies) {
  const fetcher = fetchImpl || globalThis.fetch;
  const deps = dependencies || {};
  return {
    configured() { try { configFor(env); return true; } catch (_) { return false; } },
    assertConfigured() { const config = configFor(env); return {model: config.model, timeout: config.timeout, maxTokens: config.maxTokens}; },
    async generate(messages, vision, options) {
      const config = configFor(env);
      const copy = prepareMessages(messages);
      const task = options && options.task;
      const maxTokens = Math.min(config.maxTokens, Object.hasOwn(TASK_OUTPUT_LIMITS, task) ? TASK_OUTPUT_LIMITS[task] : config.maxTokens);
      if (typeof fetcher !== 'function') fail('SERVICE_NOT_CONFIGURED', '云函数需要支持 fetch 的 Node.js 运行时。', false);
      const controller = new AbortController(); let timer;
      try {
        const deadline = new Promise((_, reject) => { timer = setTimeout(() => {
          controller.abort(); reject(new ApiError('PROVIDER_TIMEOUT', '图片识别处理超时，请稍后重试。', true));
        }, config.timeout); });
        const work = async () => {
          const body = {model: config.model, messages: copy, temperature: 0.2, max_tokens: maxTokens, stream: false};
          // Model-specific JSON mode is opt-in; prompts already request JSON.
          if (config.jsonMode === 'json_object') body.response_format = {type: 'json_object'};
          if (config.thinking) body.thinking = {type: config.thinking};
          if (config.reasoningEffort) body.reasoning_effort = config.reasoningEffort;
          const response = await fetcher(config.endpoint, {method: 'POST', headers: {'Content-Type': 'application/json', Authorization: 'Bearer ' + config.apiKey}, body: JSON.stringify(body), signal: controller.signal, redirect: 'error'});
          if (!response.ok && !response.body) throw mappedError(response.status, null);
          const raw = await readLimited(response);
          let envelope; try { envelope = JSON.parse(raw); } catch (_) {
            if (!response.ok) throw mappedError(response.status, null);
            fail('PROVIDER_INVALID_RESPONSE', '图片识别没有返回可读取的数据，请重试。', true);
          }
          if (!response.ok || (envelope && (envelope.error || envelope.Error))) throw mappedError(response.status, envelope);
          const choice = envelope && Array.isArray(envelope.choices) && envelope.choices[0];
          const content = choice && choice.message && choice.message.content;
          if ((typeof content !== 'string' || !content.trim()) && choice && ['length', 'max_tokens'].includes(choice.finish_reason)) {
            fail('PROVIDER_OUTPUT_LIMIT', '图片识别达到本次输出长度上限，尚未生成完整结果。照片仍在，可重试或手动填写。', true);
          }
          if (typeof content !== 'string' || !content.trim()) fail('PROVIDER_INVALID_RESPONSE', '图片识别本次没有生成结果。照片仍在，可重试或手动填写。', true);
          if (controller.signal.aborted) throw new ApiError('PROVIDER_TIMEOUT', '图片识别处理超时，请稍后重试。', true);
          if (typeof deps.onUsage === 'function') {
            const usage = envelope.usage || {};
            deps.onUsage(Object.fromEntries(['prompt_tokens', 'completion_tokens', 'total_tokens'].map(key => [key, Number.isSafeInteger(usage[key]) && usage[key] >= 0 ? usage[key] : null])));
          }
          return readContent(content);
        };
        return await Promise.race([work(), deadline]);
      } catch (error) {
        if (controller.signal.aborted) fail('PROVIDER_TIMEOUT', '图片识别处理超时，请稍后重试。', true);
        if (error instanceof ApiError) throw error;
        fail('PROVIDER_NETWORK_ERROR', '暂时无法连接 TokenHub 图片识别服务，请稍后重试。', true);
      } finally { clearTimeout(timer); }
    }
  };
}

module.exports = {createTokenHubProvider, configFor, prepareMessages, mappedError, ENDPOINT};
