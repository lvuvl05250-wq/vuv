'use strict';

const v = require('./validation');
const period = require('./period');
const {normalizeFoodExclusions}=require('./food-exclusions');
const {validateMealLabel}=require('./saved-food-label');
const {actionTemplate, uniqueActions, audio, video, CATEGORIES} = require('./catalog');

function profile(input) {
  const p = v.object(input, 'profile', ['name','avatarPath','adult','safetyAnswered','specialCondition','restrictions','allergies','foodExclusions','notes','goals','onboarded','birthDate','heightCm','weightKg','bodyFatPercent','exerciseHabit','avoidedActivities','bodyNotes','healthSummary','measurements']);
  const birthDate=p.birthDate===undefined||p.birthDate===''?'':v.date(p.birthDate,'birthDate');
  const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
  if(birthDate&&birthDate>today)v.invalid('birthDate');
  let age=null;
  if(birthDate){age=Number(today.slice(0,4))-Number(birthDate.slice(0,4));if(today.slice(5)<birthDate.slice(5))age-=1;}
  // Legacy flags remain in stored snapshots; age comes only from the birth date.
  if(p.adult!==undefined)v.boolean(p.adult,'adult');
  const adult=age!==null&&age>=18;
  const heightCm=p.heightCm===null||p.heightCm===undefined?null:v.number(p.heightCm,'heightCm',30,300);
  const weightKg=p.weightKg===null||p.weightKg===undefined?null:v.number(p.weightKg,'weightKg',1,700);
  const bodyFatPercent=v.nullableNumber(p.bodyFatPercent,'bodyFatPercent',100);
  const measurements=unique(v.list(p.measurements===undefined?[]:p.measurements,'measurements',1000,measurement),'measurements');
  return { name:v.text(p.name, 'name', 60), avatarPath:v.text(p.avatarPath,'avatarPath',1000), adult, safetyAnswered:p.safetyAnswered===undefined?false:v.boolean(p.safetyAnswered, 'safetyAnswered'), specialCondition:v.boolean(p.specialCondition, 'specialCondition'), restrictions:v.texts(p.restrictions,'restrictions',30,80), allergies:v.text(p.allergies,'allergies',1000), foodExclusions:normalizeFoodExclusions(p,p.foodExclusions), notes:v.text(p.notes,'notes',2000), goals:v.texts(p.goals,'goals',15,200), onboarded:v.boolean(p.onboarded,'onboarded'),birthDate,heightCm,weightKg,bodyFatPercent,exerciseHabit:v.text(p.exerciseHabit,'exerciseHabit',2000),avoidedActivities:v.text(p.avoidedActivities,'avoidedActivities',4000),bodyNotes:v.text(p.bodyNotes,'bodyNotes',4000),healthSummary:v.text(p.healthSummary,'healthSummary',8000),measurements };
}
function measurement(input,field){
  const m=v.object(input,field,['id','name','value','unit','date','source','reportId','sourceMetricKey','createdAt']);
  const source=v.choice(m.source,field+'.source',['manual','report']);
  return {id:v.text(m.id,field+'.id',100,true),name:v.text(m.name,field+'.name',100,true),value:v.text(m.value,field+'.value',100,true),unit:v.text(m.unit,field+'.unit',60),date:v.date(m.date,field+'.date'),source,reportId:v.text(m.reportId,field+'.reportId',100,source==='report'),sourceMetricKey:v.text(m.sourceMetricKey,field+'.sourceMetricKey',600),createdAt:v.timestamp(m.createdAt,field+'.createdAt')};
}
function metric(input, field, required) {
  const m = v.object(input, field, ['name','value','unit','reference']);
  const needsValue=required!==false;
  if(m.value!==undefined&&typeof m.value!=='string'&&typeof m.value!=='number')v.invalid(field+'.value');
  return {name:v.text(m.name,field+'.name',100,needsValue), value:v.text(String(m.value === undefined ? '' : m.value),field+'.value',100,needsValue),unit:v.text(m.unit,field+'.unit',60),reference:v.text(m.reference,field+'.reference',150)};
}
function action(input, field) {
  const a=v.object(input,field,['id','actionId','title','durationMinutes','steps','minimumVersion','stopSignal','status','feedback','createdAt','date','source','kind','category','tags','avoidWhen','audio','video']);
  const out={id:v.text(a.id,field+'.id',100,true),actionId:v.text(a.actionId,field+'.actionId',100),title:v.text(a.title,field+'.title',200,true),durationMinutes:v.number(a.durationMinutes,field+'.durationMinutes',0,1440),steps:v.texts(a.steps,field+'.steps',30,1000),minimumVersion:v.text(a.minimumVersion,field+'.minimumVersion',1000),stopSignal:v.text(a.stopSignal,field+'.stopSignal',1000),status:v.choice(a.status,field+'.status',['planned','completed','skipped']),feedback:a.feedback ? v.choice(a.feedback,field+'.feedback',['comfortable','neutral','uncomfortable']) : '',createdAt:v.timestamp(a.createdAt,field+'.createdAt'),date:v.date(a.date,field+'.date'),source:v.choice(a.source,field+'.source',['manual','catalog','ai','rule'])};
  if(a.kind) out.kind=v.choice(a.kind,field+'.kind',['movement','care']);
  if(a.tags) out.tags=v.texts(a.tags,field+'.tags',30,80);
  if(a.avoidWhen) out.avoidWhen=v.texts(a.avoidWhen,field+'.avoidWhen',30,80);
  if(a.category!==undefined)out.category=v.choice(a.category,field+'.category',CATEGORIES);
  if(a.audio!==undefined)out.audio=audio(a.audio,field+'.audio');
  if(a.video!==undefined)out.video=video(a.video,field+'.video');
  return out;
}
function meal(input,field) {
  const m=v.object(input,field,['id','date','time','name','note','photoPath','kcal','protein','carbs','fat','nutritionSource','tags','confirmed','createdAt','updatedAt','foodLabel','labelPhotoPaths']);
  const time=v.text(m.time,field+'.time',5,true);
  if(!/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))v.invalid(field+'.time');
  if(m.photoPath) v.invalid(field+'.photoPath（云同步前须移除本机照片路径）');
  const out={id:v.text(m.id,field+'.id',100,true),date:v.date(m.date,field+'.date'),time,name:v.text(m.name,field+'.name',200,true),note:v.text(m.note,field+'.note',4000),photoPath:'',kcal:v.nullableNumber(m.kcal,field+'.kcal',30000),protein:v.nullableNumber(m.protein,field+'.protein',3000),carbs:v.nullableNumber(m.carbs,field+'.carbs',3000),fat:v.nullableNumber(m.fat,field+'.fat',3000),nutritionSource:v.choice(m.nutritionSource,field+'.nutritionSource',['manual','ai-estimate','label']),tags:v.texts(m.tags,field+'.tags',30,80),confirmed:v.boolean(m.confirmed,field+'.confirmed')};
  if(m.labelPhotoPaths!==undefined&&(!Array.isArray(m.labelPhotoPaths)||m.labelPhotoPaths.length))v.invalid(field+'.labelPhotoPaths（云同步前须移除本机照片路径）');
  out.labelPhotoPaths=[];out.foodLabel=m.foodLabel===undefined?null:m.foodLabel;
  try{out.foodLabel=validateMealLabel(out);}catch(error){v.invalid(field+'.foodLabel');}
  if(m.createdAt)out.createdAt=v.timestamp(m.createdAt,field+'.createdAt');
  if(m.updatedAt)out.updatedAt=v.timestamp(m.updatedAt,field+'.updatedAt');
  return out;
}
function plan(input,field) {
  const p=v.object(input,field,['id','title','type','goal','source','days','createdAt','note']);
  const seen=new Set();
  const days=v.list(p.days,field+'.days',60,(d,f)=>{
    v.object(d,f,['date','title','minutes','done','details','actionIds']);
    const date=v.date(d.date,f+'.date');if(seen.has(date))v.invalid(f+'.date重复');seen.add(date);
    const actionIds=v.texts(d.actionIds,f+'.actionIds',10,100);if(new Set(actionIds).size!==actionIds.length)v.invalid(f+'.actionIds');
    return {date,title:v.text(d.title,f+'.title',300,true),minutes:v.number(d.minutes,f+'.minutes',0,600),done:v.boolean(d.done,f+'.done'),details:v.text(d.details,f+'.details',5000),actionIds};
  });
  return {id:v.text(p.id,field+'.id',100,true),title:v.text(p.title,field+'.title',200,true),type:v.choice(p.type,field+'.type',['life','strength','aerobic']),goal:v.text(p.goal,field+'.goal',2000),source:v.choice(p.source,field+'.source',['manual','ai']),days,createdAt:v.timestamp(p.createdAt,field+'.createdAt'),note:v.text(p.note,field+'.note',8000)};
}
function report(input,field){
  const r=v.object(input,field,['id','title','date','photoPath','confirmed','metrics','restrictions','note','createdAt','updatedAt']);
  if(r.photoPath)v.invalid(field+'.photoPath（云同步前须移除本机照片路径）');
  const out={id:v.text(r.id,field+'.id',100,true),title:v.text(r.title,field+'.title',200,true),date:v.date(r.date,field+'.date'),photoPath:'',confirmed:v.boolean(r.confirmed,field+'.confirmed'),metrics:v.list(r.metrics,field+'.metrics',100,(m,f)=>metric(m,f,r.confirmed)),restrictions:v.texts(r.restrictions,field+'.restrictions',30,80),note:v.text(r.note,field+'.note',4000)};
  if(r.createdAt)out.createdAt=v.timestamp(r.createdAt,field+'.createdAt');if(r.updatedAt)out.updatedAt=v.timestamp(r.updatedAt,field+'.updatedAt');return out;
}
function unique(items, field){const seen=new Set();for(const r of items){if(seen.has(r.id))v.invalid(field+'.id重复');seen.add(r.id);}return items;}
function validateState(input){
  v.size(input,'state',700*1024);
  const s=v.object(input,'state',['profile','days','meals','plans','reports','tickets','settings','customActions','periodRecords','periodSettings']);
  const days={};v.object(s.days,'days');if(Object.keys(s.days).length>730)v.invalid('days');
  for(const key of Object.keys(s.days)){
    v.date(key,'days.key');const d=v.object(s.days[key],'day',['date','energy','scene','minutes','mood','note','actions','carePreference','scenes']);
    if(d.date!==key)v.invalid('day.date');
    days[key]={date:key,energy:v.number(d.energy,'day.energy',1,5,true),scene:v.choice(d.scene,'day.scene',['office','classroom','dorm','home','outdoor','commute','any']),scenes:v.list(d.scenes===undefined?[d.scene]:d.scenes,'day.scenes',7,(value,field)=>v.choice(value,field,['office','classroom','dorm','home','outdoor','commute','any'])),minutes:v.number(d.minutes,'day.minutes',0,1440),carePreference:d.carePreference===undefined?50:v.number(d.carePreference,'day.carePreference',0,100),mood:v.text(d.mood,'day.mood',100),note:v.text(d.note,'day.note',4000),actions:unique(v.list(d.actions,'day.actions',100,action),'day.actions')};
    if(!days[key].scenes.length||new Set(days[key].scenes).size!==days[key].scenes.length)v.invalid('day.scenes');
    if(days[key].actions.some(a=>a.date!==key))v.invalid('day.actions.date');
  }
  const settings=v.object(s.settings,'settings',['aiConsent','cloudConsent','reduceMotion','companion','savedRecipes','foodPreferences','foodAvoid']);
  const tickets=unique(v.list(s.tickets,'tickets',730,(t,f)=>{
    v.object(t,f,['id','date','title','note','actions','meals','mood','createdAt','authorName','companionKey','diary','updatedAt']);
    const date=v.date(t.date,f+'.date');const actions=v.list(t.actions,f+'.actions',100,action);const meals=v.list(t.meals,f+'.meals',100,meal);
    if(actions.some(a=>a.date!==date)||meals.some(m=>m.date!==date))v.invalid(f+'.date');
    return {id:v.text(t.id,f+'.id',100,true),date,title:v.text(t.title,f+'.title',200,true),note:v.text(t.note,f+'.note',8000),actions,meals,...(t.diary?{diary:require('./diary-content').normalizeDiary(t.diary,t.companionKey)}:{}),...(t.updatedAt?{updatedAt:v.timestamp(t.updatedAt,f+'.updatedAt')}:{}),...(t.authorName!==undefined?{authorName:v.text(t.authorName,f+'.authorName',60)}:{}),...(t.companionKey!==undefined?{companionKey:v.choice(t.companionKey,f+'.companionKey',['xiaowei','cat','dachshund'])}:{}),mood:v.text(t.mood,f+'.mood',100),createdAt:v.timestamp(t.createdAt,f+'.createdAt')};
  }),'tickets');
  if(new Set(tickets.map(t=>t.date)).size!==tickets.length)v.invalid('tickets.date重复');
  const customActions=uniqueActions(v.list(s.customActions===undefined?[]:s.customActions,'customActions',300,(a,f)=>actionTemplate(a,f,'manual')),'customActions');
  let periodRecords;try{periodRecords=period.validateRecords(s.periodRecords,new Date(Date.now()+8*3600000).toISOString().slice(0,10));}catch(error){v.invalid('periodRecords');}
  let periodSettings;try{periodSettings=period.validateSettings(s.periodSettings);}catch(error){v.invalid('periodSettings');}
  const savedRecipes=settings.savedRecipes===undefined?[]:v.texts(settings.savedRecipes,'savedRecipes',100,100);if(new Set(savedRecipes).size!==savedRecipes.length)v.invalid('savedRecipes');
  const pref=v.object(settings.foodPreferences===undefined?{}:settings.foodPreferences,'foodPreferences',['taste','color','texture','temperature','scene']);
  const foodPreferences={};['taste','color','texture','temperature','scene'].forEach(k=>{foodPreferences[k]=v.text(pref[k], 'foodPreferences.'+k,80);});
  const foodAvoid=settings.foodAvoid===undefined?[]:v.texts(settings.foodAvoid,'foodAvoid',30,80);if(new Set(foodAvoid).size!==foodAvoid.length)v.invalid('foodAvoid');
  return {profile:profile(s.profile),periodRecords,periodSettings,days,meals:unique(v.list(s.meals,'meals',2000,meal),'meals'),plans:unique(v.list(s.plans,'plans',100,plan),'plans'),reports:unique(v.list(s.reports,'reports',100,report),'reports'),tickets,customActions,settings:{aiConsent:v.boolean(settings.aiConsent,'aiConsent'),cloudConsent:v.boolean(settings.cloudConsent,'cloudConsent'),reduceMotion:v.boolean(settings.reduceMotion,'reduceMotion'),companion:v.choice(settings.companion===undefined?'xiaowei':settings.companion,'companion',['xiaowei','cat','dachshund']),savedRecipes,foodPreferences,foodAvoid}};
}

module.exports={profile,metric,meal,validateState};
