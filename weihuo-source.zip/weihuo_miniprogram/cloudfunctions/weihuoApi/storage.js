'use strict';

const crypto = require('node:crypto');
const { fail } = require('./errors');
const {validateCatalog} = require('./catalog');

function subjectId(identity) { return crypto.createHash('sha256').update(identity.appid + ':' + identity.openid).digest('hex'); }
function first(result) { const data=result && result.data; return Array.isArray(data) ? data[0] || null : data || null; }
async function getDocument(ref) {
  try { return first(await ref.get()); }
  catch(error) {
    // Some SDK releases throw for a missing document. A missing collection or
    // permission error must stay an error, never masquerade as an empty account.
    if(error && /document(?: with _id .+)? (?:does not exist|not found)/i.test(String(error.errMsg || error.message || '')) && !/collection/i.test(String(error.errMsg || error.message || '')))return null;
    throw error;
  }
}

function createStorage(db, now) {
  const clock=now || Date.now;
  return {
    async getCatalog() {
      let row;
      try { row=await getDocument(db.collection('weihuo_catalog').doc('current')); }
      catch(error) {
        const message=String(error && (error.errMsg || error.message || error.code) || '');
        if(/COLLECTION_NOT_EXIST|DATABASE_COLLECTION_NOT_EXIST|collection[^\n]*(?:does not exist|not exist|not found)/i.test(message))fail('CATALOG_NOT_CONFIGURED','云端行动库尚未配置，请稍后再试。',false);
        throw error;
      }
      return validateCatalog(row,clock());
    },
    async pull(identity) {
      const row=await getDocument(db.collection('weihuo_records').doc(subjectId(identity)));
      return row ? {version:row.version,state:row.state,updatedAt:row.updatedAt} : {version:0,state:null,updatedAt:null};
    },
    async push(identity,baseVersion,state) {
      const key=subjectId(identity);
      return db.runTransaction(async transaction=>{
        const ref=transaction.collection('weihuo_records').doc(key);
        const current=await getDocument(ref);
        const version=current ? current.version : 0;
        if(version!==baseVersion)fail('VERSION_CONFLICT','云端记录已更新，请先读取并选择保留哪份记录。',false,{currentVersion:version});
        const updatedAt=new Date(clock()).toISOString();
        await ref.set({data:{owner:key,version:version+1,state,updatedAt}});
        return {version:version+1,updatedAt};
      });
    },
    async erase(identity,baseVersion) {
      // Preserve a versioned tombstone so an older device cannot silently
      // recreate records after the user deleted their cloud copy.
      return this.push(identity,baseVersion,null);
    },
    async reserveAI(identity,limit) {
      const nowMs=clock();const date=new Date(nowMs+8*3600000).toISOString().slice(0,10);
      const key=subjectId(identity);
      return db.runTransaction(async transaction=>{
        const ref=transaction.collection('weihuo_usage').doc(key);
        const row=await getDocument(ref);
        const count=row && row.date===date ? row.count : 0;
        if(row && nowMs-row.lastRequestAt<2000)fail('RATE_LIMITED','请求太快，请稍等片刻。',true);
        if(count>=limit)fail('DAILY_LIMIT_REACHED','今天的 AI 请求次数已用完，明天可继续。',false);
        await ref.set({data:{owner:key,date,count:count+1,lastRequestAt:nowMs}});
      });
    }
  };
}

module.exports={createStorage,subjectId};
