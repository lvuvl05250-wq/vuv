'use strict';

// Explicit operator command only. No automatic reads, uploads, retries or deployment.
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const {readConfiguration, syntheticReport} = require('./ai-preflight');
const {createTokenHubProvider} = require('../weihuoApi/tokenhub-provider');
const {runAI} = require('../weihuoApi/ai');
const ROOT = path.resolve(__dirname, '../..');
const DEFAULT_FILE = path.resolve(__dirname, '../.env.weihuo-vision.local');

function issue(code) { const error = new Error(code); error.code = code; throw error; }
function initialize(file = DEFAULT_FILE) {
  const destination = path.resolve(file);
  if (spawnSync('git', ['check-ignore', '--quiet', '--', destination], {cwd: ROOT, stdio: 'ignore'}).status !== 0) issue('CONFIG_NOT_IGNORED');
  const content = fs.readFileSync(path.resolve(__dirname, '../vision.env.example'), 'utf8');
  let fd;
  try { fd = fs.openSync(destination, 'wx', 0o600); fs.writeFileSync(fd, content); }
  catch (error) { issue(error.code === 'EEXIST' ? 'CONFIG_ALREADY_EXISTS' : 'CONFIG_WRITE_FAILED'); }
  finally { if (fd !== undefined) fs.closeSync(fd); }
  return {created: true, path: destination, mode: '0600'};
}
function status(env) {
  const provider = createTokenHubProvider(env);
  return {providerSelected: env.WEIHUO_AI_VISION_PROVIDER === 'tokenhub', keyPresent: Boolean(env.WEIHUO_AI_VISION_API_KEY), modelPresent: Boolean(env.WEIHUO_AI_VISION_MODEL), configured: env.WEIHUO_AI_VISION_PROVIDER === 'tokenhub' && provider.configured()};
}
async function liveProbe(env, fetchImpl) {
  if (env.WEIHUO_AI_VISION_PROVIDER !== 'tokenhub') issue('CONFIG_INVALID');
  let usage = null;
  const provider = createTokenHubProvider(env, fetchImpl, {onUsage: value => { usage = value; }});
  const started = Date.now();
  const output = await runAI('extractReport', {consent: true, imageBase64: syntheticReport().toString('base64'), mimeType: 'image/png'}, provider, async () => {});
  const matched = output.metrics.some(metric => metric.name.trim().toUpperCase() === 'MARKER' && metric.value.trim() === '42' && metric.unit.trim().toUpperCase() === 'MG');
  const usagePresent = Boolean(usage && usage.total_tokens > 0);
  return {ok: matched && usagePresent, syntheticOnly: true, syntheticContentMatched: matched, model: env.WEIHUO_AI_VISION_MODEL, elapsedMs: Date.now() - started, usage, ...(!matched ? {code: 'PROBE_CONTENT_MISMATCH'} : !usagePresent ? {code: 'PROBE_USAGE_MISSING'} : {})};
}
async function main(args, deps = {}) {
  let file = DEFAULT_FILE, mode = 'check', modeSelected = false, fileSelected = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--config' && args[i + 1] && !fileSelected && !args[i + 1].startsWith('--')) { file = path.resolve(args[++i]); fileSelected = true; }
    else if (['--init', '--check', '--live'].includes(args[i])) {
      if (modeSelected) issue('ARGUMENT_INVALID');
      mode = args[i].slice(2); modeSelected = true;
    } else issue('ARGUMENT_INVALID');
  }
  if (mode === 'init') return initialize(file);
  const env = readConfiguration(file);
  if (Object.keys(env).some(key => !key.startsWith('WEIHUO_AI_VISION_'))) issue('CONFIG_INVALID');
  const configured = status(env);
  if (mode === 'check') return {live: false, ...configured};
  return {live: true, ...await liveProbe(env, deps.fetchImpl)};
}
if (require.main === module) main(process.argv.slice(2)).then(result => {
  process.stdout.write(JSON.stringify(result) + '\n');
  if (result.ok === false || result.configured === false) process.exitCode = 1;
}).catch(error => {
  const code = error && typeof error.code === 'string' && /^(?:CONFIG_|ARGUMENT_|SERVICE_NOT_CONFIGURED$|PROVIDER_|PROBE_)/.test(error.code) ? error.code : 'PREFLIGHT_FAILED';
  process.stdout.write(JSON.stringify({ok: false, code}) + '\n'); process.exitCode = 1;
});
module.exports = {initialize, status, liveProbe, main};
