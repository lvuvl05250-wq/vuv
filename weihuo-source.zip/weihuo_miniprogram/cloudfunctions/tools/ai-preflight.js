'use strict';

// Explicit operator tooling. It never runs when the mini program or cloud
// function starts, and never reads user records or prints configuration values.
const fs=require('node:fs');
const path=require('node:path');
const zlib=require('node:zlib');
const {spawnSync}=require('node:child_process');
const {createProvider}=require('../weihuoApi/provider');
const {runAI}=require('../weihuoApi/ai');

const PROJECT=path.resolve(__dirname,'../..');
const DEFAULT_CONFIG=path.resolve(__dirname,'../.env.weihuo-ai.local');
const CONFIG_KEYS=['WEIHUO_AI_PROVIDER','WEIHUO_AI_ENDPOINT','WEIHUO_AI_API_KEY','WEIHUO_AI_MODEL','WEIHUO_AI_VISION_MODEL','WEIHUO_AI_TIMEOUT_MS','WEIHUO_AI_DAILY_LIMIT','WEIHUO_AI_VISION_PROVIDER','WEIHUO_AI_VISION_ENDPOINT','WEIHUO_AI_VISION_API_KEY','WEIHUO_AI_VISION_TIMEOUT_MS','WEIHUO_AI_VISION_MAX_TOKENS','WEIHUO_AI_VISION_JSON_MODE','WEIHUO_AI_VISION_THINKING','WEIHUO_AI_VISION_REASONING_EFFORT'];
const CODES=new Set(['SERVICE_NOT_CONFIGURED','PROVIDER_AUTH_FAILED','PROVIDER_QUOTA_EXCEEDED','PROVIDER_RATE_LIMITED','PROVIDER_TIMEOUT','PROVIDER_NETWORK_ERROR','PROVIDER_UNAVAILABLE','PROVIDER_REQUEST_REJECTED','PROVIDER_INVALID_RESPONSE']);

function problem(code){const error=new Error(code);error.code=code;throw error;}
function parseConfiguration(text){
  const result={};
  for(const line of text.split(/\r?\n/)){
    if(!line.trim()||line.trim().startsWith('#'))continue;
    const match=line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if(!match||!CONFIG_KEYS.includes(match[1])||Object.hasOwn(result,match[1]))problem('CONFIG_INVALID');
    let value=match[2];
    if(value.startsWith('"')){try{value=JSON.parse(value);}catch(_){problem('CONFIG_INVALID');}}
    else if(value.startsWith("'")){if(!value.endsWith("'"))problem('CONFIG_INVALID');value=value.slice(1,-1);}
    if(typeof value!=='string'||/[\r\n\u0000]/.test(value))problem('CONFIG_INVALID');
    result[match[1]]=value.trim();
  }
  return result;
}

function initializeConfiguration(file=DEFAULT_CONFIG){
  const destination=path.resolve(file);
  // Do not create a secret-bearing file unless Git already excludes that exact
  // path. Use argv, never a shell, so a path cannot become executable text.
  const ignored=spawnSync('git',['check-ignore','--quiet','--',destination],{cwd:PROJECT,stdio:'ignore'});
  if(ignored.status!==0)problem('CONFIG_NOT_IGNORED');
  const contents=fs.readFileSync(path.resolve(__dirname,'../.env.example'),'utf8');
  let fd;
  try{fd=fs.openSync(destination,'wx',0o600);fs.writeFileSync(fd,contents,'utf8');}
  catch(error){if(error.code==='EEXIST')problem('CONFIG_ALREADY_EXISTS');problem('CONFIG_WRITE_FAILED');}
  finally{if(fd!==undefined)fs.closeSync(fd);}
  return {configuration:'created',path:destination,mode:'0600'};
}

function readConfiguration(file=DEFAULT_CONFIG){
  let stat,text;
  try{stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink())problem('CONFIG_INVALID');if((stat.mode&0o077)!==0)problem('CONFIG_PERMISSIONS');text=fs.readFileSync(file,'utf8');}
  catch(error){if(error&&/^CONFIG_/.test(error.code||''))throw error;problem('CONFIG_MISSING');}
  return parseConfiguration(text);
}

function configurationStatus(env){
  const provider=createProvider(env);
  return {variables:Object.fromEntries(CONFIG_KEYS.map(k=>[k,Boolean(env[k])])),textConfigured:provider.configured(false),visionConfigured:provider.configured(true)};
}

function crc32(buffer){let crc=0xffffffff;for(const byte of buffer){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function pngChunk(type,data){const name=Buffer.from(type),length=Buffer.alloc(4),checksum=Buffer.alloc(4);length.writeUInt32BE(data.length);checksum.writeUInt32BE(crc32(Buffer.concat([name,data])));return Buffer.concat([length,name,data,checksum]);}
function syntheticReport(){
  const glyphs={
    A:['01110','10001','10001','11111','10001','10001','10001'],C:['01111','10000','10000','10000','10000','10000','01111'],
    E:['11111','10000','10000','11110','10000','10000','11111'],G:['01111','10000','10000','10111','10001','10001','01111'],
    H:['10001','10001','10001','11111','10001','10001','10001'],I:['11111','00100','00100','00100','00100','00100','11111'],
    K:['10001','10010','10100','11000','10100','10010','10001'],M:['10001','11011','10101','10101','10001','10001','10001'],
    N:['10001','11001','10101','10011','10001','10001','10001'],R:['11110','10001','10001','11110','10100','10010','10001'],
    S:['01111','10000','10000','01110','00001','00001','11110'],T:['11111','00100','00100','00100','00100','00100','00100'],
    Y:['10001','10001','01010','00100','00100','00100','00100'],'2':['01110','10001','00001','00010','00100','01000','11111'],
    '4':['00010','00110','01010','10010','11111','00010','00010']
  };
  const width=640,height=200,scale=6,pixels=Buffer.alloc(width*height*3,255);
  function draw(text,y){let x=22;for(const char of text){const shape=glyphs[char];if(shape)shape.forEach((row,gy)=>{for(let gx=0;gx<5;gx++)if(row[gx]==='1')for(let dy=0;dy<scale;dy++)for(let dx=0;dx<scale;dx++){const offset=((y+gy*scale+dy)*width+x+gx*scale+dx)*3;pixels.fill(0,offset,offset+3);}});x+=6*scale;}}
  draw('SYNTHETIC TEST',20);draw('MARKER 42 MG',108);
  const rows=[];for(let y=0;y<height;y++)rows.push(Buffer.from([0]),pixels.subarray(y*width*3,(y+1)*width*3));
  const header=Buffer.alloc(13);header.writeUInt32BE(width);header.writeUInt32BE(height,4);header[8]=8;header[9]=2;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),pngChunk('IHDR',header),pngChunk('IDAT',zlib.deflateSync(Buffer.concat(rows))),pngChunk('IEND',Buffer.alloc(0))]);
}

async function probe(env,{roles=['text','vision'],fetchImpl}={}){
  const provider=createProvider(env,fetchImpl),result={};
  for(const role of roles){
    const started=Date.now();
    try{
      let output;
      if(role==='text'){
        output=await runAI('parseState',{consent:true,text:'合成测试：精力为3，当前在办公室，可用时间5分钟，心情平静。'},provider,async()=>{});
        if(output.energy!==3||output.scene!=='office'||output.minutes!==5)problem('PROBE_CONTENT_MISMATCH');
      }else if(role==='vision'){
        output=await runAI('extractReport',{consent:true,imageBase64:syntheticReport().toString('base64'),mimeType:'image/png'},provider,async()=>{});
        if(!output.metrics.some(m=>m.name.trim().toUpperCase()==='MARKER'&&m.value.trim()==='42'&&m.unit.trim().toUpperCase()==='MG'))problem('PROBE_CONTENT_MISMATCH');
      }else problem('PROBE_ROLE_INVALID');
      result[role]={ok:true,schemaValidated:true,syntheticContentMatched:true,milliseconds:Date.now()-started};
    }catch(error){result[role]={ok:false,code:CODES.has(error.code)||error.code==='PROBE_CONTENT_MISMATCH'?error.code:'PROBE_FAILED',milliseconds:Date.now()-started};}
  }
  return result;
}

async function main(args){
  const allowed=new Set(['--init','--live','--config','--role']);let file=DEFAULT_CONFIG,role='both';
  for(let i=0;i<args.length;i++){if(!allowed.has(args[i]))problem('ARGUMENT_INVALID');if(args[i]==='--config'){if(!args[i+1])problem('ARGUMENT_INVALID');file=path.resolve(args[++i]);}else if(args[i]==='--role'){role=args[++i];if(!['both','text','vision'].includes(role))problem('ARGUMENT_INVALID');}}
  if(args.includes('--init')){if(args.includes('--live'))problem('ARGUMENT_INVALID');return initializeConfiguration(file);}
  const env=readConfiguration(file),status=configurationStatus(env);
  if(!args.includes('--live'))return {configuration:status,live:false};
  const results=await probe(env,{roles:role==='both'?['text','vision']:[role]});
  if(Object.values(results).some(r=>!r.ok))process.exitCode=1;
  return {configuration:status,live:true,syntheticOnly:true,results};
}

if(require.main===module)main(process.argv.slice(2)).then(result=>process.stdout.write(JSON.stringify(result)+'\n')).catch(error=>{process.stdout.write(JSON.stringify({ok:false,code:/^(?:CONFIG_|ARGUMENT_)/.test(error.code||'')?error.code:'PREFLIGHT_FAILED'})+'\n');process.exitCode=1;});
module.exports={parseConfiguration,initializeConfiguration,readConfiguration,configurationStatus,syntheticReport,probe};
