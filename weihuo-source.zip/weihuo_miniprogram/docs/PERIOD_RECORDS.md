# 经期记录、下次估计与手机日历提醒

## 实现范围

个人档案中的可选工具，无性别或成年门槛。页面支持实际起止日期、可选日感受与备注、修改、删除、撤销、下次经期日期估计，以及用户主动添加的手机日历提醒。

实际记录与估计数据始终分开：

- `periodRecords` 只保存用户明确记录的日期。实际经期在月历用粉色实底显示。
- 估计只由纯函数返回，月历用浅粉色虚线并写明“预计”，不存入实际记录。
- 经过预计日不会自动记为出血、不会补上一次结束、不会自动滚动到再下个周期。
- 当实际日期修改、新增或撤销后，估计跟随真实记录重新计算。
- 未知结束日期只着色开始日和有日感受的日期；感受不等于出血。
- 不推算排卵、受孕或疾病，不调用 AI。无经期记录的用户无需使用。

## 估计规则与依据

NHS 将周期定义为一次经期的开始日至下次经期开始前一天；28 天周期、5 天持续只是常见参考，不能当作个人实测值。来源：[NHS Periods](https://www.nhs.uk/conditions/periods/)、[NHS Irregular periods — Keeping track](https://www.nhs.uk/symptoms/irregular-periods/)。本页在尚未设置且历史不足时明确显示“默认设置 28 天 / 5 天”。

本项目独立实现下列确定性规则：

1. 需要至少一次真实开始日期作为估计起点，没有记录时不编造日期。
2. `history` 模式下，有至少 2 个完整的“实际开始→下一实际开始”间隔（即至少 3 个真实开始日）时，取最近最多 6 个间隔的中位数。偶数样本取中间两项均值，再四舍五入到整数日。
3. 持续天数按 `结束日 - 开始日 + 1` 计算，只有明确填写了结束日期的记录才计入。至少 2 个已结束记录时，取最近最多 6 次持续天数的中位数。
4. 以上两类历史数据独立判断是否足够；不足时使用用户保存的值，未设置则使用明示默认。界面分别标明周期与持续天数的来源。
5. `manual` 模式始终使用用户保存的周期与持续天数。
6. `预计开始 = 最新实际开始 + 周期天数`；`预计结束 = 预计开始 + 持续天数 - 1`。只推导这一次。
7. 实际结束日期已达到或超过预计开始、或估计持续天数超过估计周期时，显示设置/记录冲突，不画出重叠的估计。
8. 日期采用 UTC 的日历日整数运算，不用手机时区计算天数差，避免夏令时把一天算成 23 或 25 小时。

中位数是本产品用于提供可解释日期参考的工程选择，不声称临床验证的预测精度。设置面板同时显示已记录间隔的最小值与最大值。

公开源码核对：drip 的 [cycle.js](https://gitlab.com/bloodyhealth/drip/-/blob/main/lib/cycle.js) 使用历史均值和波动范围作预测，[cycle-length.js](https://gitlab.com/bloodyhealth/drip/-/blob/main/lib/cycle-length.js) 提供统计值；它的预测实现并非本项目的中位数/仅下一次规则。已阅读 [GPL-3.0 许可证](https://gitlab.com/bloodyhealth/drip/-/raw/main/LICENSE)，没有复制或改写其源码，也未引入它作为依赖。

资料核对日期：2026-10-05。

## 状态格式

现有 `schema:1` 的两个顶级字段：

```js
periodRecords: [{
  id: 'period_unique_id',
  startDate: '2026-10-01',
  endDate: '', // 未填写结束日
  days: [{date: '2026-10-01', feelings: ['tired'], note: ''}],
  createdAt: '2026-10-01T03:00:00.000Z',
  updatedAt: '2026-10-01T03:00:00.000Z'
}],
periodSettings: {
  predictionMode: 'history', // 或 manual
  cycleLengthDays: 28,
  periodLengthDays: 5,
  configured: false // 用户明确保存设置后为 true
}
```

旧数据缺少 `periodRecords` 时归一化为 `[]`，缺少 `periodSettings` 时归一化为上述默认对象。不把历史放进 `profile`，避免个人资料用于 AI 时顺带上传经期内容。两字段纳入用户授权的私人云备份、导出、恢复和全部删除。

设置仅接受整数：周期 1–365 天、持续 1–90 天，且持续不超过周期。这里是输入容量边界，不是“正常/异常”的医学判断。实际日期记录没有这些持续天数限制。

日感受仅允许 `pain/tired/bloating/backache/headache/low_mood`；备注最多 500 字。最多 240 次记录、1000 条日感受属于容量限制。

## 纯函数与前后端一致性

客户端：`miniprogram/services/period.js`。云函数独立部署副本：`cloudfunctions/weihuoApi/period.js`。测试严格比较两份内容，修改需同步。

- `validateSettings(input)`：兼容缺失字段、补默认值、校验并返回新对象。
- `estimateNext(records, settings, today)`：返回日期、来源、样本数、间隔范围与状态，不修改任何输入。
  - 状态：`no-records / estimated / past-estimate / conflict / out-of-range`。
  - `cycleSource`、`periodSource`：`history / manual / default`。
- `addDateDays(date, count)`：日历日加减；超出 1900–2200 年范围返回空日期。
- `validateRecords(input, today)`：日期、未来记录、编号、范围、重叠和日感受校验；返回规范化新数组。
- `upsertRecord(records, patch, {today, now, id})`、`deleteRecord(records, id, today)`、`putDay(...)`：不修改输入。
- `recordForDate(records, date, today)`：只查实际记录；未结束记录可以填写截至今天的感受，不表示期间每天已确认出血。
- `buildMonth(records, month, selectedDate, today, settings)`：星期一开头的 42 格月历。`mark` 只描述实际记录，`predicted/predictionMark/predictionLabel` 另外描述估计；有感受但未确认出血的日期可同时有“预计”和感受标记。
- `getContext(records, date, today)`：只返回实际 `{date, periodRecorded, feelings}`，不含备注和估计，也不向 AI 自动发送。

实际区间不得重叠。最多一条未填写结束日的记录，且为最新记录；新增下一次前先自行补充上次实际结束日期，不自动填写昨天或猜测结束日。

## store 接口

```js
store.getPeriodRecords()
store.replacePeriodRecords(nextRecords, expectedCurrentRecords)
store.getPeriodSettings()
store.savePeriodSettings(patch)
```

记录替换使用比较后保存：只有当前值与 `expectedCurrentRecords` 一致才原子落盘；否则拒绝覆盖较新的数据。写盘失败不改内存。

本页保留最近一次成功记录修改的 `{before, after, namespace}`，撤销调用 `replacePeriodRecords(before, after)`；其他地方已改记录时拒绝撤销。未保存草稿切换日期先确认；设置草稿独立保留，错误、取消或账号变化不会假称成功。

## 手机日历提醒

复用 `services/calendar-reminder.js` 和官方 [wx.addPhoneCalendar](https://developers.weixin.qq.com/miniprogram/dev/api/device/calendar/wx.addPhoneCalendar.html)。

- 打开页面、查看预测、保存实际记录、保存周期设置均不请求权限、不添加日程。
- 用户展开提醒，选择日期与手机当地时间，明确点击“添加到手机日历”后才调用系统 API。
- 标题固定为“微活 · 查看自己的记录”，不带经期、感受、身体备注、账号等信息，也不创建小程序计划记录。
- 按当前账号、最新真实记录 ID/开始日期及估计起止日期区分提醒；本次运行内相同事件去重，并有并发锁。
- 已添加后改变时间会提示另建提醒，旧项不会自动更新。经期记录和估计变化也不会自动修改手机日历。
- 系统拒绝、取消、不支持和失败都显示真实结果，保留选定日期时间；仅系统成功回调后显示已添加。
- 拒绝过去时刻；不改变日历日期的时区归属。提醒响铃取决于手机日历与系统设置。
- 不使用微信订阅消息，不宣称微信推送或后台必定响铃。应用重启后不会假装拥有查询或删除系统日历的能力。

## 入口与验证

唯一业务入口为档案夹的“个人档案 → 经期日历”，不在设置再放一份，不加入首次建档必填流程。路由 `/pages/period/index`，可用过去或今天的 `?date=YYYY-MM-DD` 打开真实记录日。

测试覆盖前后端源一致、默认和手动设置、两个真实间隔的中位数、最近六次窗口、持续天数含首尾、闰日、缺失结束日期、过期估计不滚动、实际/预计分离、记录纠正与撤销、未来只能查看、存储失败、账号变化和日历拒绝/取消/重复点击。真实微信日期选择器和手机系统授权/日历落地由根任务在模拟器/真机验证。
