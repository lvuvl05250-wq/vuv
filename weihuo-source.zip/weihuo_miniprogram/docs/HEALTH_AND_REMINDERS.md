# 健康数据与活动提醒：接入边界

核对日期：2026-10-05。只依据官方资料；尚未在当前个人主体 AppID 真机验证权限或模板资格。

## 本项目建议

先做用户主动连接微信运动以记录步数，再提供“加入手机日历”的每天/每周重复提醒。微信订阅通知仅在该账号有适用模板时作为补充。完整穿戴设备数据按具体品牌另行接入。

| 路径 | 能力与限制 | 官方依据 |
| --- | --- | --- |
| 微信运动 | `wx.getWeRunData` 需先登录并授权 `scope.werun`，读取过去 31 天步数。用户主动进入小程序才更新；不是心率、睡眠或通用健康库。 | [微信运动 API](https://developers.weixin.qq.com/miniprogram/dev/api/open-api/werun/wx.getWeRunData.html) |
| Apple 健康 | HealthKit 要求原生 App capability 与逐类数据授权。当前 WXML/JS 工程没有该原生桥接；可由未来 Flutter App 经用户授权后同步云端。后半句为架构判断。 | [HealthKit 配置](https://developer.apple.com/documentation/xcode/configuring-healthkit-access) |
| Android 健康 | Health Connect 要求 Android SDK、Manifest 与运行时权限，设备与系统支持也有条件。当前微信小程序不能直接继承其他 App 的授权；未来可经原生 App 接入。后半句为架构判断。 | [Health Connect 入门](https://developer.android.com/health-and-fitness/health-connect/get-started) |
| 品牌云接口 | 必须按品牌申请服务和数据权限，用户 OAuth 授权后才可读取获批数据。个人小程序主体不会自动获得任意品牌权限。 | [华为授权](https://developer.huawei.com/consumer/en/doc/hmscore-guides/auth-example-0000001054581058)、[应用资质](https://developer.huawei.com/consumer/en/doc/HMSCore-Guides/application-qualification-description-0000001425636570) |
| BLE 设备 | 微信可连接并读写 BLE 特征，但要有具体设备开放的协议；不等于可以获取任意手表历史库。 | [蓝牙文档](https://developers.weixin.qq.com/miniprogram/dev/framework/device/bluetooth.html) |
| 系统日历 | `wx.addPhoneRepeatCalendar` 经 `scope.addPhoneCalendar` 授权，可添加每天/每周等重复事件及提醒。受日历与系统通知设置影响，不保证精准闹钟式唤醒。 | [重复日历 API](https://developers.weixin.qq.com/miniprogram/dev/api/device/calendar/wx.addPhoneRepeatCalendar.html) |

## 微信订阅提醒

- 普通一次性订阅通过用户主动点击申请；一次授权对应一条消息。“保持选择”不是永久授权。
- 长期订阅面向特定服务场景，不能默认个人生活记录小程序具备资格。新版一次性 Beta 也有特定业务范围，不能当作通用每日提醒。
- 需要管理员在该 AppID 的“功能 → 订阅消息”中核对适用模板和类目，取得模板 ID、字段结构。没有适用模板时，应如实申请匹配场景，不借用医疗类目。
- 云端定时函数可以扫描到期任务、发送已获授权的模板消息并去重。调度需独立内部入口，不能因此放松现有用户身份校验。通知送达不等于手机已弹出提醒。
- 日历添加应由用户明确点击；避免重复添加。当前采用的接口只负责添加，编辑和取消需明确引导用户到系统日历管理。

依据：[订阅消息概述](https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/subscribe-message-overview.html)、[授权 API](https://developers.weixin.qq.com/miniprogram/dev/api/open-api/subscribe-message/wx.requestSubscribeMessage.html)、[CloudBase 定时任务](https://docs.cloudbase.net/recipes/schedule-cloud-function-cron-job)。

## 实施前需要核对

1. 微信运动/日历接口在当前 AppID 的可用性、隐私声明、真机用户授权与拒绝后的路径。
2. 若选微信订阅通知：适用模板 ID/字段，原生微信登录、云服务关联和发送权限。
3. 若选穿戴设备：具体品牌型号、官方开放协议/申请资格、用户单独授权。

## 当前实现状态（2026-10-05）

生活计划页已接入单次手机日历提醒：展开计划后，每个尚有可选未来时间的计划日均可直接选择时分，再点击“添加到手机日历”。保存计划、进入页面或选择时间本身不会申请日历授权。

- 使用 [`wx.addPhoneCalendar`](https://developers.weixin.qq.com/miniprogram/dev/api/device/calendar/wx.addPhoneCalendar.html)，基础库至少 2.15.0，需 `scope.addPhoneCalendar`。由调用后的系统流程处理用户授权；不预先批量申请权限。
- 事件仅包含“微活 · 行动标题”、开始/结束时间、非全天标记与开始时提醒。不会发送个人档案、身体数据、经期、备注、云端身份或定位，也没有后台网络调用。
- `startTime` 按 Unix 秒传入；官方参数表将 `endTime` 列为字符串，因此传秒数的字符串。`alarm=true`、`alarmOffset=0` 表示开始时提醒。
- 日期与时分使用手机当前本地时区构造，逐项回验年月日时分。不会把计划日期当作 UTC 解析；过去时间和夏令时切换中不存在的本地时间会被拒绝。跨地区后再次添加，以手机当时的时区为准。
- 取消、拒绝权限、不支持或调用失败均不记为成功，保留已选时间。成功后提示到手机日历查看；是否响铃取决于系统日历与通知设置，不承诺后台精确唤醒。
- 页面与服务均有进行中锁。同一小程序运行会话内，相同计划日和相同事件参数的重复点击不会再调用添加接口；已添加后改时间或标题再添加，会先说明这是新建另一条。该缓存仅在内存，不读取系统日历，也不能跨小程序重启判断是否已存在。
- 修改/删除小程序里的计划不会修改/删除手机日历事件。界面明确提示到系统日历管理原事件。

本轮没有启用每天/每周重复日历，也没有接入微信订阅模板或云端推送。重复接口的官方参数已核对，但不同计划日的项目并不相同，因此当前按用户逐日明确选择添加一次。页面内行动计时仍不等同后台提醒。

代码：`miniprogram/services/calendar-reminder.js`、`miniprogram/pages/plans/`。测试：`tests/calendar-reminder.test.js`，覆盖日期/时区/夏令时、取消/拒绝/失败、重复点击、页面保存和选择不触发权限、账号切换及过期计划。真机系统日历弹窗、当前个人主体 AppID 的授权和实际响铃尚待用户手机验证；自动测试不代表这些实机环节已通过。
