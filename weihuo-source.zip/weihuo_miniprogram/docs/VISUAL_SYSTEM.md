# 微活本轮视觉系统

## 视觉与交互

- 浅叶绿 `#D9E8B8` 为主要交互色，深叶色 `#243B2B` 用于文字；浅杏和麦黄作局部贴纸点缀。
- 贴纸统一使用略粗糙的拓印/木刻质感、简化色块和白色裁切边；不用荧光绿、镜面3D、浓妆人物。
- 大标题约48–52rpx、主要文字32rpx、辅助文字28rpx。卡片间有明确空隙；完成项常驻、灰字划线。
- 功能入口各只有一个主位置，图卡可以微微溢出边缘，但文字、点击区不能被遮挡。
- 陪伴伙伴：小微、团团（小猫）、卷卷（腊肠犬）。选择只在伙伴页同时展示三位，其他陪伴插图由当前选择派生。动物有等待、开心、欢迎、进食、休息及脸部贴纸，小微用日记贴纸和朱砂签名章反馈。

## 整页设计参考与实现责任

生成板仅作为视觉参考，示例日期、热量、任务不可写入用户记录；生成板附加的口号也不照搬。

| 页面组 | 完整设计参考 | 主要落地 |
|---|---|---|
| 行动方向 | `preview/ui-directions-v2.png` | `pages/actions` |
| 今日、档案夹、设置 | `preview/ui-today-archive-settings.png` | `pages/today`、`archive`、`profile`、`settings` |
| 记餐、食物探索、经期 | `preview/ui-food-period-subpages.png` | `pages/meal-edit`、`recipes`、`period` |
| 行动详情、个人档案、计划 | `preview/ui-action-profile-plan-subpages.png` | `pages/action`、`profile-edit`、`plan-edit` |

## 本轮生成提示词规范

使用内置 image_gen 图像工具。页面生成任务明确为完整 ui-mockup，逐页指定真实功能顺序、单一主按钮、大字体及独立卡片；要求同参考板的浅叶绿生活手帐、粗拓印白边贴纸，禁止冗余功能与教育口号。素材生成以相机贴纸为风格参考，要求 broad simple flat shapes、slightly irregular dark olive outlines、coarse handmade linocut/rubber-stamp texture、transparent background、white die-cut border；按相机/运动鞋/笔记本/餐碗/食谱/票根/日历分别描述用途。动物两态要求保留同一身份、绿方巾和色彩，只改姿态/表情；小微要求自然素颜，不出现口红、睫毛膏或妆感。

## 资源策略

- 上线使用的最终图在 `miniprogram/assets/`；整页参考图只放 `preview/`，不打入小程序。
- 本轮将PNG缩到实际所需尺寸并压缩为256色调色板，保留透明边缘。单文件≤200KiB、主包<2MiB由 `npm run check` 强制检查。
- 云端行动媒体使用已有HTTPS音频/视频字段，按需加载；音频只在明确有真实资源的行动中显示，不生成假播放控件。
- 只在检索源代码确认无引用后，逐个删除旧素材；保留原始生成图在工具生成目录，方便后续重新导出。


## 日记与签名章

- 日记上半部为白纸、下半部为淡绿便签，中间虚线；正文黑色，行动/餐食事实用浅绿、杏色、淡紫标注。
- 小微印章：`miniprogram/assets/xiaowei-seal.png`，14,296 bytes。内置 image_gen 生成；视觉要求是朱砂方形篆刻“小微”、不规则印泥、刻刀与拓印质感、透明背景，避免圆圈内普通印刷字。
- 脸部贴纸：`companion-cat-face.png` 与 `companion-dog-face.png`。内置 image_gen，以各自 welcome 图为身份和纹理参考。
- 猫脸生成提示：Generate one standalone HEAD-ONLY face sticker of this exact black-and-white tuxedo cat 团团, for its diary reaction icon. Preserve exact green eyes, white muzzle, black forehead and nose, slight cream paper white die-cut border, fine fur and rough vintage linocut texture from reference. Face looks softly happy and friendly, slight head tilt, both ears fully visible. Head only, no body, no neck scarf, no paws, no extra objects, no lettering. Center the cutout on a genuinely transparent square canvas. Match the reference aesthetic precisely; not glossy 3D, not minimalist line art. One usable small sticker.
- 狗脸生成提示：Generate one standalone HEAD-ONLY face sticker of this exact warm brown dachshund 卷卷, for its diary reaction icon. Preserve its wide soft floppy ears, long rounded dachshund muzzle, black nose, big dark friendly eyes, small cheerful smile. Match the rough vintage printed illustration texture and cream white die-cut border in reference, including a little fine fur detail. Face only, no body, no paws, no scarf, no text, no additional objects. Both long ears fully included, generous transparent margins. Genuinely transparent square canvas. One usable small sticker; not glossy 3D, not minimal line art.
