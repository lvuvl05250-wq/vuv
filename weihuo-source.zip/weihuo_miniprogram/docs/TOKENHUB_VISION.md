# 图片识别：TokenHub 连接与验证

更新：2026-10-05。文字仍通过 CloudBase `hy3`；包含图片的请求可单独通过腾讯 TokenHub。此路径不要求升级 CloudBase 套餐，不改变运行时 IAM。

## 当前实现

- `cloudfunctions/weihuoApi/provider.js` 按实际图片内容分流，文字保留原有配置与调用路径。
- `tokenhub-provider.js` 使用固定官方 HTTPS 地址 `https://tokenhub.tencentmaas.com/v1/chat/completions`，禁止重定向及其他主机；密钥只在服务端请求头中使用。
- 图片一次交给视觉模型，同时得到文字/JSON结果；继续使用原有 `readContent` / `normalizeResult`，没有第二次校验模型调用。
- 可读正文、部分 JSON、空营养字段继续保留。`finish_reason=length` 且有正文时也保留；只有没有正文时返回明确错误。`reasoning_content` 不作为识别结果展示。
- 不自动重试。网络、认证、模型未开通、额度、限流、超时和空结果分别报错，错误不含上游正文、请求头或密钥。
- 餐食/报告页面现有失败分支保留所选照片和填写内容；保存仍由用户确认。

## 低价候选与费用

来源为腾讯 TokenHub 官方[模型列表](https://cloud.tencent.com/document/product/1823/130051)、[计费说明](https://cloud.tencent.com/document/product/1823/130055)。以下只比较输入/输出单价，人民币/百万 tokens；不是食品识别准确率排名。

| 模型 ID | 输入 / 输出 | 1,000 次假设费用 | 图片与输出能力 |
| --- | --- | --- | --- |
| `glm-5.3-flash` | 0.8 / 2.8 | 2.60 元 | 官方列出图片与结构化输出；本项目低价候选 |
| `deepseek/deepseek-flash` | 谷时 1 / 4；峰时 2 / 8 | 3.50 / 7.00 元 | DeepSeek V4.1 Flash 直连，图片与结构化输出；不要误填仅文字的 `deepseek-v4-flash` |
| `minimax-m3` | 2.1 / 8.4（本项目远低于其 512K 档） | 7.35 元 | 图片输入，可关闭思考；专用 JSON 模式需单独实测 |

计算假设每次 1,500 输入、500 输出：`1000 × (1500 × 输入单价 + 500 × 输出单价) / 1000000`。图片 token、系统提示及思考输出都影响实际费用。GLM-5.3-Flash [不能关闭思考，但支持 low/high/max 推理强度，默认 max](https://cloud.tencent.com/document/product/1823/131208)。本项目现显式用 `low`，不能承诺每次输出只有 500 tokens。

Qwen3.5 Flash / Plus 已于 2026-09-08 从 TokenHub、ADP、CloudBase 下线，旧价格表残留项目不能作为开通依据，见[官方下线公告](https://cloud.tencent.com/announce/detail/2427)。个人 Token Plan [不支持图片/视频多模态](https://cloud.tencent.com/document/product/1823/130060)，本小程序应使用相应模型的按量服务，不能买错成文字订阅。

## 配置与部署

1. 在 [TokenHub 控制台](https://console.cloud.tencent.com/tokenhub/) 开通平台，确认 `glm-5.3-flash` 可用及其按量后付费/可用额度；创建有该模型权限的 TokenHub API Key。它是 TokenHub 平台密钥，不是某个 HY-Vision 专用密钥。
2. 本地只在 `cloudfunctions/.env.weihuo-vision.local` 填写。文件已被 Git 忽略，权限为 `0600`。已有文件不要重新初始化，避免覆盖用户填写。
3. 在 CloudBase 环境 `weihuo-dev-d7gw5z8z79ca7a924` 的云函数 `weihuoApi` 配置中设置下列环境变量；通过控制台输入密钥，不放在命令行、聊天、前端、`cloudbaserc.json` 或源码中。
4. 保留所有已有函数环境变量，尤其 `WEIHUO_AI_PROVIDER=cloudbase`、`WEIHUO_AI_MODEL=hy3`。更新环境变量时注意管理 API 可能整体替换变量列表，不能只提交视觉变量而丢失原项。
5. 部署包含新 provider 文件的云函数代码。该实现使用 Node.js 20 已有 `fetch`，无新增依赖。云函数不会自动读取本地 `.env` 文件；本地验证成功不等于云端已部署。
6. 云端再通过小程序执行一张合成测试图片，并确认文字仍可正常调用。不要用个人健康资料做连通性测试。

| 变量 | 本项目配置 |
| --- | --- |
| `WEIHUO_AI_VISION_PROVIDER` | `tokenhub` |
| `WEIHUO_AI_VISION_ENDPOINT` | `https://tokenhub.tencentmaas.com/v1/chat/completions` |
| `WEIHUO_AI_VISION_API_KEY` | 仅服务端填写真实值，本文不记录 |
| `WEIHUO_AI_VISION_MODEL` | `glm-5.3-flash` |
| `WEIHUO_AI_VISION_TIMEOUT_MS` | `45000` |
| `WEIHUO_AI_VISION_MAX_TOKENS` | `2048` |
| `WEIHUO_AI_VISION_JSON_MODE` | `text`，省略专用 response_format，但任务提示仍要求 JSON |
| `WEIHUO_AI_VISION_THINKING` | 留空；GLM-5.3-Flash 不能设 `disabled` |
| `WEIHUO_AI_VISION_REASONING_EFFORT` | `low`；未设时该 GLM 模型也默认使用 `low` |

JSON 模式仅允许 `text` / `json_object`；模型支持与实际响应核验后可选 `json_object`。兼容字段依据[官方 ChatCompletions 文档](https://cloud.tencent.com/document/product/1823/135872)，单模型能力以模型文档为准。无需为了测试格式而提高输出上限。

## 本机验证命令

从项目根目录运行。工具不打印密钥、请求头或响应正文。

```sh
# 仅新配置才运行，不会覆盖已有文件
node cloudfunctions/tools/vision-preflight.js --init

# 只报告字段存在与配置形状，不联网、不证明权限或额度
node cloudfunctions/tools/vision-preflight.js --check

# 明确发起一次真实请求：程序生成的 MARKER 42 MG 测试图，无业务写入
node cloudfunctions/tools/vision-preflight.js --live
```

`--live` 要求实际识别值匹配且返回正数 usage，才输出 `ok:true`；只返回有效 JSON 不算通过。它会产生一次模型调用费用，不做循环重试。初始化配置源为 `cloudfunctions/vision.env.example`，模型候选不会自动激活或充值。

## 限制和失败行为

- 服务端仅接受 1–2 张 JPEG / PNG / WebP base64，核对文件签名，每张解码后最多 512 KiB；不替用户抓取远程 URL。
- provider 输入上限 1,600 KiB。应用外层仍有更严的 850 KiB 请求总量限制；前端单图 base64 上限 680,000 字符，双标签图每张 340,000 字符，因此实际应先裁剪/压缩。
- 输出响应最多 128 KiB。全局预算默认 2,048，可配置范围 256–4,096；任务上限分别为餐食识别 512、营养标签 768、原值转录 1,536，实际取任务与全局中较小者，包括模型计入的思考 tokens。完整提示词、原图内容和字段结构均保留，输出上限不是要求模型写满。
- 整个请求（含响应体读取）默认 45 秒，配置不得超过 50 秒。没有后台自动重试或多模型兜底计费。
- 只完成思考、正文为空、超时、认证失败均不冒充识别成功。已有正文允许用户阅读和手动补充；未返回的营养数值为空，不补编。

## 验证记录与尚未验证

2026-10-05，真实 TokenHub `glm-5.3-flash`：人工合成英文指标 PNG 通过生产 provider + `runAI('extractReport')`，正确读取 `MARKER=42 MG`。耗时 16.983 秒，输入 741、输出 674、总计 1,415 tokens；按当前公开单价估算约 0.002480 元。该费用仅代表这个样本。

中文营养表和食物插画的独立合成测试结果保存在忽略目录 `preview/vision-chinese-label-live.json`、`preview/vision-food-illustration-live.json`。结果必须以文件里的 `ok` 和各字段检查为准，不把插画识别当作真实餐盘份量/热量准确率测试。

| 合成样本 | 实际结果 | 耗时 | 输入 / 输出 tokens | 按公开单价估算 |
| --- | --- | --- | --- | --- |
| 清晰中文营养表 | 每 100g、840kJ、蛋白质 5g、脂肪 3g、碳水 32g，六字段（含单位）均匹配 | 7.740 秒 | 1,802 / 417 | 0.002608 元 |
| 项目面食插画 | 识别面、番茄、绿叶菜、蛋；按请求不输出份量/营养数字 | 11.772 秒 | 911 / 450 | 0.0019888 元 |

三次真实请求均未写业务记录、未使用个人资料。最新 63 项 provider / cloud / preflight 相关测试通过，0 跳过；覆盖固定主机、重定向、密钥脱敏、无配置不影响文字、双图、上限、慢响应体、空思考输出、截断正文保留与营养空值。

### 延迟专项验证：2026-10-05 后续更新

用户要求尽量在 10 秒内完成后，对两个模型各做英文 2 次、中文 2 次，共 8 次顺序调用，不自动重试，不购买或切换套餐。英文 PNG 固定 640×200 / 2,976 字节，中文 PNG 固定 840×610 / 58,519 字节；使用生产 `runAI` 完整提示词。

| 模型设置 | 英文完整响应（两次） | 中文完整响应（两次） | P50 / 最大 | 正确率（本组） | 四次估算总费 |
| --- | --- | --- | --- | --- | --- |
| GLM-5.3-Flash，`reasoning_effort=low`，输出上限 768 | 3.937 / 6.786 秒 | 3.552 / 2.930 秒 | 3.7445 / 6.786 秒 | 4/4 | 0.0050628 元 |
| MiniMax M3，`thinking=disabled`，JSON模式，输出上限 512 | 5.087 / 22.151 秒 | 3.697 / 3.570 秒 | 4.392 / 22.151 秒 | 4/4 | 0.0149898 元 |

结论：保留 GLM，改用其官方支持的较低推理强度。GLM 英文输出为 47/47 tokens，中文为 126/135 tokens；MiniMax 更贵且本组出现 22 秒长尾。样本很小，不构成长期延迟保证。以上计时从调用开始至完整响应及本地解析结束，不是首字时间。证据见 `preview/vision-latency-benchmark.json`。

另以 TokenHub 验证 `hy3` 的关闭思考参数：生产 `parseState` 提示词、输出上限 512，合成句子的精力 2 / home / 20 分钟均正确，两次完整响应 3.576 / 1.479 秒，均 564 输入、29 输出 tokens，估每次 0.00068 元。它证明该模型参数可用，**不等于 CloudBase 生产文字链路已验证同样延迟**，且没有迁移文字 provider。证据见 `preview/text-latency-benchmark.json`。

MiniMax 的关闭思考及 JSON 模式依据[官方调用指南](https://cloud.tencent.com/document/product/1823/132246)。没有为了更快返回删除安全边界、字段要求或长提示词。

本机真实调用证明密钥和选定模型在测试时可用。云函数部署后的运行环境、真机拍摄照片、复杂中文标签及真实菜品份量估计仍需分别验证。没有证明营养估算的准确率。

协议与图片格式依据：[腾讯图片理解](https://cloud.tencent.com/document/product/1823/136956)、[API 使用说明](https://cloud.tencent.com/document/product/1823/130079)。CloudBase 模型包和 TokenHub 按量模型是不同服务；本轮未调整 CloudBase 套餐、IAM 或生产模型开关。
