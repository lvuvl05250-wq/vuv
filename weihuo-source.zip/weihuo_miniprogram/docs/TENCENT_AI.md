# 腾讯云托管模型接入

## 当前状态（2026-10-05）

- 云函数使用官方 `@cloudbase/node-sdk` `3.18.3` 的托管模型通道，provider 为 `cloudbase`。
- CloudBase 个人版环境已启用文字模型 `hy3`。真实云调用已成功返回 `energy:2, scene:home, minutes:20`，耗时 21.996 秒；结果记录在 `preview/ai-live-text.json`。
- 托管通道使用云函数运行身份，不需要第三方 API Key，也不读取本机旧凭据文件。此处不是旧 Token Credits 路线。
- `WEIHUO_AI_VISION_MODEL` 尚未配置。Qwen3.5 试调用返回模型未上线或当前套餐不支持；餐食照片和报告 OCR 暂无真实成功记录。

## 云函数变量

| 变量 | 用途 |
| --- | --- |
| `WEIHUO_AI_PROVIDER` | `cloudbase` |
| `WEIHUO_AI_MODEL` | 已启用的文字模型；当前为 `hy3` |
| `WEIHUO_AI_VISION_MODEL` | 已启用且支持图片输入的模型 ID；未确认前留空 |
| `WEIHUO_AI_TIMEOUT_MS` | 可选，默认 `45000`；允许 `1000` 至 `50000` 毫秒 |

此通道不要求 `WEIHUO_AI_ENDPOINT` 或 `WEIHUO_AI_API_KEY`。如改用旧 OpenAI 兼容服务，才需要相应服务地址、凭据及适配核验；旧配置的 HTTP 401 不代表当前 `cloudbase/hy3` 调用失败。不要把任何密钥写入前端、提交代码或发到聊天。

## 调用与验证边界

1. 请求仍经过原生身份校验、AI 同意、任务输入白名单与结果 schema 校验。
2. 当前实际成功只覆盖一次文字任务；不等于所有提示任务质量、端内交互、套餐费用或图像能力都已验收。
3. 图片消息仍需单独配置支持图像输入的视觉模型。文字模型 `hy3` 不会自动承担图片识别；视觉未配置时照片分析/OCR 不可用。
4. SDK 输出有大小限制，不启用工具或自动重试；超时、额度、权限与格式错误使用固定错误码，不记录密钥或完整用户内容。
5. 进行图片实测前，需取得用户对本次图片处理的明确同意。

## 官方资料

- [CloudBase Node SDK 接入](https://docs.cloudbase.net/en/ai/model/nodejs-access)
- [CloudBase Node AI API](https://docs.cloudbase.net/en/api-reference/server/node-sdk/ai)
- [CloudBase 托管模型与套餐说明](https://docs.cloudbase.net/ai/model/overview)
