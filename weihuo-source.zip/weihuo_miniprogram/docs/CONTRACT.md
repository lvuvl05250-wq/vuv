# Shared contract — root owns services and global config

Use native CommonJS JS; no optional chaining or wx APIs not documented. No mock records, no network request from pages except services/api.js. Pages use common app.wxss classes and minimal local styles. Route files index.js/wxml/wxss/json complete.

## Routes
Tabs in visible order: actions (0), meals (1), today (2, default entry), archive (3), profile (4). Paths: pages/today/index, pages/actions/index, pages/meals/index, pages/archive/index, pages/profile/index.
Details: pages/state/index, pages/action/index?id=RECORD_OR_CATALOG_ID, pages/meal-edit/index?id=OPTIONAL, pages/report/index?id=OPTIONAL, pages/plans/index, pages/plan-edit/index?id=OPTIONAL, pages/ticket/index?date=YYYY-MM-DD, pages/settings/index.

## services/store.js (synchronous, throws on invalid write / failed persistence)
getState() returns deep clone {profile,days,meals,plans,reports,tickets,settings}; getProfile(); saveProfile(patch); today() -> YYYY-MM-DD; uid(prefix); getDay(date=today()) -> {date,energy:3,scene:'office',minutes:3,mood:'平静',note:'',actions:[]}; saveDay(patch,date=today()).
profile {name:'',adult:false,safetyAnswered:false,specialCondition:false,restrictions:[],allergies:'',notes:'',goals:[],onboarded:false}; restrictions English tags matching catalog avoidWhen.
getCatalog() -> action array (id,title,durationMinutes,kind:'movement'|'care',scenes[],energyLevels[],steps[],minimumVersion,stopSignal,tags[],avoidWhen[]); recommend(count=3) -> filtered catalog array; addAction(actionOrId,date=today()) -> record; getAction(recordId) -> record or null; setActionStatus(recordId,status,feedback?) -> record; status planned/completed/skipped, feedback comfortable/neutral/uncomfortable. addAction supports custom {title,durationMinutes,steps,kind,source:'manual'}; returned record {id,actionId,title,durationMinutes,steps,minimumVersion,stopSignal,status,feedback,createdAt,date,source}.
getMeals(date) -> date filtered, omit date -> all sorted newest; saveMeal(patch) -> saved record; deleteMeal(id). Meal {id,date,time,name,note,photoPath,kcal:null,protein:null,carbs:null,fat:null,nutritionSource:'manual'|'ai-estimate',tags:[],confirmed:true}. Numeric fields null or >=0; no invented calories. saveMeal updates by id.
getPlans() -> array; savePlan(patch) -> plan; deletePlan(id). Plan {id,title,type:'life'|'strength'|'aerobic',goal,source:'manual'|'ai',days:[{date,title,minutes,done:false}],createdAt}.
getReports() -> array; saveReport(patch) -> report; deleteReport(id). Report {id,title,date,photoPath,confirmed:false,metrics:[{name,value,unit,reference}],restrictions:[],note}. OCR candidates must not be treated as confirmed. Store separately until user presses confirm. No diagnostic interpretation.
sealTicket(date=today(),note='') -> immutable snapshot {id,date,title,note,actions:[],meals:[],mood,createdAt}; getTickets() -> sorted array; getTicket(date) -> snapshot or null; deleteTicket(date).
getSettings() -> {aiConsent:false,cloudConsent:false,reduceMotion:false}; saveSettings(patch); clearAll(); exportData() -> JSON string; restoreData(jsonText) validates own schema; subscribe(fn)->unsubscribe.

## services/api.js
status() -> {configured:boolean,connected:boolean,label:string,error:string}; request(task,payload) -> Promise actual JSON result; reject Error with user readable message when unavailable. Tasks: parseState, explainActions, analyzeMeal, extractReport, generatePlan, generateTicketTitle, mealDayReview. Pages must await and catch; show no fake success. AI consent is required in API service via modal before any upload.
analyzeMeal result {name,candidates:[],kcalMin,kcalMax,protein,carbs,fat,note}; extractReport result {metrics:[{name,value,unit,reference}],note}; generatePlan result {title,days:[{date,title,minutes}],note}. Do not auto save model result; user edits and confirms.
services/media.js: choosePhoto() -> Promise permanent wxfile path (wx.chooseMedia and saveFile), error cancellation distinguish; removePhoto(path) -> Promise; askImageConsent() handled by API before cloud upload.
services/ui.js: toast(message); error(error); confirm(title,content)->Promise<boolean>; dateLabel(date); setTab(page,index) if using custom component. call store methods within try/catch. Every page onShow reloads fresh state.

## Visual specification
IMPORTANT user correction: use ACTUAL FINAL Flutter UI source, not V1 PRD/prototype board. Read ../weihuo_app/lib/design_system/app_colors.dart, app_theme.dart, weihuo_widgets.dart and corresponding feature/presentation files. Paper #FBFAF7; paperDeep #F4EFE6; ink #20201D; muted #77736B; navy #465578; sage #8EA391; butter #E9C96F; coral #D77B67. Title LeeeafHei font if licensing/size allows, else native Chinese for now; body PingFang SC/Microsoft YaHei. Existing app brand overrides generic skill font prohibitions. Preserve latest Flutter page headings, open-paper layout, thin dividers, small character, line icons and five-tab rhythm. Do not invent a redesigned dashboard. No emoji icons or gradients.
Global classes: page, eyebrow, page-title, subtitle, row, between, stack, section, section-title, sheet, paper, blue, green, yellow, muted, small, mono, divider, chip/chip.active, chips, button, button.secondary, button.ghost, button.danger, field, label, input, textarea, empty, badge, error-box, bottom-space, link, hero-character, section-head. Native button reset globally.
Assets will be /assets/xiaowei-greeting.png, /assets/xiaowei-walking.png, /assets/xiaowei-eating.png, /assets/xiaowei-recording.png, /assets/xiaowei-resting.png, /assets/xiaowei-ticket.png. Images compressed copies of original app assets.

Agent ownership: action agent pages/actions,action,plans,plan-edit; record agent pages/meals,meal-edit,report; cloud agent cloudfunctions,docs/CLOUD.md and dedicated tests/cloud*. Root all other files and services. Notify root before contract changes, no editing global styles or lockfiles. No framework installs required.

## 2026-10-04 用户验收纠正
首次欢迎→微信身份（无云时明确本机体验）→首次建档→保存→今日。移除活动边界确认开关，保存建档时内部safetyAnswered=true。profile新增birthDate,heightCm,weightKg,bodyFatPercent,exerciseHabit,avoidedActivities,bodyNotes,healthSummary,measurements；缺字段兼容旧数据。summary候选采用才记住，报告确认后可登记为有来源日期的measurement。新增welcome/profile-edit/measurements，archive为档案摘要。
