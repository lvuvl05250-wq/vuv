# 云端接入与验收

原生微信登录已实测进入个人档案；CloudBase 环境、`weihuoApi` 和数据库已部署。文字模型 `cloudbase/hy3` 的真实云调用成功。跨设备备份、视觉模型与图像识别仍需分别核验，不能把其中一项的成功当成全部上线。

## 当前状态（2026-10-05）

- 环境：上海个人版 `weihuo-dev-d7gw5z8z79ca7a924`；DocumentDB 正常。
- `weihuoApi` 为 Active，Event / Node.js 20.19，60 秒、256 MB；部署含 `wx-server-sdk@3.0.1` 与 `@cloudbase/node-sdk@3.18.3`。
- `weihuo_records`、`weihuo_usage`、`weihuo_catalog` 均已创建；ACL 读回为 `ADMINONLY`。
- 微信真机用户已完成登录并进入档案；这尚不代表多账号/多设备同步已验收。
- 文字模型 `hy3` 真实调用返回 energy=2、scene=home、minutes=20，耗时 21.996 秒。证据：`preview/ai-live-text.json`。此通道不需要 API Key。
- 视觉模型尚未配置。Qwen3.5 试调用返回模型未上线或当前套餐不支持；图片 OCR 没有成功实测。
- 云端行动库 current 已 CAS 发布 `2026-10-05.3` / 137 条；原生客户端读取正确版本仍待验收。

管理端 `auth` 分支缺少原生身份时返回 `UNAUTHENTICATED`，这是预期拒绝；真实微信登录已有独立实测证据。云备份仍需用户单独同意并手动操作，也未完成两账号、两设备往返验收。

## 部署所需项目

1. 使用该小程序 AppID 绑定的 CloudBase 环境，确认环境支持文档数据库、云函数及调用外部 HTTPS 服务。把已确认的环境 ID 填入 `miniprogram/config.js` 的 `cloudEnv`，函数名保持 `weihuoApi`。环境 ID 与 AppID 是公开标识，任何密钥都不要写入小程序。
2. 在文档数据库创建 `weihuo_records`、`weihuo_usage`、`weihuo_catalog` 三个集合。SDK 写入不会自动创建集合。分别使用 `cloudfunctions/database.rules.json` 的 `{ "read": false, "write": false }`，禁止小程序直接读写，由云函数根据微信身份访问。共享行动库只由受信任管理员发布；不要给集合开放公共读写。
3. 在微信开发者工具选定正确云环境，右键 `cloudfunctions/weihuoApi`，选择上传并部署、云端安装依赖。当前锁定依赖为 `wx-server-sdk@3.0.1`（微信身份与数据库事务）和 `@cloudbase/node-sdk@3.18.3`（托管模型调用）；当前部署已安装。
4. 函数类型为 **Event**，入口 `index.main`，当前部署运行时为 Node.js 20.19。函数配置确认超时 **60 秒**、内存 **256 MB 或以上**；上游请求默认超时 45 秒。`config.json` 不申请微信 OpenAPI 权限。后续重新部署仍应核对实际运行时、超时和内存，不能仅以本地配置存在为依据。
5. 函数保留原生小程序调用入口，不绑定 HTTP 访问服务，不启用匿名或第三方小程序调用。代码仍检查可信上下文的 `APPID` 和 `OPENID`，拒绝 HTTP 包装与调用数据伪造身份。

`auth` 分支只验证可信微信身份，不读写业务集合，也不需要模型 API Key。管理端 CLI 缺少原生身份时返回 `UNAUTHENTICATED` 属预期；真实微信用户登录进入档案已单独实测。腾讯云资源管理 OAuth 与小程序原生身份注入不同，不需要另做网页 OAuth 登录。

## 服务端环境变量

托管模型使用云函数运行身份，不需要把 API Key 放进服务端或小程序。当前配置与可选项：

| 变量 | 用途 |
| --- | --- |
| `WEIHUO_APPID` | 必填，与小程序 AppID 一致 |
| `WEIHUO_AI_PROVIDER` | 当前使用 `cloudbase` |
| `WEIHUO_AI_MODEL` | 当前文字模型 `hy3` |
| `WEIHUO_AI_VISION_MODEL` | 支持图片的模型 ID；尚未确认时留空 |
| `WEIHUO_AI_TIMEOUT_MS` | 可选，1000–50000 毫秒，默认 45000 |
| `WEIHUO_AI_DAILY_LIMIT` | 可选，每微信用户每天 1–500 次，默认 50 |

托管路由不要求 `WEIHUO_AI_ENDPOINT` 或 `WEIHUO_AI_API_KEY`。旧 OpenAI 兼容 provider 仍保留为备用适配；它的本机预检工具只覆盖那一路径，不能用于判定当前 `cloudbase/hy3` 状态。任何密钥只放在受控服务端配置中。

文字模型已完成一次真实云调用。视觉模型未配置，Qwen3.5 尝试返回模型未上线或当前套餐不支持；需要图像能力时，先确认当前套餐可用且支持图片的模型，再配置 `WEIHUO_AI_VISION_MODEL` 并做真实图片验收。不要把旧凭据 HTTP 401 记录当成当前托管模型失败。

## 调用契约

```js
wx.cloud.callFunction({
  name: 'weihuoApi',
  data: { task: 'parseState', payload: { consent: true, text: '用户本次提交的文字' } }
});
```

成功为 `{ok:true,data,requestId}`；失败为 `{ok:false,error:{code,message,retryable,details?},requestId}`。`requestId` 不含个人内容。不要忽略错误码并显示成功。

| task | payload / 返回 |
| --- | --- |
| `auth` / `status` | 空对象；返回当前用户的 `openid`、`appid`、连接与文本/图片服务配置状态，仅作本机账号隔离，不能当作 Token |
| `getCatalog` | 空对象；读取已发布共享行动库，返回 `{version,publishedAt,items}`；不上传个人资料、不调用模型 |
| `syncPull` | `{consent:true}`；返回 `{version,state,updatedAt}`，未保存或已删除时 state 为 null |
| `syncPush` | `{consent:true,baseVersion,state}`；成功返回新 version 与 updatedAt |
| `deleteCloudData` | `{confirm:true,baseVersion}`；版本一致才删除当前用户云端副本 |
| `parseState` | `{consent:true,text}`；energy/scene/minutes 可为 null，另有 mood/note |
| `explainActions` | `{consent:true,actions,profile?,day?,text?}`；只返回候选 id 子集和 reason |
| `analyzeMeal` | `{consent:true,text?,name?,note?,imageBase64?,mimeType?,profile?}`；name/candidates、kcalMin/kcalMax、protein/carbs/fat 与 note |
| `extractReport` | `{consent:true,text?,imageBase64?,mimeType?}`；仅 metrics 与 note，不返回诊断；候选必须逐项确认 |
| `generatePlan` | `{consent:true,type,goal,startDate,dayCount?,minutes?,profile,constraints?,preferences?,context?,actions?}`；title、days[{date,title,minutes,details,actionIds}]、note |
| `generateTicketTitle` | `{consent:true,date,actions,meals,mood}`；title/note |
| `mealDayReview` | `{consent:true,date,meals,phase?,profile?}`；summary/suggestions、kcalMin/kcalMax、note |
| `summarizeProfile` | `{consent:true,profile}`；返回待采用的 `{summary,restrictions,restrictionEvidence:[{tag,text}],allergies,avoidedActivities}` |

计划 type 为 life/strength/aerobic；dayCount 仅 3、7、14（缺省 7），必须连续日期；每日上限 minutes 为 1–120（缺省 30），休息日可为 0。返回 details 保存准备、主体、强度、组次/休息、最小版本与停止提示，note 保存目标、预期及反馈调整。没有伪造的默认方案。力量/有氧必须先确认成年及活动安全信息。所有类型若档案已有活动限制、特殊情况或输入提及伤病条件，当前自动规划会明确返回 `PLAN_SAFETY_REVIEW_REQUIRED`；人工确认过的计划仍可手动录入。关键词和结构校验无法替代运动专业审核，真实生成质量尚未验收。

计划可提交个人或公共库的行动候选，每项只含 `{id,title,durationMinutes,kind,category,steps,avoidWhen}`，最多 100 项且合计不超过 120 KiB。服务端校验格式、唯一 ID；返回的每个 `actionIds` 必须是输入候选的子集且不重复（每天最多 10 个）。传入候选时，有活动分钟的日子必须引用至少一个候选；不传候选时 `actionIds` 只能为空。候选本身不是管理员签名的内容，个人自建文本仍作为用户资料处理。计划保存候选引用，但用户删除模板后，既有计划文字仍保留；跨设备时不得把失效引用当成可执行模板。

档案摘要只整理填写的事实和已确认记录，不根据测量数值新增禁忌或给诊断。新限制只可来自 `bodyNotes` / `avoidedActivities` 的明确原文，必须给对应 `restrictionEvidence`，逐字片段、身体部位及非否定的限制表述均校验；已有受控限制保留。候选只有本人明确采用后才能写入 `healthSummary` 和限制字段。所有 AI 请求仍需独立同意。

照片必须由客户端在明确同意后压缩、读取为 base64，并给匹配的 JPEG/PNG/WebP MIME。服务端核对编码、文件头和大小，解码最多 512 KiB；拒绝任意图片 URL 或本机路径。图片只用于本次模型请求，不写数据库，不生成长期云端图片。文件头检查不能保证图像一定可识别；供应商无法处理时返回错误。OCR 不生成医学解读，不能直接将候选写为已确认档案。

AI 处理同意与云端记录保存同意独立。`payload.consent=true` 必须对应客户端已征得同意，不是让前端绕过授权弹窗。AI 接口没有写入业务记录的副作用。

## 云同步约束

手动记录先保存在本机；云端备份与恢复需要独立取得云保存同意并由用户手动操作，不会因本机记录或 AI 调用自动上传个人资料。真实微信登录已进入档案，但跨账号隔离、两设备备份/恢复、版本冲突与删除仍待在线验收。

云端以 `SHA-256(APPID + ':' + OPENID)` 确定唯一文档，不接受客户端指定 owner/userId。事务中的 `baseVersion` 比较和写入原子执行；冲突返回 `VERSION_CONFLICT` 与 `details.currentVersion`，客户端保留本机数据并让用户明确选择。删除保留不含业务数据的版本墓碑，阻止旧设备静默重新上传已删除内容。

state 顶层只允许 profile/days/meals/plans/reports/tickets/settings/customActions；旧备份缺 `customActions` 时补为空数组。最大 JSON 大小为 700 KiB；每日记录和票根最多 730，饮食 2000，计划和报告各 100，个人行动模板最多 300。day.carePreference 0–100，0 为照顾、100 为运动。scene 支持 office/classroom/dorm/home/outdoor/commute/any。plan.note ≤8000 字、day.details ≤5000 字，day.actionIds 保留候选引用，旧计划缺字段时为空数组。日期、唯一 ID、非负有限数值、报告确认状态均校验。未确认报告可保留空 name/value，确认后必须填齐。

profile 兼容旧字段，并补空的 birthDate、heightCm、weightKg、bodyFatPercent、exerciseHabit、avoidedActivities、bodyNotes、healthSummary、measurements。身高范围 30–300 cm、体重 1–700 kg、体脂率 0–100%，未填写为 null；这些是输入容量约束，不是健康标准。measurements 最多 1000 条，value 为原值字符串，记录 name/unit/date/source/createdAt；来源为 report 时必须带 reportId，可保留 sourceMetricKey（最多 600 字）标识原始报告项目，编辑数值不应改掉原始来源标识。

上传前必须移除 action.timer，清空所有 meal/report（包括票根快照中）的 photoPath。本机文件路径不能在另一台设备上恢复，不应被当成云资源地址。服务端拒绝含本机路径的状态。AI 同意、云保存同意不得因恢复他人文件或云端备份而自动获得，客户端保留本次会话的同意状态。

调用次数存在另一个集合，每用户最短间隔 2 秒、按北京时间每天重置。外部服务请求开始前占用额度，失败也计一次，避免无限失败重试造成费用；缺配置、参数错或未同意不会占用次数。删除业务记录不会立即重置当天配额。没有自动重试或静默降级。

## 共享行动库、个人模板与音频

共享库在 `weihuo_catalog` 的固定文档 `current` 中发布：

云端 current 已 CAS 发布 `2026-10-05.3` / 137 条。下方是结构示例；客户端读取此版本仍待验收。

```json
{
  "_id": "current",
  "version": "由维护者填写的唯一版本号",
  "publishedAt": "实际发布时间的 ISO 时间字符串",
  "items": []
}
```

上面仅为文档结构，空 items 会返回 `CATALOG_NOT_CONFIGURED`。维护者准备并校验完整非空内容后，由管理员控制台或受信任管理工具一次写入 current；客户端不能指定文档 ID、读取未发布版本或更新共享库。发布前保留上一版本的管理员备份，回滚也应重新赋予唯一版本号。云端返回内容时移除 `_id`。缺集合、缺 current、缺发布时间、未来发布时间或空 items 均为 `CATALOG_NOT_CONFIGURED`；内容不符合格式为 `CATALOG_INVALID`；权限或数据库故障为 `STORAGE_UNAVAILABLE`。本地随包库可以继续使用，但不能把它标成云库读取成功。

items 最多 1000 项，文档最多 700 KiB。每项的通用字段如下：

```text
id, title, durationMinutes, steps[], minimumVersion, stopSignal,
kind: movement | care,
category: movement | relaxation | meditation | focus | nature | senses | care,
tags[], avoidWhen[], scenes[], energyLevels[], priority,
source: catalog（共享）或 manual（个人）,
createdAt?, updatedAt?, audio?: {url,durationSeconds,transcript}
```

个人模板须有 createdAt/updatedAt，source 固定 manual，并且只写入当前微信用户的 `weihuo_records.state.customActions`，沿用完整状态的版本冲突处理。title ≤200 字；durationMinutes 为 1–180；steps ≤30 项且每项 ≤1000 字；minimumVersion/stopSignal 各 ≤1000 字；tags/avoidWhen 各 ≤30 项且每项 ≤80 字；scenes 为既有七个场景；energyLevels 只允许 low/medium/high；priority 为 1–5，缺省 3。旧共享素材可保留 actionKind、knowledgeCard、alwaysPresent、habitTemplate，category 缺省由 kind 补为 movement/care；新版知识内容为 `knowledge:{title,body,sourceTitle,sourceUrl}`，body ≤5000 字，sourceUrl 可空或公共 HTTPS 地址。`reviewedLibrary` 等来源文字只是旧内容标签，不代表本轮完成了真人专业审核。

audio 只允许公共 HTTPS 域名链接，禁明文 HTTP、用户密码、IP/本机地址、非 443 端口及 fragment；durationSeconds 为 1–7200 整数、transcript ≤12000 字。云函数不会下载、代理或自动合成该链接；开发者仍须配置真实音频域名、访问权限和微信要求的合法域名，真机验证可播放、可停止及前后台切换。已开始的行动快照可保留 category/audio，避免模板更新改变历史内容。

字节音频合成服务本轮只预留接入约定：未来凭据仅放服务端环境变量 `WEIHUO_AUDIO_ENDPOINT`、`WEIHUO_AUDIO_APP_ID`、`WEIHUO_AUDIO_ACCESS_TOKEN`、`WEIHUO_AUDIO_RESOURCE_ID`、`WEIHUO_AUDIO_VOICE_TYPE`。这些变量目前不会被读取，尚无合成任务；填写变量不会启用服务。后续必须依据实际购买产品实现协议适配、授权与额度限制，再把输出登记为库中的 HTTPS 音频。没有创建任何付费请求或生成假音频。

## 错误与核验

配置/授权：`SERVICE_NOT_CONFIGURED`、`UNAUTHENTICATED`、`NATIVE_CALL_REQUIRED`、`AI_CONSENT_REQUIRED`、`CLOUD_CONSENT_REQUIRED`。

参数/状态：`INVALID_ARGUMENT`、`PAYLOAD_TOO_LARGE`、`VERSION_CONFLICT`、`SAFETY_PROFILE_REQUIRED`、`PLAN_SAFETY_REVIEW_REQUIRED`、`PLAN_NOT_COMPATIBLE`。

行动库：`CATALOG_NOT_CONFIGURED`、`CATALOG_INVALID`。外部服务错误按权限、额度、限流、超时、网络和返回格式分类；数据库故障为 `STORAGE_UNAVAILABLE`，不会返回空账号假装读取成功。

本地云函数测试使用注入的网络/数据库传输替身，覆盖鉴权、Schema、事务版本比较、图片校验、提示词构造和错误处理。全量测试最终数量由根在修复旧 extra 字段断言并复跑后补入 [验证记录](VERIFICATION.md)。

## 仍待在线验收

- 两个微信用户的数据与个人模板隔离；同账号两设备备份、恢复、冲突处理与云删除。
- 普通客户端无法直接读写三个集合；小程序读取正确的共享行动库版本，普通用户不能发布。
- 选择套餐支持的视觉模型后，真实餐食图片和报告 OCR 调用及用户核对流程。
- 日历提醒的系统权限请求在手机端实际运行。
- 视频链接跳转与真实音频播放；本轮没有用户实际音视频资源，音频合成未接入。
- 外部服务额度、网络断开和超时情况下的真实环境表现。

