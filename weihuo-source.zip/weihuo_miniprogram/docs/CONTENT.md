# 微活行动内容说明

2026-10 的这轮内容调整把原有 102 条逐项重新编辑，增加 20 条自我照顾行动，共 122 条。目录内容统一标为 `source: 'catalog'`，不冒充用户记录或 AI 实时生成结果。

## 分类与兼容

| category | 中文 | 条数 |
| --- | --- | ---: |
| movement | 轻活动 | 51 |
| relaxation | 放松 | 17 |
| meditation | 冥想与当下觉察 | 7 |
| focus | 专注 | 5 |
| nature | 自然观察 | 8 |
| senses | 感官小发现 | 10 |
| care | 日常照顾 | 24 |

原有 `id`、`actionKind`、`kind`、`scenes`、`energyLevels`、`tags`、`avoidWhen`、`stopSignal`、`priority` 完整保留，避免既有记录、推荐筛选或活动限制失去对应关系。`kind` 继续区分运动与照顾；`category` 提供更具体的内容分类。原知识卡的 `id`、`topic`、`sourceRefs`、`source`、`dismissible` 保留兼容用途，界面应使用新字段 `sourceTitle` 和 `sourceUrl` 展示出处，不把历史字段 `reviewedLibrary` 当成医学审校资质。

## 时长与步骤

时长是准备、尝试、短暂休息合在一起的编辑估计，不是医疗剂量，也不是最低完成要求。每条都保留更小版本和退出信号。

当前有 1 分钟 54 条、2 分钟 32 条、3 分钟 24 条、5 分钟 8 条、10 分钟 2 条、12 分钟 1 条、20 分钟 1 条。12 分钟对应有去程和回程的户外慢走；20 分钟对应午后预留休息。呼吸三次、站起坐下两次、喝几口水等短步骤以 1 分钟为主。

本轮修正的典型错配：

- “久坐后走三分钟”从 8 改为 3 分钟；“窗边看远处三分钟”从 4 改为 3 分钟。
- “站起坐下两次”从 8 改为 1 分钟，保留稳固座椅和原有禁忌。
- 原“做一次自然长呼气”从 7 改为 1 分钟，并改名“跟着一次自然呼气”，明确不强迫延长。
- “用温水暖一下双手”从 7 改为 1 分钟，步骤改为试温、温水流过双手、擦干；不再错误复用喝水步骤。
- 叶子观察从 8 改为 3 分钟：发现几种叶子、喜欢哪一种颜色、像什么、给叶子起名字；不摘取植物。
- 每条的完整步骤组合都不同。保留路口、湿滑地面、稳固支撑等实际场景提示，去掉与行动无关的统一安全开场。

## 知识卡出处

每张卡都有 `title`、`body`、`sourceTitle`、`sourceUrl`。有直接来源的短转述只覆盖下列来源支持的一般信息，不扩展为治疗、疾病判断或个人效果承诺。

- [WHO：Physical activity](https://www.who.int/news-room/fact-sheets/detail/physical-activity)：身体活动可以累计、减少久坐；用于短走与散步卡片。
- [NHS：Breathing exercises for stress](https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/)：呼吸轻柔舒适、不强迫吸得更深。
- [NCCIH：Meditation and mindfulness](https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety)：留意当下、不过早评价，不要求脑中没有念头。
- [AAO：Digital eye strain](https://aao.org/eye-health/tips-prevention/blue-light-digital-eye-strain)：屏幕使用时容易减少眨眼，安排规律用眼休息。
- [NHS：Water, drinks and hydration](https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/water-drinks-nutrition/)：把规律饮水放入一天的日常安排。

其余卡片使用标题“一个小窍门”、`sourceTitle: '微活生活实践'`、空 `sourceUrl`，说明具体的操作办法或观察角度。它们是产品编辑建议，不包装成研究发现。午后休息卡没有借用未核实的睡眠效果结论。

音乐类行动说明使用者在自己常用的播放器选择内容；目录不包含音频，也不显示并不存在的播放入口。

## 验证

运行 `node --test tests/catalog.test.js`，检查原始 102 条安全与兼容字段指纹、分类与来源、标题和计时一致、步骤不重复、实际动作错配修复、知识卡出处和新内容覆盖。指纹来自本次修改前的真实目录；测试还会人为去掉深蹲禁忌，确认该检查能识别安全约束被削弱。

机器验证能发现结构、来源字段和重复套话问题，无法代替读者对语气与节奏的体验。本轮估时为编辑判断，尚未开展真人逐条计时验证。
