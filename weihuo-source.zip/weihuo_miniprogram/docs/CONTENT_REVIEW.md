# 微活行动库内容复核记录

复核日期：2026-10-05

## 本轮范围

本轮精修共享目录中的 40 条行动：自然观察 8 条、感官发现 10 条、冥想与当下觉察 7 条、专注 5 条、轻活动 8 条、饮食照顾 2 条。其余 82 条未改。

自然观察、感官、冥想、专注和饮食照顾条目调整了标题、步骤、最小版本或知识卡文案，让行动有更具体的观察对象和更容易开始的第一步。轻活动条目只调整知识卡解释与出处；运动步骤、最小版本和时长没有改动。随后又从这40条里挑出8条自然观察、触觉感官与专注行动，补上研究解释及来源；第二轮只改知识卡的标题、正文和出处，不改行动步骤。

本轮保留所有条目的 `id`、`actionKind`、`kind`、`category`、`durationMinutes`、`scenes`、`energyLevels`、`tags`、`avoidWhen`、`stopSignal`、`priority` 和行动来源。知识卡的 `id`、`topic`、`sourceRefs`、`source`、`dismissible` 字段也保留。没有增加诊断、疗效保证、营养摄入量或治疗建议。

## 一手来源与采用边界

以下官方页面于 2026-10-05 实际查阅。知识卡只转述页面明确支持的一般信息；没有相应依据的观察、专注与触感提示继续标作“微活生活实践”，不冒充研究结论。

- [WHO · Physical activity](https://www.who.int/news-room/fact-sheets/detail/physical-activity)：WHO 将走路、增强肌肉力量等活动纳入身体活动，并指出任何活动量都比完全不活动好、活动可以累计。对应 `office_corridor_walk`、`classroom_aisle_walk`、`dorm_wall_push`、`reviewed_classroom_movement_07`、`reviewed_dorm_movement_02`、`reviewed_home_movement_02`、`reviewed_outdoor_movement_03`、`movement_strength_explore_15`、`movement_walk_experience_20`。15分钟力量体验与20分钟步行是目录的行动时长，不等同于WHO建议的运动剂量。
- [NCCIH · Meditation and Mindfulness: Effectiveness and Safety](https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety)：页面列出呼吸可作为冥想专注的感受，并将正念描述为对当下保持注意或觉察、尽量不作评判。本轮据此解释留意呼吸、发现走神后回到当下的练习，不承诺治疗或情绪改善。对应 `classroom_quiet_breath`、`mindful_one_minute`。
- [NHS · Breathing exercises for stress](https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/)：页面提醒让呼吸舒适地流动、不强迫加深。本轮只采用这一点，不把目录里的短暂停留说成 NHS 的完整呼吸练习或医疗剂量。对应 `reviewed_office_care_07`、`reviewed_classroom_care_06`。
- [NHS · The Eatwell Guide](https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/the-eatwell-guide/)：复核了食物类别的用词。两条饮食行动仍然是可选的日常实践，没有写成每餐必须吃什么或吃多少的建议，知识卡因此保持“微活生活实践”与空链接。
- [NHS · Water, drinks and hydration](https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/water-drinks-nutrition/)：查阅了目录已有饮水知识卡所引用的页面；本轮没有调整饮水条目。
- [AAO · Digital Devices and Your Eyes](https://aao.org/eye-health/tips-prevention/blue-light-digital-eye-strain)：搜索结果显示了 AAO 关于屏幕使用时眨眼频率下降和看远处休息的说明，但该站点直接打开返回 403。本轮没有使用这一页面新增主张，也没有改动相关眼睛休息条目。

## 精修条目

- 自然观察（8）：`dorm_window_air`、`outdoor_sunlight_stand`、`outdoor_leaf_observe`、`reviewed_dorm_care_02`、`reviewed_outdoor_care_02`、`nature_cloud_shapes`、`nature_leaf_palette`、`nature_light_edges`。
- 感官发现（10）：`reviewed_office_care_04`、`reviewed_classroom_care_04`、`reviewed_dorm_care_05`、`reviewed_home_care_05`、`reviewed_home_care_06`、`reviewed_outdoor_care_04`、`reviewed_outdoor_care_06`、`senses_three_sounds`、`senses_texture`、`senses_first_bite`。
- 冥想与当下觉察（7）：`classroom_quiet_breath`、`reviewed_office_care_07`、`reviewed_classroom_care_06`、`mindful_one_minute`、`mindful_open_eyes`、`mindful_name_thought`、`mindful_contact_points`。
- 专注（5）：`classroom_posture_note`、`focus_first_sentence`、`focus_five_minute_piece`、`focus_read_for_joy`、`focus_one_window`。
- 轻活动（8）：`office_corridor_walk`、`classroom_aisle_walk`、`dorm_wall_push`、`reviewed_classroom_movement_07`、`reviewed_dorm_movement_02`、`reviewed_home_movement_02`、`reviewed_outdoor_movement_03`、`reviewed_strength_wall_sit`。
- 饮食照顾（2）：`reviewed_home_care_03`、`reviewed_home_care_07`。

## 第二轮知识卡补充（8条）

以下来源于 2026-10-05 实际查阅的研究摘要、原始论文全文或 NCBI Bookshelf 生理学章节。Treisman 与 Gelade 的 PDF 是 Hope College 心理学实验室托管的原始论文全文副本；PubMed 与 NCBI 页面提供对应的研究摘要或生理学条目。前端卡片写简明事实和可尝试的动作线索；研究对象、方法与适用边界集中记在本节。

### 自然观察

- `outdoor_leaf_observe`： [Berman、Jonides 与 Kaplan · 自然环境与注意实验（2008）](https://pubmed.ncbi.nlm.nih.gov/19121124/)。两项实验中，自然环境散步或看自然图片之后，参与者在定向注意测验上的表现有所改善。实验没有观察单片叶子；叶缘和叶脉给行动提供一个具体的观察对象。
- `nature_leaf_palette`： [Treisman 与 Gelade · 视觉注意原始研究（1980）](https://facultypsy.hope.edu/psychlabs/exp/visualsearch/readings/TreismanGelade_1980.pdf)。原始论文使用视觉搜索等实验，比较单一特征与颜色、形状组合的辨认，并提出组合搜索需要聚焦注意。行动把颜色搜索线索用于叶片观察；原实验材料不是自然场景。

### 触觉与感官

- `senses_texture`： [Zompa 与 Chapman · 触觉纹理辨别实验（1995）](https://pubmed.ncbi.nlm.nih.gov/7502607/)。12名受试者用指尖分辨凸点表面的纹理变化；把注意指向触觉时，速度和准确率高于注意被引向视觉的条件。实验使用人工凸点表面；衣袖纹理是行动中的日常触觉观察对象。
- `reviewed_dorm_care_05`： [NCBI Bookshelf · Physiology, Sensory Receptors](https://www.ncbi.nlm.nih.gov/books/NBK539861/)。生理学章节区分皮肤对触碰、压力等机械刺激和温度的感受器。知识卡将此机制转成温水时留意水流和暖意的具体线索。
- `senses_first_bite`： [Engelen 等 · 半固体食物温度与感官实验（2003）](https://pubmed.ncbi.nlm.nih.gov/14637326/)。受训品评者评估布丁和蛋黄酱；产品温度影响了一些风味与口感评分，口腔温度的影响较小。实验对象是特定半固体食物与感官评分；日常卡片让人任选温度、口感或味道留意。

### 专注

- `focus_first_sentence`： [Masicampo 与 Baumeister · 计划与未完成目标（2011）](https://users.wfu.edu/masicaej/MasicampoBaumeister2011JPSP.pdf)。多项实验显示，未完成目标会干扰无关阅读；为目标形成具体计划后，这类干扰减弱。卡片把“先写一句”作为写作目标的具体起点。
- `focus_five_minute_piece`： [Forsyth 与 Burt · 任务拆分与时间估计实验（2008）](https://pubmed.ncbi.nlm.nih.gov/18604961/)。三项实验中，人们给整项任务分配的时间均低于逐项估算子任务后相加的时间。研究针对时间估计；卡片把读一小段写成可见的小步骤。
- `focus_one_window`： [Rubinstein、Meyer 与 Evans · 任务切换实验（2001）](https://pubmed.ncbi.nlm.nih.gov/11518143/)。四项实验让参与者在几何分类或算术规则之间交替；任务切换带来额外用时，明确的任务提示能缩小成本。原实验任务不是电脑窗口操作；卡片将“留一个当前窗口、写下下一步”作为清楚提示的日常做法。

## 验证

第一轮运行 `node --test tests/catalog.test.js tests/cloud-catalog.test.js tests/cloud-integration.test.js`：21 项通过，0 项失败。补充8张知识卡及来源白名单后，同一命令复跑仍为21项通过、0项失败；覆盖原有102条安全字段指纹、知识卡来源约束、云目录读取和云端结构往返。

目录源文件可被 Node.js 正常加载；所有 8 条运动行动的步骤与最小版本在写入前后保持一致，受保护的安全与兼容字段也保持一致。本轮没有进行真人试用或逐条计时。

## 新增日常行动（15条）

新增行动追加在原122条之后。本批共15条：专注3条、感官3条、连接与照顾4条、放松2条、自然1条、运动体验2条。连接与照顾4条中，2条是征得同意后分享或倾听，2条是给未完成事项留下一步、暂停一条非紧急提醒。两条运动分别为15分钟轻量力量活动与20分钟舒适步行，可按小段完成。标题与步骤用具体的小动作表达；涉及对话时保留对方不方便就停止的选项。未给行动添加音频字段或接入语音生成接口。

### 前端表达收口

本轮将前端少数“本行动不等同于某种效果/不是门槛”式解释改成直接事实或具体体验线索；研究对象与适用范围保留在本复核记录中。涉及的旧条目为 `outdoor_slow_walk`、`reviewed_office_movement_01`、`reviewed_classroom_care_05`、`reviewed_home_care_03`、`reviewed_outdoor_care_05` 的知识卡，以及 `reviewed_home_care_07` 的步骤。只改文案，没有改这些条目的 ID、类别、时长、tags、avoidWhen、stopSignal 或 priority。

### 新增来源与适用范围

- [Roediger 与 Karpicke · Test-Enhanced Learning（2006）](https://www.psychologicalscience.org/journals/psychological-science/j.1467-9280.2006.01693.x/)：两项实验使用学生阅读短文和自由回想，随后在不同延迟后测试记忆。研究对象是文章回想与延迟记忆；`focus_recall_one_idea` 把回想用作日常读书步骤。
- [Dodhia 与 Dismukes · Interruptions create prospective memory tasks（期刊卷期2009，在线首发2008）](https://onlinelibrary.wiley.com/doi/10.1002/acp.1441)：两项实验研究任务被打断后如何记得返回；作者讨论了意图编码、检索线索和实施计划。`focus_return_marker` 将“留一条回来线索”用于日常读写；论文研究了任务中断场景。
- [NCBI Bookshelf · Physiology, Sensory Receptors](https://www.ncbi.nlm.nih.gov/books/NBK539861/)：章节说明气味分子与鼻腔嗅觉受体结合后形成传往大脑的信号；皮肤有机械与温度感受器，内耳毛细胞会把声音振动转成神经信号。对应 `senses_smell_familiar`、`senses_notice_safe_temperature` 与 `senses_follow_sound_shape`；这些卡片转述感官生理机制。
- [美国卫生与公众服务部 · Social Connection Advisory](https://www.hhs.gov/surgeongeneral/reports-and-publications/connection/index.html)：公共卫生署长的咨询报告将社会连接放在个人、社区与社会健康的广泛框架中。它讨论社会关系的总体作用；`care_share_small_discovery` 提供的是一次低压力的交流邀请，不推断单次交流会产生特定健康结果。
- [Masicampo 与 Baumeister · Consider It Done!（2011）](https://users.wfu.edu/masicaej/MasicampoBaumeister2011JPSP.pdf)：实验研究发现，为未完成目标形成具体计划后，目标对无关阅读任务的干扰会减弱。`care_park_next_step` 据此提供写下一步的生活实践；论文没有研究睡前备忘或助眠。
- [Albulescu 等 · 微休息系统综述与元分析（2022）](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0272460)：22个独立样本、共2335人；对象主要是健康的学生或员工在消耗性任务间进行的短休息实验或准实验。汇总结果显示活力与疲劳方面是小幅差异，整体表现差异未达显著；研究没有确定唯一最佳时长，也没有单独测试涂鸦或静音提醒。这些结果为短休息卡提供背景，不把效果归到某一种休息内容。
- [WHO · Physical activity](https://www.who.int/news-room/fact-sheets/detail/physical-activity)：`movement_strength_explore_15` 与 `movement_walk_experience_20` 分别借用增强肌肉力量的活动、步行均属于身体活动的定义。15分钟和20分钟是行动卡时长；卡片不将其描述为达到某个健康建议剂量。

### 新增条目

- 专注（3）：`focus_recall_one_idea`、`focus_return_marker`、`focus_reading_question`。
- 感官（3）：`senses_smell_familiar`、`senses_notice_safe_temperature`、`senses_follow_sound_shape`。
- 连接与照顾（4）：`care_share_small_discovery`、`care_listen_or_think_together`、`care_park_next_step`、`care_pause_one_notification`。
- 放松（2）：`relaxation_margin_doodle`、`relaxation_hum_familiar_tune`。
- 自然（1）：`nature_check_known_plant`。
- 运动体验（2）：`movement_strength_explore_15`、`movement_walk_experience_20`。

其中没有直接来源支持的对话方式、盆栽观察、涂鸦细节和哼唱均标注为“微活生活实践”，没有伪装成研究结论。两条新增运动分别提供轻量力量体验和舒适步行，步骤可拆成较短小段；用贴合动作的简短提示说明何时停下。旧条目的受保护ID、类别、时长、运动边界及其他安全元数据均未更改。

## 新增批次验证

目录定向校验：`node --test tests/catalog.test.js tests/cloud-catalog.test.js tests/cloud-integration.test.js`，22项通过、0项失败、0项跳过。验证包含原102条安全字段指纹、旧20条新增内容、知识卡来源白名单、新15条覆盖与契约，以及真实目录通过云目录结构校验。随后运行完整 `npm test`：244项通过、0项失败、0项跳过。
