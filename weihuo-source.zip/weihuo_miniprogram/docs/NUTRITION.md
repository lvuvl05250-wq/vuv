# 营养摘要估算说明

`miniprogram/services/nutrition-summary.js` 导出纯函数 `nutritionSummary(profile, meals, date)`。它为指定日期生成已记录宏量营养素供能占比，以及可选的“日常消耗估算”范围；不读取或修改存储，不产生目标值，也不把计划运动时长换算成全天消耗。

## 返回值

```js
{
  date,
  expenditure: {
    status: 'estimated' | 'minor' | 'unavailable' | 'out_of_range',
    minKcal: number | null,
    maxKcal: number | null,
    label: '日常消耗估算',
    assumption: string | null,
    reason: string | null
  },
  macros: {
    status: 'available' | 'partial' | 'no_data',
    confirmedMealCount: number,
    kcal: { protein: number | null, carbs: number | null, fat: number | null, total: number | null },
    grams: { protein: number | null, carbs: number | null, fat: number | null },
    percentages: { protein: number | null, carbs: number | null, fat: number | null },
    coverage: {
      protein: { recorded: number, total: number },
      carbs: { recorded: number, total: number },
      fat: { recorded: number, total: number }
    }
  }
}
```

## 日常消耗范围

年龄按出生日期和请求的 `date` 计算。资料缺少有效生日、身高或体重时，`status` 为 `unavailable`，范围为 `null`。未满18岁时为 `minor`，不生成消耗估算，仍可返回餐食记录。18岁以及超过78岁时为 `out_of_range`：Mifflin–St Jeor 原始研究纳入19–78岁成人，所以本实现不把公式外推到研究范围外。

成人在研究年龄范围内且身高、体重有效时，使用 Mifflin–St Jeor 的静息能量消耗（REE）方程：

```text
REE = 10 × 体重kg + 6.25 × 身高cm − 5 × 年龄 + 系数
系数端点：−161 与 +5
```

资料没有性别字段，所以两种方程系数都保留为范围端点，不推测用户性别。为了估算日常总消耗，再分别乘上 FAO/WHO/UNU 报告中“静坐或轻活动生活方式”PAL 范围 1.40–1.69，并将两端舍入到最接近的10 kcal。返回值按单日 kcal 表示。

这只是明确假设下的范围，不是个人实测值或统计置信区间。PAL 描述一段时间的日常生活方式；本实现不会从某天计划的活动分钟数推断它。前端应一并显示 `assumption`，范围为空时显示 `reason`。

## 宏量营养素供能占比

仅汇总满足 `meal.date === date && meal.confirmed === true` 的餐食。蛋白质、碳水化合物和脂肪分别按已记录克数乘以 4、4、9 kcal/g 计算；未填写字段始终是 `null`，不会补成零。`coverage` 说明每种营养素在多少条确认餐食中有数值。若有些字段缺失，状态为 `partial`，比例只以已记录宏量对应的供能合计为分母；前端应让用户看出这是一份部分记录的构成。

确认餐食数为零或所有餐食的宏量字段都为空时，状态为 `no_data`，能量和比例均为 `null`。记录值都为零时，状态仍是 `available`（或因缺字段而为 `partial`），但总能量为零、比例为 `null`，因为没有可用的比例分母。这里的环图表示已记录营养素的能量构成，不是目标进度或“达标”比例。

4/4/9 是一般营养标签能量换算因子。美国 21 CFR 101.9 也规定了蛋白质、总碳水与脂肪的通用换算因子；标签舍入、膳食纤维、糖醇和特殊 Atwater 系数可能使宏量换算值与食物标签热量不完全一致。因此摘要只展示“按已记录宏量换算的供能构成”，不覆盖或反推餐食的 kcal 字段。

## 一手来源

- Mifflin MD 等，*A new predictive equation for resting energy expenditure in healthy individuals*，PubMed 原始研究摘要（1989；498名19–78岁参与者）：[https://pubmed.ncbi.nlm.nih.gov/2305711/](https://pubmed.ncbi.nlm.nih.gov/2305711/)
- FAO/WHO/UNU，*Human Energy Requirements*，成人能量需要量及 PAL 定义和静坐/轻活动范围：[第5章成人能量需要量](https://www.fao.org/4/y5686e/y5686e07.htm)
- 美国联邦法规 21 CFR §101.9，营养标签能量换算因子：[Nutrition labeling of food](https://www.ecfr.gov/current/title-21/chapter-I/subchapter-B/part-101/subpart-A/section-101.9)
