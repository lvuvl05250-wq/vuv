'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {ageAt, isAdult} = require('../miniprogram/services/age');
const {profile} = require('../cloudfunctions/weihuoApi/state');

function input(birthDate, adult) {
  return {name: '', birthDate, adult, safetyAnswered: false, specialCondition: false,
    restrictions: [], allergies: '', notes: '', goals: [], onboarded: true};
}

test('age changes on the birthday and blank birth dates remain unknown', () => {
  assert.equal(ageAt('2008-10-05', '2026-10-04'), 17);
  assert.equal(ageAt('2008-10-05', '2026-10-05'), 18);
  assert.equal(ageAt('2008-10-05', '2026-10-06'), 18);
  assert.equal(ageAt('2026-10-05', '2026-10-05'), 0);
  for (const blank of ['', null, undefined]) {
    assert.equal(ageAt(blank, '2026-10-05'), null); assert.equal(isAdult(blank, '2026-10-05'), false);
  }
});

test('leap dates use calendar age and malformed or future dates cannot produce an age', () => {
  assert.equal(ageAt('2008-02-29', '2026-02-28'), 17);
  assert.equal(ageAt('2008-02-29', '2026-03-01'), 18);
  assert.equal(ageAt('1900-01-01', '2026-10-05'), 126);
  for (const value of ['2026-02-29', '2026-02-30', '2000-13-01', '2026-10-06', '2008-2-29', 'bad', 20080101]) {
    assert.throws(() => ageAt(value, '2026-10-05'), /出生日期/);
  }
});

test('client helper and cloud profile agree across birthday and Shanghai midnight, overriding stale flags', t => {
  const originalNow = Date.now;
  t.after(() => { Date.now = originalNow; });
  for (const [timestamp, day] of [['2026-10-04T15:59:59Z', '2026-10-04'], ['2026-10-04T16:00:00Z', '2026-10-05']]) {
    Date.now = () => Date.parse(timestamp);
    for (const birthDate of ['', '2012-10-05', '2008-10-05', '2000-02-29', '1900-01-01']) {
      const expected = isAdult(birthDate, day);
      assert.equal(isAdult(birthDate), expected);
      assert.equal(profile(input(birthDate, !expected)).adult, expected);
    }
    assert.throws(() => profile(input('2026-02-30', true)));
    assert.throws(() => profile(input('2027-01-01', true)));
  }
});
