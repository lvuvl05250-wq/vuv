'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '../miniprogram');
const {normalizeResult} = require('../cloudfunctions/weihuoApi/model-result');
const disk = new Map();
let notices = [];
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => disk.set(key, structuredClone(value)),
  showModal: options => { if(options.success)options.success({confirm:true}); }, showToast: options => notices.push(options.title),
  navigateTo() {}, navigateBack() {}, switchTab() {}, redirectTo() {}
};
global.getCurrentPages = () => [{}];
const store = require(path.join(root, 'services/store'));
const api = require(path.join(root, 'services/api'));
const originalRequest = api.request;
function page(name) {
  let definition; global.Page = value => { definition = value; };
  const file = path.join(root, 'pages', name, 'index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data:structuredClone(definition.data)});
  instance.setData = function(patch, callback) {
    for (const [key, value] of Object.entries(patch)) {
      const keys=key.replace(/\[(\d+)\]/g, '.$1').split('.'); let target=this.data;
      while(keys.length>1)target=target[keys.shift()]; target[keys[0]]=value;
    }
    if(callback)callback();
  };
  instance.onLoad({}); if(instance.onShow)instance.onShow(); return instance;
}
function plan() {
  const edit=page('plan-edit');
  edit.setData({title:'我自己的安排', goal:'留一点读书时间', note:'原本的备注', days:[{date:store.today(),title:'读自己选的书',minutes:20,details:'原先写好的步骤',actionIds:[],done:false}]});
  return edit;
}
test.beforeEach(()=>{disk.clear();store.useLocal();store.clearAll();notices=[];});
test.afterEach(()=>{api.request=originalRequest;});

test('plain model prose stays visible beside an unchanged plan editor and is not saved as a completed plan',async()=>{
  const edit=plan(), before=structuredClone(edit.data);
  api.request=async()=>normalizeResult('generatePlan',{startDate:store.today(),dayCount:3},'可以先把周末留给散步。');
  await edit.generate();
  assert.equal(edit.data.aiBody,'可以先把周末留给散步。');assert.match(edit.data.aiNotice,/还没有/);
  assert.deepEqual(edit.data.days,before.days);assert.equal(edit.data.title,before.title);assert.equal(edit.data.note,before.note);
  assert.equal(edit.data.aiDraft,false);assert.equal(edit.data.aiError,'');assert.equal(store.getPlans().length,0);assert.deepEqual(notices,[]);
});

test('a nullable plan duration remains missing, with partial details visible and user input untouched',async()=>{
  const edit=plan(), before=structuredClone(edit.data.days);
  api.request=async()=>normalizeResult('generatePlan',{startDate:store.today(),dayCount:3},{days:[{title:'到窗边看看',minutes:null,details:'看看远处的树'}],body:'这是一个还需补充时长的想法。'});
  await edit.generate();
  assert.deepEqual(edit.data.days,before);assert.match(edit.data.aiBody,/时长待填写/);assert.match(edit.data.aiBody,/看看远处的树/);
  assert.match(edit.data.aiNotice,/部分/);assert.equal(edit.data.aiError,'');assert.equal(store.getPlans().length,0);
});

test('an empty plan response does not invent days, prose or a successful generation',async()=>{
  const edit=plan(), before=structuredClone(edit.data.days);api.request=async()=>({days:[],note:null,body:null});
  await edit.generate();assert.deepEqual(edit.data.days,before);assert.equal(edit.data.aiBody,'');assert.match(edit.data.aiNotice,/没有返回/);
  assert.equal(edit.data.aiDraft,false);assert.deepEqual(notices,[]);
});

test('valid zero-minute rest day is editable while a written plan title and note survive',async()=>{
  const edit=plan();api.request=async()=>({title:'模型标题',days:[{date:store.today(),title:'休息',minutes:0,details:null,actionIds:null}],note:null});
  await edit.generate();assert.equal(edit.data.days[0].minutes,0);assert.equal(edit.data.days[0].details,'');
  assert.deepEqual(edit.data.days[0].actionIds,[]);assert.equal(edit.data.title,'我自己的安排');assert.equal(edit.data.note,'原本的备注');
  assert.equal(edit.data.aiDraft,true);assert.equal(store.getPlans().length,0);
});

test('report body without metrics remains readable without replacing handwritten data or confirming a report',async()=>{
  const edit=page('report');edit.setData({title:'我自己的资料',photoPath:'wxfile://source',note:'手写备注',metrics:[{_key:'own',name:'身高',value:'163',unit:'cm',reference:''}]});
  api.request=async()=>normalizeResult('extractReport',{},'照片右侧文字不清晰，请核对原件。');
  await edit.extract();assert.match(edit.data.ocrNote,/照片右侧文字不清晰/);assert.equal(edit.data.ocrError,'');
  assert.equal(edit.data.metrics[0].value,'163');assert.equal(edit.data.note,'手写备注');assert.equal(edit.data.photoPath,'wxfile://source');
  assert.equal(edit.data.candidate,false);assert.equal(edit.data.confirmed,false);assert.equal(store.getReports().length,0);
});

test('partial OCR appends editable candidates, deduplicates exact repeats and never changes null into zero',async()=>{
  const edit=page('report');edit.setData({title:'自己的资料',photoPath:'wxfile://source',metrics:[{_key:'own',name:'身高',value:'163',unit:'cm',reference:''}]});
  api.request=async()=>normalizeResult('extractReport',{}, {metrics:[{name:'身高',value:163,unit:'cm'},{name:'体重',value:null,unit:'kg'}],body:'体重数值未能读清。'});
  await edit.extract();assert.equal(edit.data.metrics.length,2);assert.equal(edit.data.metrics[0]._key,'own');
  assert.equal(edit.data.metrics[1].name,'体重');assert.equal(edit.data.metrics[1].value,'');assert.equal(edit.data.candidate,true);
  await edit.save({currentTarget:{dataset:{confirmed:true}}});assert.equal(store.getReports().length,0);assert.match(edit.data.error,/补齐/);
});

test('profile prose with nullable fields is a reviewable candidate and does not erase allergies or limitations',async()=>{
  const edit=page('profile-edit');edit.setData({'draft.allergies':'牛奶过敏','draft.avoidedActivities':'不做跳跃','draft.restrictions':['ankle'],'draft.bodyNotes':'脚踝有旧伤'});
  api.request=async()=>({summary:null,body:'你希望记录日常活动，也留意脚踝的感受。',restrictions:null,restrictionEvidence:null,allergies:null,avoidedActivities:null});
  await edit.summarize();assert.equal(edit.data.candidate.summary,'你希望记录日常活动，也留意脚踝的感受。');assert.equal(edit.data.aiError,'');
  assert.equal(edit.data.draft.healthSummary,'');edit.adoptSummary();assert.equal(edit.data.draft.allergies,'牛奶过敏');
  assert.equal(edit.data.draft.avoidedActivities,'不做跳跃');assert.deepEqual(edit.data.draft.restrictions,['ankle']);assert.equal(store.getProfile().healthSummary,'');
});

test('late report and plan results cannot modify an editor after the active account changes',async()=>{
  for(const name of ['report','plan-edit']) {
    store.useLocal(); const edit=name==='report'?page(name):plan();
    if(name==='report')edit.setData({photoPath:'wxfile://source'});
    let resolve;api.request=()=>new Promise(done=>{resolve=done;});
    const pending=name==='report'?edit.extract():edit.generate();
    // Plan replacement asks for confirmation before it reaches the API call.
    await Promise.resolve();
    store.switchAccount('changed_consumer_account');
    resolve({metrics:[{name:'身高',value:'165'}],days:[{date:store.today(),title:'模型内容',minutes:5}]});await pending;
    if(name==='report')assert.equal(edit.data.metrics.length,0);
    else assert.equal(edit.data.days[0].title,'读自己选的书');
  }
});
