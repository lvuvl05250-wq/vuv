'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let navigation = [], failWrites = false;
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => { if (failWrites) throw new Error('test: storage unavailable'); disk.set(key, JSON.parse(JSON.stringify(value))); },
  showToast: () => {}, showModal: value => { if (value.success) value.success({confirm: true}); },
  switchTab: value => navigation.push(value.url), navigateTo: value => navigation.push(value.url),
  pageScrollTo: () => {}, cloud: {callFunction: async () => { throw new Error('test: offline'); }}
};
const store = require(path.join(root, 'services/store'));
const api = require(path.join(root, 'services/api'));
const originalConnect = api.connect, originalRequest = api.request;
function page(name) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages', name, 'index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = function (patch, callback) {
    Object.entries(patch).forEach(([key, value]) => {
      const parts = key.replace(/\[(\d+)\]/g, '.$1').split('.'); let target = this.data;
      while (parts.length > 1) target = target[parts.shift()]; target[parts[0]] = value;
    });
    if (callback) callback();
  };
  return instance;
}
function editor() { const instance = page('profile-edit'); instance.onLoad({onboarding: '1'}); instance.onShow(); return instance; }
function summaryResult(patch) { return Object.assign({summary: '用户填写脚踝受伤，日常希望多一些自我照顾。', restrictions: ['ankle'], restrictionEvidence: [{tag: 'ankle', text: '脚踝受伤'}], allergies: '', avoidedActivities: ''}, patch); }
test.beforeEach(() => {
  failWrites = false; navigation = []; api.connect = originalConnect; api.request = originalRequest;
  store.useLocal(); store.clearAll();
});
test.afterEach(() => { api.connect = originalConnect; api.request = originalRequest; });

test('welcome stays at login when real cloud is unavailable and offers no local bypass', async () => {
  const welcome = page('welcome'); await welcome.onShow();
  assert.equal(navigation.length, 0);
  await welcome.login(); assert(welcome.data.error); assert.equal(navigation.length, 0);
  assert.equal(store.getNamespace(), 'local'); assert.equal(store.getProfile().onboarded, false);
  assert.equal(welcome.localExperience, undefined);
});

test('successful verified WeChat identity opens its own first profile', async () => {
  store.saveProfile({name: '本机称呼'});
  api.connect = async () => { store.switchAccount('onboarding-new-account'); store.clearAll(); return {openid: 'onboarding-new-account'}; };
  const welcome = page('welcome'); await welcome.login();
  assert.equal(store.getNamespace(), 'account:onboarding-new-account');
  assert.equal(store.getProfile().name, ''); assert.equal(welcome.data.error, '');
  assert.equal(navigation[0], '/pages/profile-edit/index?onboarding=1');
});

test('cached onboarded WeChat account cannot bypass fresh identity verification', async () => {
  store.switchAccount('onboarding-cached-account'); store.clearAll(); store.saveProfile({onboarded: true});
  api.connect = async () => { throw new Error('请重新连接微信'); };
  const welcome = page('welcome'); await welcome.onShow();
  assert.equal(navigation.length, 0); assert.equal(welcome.data.error, '请重新连接微信');
  api.connect = async () => ({openid: 'onboarding-cached-account'});
  await welcome.onShow(); assert.equal(navigation[0], '/pages/today/index');
});

test('legacy completed local onboarding cannot bypass WeChat login', async () => {
  store.saveProfile({onboarded: true});
  api.connect = async () => { throw new Error('must not call'); };
  const welcome = page('welcome'); await welcome.onShow();
  assert.equal(navigation.length, 0); assert.equal(welcome.data.error, '');
});

test('profile save converts numeric drafts, derives adulthood, and completes onboarding', () => {
  const edit = editor();
  edit.setData({'draft.name': ' 小微 ', 'draft.birthDate': '2000-02-29', 'draft.heightCm': '165.5', 'draft.weightKg': '52',
    'draft.bodyFatPercent': '', 'draft.exerciseHabit': '偶尔活动', 'draft.bodyNotes': '脚踝受伤', 'draft.avoidedActivities': '暂时避免跳跃', 'draft.restrictions': ['ankle']});
  edit.save(); const saved = store.getProfile();
  assert.equal(saved.name, '小微'); assert.equal(saved.adult, true); assert.equal(saved.heightCm, 165.5);
  assert.equal(saved.weightKg, 52); assert.equal(saved.bodyFatPercent, null);
  assert.equal(saved.safetyAnswered, true); assert.equal(saved.onboarded, true);
  assert.equal(saved.avoidedActivities, '暂时避免跳跃'); assert.equal(navigation[0], '/pages/today/index');
});

test('birth date alone determines age and minors can finish onboarding without a separate age answer', () => {
  const edit = editor();
  const birthDate = (Number(store.today().slice(0, 4)) - 14) + store.today().slice(4);
  edit.field({currentTarget: {dataset: {field: 'birthDate'}}, detail: {value: birthDate}});
  assert.equal(edit.data.ageText, '14 岁'); assert.equal(edit.data.draft.adult, false);
  assert.equal(edit.setAdult, undefined);
  edit.next(); edit.next(); edit.next(); edit.save();
  assert.equal(store.getProfile().birthDate, birthDate); assert.equal(store.getProfile().adult, false);
  assert.equal(store.getProfile().onboarded, true); assert.equal(navigation[0], '/pages/today/index');
});

test('clearing birth date discards stale adulthood and still permits saving', () => {
  const edit = editor();
  edit.setData({'draft.birthDate': '2000-02-29'}); edit.refreshAge(); assert.equal(edit.data.draft.adult, true);
  edit.clearBirth(); assert.equal(edit.data.ageText, ''); assert.equal(edit.data.draft.adult, false);
  edit.setData({'draft.adult': true});
  assert.equal(edit.toProfilePatch(true).adult, false);
  edit.save(); assert.equal(store.getProfile().onboarded, true); assert.equal(store.getProfile().birthDate, '');
});

test('keyboard layout reserves the footer, scrolls to input, and detaches its listener on leaving', t => {
  const original = {getWindowInfo: wx.getWindowInfo, onKeyboardHeightChange: wx.onKeyboardHeightChange, offKeyboardHeightChange: wx.offKeyboardHeightChange};
  t.after(() => Object.assign(wx, original));
  let listener, removed;
  wx.getWindowInfo = () => ({windowWidth: 375, windowHeight: 640, screenHeight: 812, safeArea: {bottom: 778}});
  wx.onKeyboardHeightChange = fn => { listener = fn; };
  wx.offKeyboardHeightChange = fn => { removed = fn; };
  const edit = editor(); assert.equal(edit.data.contentHeight, 536);
  edit.focusField({currentTarget: {dataset: {field: 'allergies'}}});
  listener({height: 260}); assert.equal(edit.data.keyboardHeight, 260); assert.equal(edit.data.contentHeight, 310);
  assert.equal(edit.data.scrollTarget, 'profile-field-allergies');
  edit.onHide(); assert.equal(edit.data.keyboardHeight, 0); assert.equal(edit.data.contentHeight, 536);
  listener({height: 200}); assert.equal(edit.data.keyboardHeight, 0);
  edit.onShow(); listener({height: 200}); assert.equal(edit.data.keyboardHeight, 200);
  edit.onHide();
  edit.onUnload(); assert.equal(removed, listener);
  listener({height: 200}); assert.equal(edit.data.keyboardHeight, 0);
});

test('invalid measurements and impossible birth date keep profile draft without onboarding', () => {
  const edit = editor(); edit.setData({'draft.heightCm': 'not-a-number'}); edit.save();
  assert.equal(store.getProfile().onboarded, false); assert(edit.data.error); assert.equal(navigation.length, 0);
  assert.equal(edit.data.scrollTarget, 'profile-error');
  edit.setData({'draft.heightCm': '', 'draft.birthDate': '2026-02-30'}); edit.save();
  assert.equal(store.getProfile().onboarded, false); assert(edit.data.error.includes('出生日期'));
});

test('storage failure never completes onboarding or leaves the editor', () => {
  const edit = editor(); edit.setData({'draft.name': '还未保存'}); failWrites = true; edit.save(); failWrites = false;
  assert(edit.data.error.includes('保存失败')); assert.equal(store.getProfile().onboarded, false);
  assert.equal(store.getProfile().name, ''); assert.equal(edit.data.draft.name, '还未保存'); assert.equal(navigation.length, 0);
});

test('opening OCR first persists draft without onboarding then refreshes confirmed information on return', () => {
  const edit = editor(); edit.setData({'draft.name': '保留草稿', 'draft.heightCm': '166', 'draft.bodyNotes': '脚踝不舒服'});
  edit.addReport(); assert.equal(store.getProfile().name, '保留草稿'); assert.equal(store.getProfile().heightCm, 166);
  assert.equal(store.getProfile().onboarded, false); assert.equal(store.getProfile().safetyAnswered, false);
  assert.equal(navigation[0], '/pages/report/index?mode=photo');
  store.saveProfile({restrictions: ['ankle']}); edit.onShow();
  assert.equal(edit.data.draft.name, '保留草稿'); assert.equal(edit.data.draft.heightCm, '166');
  assert.deepEqual(edit.data.draft.restrictions, ['ankle']);
});

test('AI summary and supported restrictions are adopted explicitly and only saved at final confirmation', async () => {
  const edit = editor(); edit.setData({'draft.bodyNotes': '脚踝受伤，暂时不要跳跃'});
  api.request = async (task, payload) => { assert.equal(task, 'summarizeProfile'); assert.equal(payload.profile.bodyNotes, '脚踝受伤，暂时不要跳跃'); return summaryResult(); };
  await edit.summarize(); assert(edit.data.candidate); assert.equal(edit.data.draft.healthSummary, ''); assert.equal(store.getProfile().healthSummary, '');
  assert.equal(edit.data.candidate.restrictionEvidence[0].label, '脚踝');
  edit.adoptSummary(); assert.equal(edit.data.candidate, null); assert(edit.data.draft.healthSummary); assert.equal(store.getProfile().healthSummary, '');
  edit.save(); assert(store.getProfile().healthSummary); assert.deepEqual(store.getProfile().restrictions, ['ankle']);
});

test('unsupported AI restriction is omitted without hiding the summary or changing existing text', async () => {
  const edit = editor(); edit.setData({'draft.bodyNotes': '我喜欢读书'});
  api.request = async () => summaryResult(); await edit.summarize();
  assert(edit.data.candidate); assert.deepEqual(edit.data.candidate.restrictions, []); assert(edit.data.aiError.includes('原文依据')); assert.equal(edit.data.draft.bodyNotes, '我喜欢读书');
  assert.deepEqual(store.getProfile().restrictions, []);
});

test('actual unavailable AI leaves all profile fields untouched', async () => {
  const edit = editor(); edit.setData({'draft.name': '自己写的资料', 'draft.allergies': '花生过敏'});
  const before = JSON.stringify(edit.data.draft); await edit.summarize();
  assert(edit.data.aiError); assert.equal(JSON.stringify(edit.data.draft), before); assert.equal(edit.data.candidate, null);
});

test('new pages contain no entity escaped expressions or visible safety confirmation switch', () => {
  ['welcome', 'profile-edit'].forEach(name => {
    const source = fs.readFileSync(path.join(root, 'pages', name, 'index.wxml'), 'utf8');
    for (const match of source.matchAll(/\{\{([\s\S]*?)\}\}/g)) {
      assert(!/&(lt|gt|amp|quot|apos);/.test(match[1]));
      assert.doesNotThrow(() => new Function('return (' + match[1] + ');'));
    }
    assert(!source.includes('safetyAnswered')); assert(!source.includes('<switch'));
    if (name === 'profile-edit') {
      assert(!source.includes('setAdult')); assert(!source.includes('adultSelected'));
      assert(!source.includes('<image')); assert(!source.includes('先这样，继续'));
    }
  });
});
