const test = require('node:test');
const assert = require('node:assert/strict');
const {connectionError} = require('../miniprogram/services/cloud-errors');

test('native activation failures retain a useful cause through the SDK wrapper', () => {
  const error = connectionError({errCode: -1, errMsg: 'cloud.callFunction:fail Error: errCode: -601034 | errMsg: no service (callId: private-trace)'});
  assert.equal(error.code, 'CLOUD_NOT_ACTIVATED');
  assert.equal(error.retryable, false);
  assert.match(error.message, /开通/);
  assert.doesNotMatch(error.message, /private-trace/);
});

test('missing binding is distinct from temporary connection failures', () => {
  assert.equal(connectionError({errCode: -601012}).code, 'CLOUD_ENV_NOT_BOUND');
  for (const cause of [undefined, null, {}, {errMsg: 'private-token-value', errCode: -1}]) {
    const error = connectionError(cause);
    assert.equal(error.code, 'CLOUD_CONNECTION_FAILED');
    assert.equal(error.retryable, true);
    assert.doesNotMatch(error.message, /private-token/);
  }
});
