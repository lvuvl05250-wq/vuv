'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const period = require('../miniprogram/services/period');
const {validateState} = require('../cloudfunctions/weihuoApi/state');
const TODAY = '2026-10-05', NOW = '2026-10-05T04:00:00.000Z';
const opts = id => ({today: TODAY, now: NOW, id: id || 'p_new'});
function record(patch) { return Object.assign({id: 'p_1', startDate: '2026-10-01', endDate: '', days: [], createdAt: NOW, updatedAt: NOW}, patch); }
function freeze(value) { Object.freeze(value); Object.values(value).forEach(item => { if (item && typeof item === 'object') freeze(item); }); return value; }

const disk = new Map();
let failWrites = false, events = [], acceptModal = true, modalHook;
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => { if (failWrites) throw new Error('disk full'); disk.set(key, JSON.parse(JSON.stringify(value))); },
  showToast: value => events.push(value.title),
  showModal: value => { if (modalHook) modalHook(value); else value.success({confirm: acceptModal}); },
  navigateTo: value => events.push(value.url), switchTab: value => events.push(value.url)
};
const store = require('../miniprogram/services/store');
const originalNow = Date.now;
test.beforeEach(() => { Date.now = () => Date.parse(NOW); failWrites = false; events = []; acceptModal = true; modalHook = null; store.useLocal(); store.clearAll(); });
test.after(() => { Date.now = originalNow; });
function page(name, query) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(__dirname, '../miniprogram/pages', name || 'period', 'index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = function (patch) { Object.assign(this.data, patch); };
  if (instance.onLoad) instance.onLoad(query || {});
  if (name !== 'profile') instance.onShow();
  return instance;
}
function setField(view, field, value) { view.field({currentTarget: {dataset: {field}}, detail: {value}}); }
function feeling(view, id) { view.toggleFeeling({currentTarget: {dataset: {id}}}); }

test('cloud and client use identical pure period rules', () => {
  assert.equal(fs.readFileSync(path.join(__dirname, '../miniprogram/services/period.js'), 'utf8'), fs.readFileSync(path.join(__dirname, '../cloudfunctions/weihuoApi/period.js'), 'utf8'));
  assert.deepEqual(period.validateRecords(undefined, TODAY), []);
  assert.throws(() => period.validateRecords(null, TODAY));
});

test('normalization is immutable, sorted and removes empty day entries without inventing feelings', () => {
  const input = freeze([record({days: [{date: '2026-10-02', feelings: [], note: '   '}, {date: '2026-10-01', feelings: ['tired', 'pain'], note: '  自己写的感受  '}]})]);
  const before = JSON.stringify(input), result = period.validateRecords(input, TODAY);
  assert.equal(JSON.stringify(input), before);
  assert.deepEqual(result[0].days, [{date: '2026-10-01', feelings: ['pain', 'tired'], note: '自己写的感受'}]);
  result[0].days[0].feelings.push('headache'); assert.equal(input[0].days[1].feelings.length, 2);
});

test('future, impossible and inverted dates cannot be saved', () => {
  for (const patch of [{startDate: '2026-10-06'}, {endDate: '2026-10-06'}, {startDate: '2026-02-30'}, {endDate: '2026-09-30'}, {startDate: 'bad'}]) {
    assert.throws(() => period.validateRecords([record(patch)], TODAY));
  }
  assert.equal(period.validateRecords([record({startDate: '2024-02-29', endDate: '2024-02-29'})], TODAY).length, 1);
});

test('overlap includes shared boundary dates and an unfinished earlier record cannot coexist with another', () => {
  const previous = record({startDate: '2026-09-01', endDate: '2026-09-05'});
  const next = record({id: 'p_2', startDate: '2026-09-05', endDate: '2026-09-09'});
  assert.throws(() => period.validateRecords([previous, next], TODAY), /重叠/);
  next.startDate = '2026-09-06'; assert.equal(period.validateRecords([next, previous], TODAY)[0].id, 'p_1');
  previous.endDate = ''; assert.throws(() => period.validateRecords([previous, next], TODAY), /结束日期/);
  next.endDate = ''; assert.throws(() => period.validateRecords([previous, next], TODAY), /结束日期/);
});

test('duplicate ids, unrecognized symptoms, excessive notes and duplicate days are rejected', () => {
  assert.throws(() => period.validateRecords([record(), record()], TODAY), /编号/);
  for (const day of [
    {date: '2026-10-02', feelings: ['diagnosis'], note: ''},
    {date: '2026-10-02', feelings: ['pain', 'pain'], note: ''},
    {date: '2026-10-02', feelings: [], note: 'x'.repeat(501)},
    {date: '2026-10-06', feelings: ['tired'], note: ''},
    {date: '2026-09-30', feelings: ['tired'], note: ''}
  ]) assert.throws(() => period.validateRecords([record({days: [day]})], TODAY));
  const day = {date: '2026-10-02', feelings: ['tired'], note: ''};
  assert.throws(() => period.validateRecords([record({days: [day, day]})], TODAY), /同一天/);
  assert.throws(() => period.validateRecords([record({publicShare: true})], TODAY), /不支持/);
});

test('editing dates cannot silently discard existing daily records and deleting a day stays explicit', () => {
  const initial = [record({endDate: '2026-10-04', days: [{date: '2026-10-04', feelings: ['tired'], note: '留下原文'}]})];
  assert.throws(() => period.upsertRecord(initial, {id: 'p_1', endDate: '2026-10-03'}, opts()), /日感受超出/);
  assert.equal(initial[0].days[0].note, '留下原文');
  const cleared = period.putDay(initial, 'p_1', '2026-10-04', [], '', opts());
  assert.equal(cleared[0].days.length, 0); assert.equal(initial[0].days.length, 1);
  assert.equal(period.upsertRecord(cleared, {id: 'p_1', endDate: '2026-10-03'}, opts())[0].endDate, '2026-10-03');
  assert.deepEqual(period.deleteRecord(cleared, 'p_1', TODAY), []);
  assert.throws(() => period.upsertRecord([], {id: 'missing'}, opts()), /不存在/);
});

test('calendar uses Monday weeks, marks actual intervals and supports leap-day months', () => {
  const cells = period.buildMonth([record({endDate: '2026-10-03'})], '2026-10', '2026-10-02', TODAY);
  assert.equal(cells.length, 42); assert.equal(cells[0].date, '2026-09-28');
  assert.equal(cells.find(c => c.date === '2026-10-01').mark, 'start');
  assert.equal(cells.find(c => c.date === '2026-10-02').mark, 'range');
  assert.equal(cells.find(c => c.date === '2026-10-02').selected, true);
  assert.equal(cells.find(c => c.date === '2026-10-03').mark, 'end');
  assert.equal(cells.find(c => c.date === '2026-10-06').future, true);
  assert.equal(period.buildMonth([], '2024-02', '', TODAY).filter(c => c.inMonth).length, 29);
  assert.equal(period.shiftMonth('2026-01', -1), '2025-12'); assert.equal(period.shiftMonth('2026-12', 1), '2027-01');
});

test('unknown end dates never become predicted flow and context contains no free-text note', () => {
  const records = [record({days: [{date: '2026-10-03', feelings: ['tired'], note: '不向模型发送的个人备注'}]})];
  const cells = period.buildMonth(records, '2026-10', TODAY, TODAY);
  assert.equal(cells.find(c => c.date === '2026-10-02').mark, '');
  assert.equal(cells.find(c => c.date === '2026-10-03').mark, 'noted');
  assert.equal(cells.find(c => c.date === '2026-10-05').mark, '');
  assert.equal(cells.find(c => c.date === '2026-10-06').recordId, '');
  assert.deepEqual(period.getContext(records, '2026-10-03', TODAY), {date: '2026-10-03', periodRecorded: false, feelings: ['tired']});
  assert.equal(period.getContext(records, '2026-10-01', TODAY).periodRecorded, true);
  assert.equal(period.buildMonth([record({endDate: '2026-10-01'})], '2026-10', '', TODAY).find(c => c.date === '2026-10-01').mark, 'both');
});

test('state migration, private export, restore and clear retain or delete real period records', () => {
  const legacy = store.getState(); delete legacy.periodRecords;
  assert.deepEqual(store.validate(legacy).periodRecords, []); assert.deepEqual(validateState(legacy).periodRecords, []);
  store.replacePeriodRecords([record()], []);
  assert.equal(validateState(store.getState()).periodRecords[0].startDate, '2026-10-01');
  const backup = store.exportData(); store.clearAll(); assert.deepEqual(store.getPeriodRecords(), []);
  store.restoreData(backup); assert.equal(store.getPeriodRecords().length, 1);
  const malformed = store.getState(); malformed.periodRecords[0].endDate = '2026-10-06';
  assert.throws(() => validateState(malformed), e => e.code === 'INVALID_ARGUMENT');
});

test('store compare-and-swap rejects stale replacement and a failed disk write changes neither memory nor disk', () => {
  store.replacePeriodRecords([record()], []);
  const before = store.getPeriodRecords(), diskBefore = store.exportRaw();
  assert.throws(() => store.replacePeriodRecords([], []), /变化/);
  const next = period.upsertRecord(before, {id: 'p_1', endDate: '2026-10-04'}, opts());
  failWrites = true; assert.throws(() => store.replacePeriodRecords(next, before), /保存失败/); failWrites = false;
  assert.deepEqual(store.getPeriodRecords(), before); assert.equal(store.exportRaw(), diskBefore);
});

test('page creates, closes and edits a real record with feelings and can undo deletion', async () => {
  const view = page('period', {date: '2026-10-01'}); assert.equal(store.getPeriodRecords().length, 0);
  view.markStart(); assert.equal(store.getPeriodRecords().length, 1); assert.equal(store.getPeriodRecords()[0].days.length, 0);
  await view.selectDate('2026-10-03'); feeling(view, 'tired'); setField(view, 'note', '比平时累一些'); view.markEnd();
  assert.equal(store.getPeriodRecords()[0].endDate, '2026-10-03'); assert.equal(store.getPeriodRecords()[0].days[0].note, '比平时累一些');
  setField(view, 'editStart', '2026-10-02'); view.save(); assert.equal(store.getPeriodRecords()[0].startDate, '2026-10-02');
  await view.undo(); assert.equal(store.getPeriodRecords()[0].startDate, '2026-10-01'); assert.equal(view.data.canUndo, false);
  await view.deleteCurrent(); assert.equal(store.getPeriodRecords().length, 0); assert.equal(view.data.canUndo, true);
  await view.undo(); assert.equal(store.getPeriodRecords()[0].days[0].note, '比平时累一些');
});

test('future edits and storage failures preserve the draft without reporting success', () => {
  const view = page('period', {date: '2026-10-01'});
  failWrites = true; view.markStart(); failWrites = false;
  assert.equal(store.getPeriodRecords().length, 0); assert.equal(view.data.canUndo, false); assert.match(view.data.error, /保存失败/); assert.equal(events.length, 0);
  view.markStart(); const before = store.getPeriodRecords(), count = events.length;
  setField(view, 'editEnd', '2026-10-06'); view.save();
  assert.deepEqual(store.getPeriodRecords(), before); assert.equal(view.data.editEnd, '2026-10-06'); assert.equal(view.data.dirty, true);
  assert.match(view.data.error, /未来/); assert.equal(events.length, count); assert.equal(view.data.saving, false);
});

test('canceling date selection retains unsaved feelings, clearing a day is explicit and saved only on confirmation', async () => {
  const view = page('period', {date: '2026-10-01'}); view.markStart(); feeling(view, 'pain'); setField(view, 'note', '草稿');
  acceptModal = false; await view.selectDate('2026-10-02'); assert.equal(view.data.selectedDate, '2026-10-01'); assert.equal(view.data.note, '草稿');
  assert.equal(store.getPeriodRecords()[0].days.length, 0);
  view.save(); assert.equal(store.getPeriodRecords()[0].days.length, 1);
  view.clearDay(); assert.equal(store.getPeriodRecords()[0].days.length, 1); assert.equal(view.data.dirty, true);
  view.save(); assert.equal(store.getPeriodRecords()[0].days.length, 0);
});

test('undo refuses to overwrite a more recent modification', async () => {
  const view = page('period', {date: '2026-10-01'}); view.markStart();
  const before = store.getPeriodRecords();
  const next = period.upsertRecord(before, {id: before[0].id, endDate: '2026-10-04'}, opts());
  store.replacePeriodRecords(next, before); const eventCount = events.length;
  await view.undo(); assert.equal(store.getPeriodRecords()[0].endDate, '2026-10-04'); assert.match(view.data.error, /变化/);
  assert.equal(events.length, eventCount);
});

test('account change during delete confirmation cannot delete either account and returning clears undo', async () => {
  const view = page('period', {date: '2026-10-01'}); view.markStart();
  let pending;
  modalHook = value => { pending = value; };
  const work = view.deleteCurrent(); assert.equal(view.data.confirming, true);
  store.switchAccount('period-other-account'); store.clearAll(); pending.success({confirm: true}); await work;
  assert.deepEqual(store.getPeriodRecords(), []); assert.match(view.data.error, /账号已变化/);
  view.onShow(); assert.equal(view.data.canUndo, false); assert.equal(view.data.currentId, '');
  store.useLocal(); assert.equal(store.getPeriodRecords().length, 1);
});

test('unloaded pages cannot apply delayed destructive confirmations', async () => {
  const view = page('period', {date: '2026-10-01'}); view.markStart();
  let pending; modalHook = value => { pending = value; };
  const work = view.deleteCurrent(); view.onUnload(); pending.success({confirm: true}); await work;
  assert.equal(store.getPeriodRecords().length, 1); assert.equal(view._undo, null);
});

test('return to today resets a browsed month even when today remains selected', async () => {
  const view = page(); assert.equal(view.data.selectedDate, TODAY);
  view.moveMonth({currentTarget: {dataset: {delta: -1}}}); assert.equal(view.data.month, '2026-09');
  await view.today(); assert.equal(view.data.month, '2026-10'); assert.equal(view.data.selectedDate, TODAY);
  view.moveMonth({currentTarget: {dataset: {delta: 1}}}); assert.equal(view.data.month, '2026-11');
});

test('unloading while deciding to discard a draft prevents delayed undo', async () => {
  const view = page('period', {date: '2026-10-01'}); view.markStart(); feeling(view, 'tired');
  let pending; modalHook = value => { pending = value; };
  const work = view.undo(); view.onUnload(); pending.success({confirm: true}); await work;
  assert.equal(store.getPeriodRecords().length, 1);
});

test('period remains optional, archive stays reachable, and settings opens companion choice', () => {
  const settings = page('profile');
  assert.equal(settings.data.rows.some(row => row.id === 'period'), false);
  settings.open({currentTarget: {dataset: {id: 'companion'}}});
  assert.equal(events[0], '/pages/settings/index?section=companion');
  settings.archive();
  assert.equal(events[1], '/pages/archive/index');
  const profileSource = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/profile/index.wxml'), 'utf8');
  assert.match(profileSource, /bindtap="archive"/);
  const source = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/period/index.wxml'), 'utf8');
  for (const match of source.matchAll(/\{\{([\s\S]*?)\}\}/g)) {
    assert(!/&(lt|gt|amp|quot|apos);/.test(match[1])); assert.doesNotThrow(() => new Function('return (' + match[1] + ');'));
  }
  const view = page();
  for (const match of source.matchAll(/bind(?:tap|change|input)="([A-Za-z]+)"/g)) assert.equal(typeof view[match[1]], 'function');
});

test('period screen puts the actual calendar and selected date before estimate settings', () => {
  const source = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/period/index.wxml'), 'utf8');
  const title = source.indexOf('class="page-title period-title"');
  const calendar = source.indexOf('class="calendar section"');
  const selection = source.indexOf('class="section selection-card"');
  const estimate = source.indexOf('class="forecast-card section"');
  const settings = source.indexOf('wx:if="{{settingsOpen}}" class="period-settings"');
  assert(title >= 0 && title < calendar);
  assert(calendar < selection && selection < estimate && estimate < settings);
  assert.doesNotMatch(source, /实际记录与下次估计/);
});
