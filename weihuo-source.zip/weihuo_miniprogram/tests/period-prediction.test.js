'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),path=require('node:path');
const period=require('../miniprogram/services/period');
const {validateState}=require('../cloudfunctions/weihuoApi/state');
const TODAY='2026-10-05',NOW='2026-10-05T04:00:00.000Z';
const config=(patch={})=>Object.assign({predictionMode:'history',cycleLengthDays:28,periodLengthDays:5,configured:false},patch);
const record=(id,startDate,endDate='')=>({id,startDate,endDate,days:[],createdAt:NOW,updatedAt:NOW});
const history=()=>[record('p_a','2026-08-01','2026-08-05'),record('p_b','2026-08-29','2026-09-03'),record('p_c','2026-09-28','2026-10-03')];
const disk=new Map();let events=[],failWrites=false,calendarCalls=[],calendarReply,modalReply;
global.wx={getStorageSync:key=>disk.get(key),setStorageSync:(key,value)=>{if(failWrites)throw Error('disk full');disk.set(key,structuredClone(value));},showToast:options=>events.push(options.title),showModal:options=>{if(modalReply)modalReply(options);else if(options.success)options.success({confirm:true});},addPhoneCalendar:options=>{calendarCalls.push(options);if(calendarReply)calendarReply(options);else options.success();}};
const store=require('../miniprogram/services/store'),realNow=Date.now;
test.beforeEach(()=>{Date.now=()=>Date.parse(NOW);failWrites=false;events=[];calendarCalls=[];calendarReply=null;modalReply=null;disk.clear();store.useLocal();store.clearAll();delete require.cache[require.resolve('../miniprogram/services/calendar-reminder')];});
test.after(()=>{Date.now=realNow;});
function page(){let definition;global.Page=value=>{definition=value;};const file=path.join(__dirname,'../miniprogram/pages/period/index.js');delete require.cache[require.resolve(file)];require(file);const view={...definition,data:structuredClone(definition.data),setData(patch){Object.assign(this.data,patch);}};view.onLoad({});view.onShow();return view;}
function settingsField(view,field,value){view.settingsField({currentTarget:{dataset:{field}},detail:{value}});}
function reminderField(view,field,value){view.reminderField({currentTarget:{dataset:{field}},detail:{value}});}
function put(records){store.replacePeriodRecords(records,store.getPeriodRecords());}

test('settings have explicit mutable-copy defaults and reject malformed values',()=>{
 const defaults=period.validateSettings();assert.deepEqual(defaults,config());defaults.cycleLengthDays=30;assert.equal(period.validateSettings().cycleLengthDays,28);
 for(const bad of [null,[],{cycleLengthDays:'28'},{cycleLengthDays:0},{cycleLengthDays:365.5},{cycleLengthDays:366},{periodLengthDays:0},{periodLengthDays:91},{cycleLengthDays:5,periodLengthDays:6},{configured:'yes'},{predictionMode:'fertility'},{public:true}])assert.throws(()=>period.validateSettings(bad));
});

test('no real start creates no predicted date; one interval uses clearly identified fallback settings',()=>{
 assert.equal(period.estimateNext([],config(),TODAY).status,'no-records');
 const one=period.estimateNext([record('p_1','2026-10-01')],config(),TODAY);
 assert.equal(one.startDate,'2026-10-29');assert.equal(one.endDate,'2026-11-02');assert.equal(one.cycleSource,'default');assert.equal(one.periodSource,'default');
 const two=period.estimateNext(history().slice(1),config({cycleLengthDays:27,configured:true}),TODAY);
 assert.equal(two.intervalCount,1);assert.equal(two.cycleLengthDays,27);assert.equal(two.cycleSource,'manual');assert.equal(two.startDate,'2026-10-25');
});

test('two real start intervals and completed durations use rounded medians with inclusive end dates',()=>{
 const input=history(),before=structuredClone(input),estimate=period.estimateNext(input,config(),TODAY);
 assert.equal(estimate.cycleLengthDays,29);assert.equal(estimate.periodLengthDays,6);assert.equal(estimate.startDate,'2026-10-27');assert.equal(estimate.endDate,'2026-11-01');
 assert.equal(estimate.cycleSource,'history');assert.equal(estimate.periodSource,'history');assert.equal(estimate.intervalCount,2);assert.equal(estimate.durationCount,3);
 assert.deepEqual(input,before);
});

test('history uses at most the latest six real intervals and unfinished records do not invent a duration',()=>{
 let start='2025-10-01';const records=[record('p_0',start,period.addDateDays(start,3))];
 [120,28,28,29,30,31,32].forEach((days,index)=>{start=period.addDateDays(start,days);records.push(record('p_'+(index+1),start,index===6?'':period.addDateDays(start,3)));});
 const result=period.estimateNext(records,config(),TODAY);
 assert.equal(result.intervalCount,6);assert.equal(result.cycleLengthDays,30);assert.equal(result.periodLengthDays,4);assert.equal(result.durationCount,6);
 assert.equal(records[records.length-1].endDate,'');
});

test('manual mode overrides history, while missing end dates keep the duration fallback explicit',()=>{
 const manual=period.estimateNext(history(),config({predictionMode:'manual',cycleLengthDays:26,periodLengthDays:4,configured:true}),TODAY);
 assert.equal(manual.startDate,'2026-10-24');assert.equal(manual.endDate,'2026-10-27');assert.equal(manual.cycleSource,'manual');assert.equal(manual.periodSource,'manual');
 const open=period.estimateNext([record('p_open','2026-10-01')],config({periodLengthDays:7,configured:true}),TODAY);
 assert.equal(open.periodLengthDays,7);assert.equal(open.durationCount,0);assert.equal(open.periodSource,'manual');
});

test('an expired estimate stays anchored to the last actual start and never rolls into another predicted cycle',()=>{
 const records=[record('p_old','2026-07-01','2026-07-05')],before=structuredClone(records);
 const now=period.estimateNext(records,config(),TODAY),later=period.estimateNext(records,config(),'2027-01-01');
 assert.equal(now.startDate,'2026-07-29');assert.equal(now.status,'past-estimate');assert.equal(later.startDate,now.startDate);assert.equal(later.endDate,now.endDate);assert.deepEqual(records,before);
});

test('month cells keep prediction and actual marks separate, including across months and leap days',()=>{
 const records=history(),cells=period.buildMonth(records,'2026-10',TODAY,TODAY,config());
 const actual=cells.find(day=>day.date==='2026-10-03'),prediction=cells.find(day=>day.date==='2026-10-27');
 assert.equal(actual.mark,'end');assert.equal(actual.predicted,false);assert.equal(prediction.mark,'');assert.equal(prediction.recordId,'');assert.equal(prediction.predicted,true);assert.equal(prediction.future,true);
 assert.match(prediction.accessibility,/未记为实际/);
 assert.equal(period.buildMonth(records,'2026-11','',TODAY,config()).find(day=>day.date==='2026-11-01').predicted,true);
 assert.equal(period.estimateNext([record('p_leap','2024-02-01','2024-02-05')],config(),'2024-02-10').startDate,'2024-02-29');
});

test('an estimate conflicting with confirmed real dates is suppressed without altering the real record',()=>{
 const actual=[record('p_long','2026-08-01','2026-09-10')],before=structuredClone(actual);
 const result=period.estimateNext(actual,config(),TODAY);assert.equal(result.status,'conflict');assert.equal(result.startDate,'');assert.deepEqual(actual,before);
});

test('recording a new actual start corrects the forecast and undo restores the previous estimate',async()=>{
 put([record('p_old','2026-09-01','2026-09-05')]);const view=page();assert.equal(view.data.forecast.startDate,'2026-09-29');
 view.markStart();assert.equal(store.getPeriodRecords().length,2);assert.equal(view.data.forecast.lastStartDate,TODAY);assert.equal(view.data.forecast.startDate,'2026-11-02');
 await view.undo();assert.equal(store.getPeriodRecords().length,1);assert.equal(view.data.forecast.startDate,'2026-09-29');
});

test('future prediction selection is read-only and opening or browsing never creates records',async()=>{
 put([record('p_view','2026-10-01','2026-10-04')]);const before=store.exportRaw(),view=page();view.showForecast();await view.selectDate('2026-10-29');
 assert.equal(view.data.selectedFuture,true);assert.equal(view.data.currentId,'');view.markStart();assert.match(view.data.error,/未来/);assert.equal(store.exportRaw(),before);assert.equal(calendarCalls.length,0);
});

test('saved period settings update the forecast without changing actual dates or requesting calendar permission',()=>{
 put(history());const before=store.getPeriodRecords(),view=page();view.settingsMode({currentTarget:{dataset:{value:'manual'}}});
 settingsField(view,'cycleLengthDays','31');settingsField(view,'periodLengthDays','4');assert.equal(view.data.forecast.startDate,'2026-10-27');view.saveSettings();
 assert.equal(store.getPeriodSettings().configured,true);assert.equal(view.data.forecast.startDate,'2026-10-29');assert.equal(view.data.settingsDirty,false);assert.deepEqual(store.getPeriodRecords(),before);assert.equal(calendarCalls.length,0);
 const validated=validateState(store.getState());assert.equal(validated.periodSettings.cycleLengthDays,31);
 const backup=store.exportData();store.clearAll();store.restoreData(backup);assert.equal(store.getPeriodSettings().cycleLengthDays,31);
});

test('invalid or failed settings writes preserve the editable values, current forecast and disk state',()=>{
 put(history());const view=page(),before=store.exportRaw(),initial=view.data.forecast.startDate;
 settingsField(view,'cycleLengthDays','');view.saveSettings();assert(view.data.settingsError);assert.equal(view.data.settingsDirty,true);assert.equal(store.exportRaw(),before);
 settingsField(view,'cycleLengthDays','30');failWrites=true;view.saveSettings();failWrites=false;
 assert.match(view.data.settingsError,/保存失败/);assert.equal(view.data.settingsDraft.cycleLengthDays,'30');assert.equal(view.data.forecast.startDate,initial);assert.equal(store.exportRaw(),before);assert.equal(events.length,0);
});

test('explicit reminder click is the only calendar call, with a neutral title and no profile or period payload',async()=>{
 put([record('p_private','2026-10-01','2026-10-04')]);const view=page();view.toggleReminder();assert.equal(calendarCalls.length,0);
 await view.addReminder();assert.equal(calendarCalls.length,1);const input=calendarCalls[0];assert.equal(input.title,'微活 · 查看自己的记录');
 assert.equal(typeof input.startTime,'number');assert.equal(input.alarm,true);assert.equal(input.alarmOffset,0);assert(!('key' in input));assert(!('description' in input));
 assert(!/经期|疼痛|period|profile|feelings/.test(JSON.stringify(input)));assert.match(view.data.reminderAdded,/2026-10-29/);assert(events.some(message=>/手机日历/.test(message)));
 assert(!events.some(message=>/微信推送|一定响/.test(message)));
});

test('calendar refusal and a past time preserve the selections and do not report success',async()=>{
 put([record('p_deny','2026-10-01','2026-10-04')]);const view=page();calendarReply=options=>options.fail({errMsg:'addPhoneCalendar:fail auth deny'});
 reminderField(view,'reminderTime','10:30');await view.addReminder();assert.match(view.data.reminderError,/允许日历权限/);assert.equal(view.data.reminderAdded,'');assert.equal(view.data.reminderTime,'10:30');assert.equal(events.length,0);
 reminderField(view,'reminderDate','2026-10-01');await view.addReminder();assert.match(view.data.reminderError,/已经过去/);assert.equal(calendarCalls.length,1);
});

test('pending and repeated identical reminder clicks are deduplicated, but changes require confirmation',async()=>{
 put([record('p_mutex','2026-10-01','2026-10-04')]);const view=page();let pending;calendarReply=options=>{pending=options;};
 const first=view.addReminder();await view.addReminder();assert.equal(calendarCalls.length,1);assert.equal(view.data.reminderBusy,true);pending.success();await first;
 await view.addReminder();assert.equal(calendarCalls.length,1);reminderField(view,'reminderTime','10:30');modalReply=options=>options.success({confirm:false});
 await view.addReminder();assert.equal(calendarCalls.length,1);assert.equal(view.data.reminderBusy,false);
});

test('account changes during reminder confirmation prevent another calendar request',async()=>{
 put([record('p_account','2026-10-01','2026-10-04')]);const view=page();await view.addReminder();assert.equal(calendarCalls.length,1);
 reminderField(view,'reminderTime','10:30');let confirmation;modalReply=options=>{confirmation=options;};
 const pending=view.addReminder();store.switchAccount('period_different_account');confirmation.success({confirm:true});await pending;
 assert.equal(calendarCalls.length,1);view.onShow();assert.equal(view.data.reminderAdded,'');assert.equal(view.data.forecast.startDate,'');
});

test('a changed actual record invalidates a pending reminder decision without creating a fake plan',async()=>{
 put([record('p_changed','2026-10-01','2026-10-04')]);const view=page();await view.addReminder();reminderField(view,'reminderTime','11:00');let confirmation;modalReply=options=>{confirmation=options;};
 const pending=view.addReminder();store.savePeriodSettings(config({predictionMode:'manual',cycleLengthDays:30,configured:true}));confirmation.success({confirm:true});await pending;
 assert.equal(calendarCalls.length,1);assert.match(view.data.reminderError,/估计日期已变化/);assert.equal(store.getPlans().length,0);
});


test('a feeling on an estimated day is not silently treated as confirmed bleeding',()=>{
 const open=record('p_feeling','2026-07-01');open.days=[{date:'2026-07-29',feelings:['tired'],note:'仅记录感受'}];
 const cell=period.buildMonth([open],'2026-07','',TODAY,config()).find(day=>day.date==='2026-07-29');
 assert.equal(cell.mark,'noted');assert.equal(cell.predicted,true);assert.equal(cell.hasFeelings,true);
 assert.equal(period.getContext([open],'2026-07-29',TODAY).periodRecorded,false);
});
