'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const {validateState}=require('../cloudfunctions/weihuoApi/state');

test('real client records round-trip through the cloud schema after removing device-only fields',()=>{
  const saved=new Map();const oldWx=global.wx;
  global.wx={getStorageSync:key=>saved.get(key),setStorageSync:(key,value)=>saved.set(key,structuredClone(value))};
  try{
    const store=require('../miniprogram/services/store');
    const {stripLocal}=require('../miniprogram/services/api');
    store.init();store.saveProfile({adult:true,safetyAnswered:true,onboarded:true});
    store.saveSettings({cloudConsent:true});
    const personal=store.saveCustomAction({title:'安静听一会儿',durationMinutes:3,steps:['坐在舒服的位置'],kind:'care',category:'meditation',audio:{url:'https://media.example.test/listen.mp3',durationSeconds:180,transcript:'给自己留一点安静。'}});
    const day=store.today();store.saveDay({carePreference:70,scene:'classroom'});
    const action=store.addAction({title:'停下来记录',durationMinutes:3,steps:['记录当下感受'],kind:'care',source:'manual'});
    store.setActionStatus(action.id,'completed','comfortable');
    store.saveMeal({name:'手动记录午餐',photoPath:'wxfile://local-meal'});
    store.saveReport({title:'待核对报告',photoPath:'wxfile://local-report',metrics:[{name:'',value:'',unit:'',reference:''}],confirmed:false});
    store.savePlan({title:'三天安排',type:'life',goal:'休息与记录',source:'manual',days:[{date:day,title:'今天休息',minutes:0,details:'按身体感受决定。',done:false,actionIds:[personal.id]}],note:'手动安排'});
    store.sealTicket(day,'今天的一页');
    const pending=store.addAction({title:'稍后再做',durationMinutes:2,steps:[],kind:'care',source:'manual'});
    store.saveActionTimer(pending.id,{running:true,startedAt:Date.now(),elapsedSeconds:2,durationSeconds:120,mode:'full'});
    const personalRecord=store.addAction(personal.id);
    const clean=stripLocal(store.getState());
    const cloud=validateState(clean);assert.equal(cloud.days[day].carePreference,70);
    assert.deepEqual(cloud.customActions[0],personal);assert.deepEqual(cloud.plans[0].days[0].actionIds,[personal.id]);
    const restoredRecord=cloud.days[day].actions.find(a=>a.id===personalRecord.id);assert.equal(restoredRecord.category,'meditation');assert.deepEqual(restoredRecord.audio,personal.audio);
    assert.equal(cloud.meals[0].photoPath,'');assert.equal(cloud.reports[0].photoPath,'');
    assert.equal(cloud.tickets[0].meals[0].photoPath,'');assert.equal(Object.hasOwn(cloud.days[day].actions[1],'timer'),false);
    store.validate(cloud);
    const own=store.getState();assert.equal(own.meals[0].photoPath,'wxfile://local-meal');assert.equal(own.days[day].actions[1].timer.running,true);
  }finally{global.wx=oldWx;}
});
