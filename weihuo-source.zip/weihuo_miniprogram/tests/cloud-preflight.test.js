'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {parseConfiguration,initializeConfiguration,readConfiguration,configurationStatus,syntheticReport,probe}=require('../cloudfunctions/tools/ai-preflight');
const v=require('../cloudfunctions/weihuoApi/validation');

const env={WEIHUO_AI_ENDPOINT:'https://example.test/v1/chat/completions',WEIHUO_AI_API_KEY:'synthetic-test-key',WEIHUO_AI_MODEL:'test-text',WEIHUO_AI_VISION_MODEL:'test-vision'};
function response(result){return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify(result)},finish_reason:'stop'}]}));}

test('server configuration parsing does not execute shell text and rejects duplicates or unknown fields',()=>{
  const parsed=parseConfiguration('# comment\nWEIHUO_AI_API_KEY="$(not-a-command)"\nWEIHUO_AI_MODEL=test-text\n');
  assert.equal(parsed.WEIHUO_AI_API_KEY,'$(not-a-command)');
  for(const text of ['OTHER_SECRET=value','WEIHUO_AI_MODEL=a\nWEIHUO_AI_MODEL=b','WEIHUO_AI_API_KEY="line\\nline"','WEIHUO_AI_MODEL="unterminated'])assert.throws(()=>parseConfiguration(text),e=>e.code==='CONFIG_INVALID');
  const status=configurationStatus(env);assert.equal(status.textConfigured,true);assert.equal(status.visionConfigured,true);
  assert.equal(JSON.stringify(status).includes('synthetic-test-key'),false);
});

test('configuration initialization requires gitignore, uses 0600 and never overwrites an existing file',()=>{
  const filename=path.resolve(__dirname,'../cloudfunctions/.env.preflight-test-'+process.pid);
  try{
    assert.equal(initializeConfiguration(filename).mode,'0600');
    assert.equal(fs.statSync(filename).mode&0o777,0o600);
    assert.equal(configurationStatus(readConfiguration(filename)).textConfigured,false);
    assert.throws(()=>initializeConfiguration(filename),e=>e.code==='CONFIG_ALREADY_EXISTS');
    fs.chmodSync(filename,0o644);assert.throws(()=>readConfiguration(filename),e=>e.code==='CONFIG_PERMISSIONS');
    assert.throws(()=>initializeConfiguration(path.resolve(__dirname,'unexpected-secret.txt')),e=>e.code==='CONFIG_NOT_IGNORED');
  }finally{if(fs.existsSync(filename))fs.unlinkSync(filename);}
});

test('synthetic OCR image is a bounded valid PNG with no private record input',()=>{
  const bytes=syntheticReport();assert.equal(bytes.readUInt32BE(16),640);assert.equal(bytes.readUInt32BE(20),200);
  assert.ok(bytes.length<512*1024);assert.equal(v.image({imageBase64:bytes.toString('base64'),mimeType:'image/png'}).mimeType,'image/png');
});

test('preflight executes the production provider and task validators for text and vision',async()=>{
  const sent=[];
  const result=await probe(env,{fetchImpl:async(_url,options)=>{
    const body=JSON.parse(options.body);sent.push(body);
    return body.model==='test-text'?response({energy:3,scene:'office',minutes:5,mood:'平静',note:'明确填写'}):response({metrics:[{name:'MARKER',value:'42',unit:'MG',reference:''}],note:'合成文字清晰'});
  }});
  assert.equal(result.text.ok,true);assert.equal(result.vision.ok,true);
  assert.equal(sent.length,2);assert.equal(sent[0].response_format.type,'json_object');
  assert.equal(sent[1].messages[1].content[1].image_url.url,'data:image/png;base64,'+syntheticReport().toString('base64'));
  assert.equal(JSON.stringify(result).includes('synthetic-test-key'),false);
});

test('a valid JSON response is insufficient when the model failed to read the synthetic content',async()=>{
  const result=await probe(env,{roles:['vision'],fetchImpl:async()=>response({metrics:[{name:'MARKER',value:'99',unit:'MG',reference:''}],note:''})});
  assert.equal(result.vision.ok,false);assert.equal(result.vision.code,'PROBE_CONTENT_MISMATCH');
  const invalid=await probe(env,{roles:['text'],fetchImpl:async()=>response({energy:3,scene:'office',minutes:5,mood:'',note:'',extra:true})});
  assert.equal(invalid.text.ok,true); // Extra model fields do not discard usable content.
  assert.equal(invalid.text.code,undefined);
});

test('authentication failure is explicit and cannot leak an upstream error body',async()=>{
  const result=await probe(env,{roles:['text'],fetchImpl:async()=>new Response('private upstream details and synthetic-test-key',{status:401})});
  assert.equal(result.text.ok,false);assert.equal(result.text.code,'PROVIDER_AUTH_FAILED');
  assert.equal(JSON.stringify(result).includes('private upstream'),false);
});
