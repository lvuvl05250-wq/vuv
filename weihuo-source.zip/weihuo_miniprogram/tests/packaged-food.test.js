'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const backend = require('../cloudfunctions/weihuoApi/food-label');
const label = require('../miniprogram/pages/meal-edit/food-label');
const text = '营养成分表 每100克\n能量 836.8 kJ\n蛋白质 8 g\n碳水化合物 30 g\n脂肪 4 g\n配料：燕麦、牛奶';
function result(patch) {
  return Object.assign({ name: '燕麦食品', ingredients: '燕麦、牛奶', servingBasis: 'per100g', servingSize: '', energyValue: 836.8, energyUnit: 'kJ', protein: 8, carbs: 30, fat: 4, flags: [], uncertainFields: [], evidence: { servingBasis: '每100克', energyValue: '能量 836.8 kJ', protein: '蛋白质 8 g', carbs: '碳水化合物 30 g', fat: '脂肪 4 g' } }, patch);
}
function valid(value) { return backend.validateResult(backend.prepare({consent: true, text}).data, value); }
function image() { return { mimeType: 'image/jpeg', imageBase64: Buffer.from([255,216,255,224,0,16,74,70,73,70,0,1]).toString('base64') }; }

test('label input requires consent and label evidence, never just a product name', () => {
  assert.throws(() => backend.prepare({name: '饼干', text}), error => error.code === 'AI_CONSENT_REQUIRED');
  assert.throws(() => backend.prepare({consent: true, name: '饼干'}), error => error.code === 'INVALID_ARGUMENT');
  assert.equal(backend.prepare({consent: true, text}).data.hasImages, false);
});

test('one or two actual image payloads are accepted, malformed and excess payloads rejected', () => {
  const prepared = backend.prepare({consent: true, images: [image(), image()]});
  assert.equal(prepared.images.length, 2);
  assert.equal(prepared.data.hasImages, true);
  assert.equal(backend.prepare(Object.assign({consent: true}, image())).images.length, 1);
  assert.throws(() => backend.prepare({consent: true, images: [image(), image(), image()]}));
  assert.throws(() => backend.prepare(Object.assign({consent: true, images: [image()]}, image())));
  assert.throws(() => backend.prepare({consent: true, images: [{mimeType: 'image/jpeg', imageBase64: 'not-an-image'}]}));
  assert.throws(() => backend.prepare({consent: true, images: [{}]}));
  assert.throws(() => backend.prepare({consent: true, text, apiKey: 'forbidden-field'}));
  const messages = backend.messagesFor(prepared.data, prepared.images);
  assert.equal(messages[1].content.filter(part => part.type === 'image_url').length, 2);
  assert.match(messages[0].content, /禁止从配料顺序、食物名称或宏量营养推导热量/);
});

test('label result preserves original kJ values and transcription evidence without calculating calories', () => {
  assert.deepEqual(valid(result()), result());
  assert.equal(Object.prototype.hasOwnProperty.call(valid(result()), 'kcal'), false);
});

test('ingredient-only input cannot justify invented energy or macro values', () => {
  const input = backend.prepare({consent: true, text: '配料：燕麦、牛奶'}).data;
  assert.throws(() => backend.validateResult(input, result()), error => error.code === 'PROVIDER_INVALID_RESPONSE');
  const unknown = result({servingBasis: 'unknown', energyValue: null, energyUnit: null, protein: null, carbs: null, fat: null, evidence: {}, flags: ['没有看到营养表']});
  const accepted = backend.validateResult(input, unknown);
  for (const key of ['energyValue', 'protein', 'carbs', 'fat']) assert.equal(accepted[key], null);
});

test('unclear, unsupported, threshold and NRV-only label numbers fail closed', () => {
  for (const bad of [
    result({evidence: {}}), result({energyValue: 100}), result({energyUnit: null}),
    result({energyUnit: 'kcal'}), result({protein: 0, uncertainFields: ['protein']}),
    result({protein: -1}), result({fat: '4'}), result({servingBasis: 'perServing'}),
    result({uncertainFields: ['invented-field']}), result({kcal: 200})
  ]) assert.throws(() => valid(bad), error => error.code === 'PROVIDER_INVALID_RESPONSE');
  const threshold = result({protein: 0.5, evidence: Object.assign({}, result().evidence, {protein: '蛋白质 <0.5 g'})});
  assert.throws(() => backend.validateResult({hasImages: true}, threshold));
  const nrv = result({protein: 13, evidence: Object.assign({}, result().evidence, {protein: '蛋白质 NRV 13%'})});
  assert.throws(() => backend.validateResult({hasImages: true}, nrv));
  const mixedNrv = result({protein: 13, evidence: Object.assign({}, result().evidence, {protein: '蛋白质 8 g NRV 13%'})});
  assert.throws(() => backend.validateResult({hasImages: true}, mixedNrv));
});

test('per100g kJ converts only after an explicit actual quantity, and preserves original values', () => {
  const converted = label.confirm(Object.assign(label.form(result()), {actualQuantity: '50'}), '燕麦食品');
  assert.deepEqual(converted.nutrition, {kcal: 100, protein: 4, carbs: 15, fat: 2});
  assert.equal(converted.label.energyValue, 836.8);
  assert.equal(converted.label.energyUnit, 'kJ');
  assert.equal(converted.label.actualQuantity, 50);
  assert.equal(converted.label.actualUnit, 'g');
  assert.equal(converted.label.source, 'label');
});

test('per100ml and perServing use distinct actual units rather than guessing density or pack size', () => {
  const liquid = label.confirm(Object.assign(label.form(result()), {servingBasis: 'per100ml', actualQuantity: '250'}));
  assert.equal(liquid.nutrition.kcal, 500);
  assert.equal(liquid.label.actualUnit, 'ml');
  const serving = label.confirm(Object.assign(label.form(result()), {servingBasis: 'perServing', servingSize: '每份30克', energyValue: '120', energyUnit: 'kcal', actualQuantity: '0.5'}));
  assert.equal(serving.nutrition.kcal, 60);
  assert.equal(serving.label.actualUnit, 'serving');
  assert.equal(serving.label.servingSize, '每份30克');
});

test('missing quantity or basis cannot become a full-package assumption; zero remains a known zero', () => {
  const missing = label.confirm(label.form(result()));
  assert.equal(missing.label.actualQuantity, null);
  assert.deepEqual(missing.nutrition, {kcal: null, protein: null, carbs: null, fat: null});
  const unknown = label.confirm(Object.assign(label.form(result()), {servingBasis: 'unknown'}));
  assert.equal(unknown.label.actualUnit, '');
  assert.equal(unknown.nutrition.kcal, null);
  assert.throws(() => label.confirm(Object.assign(label.form(result()), {servingBasis: 'unknown', actualQuantity: '50'})));
  assert.equal(label.confirm(Object.assign(label.form(result()), {actualQuantity: '0'})).nutrition.kcal, 0);
});

test('manual transcription can save ingredients alone, but cannot invent nutrition from ingredients', () => {
  const converted = label.confirm(Object.assign(label.blank(), {ingredients: '小麦粉、水'}));
  assert.equal(converted.label.energyUnit, null);
  assert.deepEqual(converted.nutrition, {kcal: null, protein: null, carbs: null, fat: null});
  assert.throws(() => label.confirm(Object.assign(label.blank(), {energyValue: '100'})), /单位/);
  assert.throws(() => label.confirm(label.blank()), /抄下/);
});

test('invalid quantity, unknown energy unit and excessive converted total cannot be saved', () => {
  for (const patch of [{actualQuantity: '-1'}, {actualQuantity: '1e2'}, {actualQuantity: '一袋'}, {actualQuantity: '999999'}, {energyUnit: ''}, {energyUnit: 'cal'}, {energyValue: 'NaN'}, {actualQuantity: '30000'}]) {
    assert.throws(() => label.confirm(Object.assign(label.form(result()), patch)));
  }
});
