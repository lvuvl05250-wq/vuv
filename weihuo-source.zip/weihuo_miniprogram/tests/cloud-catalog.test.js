'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const {createHandler}=require('../cloudfunctions/weihuoApi/handler');
const {createStorage}=require('../cloudfunctions/weihuoApi/storage');
const {createProvider}=require('../cloudfunctions/weihuoApi/provider');
const {validateState}=require('../cloudfunctions/weihuoApi/state');
const {validateCatalog,audio}=require('../cloudfunctions/weihuoApi/catalog');
const {prepare,validateResult}=require('../cloudfunctions/weihuoApi/ai');
const {messagesFor}=require('../cloudfunctions/weihuoApi/prompts');
const library=require('../miniprogram/services/catalog');

const APPID='wx_catalog_test';
const NOW=Date.UTC(2026,9,4,4,0,0);
const STAMP='2026-10-04T03:00:00.000Z';
function profile(){return {name:'',adult:true,safetyAnswered:true,specialCondition:false,restrictions:[],allergies:'',notes:'',goals:[],onboarded:true};}
function state(){return {profile:profile(),days:{},meals:[],plans:[],reports:[],tickets:[],settings:{aiConsent:false,cloudConsent:true,reduceMotion:false}};}
function template(){return {id:'custom_1',title:'给自己留一点安静',durationMinutes:3,steps:['坐在舒服的位置，听一会儿环境的声音。'],minimumVersion:'停留半分钟也可以',stopSignal:'感到不适时停止',kind:'care',category:'meditation',tags:['quiet'],avoidWhen:[],scenes:['home','any'],energyLevels:['low','medium','high'],priority:3,source:'manual',createdAt:STAMP,updatedAt:STAMP,audio:{url:'https://media.example.test/quiet.mp3',durationSeconds:180,transcript:'找一个舒服的位置。'}};}
function catalog(items){return {version:'2026-10-04.1',publishedAt:STAMP,items:items||library};}
function database(){
  const rows=new Map();let queue=Promise.resolve();
  function collection(name){return {doc(id){return {async get(){const row=rows.get(name+'/'+id);return {data:row?[structuredClone(row)]:[]};},async set({data}){rows.set(name+'/'+id,structuredClone(data));}};}};}
  return {rows,collection,runTransaction(fn){const next=queue.then(()=>fn({collection}));queue=next.catch(()=>{});return next;}};
}
function handler(db,openid){const env={WEIHUO_APPID:APPID};return createHandler({env,storage:createStorage(db,()=>NOW),provider:createProvider(env),getWXContext:()=>openid===null?{}:{APPID,OPENID:openid||'catalog_user_a'}});}
function candidate(a){return {id:a.id,title:a.title,durationMinutes:a.durationMinutes,kind:a.kind,category:a.category|| (a.kind==='movement'?'movement':'care'),steps:a.steps,avoidWhen:a.avoidWhen};}
function planInput(){return {consent:true,type:'life',goal:'安排放松时间',startDate:'2026-10-04',dayCount:3,minutes:10,profile:profile(),actions:[candidate(template())]};}
function planResult(){return {title:'给自己留一点空间',days:[4,5,6].map(day=>({date:'2026-10-0'+day,title:'安静片刻',minutes:3,details:'坐在舒服的位置，听一会儿环境的声音，感到不适时停止。',actionIds:['custom_1']})),note:'在这一轮结束后按自己的感受调整。'};}

test('legacy state defaults customActions to empty; personal templates retain audio and category',()=>{
  assert.deepEqual(validateState(state()).customActions,[]);
  const s=state();s.customActions=[template()];
  assert.deepEqual(validateState(s).customActions,s.customActions);
  const before=structuredClone(s);validateState(s);assert.deepEqual(s,before);
});

test('personal templates reject malformed, duplicate and shared-library-shaped input',()=>{
  for(const edit of [a=>{a.durationMinutes=0;},a=>{a.durationMinutes=181;},a=>{a.priority=100;},a=>{a.category='medical';},a=>{a.scenes=['server-room'];},a=>{a.energyLevels=[3];},a=>{a.source='catalog';},a=>{a.audio.durationSeconds=7201;},a=>{a.createdAt='yesterday';}]){
    const s=state();const a=template();edit(a);s.customActions=[a];assert.throws(()=>validateState(s),e=>e.code==='INVALID_ARGUMENT');
  }
  const s=state();s.customActions=[template(),template()];assert.throws(()=>validateState(s));
  s.customActions=Array.from({length:301},(_,i)=>Object.assign(template(),{id:'custom_'+i,audio:undefined}));assert.throws(()=>validateState(s));
});

test('audio accepts bounded public HTTPS links and rejects credentials, local targets and arbitrary schemes',()=>{
  assert.equal(audio(template().audio,'audio').durationSeconds,180);
  for(const url of ['http://media.example.test/a.mp3','wxfile://a.mp3','data:audio/mp3;base64,aaa','https://user:password@media.example.test/a.mp3','https://localhost/a.mp3','https://127.0.0.1/a.mp3','https://2130706433/a.mp3','https://[::1]/a.mp3','https://audio.local/a.mp3','https://media.example.test:8888/a.mp3','https://media.example.test/a.mp3#fragment']){
    assert.throws(()=>audio(Object.assign(template().audio,{url}),'audio'),e=>e.code==='INVALID_ARGUMENT');
  }
});

test('published catalog validates the actual bundled library and exposes no database metadata',async()=>{
  const db=database();db.rows.set('weihuo_catalog/current',Object.assign({_id:'current'},catalog()));
  const result=await handler(db)({task:'getCatalog',payload:{}});
  assert.equal(result.ok,true);assert.equal(result.data.items.length,library.length);assert.equal(result.data.items[0].source,'catalog');
  assert.equal(result.data.items[0].category,library[0].kind==='movement'?'movement':'care');assert.equal(Object.hasOwn(result.data,'_id'),false);
  assert.equal(db.rows.size,1,'读共享库不写个人记录或计费次数');
});

test('catalog requires native identity and has no client update operation',async()=>{
  const db=database();db.rows.set('weihuo_catalog/current',catalog());const call=handler(db);
  assert.equal((await handler(db,null)({task:'getCatalog'})).error.code,'UNAUTHENTICATED');
  assert.equal((await call({task:'getCatalog',payload:{version:'unpublished'}})).error.code,'INVALID_ARGUMENT');
  assert.equal((await call({task:'getCatalog',headers:{}})).error.code,'NATIVE_CALL_REQUIRED');
  assert.equal((await call({task:'publishCatalog',payload:catalog()})).error.code,'TASK_NOT_FOUND');
  assert.equal(db.rows.get('weihuo_catalog/current').version,catalog().version);
});

test('unpublished or missing catalog never claims success; infrastructure failures stay distinct',async()=>{
  const db=database();const call=handler(db);
  assert.equal((await call({task:'getCatalog'})).error.code,'CATALOG_NOT_CONFIGURED');
  for(const row of [{version:'draft',items:library},catalog([]),Object.assign(catalog(),{publishedAt:'2099-01-01T00:00:00.000Z'})]){
    db.rows.set('weihuo_catalog/current',row);assert.equal((await call({task:'getCatalog'})).error.code,'CATALOG_NOT_CONFIGURED');
  }
  for(const [message,code] of [['COLLECTION_NOT_EXIST','CATALOG_NOT_CONFIGURED'],['database collection does not exist','CATALOG_NOT_CONFIGURED'],['permission denied private details','STORAGE_UNAVAILABLE']]){
    const failing={collection(){return {doc(){return {async get(){throw new Error(message);}};}};}};
    const result=await handler(failing)({task:'getCatalog'});assert.equal(result.error.code,code);assert.equal(JSON.stringify(result).includes('private details'),false);
  }
});

test('invalid published items are not returned as trusted library content',()=>{
  const item=Object.assign(template(),{source:'catalog'});
  for(const edit of [x=>{x.audio.url='http://media.example.test/a.mp3';},x=>{x.steps=['x'.repeat(1001)];},x=>{x.category='diagnosis';}]){
    const a=structuredClone(item);edit(a);assert.throws(()=>validateCatalog(catalog([a]),NOW),e=>e.code==='CATALOG_INVALID');
  }
  assert.throws(()=>validateCatalog(catalog([item,item]),NOW),e=>e.code==='CATALOG_INVALID');
});

test('published knowledge preserves attributed text and rejects unsafe source links',()=>{
  const item=Object.assign(template(),{source:'catalog',knowledge:{title:'留一点安静的空间',body:'按当下感受决定是否继续。',sourceTitle:'内容维护说明',sourceUrl:'https://example.test/guide'}});
  assert.deepEqual(validateCatalog(catalog([item]),NOW).items[0].knowledge,item.knowledge);
  item.knowledge.sourceUrl='javascript:alert(1)';assert.throws(()=>validateCatalog(catalog([item]),NOW),e=>e.code==='CATALOG_INVALID');
  item.knowledge.sourceUrl='';assert.equal(validateCatalog(catalog([item]),NOW).items[0].knowledge.sourceUrl,'');
});

test('legacy knowledge cards support bounded attribution fields without loosening URL validation',()=>{
  const item=Object.assign(template(),{source:'catalog',knowledgeCard:{id:'k1',topic:'action',title:'留一点安静的空间',body:'按当下感受决定是否继续。',sourceRefs:['k1'],source:'catalog',dismissible:true,sourceTitle:'内容维护说明',sourceUrl:'https://example.test/guide'}});
  assert.deepEqual(validateCatalog(catalog([item]),NOW).items[0].knowledgeCard,item.knowledgeCard);
  item.knowledgeCard.sourceUrl='http://example.test/guide';assert.throws(()=>validateCatalog(catalog([item]),NOW),e=>e.code==='CATALOG_INVALID');
  item.knowledgeCard.sourceUrl='';item.knowledgeCard.sourceTitle='x'.repeat(201);assert.throws(()=>validateCatalog(catalog([item]),NOW),e=>e.code==='CATALOG_INVALID');
});

test('custom actions sync only into their authenticated owner and cannot overwrite shared catalog',async()=>{
  const db=database();db.rows.set('weihuo_catalog/current',catalog());const s=state();s.customActions=[template()];
  const a=handler(db,'catalog_user_a'),b=handler(db,'catalog_user_b');
  assert.equal((await a({task:'syncPush',payload:{consent:true,baseVersion:0,state:s}})).ok,true);
  assert.equal((await b({task:'syncPull',payload:{consent:true}})).data.state,null);
  assert.equal((await a({task:'syncPull',payload:{consent:true}})).data.state.customActions[0].audio.url,template().audio.url);
  s.catalog=catalog();assert.equal((await a({task:'syncPush',payload:{consent:true,baseVersion:1,state:s}})).error.code,'INVALID_ARGUMENT');
  assert.equal(db.rows.get('weihuo_catalog/current').version,catalog().version);
});

test('plans retain supplied references, deduplicate and omit unknown references without rejecting prose',()=>{
  const input=prepare('generatePlan',planInput()).data;
  assert.deepEqual(validateResult('generatePlan',input,planResult()).days[0].actionIds,['custom_1']);
  for(const ids of [['invented_id'],['custom_1','custom_1'],[]]){
    const result=planResult();result.days[0].actionIds=ids;const normalized=validateResult('generatePlan',input,result);assert.deepEqual(normalized.days[0].actionIds,ids.includes('custom_1')?['custom_1']:[]);assert.equal(normalized.days[0].details,result.days[0].details);
  }
  const rest=planResult();rest.days[0].minutes=0;rest.days[0].actionIds=[];assert.deepEqual(validateResult('generatePlan',input,rest).days[0].actionIds,[]);
  const payload=planInput();payload.profile.bodyNotes='脚踝受伤';assert.throws(()=>prepare('generatePlan',payload),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
  const prompt=messagesFor('generatePlan',input);assert.match(prompt[0].content,/只能使用其中真实存在的id/);assert.equal(JSON.parse(prompt[1].content).input.actions[0].audio,undefined);
});

test('client candidate projection accepts eighty real items; legacy requests cannot invent ids',()=>{
  const payload=planInput();payload.actions=library.slice(0,80).map(candidate);
  assert.equal(prepare('generatePlan',payload).data.actions.length,80);
  payload.actions=[candidate(template()),candidate(template())];assert.throws(()=>prepare('generatePlan',payload));
  delete payload.actions;const input=prepare('generatePlan',payload).data;
  const result=planResult();assert.deepEqual(validateResult('generatePlan',input,result).days[0].actionIds,[]);
  result.days.forEach(d=>delete d.actionIds);assert.deepEqual(validateResult('generatePlan',input,result).days[0].actionIds,[]);
});
