'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
function setup(){
  const old=global.wx,saved=new Map(),calls=[];let response,release;
  global.wx={getStorageSync:k=>saved.get(k)||'',setStorageSync:(k,v)=>saved.set(k,structuredClone(v)),cloud:{callFunction:async({data})=>{calls.push(data.task);if(data.task==='auth')return {result:{ok:true,data:{openid:'refresh_user'}}};return await new Promise(r=>{release=r;});}}};
  for(const m of ['store','api'])delete require.cache[require.resolve('../miniprogram/services/'+m)];
  const store=require('../miniprogram/services/store'),api=require('../miniprogram/services/api');store.init();
  return {store,api,calls,saved,resolve:r=>release({result:r}),close:()=>{global.wx=old;}};
}
test('authentication completes while catalog is pending; refresh deduplicates and throttles',async()=>{
 const h=setup();try{
  assert.deepEqual(await h.api.refreshCatalogInBackground(),{skipped:true});
  await h.api.connect();assert.equal(h.api.isAuthenticated(),true);assert.deepEqual(h.calls,['auth','getCatalog']);
  const a=h.api.refreshCatalog(),b=h.api.refreshCatalog();assert.equal(a,b);
  let notified=0;const unsubscribe=h.store.subscribe(()=>notified++);
  const data={version:'new',items:require('../miniprogram/services/catalog').slice(0,3)};h.resolve({ok:true,data});await a;
  assert.equal(notified,1);await h.api.refreshCatalogInBackground();assert.equal(h.calls.length,2);
  assert.equal(h.store.updateCloudCatalog(data),false);assert.equal(notified,1);unsubscribe();
 }finally{h.close();}
});
test('failed background refresh preserves catalog, personal actions, history and connection',async()=>{
 const h=setup();try{
  const personal=h.store.saveCustomAction({title:'我自己的行动',steps:['坐一会儿']});
  const recorded=h.store.addAction(personal.id);const data={version:'good',items:require('../miniprogram/services/catalog').slice(0,2)};h.store.updateCloudCatalog(data);
  // Avoid local migration by connecting an existing account namespace first.
  h.store.switchAccount('refresh_user');h.store.saveCustomAction({title:'账号行动',steps:['休息']});
  await h.api.connect();const pending=h.api.refreshCatalogInBackground();h.resolve({ok:false,error:{code:'TEMPORARY',message:'unavailable'}});await pending;
  assert.equal(h.api.status().connected,true);assert.ok(h.api.status().catalogError);
  assert.equal(h.store.getCustomActions().length,1);assert.equal(h.saved.get('weihuo:catalog').version,'good');
  await h.api.refreshCatalogInBackground();assert.deepEqual(h.calls,['auth','getCatalog']);
  h.store.useLocal();assert.equal(h.store.getAction(recorded.id).title,'我自己的行动');
 }finally{h.close();}
});
test('corrupt downloaded catalogs cannot replace a valid cached library',()=>{
 const h=setup();try{const good={version:'good',items:require('../miniprogram/services/catalog').slice(0,2)};h.store.updateCloudCatalog(good);
  assert.throws(()=>h.store.updateCloudCatalog({version:'bad',items:[{id:'broken'}]}));assert.equal(h.saved.get('weihuo:catalog').version,'good');
 }finally{h.close();}
});
