'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const catalog = require('../miniprogram/services/catalog');

// Captured before the 2026-10 editorial pass. This freezes the original 102
// identities, compatibility fields, restrictions and stop instructions.
const LEGACY_FINGERPRINT = 'd871990d3acd96710751c71fce5906762d9d4c3e7073e9bcd4892eb269722176';
const LEGACY_FIELDS = ['id', 'actionKind', 'kind', 'scenes', 'energyLevels', 'tags', 'avoidWhen', 'stopSignal', 'priority'];
const CATEGORIES = ['movement', 'relaxation', 'meditation', 'focus', 'nature', 'senses', 'care'];
const REFERENCES = new Set([
  'https://www.who.int/news-room/fact-sheets/detail/physical-activity',
  'https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/',
  'https://www.nccih.nih.gov/health/meditation-and-mindfulness-effectiveness-and-safety',
  'https://aao.org/eye-health/tips-prevention/blue-light-digital-eye-strain',
  'https://www.nhs.uk/live-well/eat-well/food-guidelines-and-food-labels/water-drinks-nutrition/',
  'https://pubmed.ncbi.nlm.nih.gov/19121124/',
  'https://facultypsy.hope.edu/psychlabs/exp/visualsearch/readings/TreismanGelade_1980.pdf',
  'https://pubmed.ncbi.nlm.nih.gov/7502607/',
  'https://www.ncbi.nlm.nih.gov/books/NBK539861/',
  'https://pubmed.ncbi.nlm.nih.gov/14637326/',
  'https://users.wfu.edu/masicaej/MasicampoBaumeister2011JPSP.pdf',
  'https://pubmed.ncbi.nlm.nih.gov/18604961/',
  'https://pubmed.ncbi.nlm.nih.gov/11518143/',
  'https://www.psychologicalscience.org/journals/psychological-science/j.1467-9280.2006.01693.x/',
  'https://onlinelibrary.wiley.com/doi/10.1002/acp.1441',
  'https://www.hhs.gov/surgeongeneral/reports-and-publications/connection/index.html',
  'https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0272460'
]);
const NEW_ACTION_IDS = [
  'focus_recall_one_idea',
  'focus_return_marker',
  'focus_reading_question',
  'senses_smell_familiar',
  'senses_notice_safe_temperature',
  'senses_follow_sound_shape',
  'care_share_small_discovery',
  'care_listen_or_think_together',
  'care_park_next_step',
  'care_pause_one_notification',
  'relaxation_margin_doodle',
  'relaxation_hum_familiar_tune',
  'nature_check_known_plant',
  'movement_strength_explore_15',
  'movement_walk_experience_20'
];
function byId(id) { return catalog.find(action => action.id === id); }
function fingerprint(items) {
  const selected = items.map(action => Object.fromEntries(LEGACY_FIELDS.map(key => [key, action[key]])));
  return crypto.createHash('sha256').update(JSON.stringify(selected)).digest('hex');
}
function titleMinutes(title) {
  const match = title.match(/([\d一二三四五六七八九十]+)分钟/);
  if (!match) return null;
  if (/^\d+$/.test(match[1])) return Number(match[1]);
  const n = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9 };
  const parts = match[1].split('十');
  if (parts.length === 1) return n[parts[0]];
  return (parts[0] ? n[parts[0]] : 1) * 10 + (parts[1] ? n[parts[1]] : 0);
}

test('all original 102 actions preserve identity, movement kind and safety metadata', () => {
  assert.equal(catalog.length, 137);
  assert.equal(fingerprint(catalog.slice(0, 102)), LEGACY_FINGERPRINT);
  assert.equal(new Set(catalog.map(action => action.id)).size, catalog.length);
});

test('safety fingerprint rejects an intentionally relaxed movement restriction', () => {
  const damaged = JSON.parse(JSON.stringify(catalog.slice(0, 102)));
  const squat = damaged.find(action => action.id === 'reviewed_strength_bodyweight_squat');
  squat.avoidWhen = [];
  assert.notEqual(fingerprint(damaged), LEGACY_FINGERPRINT);
});

test('every action has a supported category and honest catalog provenance', () => {
  for (const action of catalog) {
    assert(CATEGORIES.includes(action.category), action.id);
    assert.equal(action.source, 'catalog', action.id);
    assert(['movement', 'care'].includes(action.kind), action.id);
    if (action.kind === 'movement') assert.equal(action.category, 'movement', action.id);
    assert(action.scenes.length > 0 && action.energyLevels.length > 0, action.id);
    assert.equal(new Set(action.tags).size, action.tags.length, action.id + ': duplicate tags');
    assert(action.stopSignal && action.minimumVersion, action.id);
  }
  assert.deepEqual(new Set(catalog.map(action => action.category)), new Set(CATEGORIES));
  for (const action of catalog.slice(102, 122)) assert.equal(action.kind, 'care');
});

test('title durations agree with timers and previously mismatched short actions are corrected', () => {
  for (const action of catalog) {
    assert(Number.isInteger(action.durationMinutes) && action.durationMinutes >= 1 && action.durationMinutes <= 20, action.id);
    const duration = titleMinutes(action.title);
    if (duration !== null) assert.equal(action.durationMinutes, duration, action.title);
  }
  assert.equal(byId('office_corridor_walk').durationMinutes, 3);
  assert.equal(byId('reviewed_home_care_02').durationMinutes, 3);
  assert.equal(byId('reviewed_classroom_movement_07').durationMinutes, 1);
  assert.equal(byId('reviewed_outdoor_care_05').durationMinutes, 1);
  assert.equal(byId('dorm_laundry_fold').durationMinutes, 3);
  assert(catalog.some(action => action.durationMinutes === 5));
  assert(catalog.some(action => action.durationMinutes === 10));
});

test('each action has distinct concrete steps without placeholder movement instructions', () => {
  const allSteps = new Set();
  for (const action of catalog) {
    assert(action.steps.length >= 2 && action.steps.length <= 5, action.id);
    for (const step of action.steps) {
      assert(typeof step === 'string' && step.trim().length >= 6, action.id);
      assert(!/完成一次小幅度、可控的动作或环境调整|先确认脚下和周围空间安全|双脚或坐骨找到稳定支撑/.test(step), action.id);
    }
    const signature = JSON.stringify(action.steps);
    assert(!allSteps.has(signature), 'Duplicated complete steps: ' + action.id);
    allSteps.add(signature);
  }
});

test('leaf exploration includes questions and hand-warming no longer instructs drinking', () => {
  const leaf = byId('outdoor_leaf_observe');
  assert.equal(leaf.category, 'nature');
  assert.equal(leaf.durationMinutes, 3);
  assert.match(leaf.steps.join(' '), /几种/);
  assert.match(leaf.steps.join(' '), /最喜欢.*颜色/);
  assert.match(leaf.steps.join(' '), /像/);
  assert.match(leaf.steps.join(' '), /不用摘/);
  const hands = byId('reviewed_dorm_care_05');
  assert.match(hands.steps.join(' '), /温水流过双手/);
  assert(!/喝几口|小口喝|喝一两口/.test(hands.steps.join(' ')));
});

test('knowledge cards distinguish reference summaries from concrete life-practice tips', () => {
  const bodies = new Set();
  for (const action of catalog) {
    const card = action.knowledgeCard;
    assert(card && card.id && card.title && card.body, action.id);
    assert(card.body.length >= 18 && card.body.length <= 180, action.id);
    assert.equal(typeof card.sourceTitle, 'string', action.id);
    assert.equal(typeof card.sourceUrl, 'string', action.id);
    if (card.sourceTitle === '微活生活实践') {
      assert.equal(card.title, '一个小窍门', action.id);
      assert.equal(card.sourceUrl, '', action.id);
    } else {
      assert(REFERENCES.has(card.sourceUrl), action.id + ': unverified reference');
    }
    assert(!/为什么这一步可能有帮助|把一个明确而轻量的身体|治疗疾病|治愈|排毒|提升免疫力|修复神经|降低血压/.test(card.body + card.title), action.id);
    assert(!/研究.{0,12}(?:没有|未)|论文.{0,12}(?:没有|未)|(?:没有|未).{0,12}(?:单独测试|单独验证|研究验证)|研究不等于|不等于本行动|不代表.{0,12}(?:疗效|效果)|不保证(?:疗效|效果)|不能证明(?:疗效|效果)/.test(card.body), action.id);
    assert(!bodies.has(card.body), 'Repeated knowledge body: ' + action.id);
    bodies.add(card.body);
    assert.equal(card.dismissible, true);
  }
});

test('new self-care actions cover all six care categories and make no embedded audio promises', () => {
  const added = catalog.slice(102, 122);
  assert.equal(added.length, 20);
  for (const category of CATEGORIES.filter(category => category !== 'movement')) assert(added.some(action => action.category === category), category);
  for (const action of added) {
    assert(!action.audioUrl && !action.audioPath, action.id);
    assert(!/点击播放|点击收听|跟随本段音频/.test(action.steps.join(' ')), action.id);
  }
});

test('new daily actions are distinct, cover the requested activity areas and retain catalog references', () => {
  const added = catalog.slice(122);
  assert.deepEqual(added.map(action => action.id), NEW_ACTION_IDS);
  assert.equal(added.length, 15);
  for (const category of ['focus', 'senses', 'care', 'relaxation', 'nature', 'movement']) {
    assert(added.some(action => action.category === category), category);
  }
  assert.equal(added.filter(action => action.category === 'focus').length, 3);
  assert.equal(added.filter(action => action.category === 'senses').length, 3);
  assert.equal(added.filter(action => action.category === 'movement').length, 2);
  assert.equal(added.filter(action => action.category === 'relaxation').length, 2);
  assert.equal(byId('movement_strength_explore_15').durationMinutes, 15);
  assert.equal(byId('movement_walk_experience_20').durationMinutes, 20);
  assert.match(byId('movement_strength_explore_15').steps.join(' '), /小段/);
  assert.match(byId('movement_walk_experience_20').steps.join(' '), /小段/);
  for (const action of added.filter(item => item.category === 'movement')) {
    assert(!/减肥|燃脂|瘦身|塑形|变美|体重/.test(action.title + action.steps.join(' ') + action.minimumVersion + action.knowledgeCard.body), action.id);
  }
  for (const action of added) {
    assert.equal(action.knowledgeCard.sourceRefs[0], action.id, action.id);
    assert.equal(action.category === 'movement', action.kind === 'movement', action.id);
    assert(!action.audioUrl && !action.audioPath, action.id);
  }
});
