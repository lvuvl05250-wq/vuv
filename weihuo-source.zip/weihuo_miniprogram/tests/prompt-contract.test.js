'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DEFINITIONS, messagesFor } = require('../cloudfunctions/weihuoApi/prompts');

const TASKS = {
  generateDiary:['title','yi','paragraphs','quote','stickers'],
  extractFoodPreferences:['foodExclusions'],
  generateAction:['title','category','durationMinutes','steps','why'],
  analyzeFoodLabel: ['name', 'ingredients', 'servingBasis', 'servingSize', 'energyValue', 'energyUnit', 'protein', 'carbs', 'fat', 'flags', 'uncertainFields', 'evidence'],
  summarizeProfile: ['summary', 'restrictions', 'restrictionEvidence', 'allergies', 'avoidedActivities'],
  parseState: ['energy', 'scene', 'minutes', 'mood', 'note'],
  explainActions: ['actions', 'note'],
  analyzeMeal: ['name', 'candidates', 'kcalMin', 'kcalMax', 'protein', 'carbs', 'fat', 'note'],
  extractReport: ['metrics', 'note'],
  generatePlan: ['title', 'days', 'note'],
  generateTicketTitle: ['title', 'note'],
  mealDayReview: ['summary', 'suggestions', 'kcalMin', 'kcalMax', 'note']
};

const SAMPLE_INPUTS = {
  generateDiary:{date:'2026-10-06',actions:[],meals:[],companionKey:'cat',allowedStickers:['face','paw','star','heart']},extractFoodPreferences:{profile:{allergies:'芒果过敏'}},generateAction:{text:'每天整理桌面',profile:{}},
  analyzeFoodLabel: { name: '饼干', text: '营养标签见图片', hasImages: true },
  summarizeProfile: { profile: {} },
  parseState: { text: '今天在家有点累，想休息5分钟' },
  explainActions: {
    text: '在家有点累',
    actions: [{ id: 'home_walk_01', title: '室内轻松走一小圈', durationMinutes: 3, avoidWhen: [] }]
  },
  analyzeMeal: { text: '豆腐蔬菜饭', name: '午餐', note: '' },
  extractReport: { text: '报告文字' },
  generatePlan: {
    type: 'aerobic', goal: '增加日常活动', startDate: '2026-10-05', dayCount: 3, minutes: 20,
    constraints: [], preferences: '', context: '',
    actions: [{ id: 'catalog_walk_01', title: '舒适步行', durationMinutes: 20, kind: 'movement', category: 'movement', steps: [], avoidWhen: [] }]
  },
  generateTicketTitle: { date: '2026-10-05', actions: ['窗边休息'], meals: [], mood: '' },
  mealDayReview: {
    date: '2026-10-05', phase: 'ongoing',
    meals: [{ name: '豆腐饭', note: '', kcal: 500, protein: 18, carbs: 70, fat: 12 }]
  }
};

function parsePromptContract(systemText) {
  const schemaMarker = '本任务JSON Schema：\n';
  const exampleMarker = '本任务完整JSON示例：\n';
  assert.equal(systemText.split(schemaMarker).length - 1, 1, 'one task schema');
  assert.equal(systemText.split(exampleMarker).length - 1, 1, 'one task example');
  const [beforeExample, exampleText] = systemText.split(exampleMarker);
  const schemaText = beforeExample.split(schemaMarker)[1];
  return { schema: JSON.parse(schemaText), example: JSON.parse(exampleText) };
}

function assertMatchesSchema(value, schema, path = '$') {
  const types = Array.isArray(schema.type) ? schema.type : [schema.type];
  const actualType = value === null ? 'null' : Array.isArray(value) ? 'array' : Number.isInteger(value) ? 'integer' : typeof value;
  assert(types.includes(actualType) || (actualType === 'integer' && types.includes('number')), `${path}: expected ${types}, got ${actualType}`);
  if (schema.enum) assert(schema.enum.some(option => Object.is(option, value)), `${path}: value outside enum`);
  if (typeof value === 'string') {
    if (schema.minLength !== undefined) assert(value.length >= schema.minLength, `${path}: too short`);
    if (schema.maxLength !== undefined) assert(value.length <= schema.maxLength, `${path}: too long`);
    if (schema.format === 'date') assert(/^\d{4}-\d{2}-\d{2}$/.test(value) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value, `${path}: invalid date`);
  }
  if (typeof value === 'number') {
    if (schema.minimum !== undefined) assert(value >= schema.minimum, `${path}: below minimum`);
    if (schema.maximum !== undefined) assert(value <= schema.maximum, `${path}: above maximum`);
    if (schema.multipleOf === 1) assert(Number.isInteger(value), `${path}: expected integer`);
  }
  if (Array.isArray(value)) {
    if (schema.minItems !== undefined) assert(value.length >= schema.minItems, `${path}: too few items`);
    if (schema.maxItems !== undefined) assert(value.length <= schema.maxItems, `${path}: too many items`);
    if (schema.uniqueItems) assert.equal(new Set(value.map(item => JSON.stringify(item))).size, value.length, `${path}: duplicate items`);
    value.forEach((item, index) => assertMatchesSchema(item, schema.items, `${path}[${index}]`));
  }
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const keys = Object.keys(value);
    assert.deepEqual(keys, schema.required, `${path}: required fields and order`);
    if (schema.additionalProperties === false) assert.deepEqual(keys.sort(), Object.keys(schema.properties).sort(), `${path}: unexpected fields`);
    for (const key of schema.required) assertMatchesSchema(value[key], schema.properties[key], `${path}.${key}`);
  }
}

test('each task prompt contains one explicit schema and a complete task-specific JSON example', () => {
  assert.deepEqual(Object.keys(DEFINITIONS), Object.keys(TASKS));
  for (const [task, fields] of Object.entries(TASKS)) {
    const messages = messagesFor(task, SAMPLE_INPUTS[task]);
    assert.equal(messages.length, 2, task);
    assert.equal(messages[0].role, 'system', task);
    assert.equal(messages[1].role, 'user', task);
    const systemText = messages[0].content;
    assert.match(systemText, /只返回一个JSON对象；不要输出Markdown、代码围栏、前言、尾注或额外解释/, task);
    assert.match(systemText, /Schema里的description只是字段说明，不是返回值/, task);
    assert.match(systemText, /示例是完整JSON，仅展示本任务的结构与语气；其中事实和数值不可照搬/, task);
    assert.doesNotMatch(systemText, /energy\s*[:：]\s*["']?1-5\s*或\s*null/, task);

    const { schema, example } = parsePromptContract(systemText);
    assert.deepEqual(Object.keys(schema.properties), fields, task);
    assert.deepEqual(schema.required, fields, task);
    assert.equal(schema.additionalProperties, false, task);
    assertMatchesSchema(example, schema);
  }
});

test('parseState makes nullability explicit while mood and note stay strings', () => {
  const input = SAMPLE_INPUTS.parseState;
  const { schema, example } = parsePromptContract(messagesFor('parseState', input)[0].content);
  assert.deepEqual(schema.properties.energy.type, ['integer', 'null']);
  assert.deepEqual(schema.properties.scene.type, ['string', 'null']);
  assert.deepEqual(schema.properties.scene.enum, ['office', 'classroom', 'dorm', 'home', 'outdoor', 'commute', 'any', null]);
  assert.deepEqual(schema.properties.minutes.type, ['integer', 'null']);
  assert.equal(schema.properties.mood.type, 'string');
  assert.equal(schema.properties.note.type, 'string');
  assert.equal(typeof example.mood, 'string');
  assert.equal(typeof example.note, 'string');
});

test('generatePlan schema and example match the requested date and exact day count', () => {
  for (const dayCount of [3, 7, 14]) {
    const input = { ...SAMPLE_INPUTS.generatePlan, dayCount, startDate: '2026-10-05' };
    const { schema, example } = parsePromptContract(messagesFor('generatePlan', input)[0].content);
    assert.equal(schema.properties.days.minItems, dayCount);
    assert.equal(schema.properties.days.maxItems, dayCount);
    assert.equal(example.days.length, dayCount);
    for (let index = 0; index < dayCount; index += 1) {
      const date = new Date(input.startDate + 'T00:00:00Z');
      date.setUTCDate(date.getUTCDate() + index);
      assert.equal(example.days[index].date, date.toISOString().slice(0, 10));
      assert.deepEqual(example.days[index].actionIds, ['catalog_walk_01']);
    }
  }
});

test('food-label prompt keeps literal evidence and no-derivation rules', () => {
  const { instruction, schema, example } = DEFINITIONS.analyzeFoodLabel;
  assert.match(instruction, /禁止从配料顺序、食物名称或宏量营养推导热量/);
  assert.match(instruction, /evidence逐项抄录支持表头或数值的原文短行/);
  assert.match(instruction, /只有配料表时所有营养数值为null/);
  assert.equal(schema.properties.energyValue.type.includes('null'), true);
  assert.equal(schema.properties.energyUnit.type.includes('null'), true);
  assert.equal(example.energyValue, 1850);
  assert.match(example.evidence.energyValue, /1850 kJ/);
  assert.match(example.evidence.protein, /7\.2 g/);
  assert.match(example.evidence.carbs, /70\.1 g/);
  assert.match(example.evidence.fat, /12\.3 g/);
});
