'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {createProvider} = require('../cloudfunctions/weihuoApi/provider');
const {createTokenHubProvider, prepareMessages, ENDPOINT} = require('../cloudfunctions/weihuoApi/tokenhub-provider');
const {runAI} = require('../cloudfunctions/weihuoApi/ai');
const {syntheticReport, readConfiguration} = require('../cloudfunctions/tools/ai-preflight');
const preflight = require('../cloudfunctions/tools/vision-preflight');
const SECRET = 'synthetic-key-never-return-this';
const png = syntheticReport().toString('base64');
const env = patch => Object.assign({WEIHUO_AI_PROVIDER: 'cloudbase', WEIHUO_AI_MODEL: 'hy3', WEIHUO_AI_VISION_PROVIDER: 'tokenhub', WEIHUO_AI_VISION_API_KEY: SECRET, WEIHUO_AI_VISION_MODEL: 'deepseek/deepseek-flash'}, patch);
function messages(count = 1) {
  return [{role: 'system', content: '只返回JSON；不保存资料。'}, {role: 'user', content: [{type: 'text', text: '提取本次图片。'}, ...Array.from({length: count}, () => ({type: 'image_url', image_url: {url: 'data:image/png;base64,' + png}}))]}];
}
function envelope(content, extra) {
  return Object.assign({id: 'synthetic-response', object: 'chat.completion', model: 'deepseek/deepseek-flash', choices: [{index: 0, message: {role: 'assistant', content: typeof content === 'string' ? content : JSON.stringify(content)}, finish_reason: 'stop'}], usage: {prompt_tokens: 1500, completion_tokens: 500, total_tokens: 2000}}, extra);
}
const response = (value, status = 200) => new Response(JSON.stringify(value), {status});
const contentResponse = value => response(envelope(value));
const errorIs = code => error => error.code === code && !JSON.stringify(error).includes(SECRET) && !error.message.includes('private-upstream');
function sdkStub(calls) {
  return {SYMBOL_CURRENT_ENV: Symbol('runtime'), init() { return {ai: () => ({createModel(group) { assert.equal(group, 'cloudbase'); return {generateText(input) { calls.push(input); const raw = envelope({note: 'hy3 text'}); return {text: raw.choices[0].message.content, rawResponses: [raw]}; }}; }})}; }};
}

test('hybrid routing preserves cloudbase hy3 text and separates image model, secret and token budget', async () => {
  const textCalls = [], visionCalls = [];
  const provider = createProvider(env({WEIHUO_AI_VISION_MAX_TOKENS: '512'}), async (url, options) => { visionCalls.push({url, options}); return contentResponse({name: '合成食品'}); }, {sdk: sdkStub(textCalls)});
  assert.equal(provider.configured(false), true); assert.equal(provider.configured(true), true);
  assert.deepEqual(await provider.generate([{role: 'user', content: '文字'}], false, {task: 'parseState'}), {note: 'hy3 text'});
  const original = messages(2), before = JSON.stringify(original);
  assert.deepEqual(await provider.generate(original, true), {name: '合成食品'});
  assert.equal(JSON.stringify(original), before);
  assert.equal(textCalls.length, 1); assert.equal(textCalls[0].model, 'hy3'); assert.equal(textCalls[0].max_tokens, 256);
  assert.deepEqual(textCalls[0].thinking, {type: 'disabled'});
  assert.equal(visionCalls.length, 1); assert.equal(visionCalls[0].url, ENDPOINT);
  const request = visionCalls[0].options, body = JSON.parse(request.body);
  assert.equal(request.headers.Authorization, 'Bearer ' + SECRET); assert.equal(request.redirect, 'error');
  assert.equal(body.model, 'deepseek/deepseek-flash'); assert.equal(body.max_tokens, 512); assert.equal(body.stream, false);
  assert.equal(body.messages[1].content.filter(p => p.type === 'image_url').length, 2);
  assert.equal(body.response_format, undefined); assert.equal(body.tools, undefined); assert.equal(body.thinking, undefined);
  assert.equal(request.body.includes(SECRET), false);
  assert.equal(JSON.stringify(provider.assertConfigured(true)).includes(SECRET), false);
});

test('an image cannot be accidentally routed to hy3 even when the caller passes false', async () => {
  const calls = []; let visionCalls = 0;
  await createProvider(env(), async () => { visionCalls++; return contentResponse({ok: true}); }, {sdk: sdkStub(calls)}).generate(messages(), false);
  assert.equal(calls.length, 0); assert.equal(visionCalls, 1);
});

test('missing vision key/model or a mistyped provider does not disable text or silently use it for images', async () => {
  for (const patch of [{WEIHUO_AI_VISION_API_KEY: ''}, {WEIHUO_AI_VISION_MODEL: ''}, {WEIHUO_AI_VISION_PROVIDER: 'typo'}]) {
    const calls = []; let fetched = false;
    const provider = createProvider(env(patch), async () => { fetched = true; }, {sdk: sdkStub(calls)});
    assert.equal(provider.configured(true), false); assert.equal(provider.configured(false), true);
    await assert.rejects(provider.generate(messages(), true), errorIs('SERVICE_NOT_CONFIGURED'));
    await provider.generate([{role: 'user', content: '文字'}], false);
    assert.equal(calls.length, 1); assert.equal(fetched, false);
  }
});

test('fixed HTTPS endpoint rejects credential forwarding, paths, ports and lookalike hosts before fetch', async () => {
  for (const endpoint of ['http://tokenhub.tencentmaas.com/v1/chat/completions', 'https://tokenhub.tencentmaas.com.evil.test/v1/chat/completions', ENDPOINT + '?x=1', ENDPOINT + '/', 'https://user:pass@tokenhub.tencentmaas.com/v1/chat/completions', 'https://tokenhub.tencentmaas.com:444/v1/chat/completions']) {
    let fetched = false;
    const provider = createTokenHubProvider(env({WEIHUO_AI_VISION_ENDPOINT: endpoint}), async () => { fetched = true; });
    assert.equal(provider.configured(), false); await assert.rejects(provider.generate(messages()), errorIs('SERVICE_NOT_CONFIGURED'));
    assert.equal(fetched, false);
  }
});

test('configuration validates limits, model ID, key header characters and explicit optional JSON/thinking modes', async () => {
  for (const patch of [{WEIHUO_AI_VISION_API_KEY: SECRET + '\r\nX: leak'}, {WEIHUO_AI_VISION_API_KEY: 'YOUR_API_KEY'}, {WEIHUO_AI_VISION_MODEL: 'model\nother'}, {WEIHUO_AI_VISION_TIMEOUT_MS: '999'}, {WEIHUO_AI_VISION_TIMEOUT_MS: '50001'}, {WEIHUO_AI_VISION_MAX_TOKENS: '255'}, {WEIHUO_AI_VISION_MAX_TOKENS: '4097'}, {WEIHUO_AI_VISION_MAX_TOKENS: '1.5'}, {WEIHUO_AI_VISION_JSON_MODE: 'json_schema'}, {WEIHUO_AI_VISION_THINKING: 'enabled'}]) assert.equal(createTokenHubProvider(env(patch)).configured(), false);
  let body;
  await createTokenHubProvider(env({WEIHUO_AI_VISION_JSON_MODE: 'json_object', WEIHUO_AI_VISION_THINKING: 'disabled'}), async (_, options) => { body = JSON.parse(options.body); return contentResponse({ok: true}); }).generate(messages());
  assert.deepEqual(body.response_format, {type: 'json_object'}); assert.deepEqual(body.thinking, {type: 'disabled'});
});

test('one/two valid images accepted; remote URLs, third images, invalid signatures, videos and excess payload rejected before fetch', async () => {
  assert.equal(prepareMessages(messages(2))[1].content.length, 3);
  const invalid = [messages(3), [], [{role: 'user', content: 'no image'}], messages()];
  invalid[3][1].content[1].image_url.url = 'https://example.test/private';
  const corrupt = messages(); corrupt[1].content[1].image_url.url = 'data:image/jpeg;base64,' + png; invalid.push(corrupt);
  const huge = messages(); huge[0].content = 'x'.repeat(1700 * 1024); invalid.push(huge);
  const video = messages(); video[1].content[1] = {type: 'video_url', video_url: {url: 'file:///private'}}; invalid.push(video);
  const oversize = Buffer.alloc(513 * 1024, 0); Buffer.from(png, 'base64').subarray(0, 12).copy(oversize);
  const largeImage = messages(); largeImage[1].content[1].image_url.url = 'data:image/png;base64,' + oversize.toString('base64'); invalid.push(largeImage);
  let calls = 0; const provider = createTokenHubProvider(env(), async () => { calls++; });
  for (const input of invalid) await assert.rejects(provider.generate(input), error => ['INVALID_ARGUMENT', 'PAYLOAD_TOO_LARGE'].includes(error.code));
  assert.equal(calls, 0);
});

test('GLM uses documented low reasoning effort by default without pretending thinking can be disabled', async () => {
  const sent = [];
  const send = async (_, options) => { sent.push(JSON.parse(options.body)); return contentResponse({ok: true}); };
  await createTokenHubProvider(env({WEIHUO_AI_VISION_MODEL: 'glm-5.3-flash'}), send).generate(messages());
  assert.equal(sent[0].reasoning_effort, 'low'); assert.equal(sent[0].thinking, undefined);
  await createTokenHubProvider(env({WEIHUO_AI_VISION_MODEL: 'glm-5.3-flash', WEIHUO_AI_VISION_REASONING_EFFORT: 'high'}), send).generate(messages());
  assert.equal(sent[1].reasoning_effort, 'high');
  assert.equal(createTokenHubProvider(env({WEIHUO_AI_VISION_MODEL: 'glm-5.3-flash', WEIHUO_AI_VISION_THINKING: 'disabled'})).configured(), false);
  assert.equal(createTokenHubProvider(env({WEIHUO_AI_VISION_REASONING_EFFORT: 'none'})).configured(), false);
  await createTokenHubProvider(env({WEIHUO_AI_VISION_MODEL: 'minimax-m3', WEIHUO_AI_VISION_THINKING: 'disabled'}), send).generate(messages());
  assert.equal(sent[2].reasoning_effort, undefined); assert.deepEqual(sent[2].thinking, {type: 'disabled'});
});

test('vision task output limits leave the complete prompt intact and respect a smaller configured ceiling', async () => {
  const original = messages(), before = JSON.stringify(original), requests = [];
  const send = async (_, options) => { requests.push(JSON.parse(options.body)); return contentResponse({ok: true}); };
  const provider = createTokenHubProvider(env(), send);
  for (const task of ['analyzeMeal', 'analyzeFoodLabel', 'extractReport']) await provider.generate(original, true, {task});
  assert.deepEqual(requests.map(r => r.max_tokens), [512, 768, 1536]);
  for (const request of requests) assert.equal(JSON.stringify(request.messages), before);
  assert.equal(JSON.stringify(original), before);
  await createTokenHubProvider(env({WEIHUO_AI_VISION_MAX_TOKENS: '256'}), send).generate(original, true, {task: 'extractReport'});
  assert.equal(requests[3].max_tokens, 256);
});

test('production food-label task routes both images once and normalizes partial values without fabricated facts', async () => {
  let calls = 0;
  const provider = createProvider(env(), async (_, options) => {
    calls++; assert.equal(JSON.parse(options.body).messages[1].content.filter(p => p.type === 'image_url').length, 2);
    return contentResponse({name: '合成标签', ingredients: '', servingBasis: 'per100g', servingSize: '', energyValue: 840, energyUnit: 'kJ', protein: 5, fat: null, carbs: null, flags: [], uncertainFields: ['fat', 'carbs'], evidence: {servingBasis: '每100g', energyValue: '能量 840kJ', protein: '蛋白质 5g'}});
  });
  const output = await runAI('analyzeFoodLabel', {consent: true, images: [{imageBase64: png, mimeType: 'image/png'}, {imageBase64: png, mimeType: 'image/png'}]}, provider, async () => {});
  assert.equal(calls, 1); assert.equal(output.energyValue, 840); assert.equal(output.fat, null); assert.equal(output.carbs, null);
});

test('plain prose, partial JSON, fences and nullable output use existing tolerant normalization with one model call', async () => {
  for (const content of ['这张标签右侧模糊。', '{"name":', '```json\n{"name":"合成食品","fat":null}\n```']) {
    let calls = 0;
    const output = await runAI('analyzeMeal', {consent: true, imageBase64: png, mimeType: 'image/png'}, createProvider(env(), async () => { calls++; return contentResponse(content); }), async () => {});
    assert.equal(calls, 1); assert.equal(output.fat, null);
    if (content.startsWith('这张')) assert.ok((output.body || output.note).includes('模糊'));
  }
});

test('HTTP and 200-envelope errors distinguish service activation, balance, auth and retryable failures without leaking details', async () => {
  const cases = [
    [402, {code: '401007', message: 'no free package'}, 'SERVICE_NOT_CONFIGURED'],
    [402, {code: 'insufficient_balance_error'}, 'PROVIDER_QUOTA_EXCEEDED'],
    [402, {}, 'PROVIDER_QUOTA_EXCEEDED'], [401, {}, 'PROVIDER_AUTH_FAILED'], [403, {}, 'PROVIDER_AUTH_FAILED'],
    [429, {}, 'PROVIDER_RATE_LIMITED'], [503, {}, 'PROVIDER_UNAVAILABLE'], [504, {}, 'PROVIDER_TIMEOUT'],
    [400, {}, 'PROVIDER_REQUEST_REJECTED'], [200, {code: 'model_not_enabled'}, 'SERVICE_NOT_CONFIGURED']
  ];
  for (const [status, upstream, code] of cases) {
    const error = Object.assign({message: 'private-upstream ' + SECRET}, upstream);
    await assert.rejects(createTokenHubProvider(env(), async () => response({error}, status)).generate(messages()), errorIs(code));
  }
  await assert.rejects(createTokenHubProvider(env(), async () => new Response(null, {status: 401})).generate(messages()), errorIs('PROVIDER_AUTH_FAILED'));
});

test('invalid, empty and excessive transport responses never become a successful business result', async () => {
  for (const makeResponse of [() => new Response('not-json'), () => contentResponse(''), () => response({choices: []}), () => contentResponse('x'.repeat(130 * 1024)), () => new Response('small', {headers: {'content-length': String(130 * 1024)}})]) {
    await assert.rejects(createTokenHubProvider(env(), async () => makeResponse()).generate(messages()), errorIs('PROVIDER_INVALID_RESPONSE'));
  }
});

test('thinking-only empty vision output reports an explicit error without a second call or fabricated fields', async () => {
  for (const [finish, content, code] of [['length', '', 'PROVIDER_OUTPUT_LIMIT'], ['stop', '', 'PROVIDER_INVALID_RESPONSE']]) {
    let calls = 0;
    const provider = createProvider(env({WEIHUO_AI_VISION_MODEL: 'glm-5.3-flash'}), async () => {
      calls++;
      return response(envelope('', {choices: [{message: {content, reasoning_content: 'private-upstream ' + SECRET}, finish_reason: finish}]}));
    });
    await assert.rejects(runAI('analyzeMeal', {consent: true, imageBase64: png, mimeType: 'image/png'}, provider, async () => {}), error => errorIs(code)(error) && /照片仍在/.test(error.message));
    assert.equal(calls, 1);
  }
});

test('length metadata preserves readable content and partial JSON without inventing nutrition values', async () => {
  for (const content of ['{"name":"一盘菜"}', '{"name":"一盘菜","note":"可能还有配菜', '能看到番茄，但图片右侧没有拍完整。']) {
    let calls = 0;
    const provider = createProvider(env({WEIHUO_AI_VISION_MODEL: 'glm-5.3-flash'}), async () => {
      calls++;
      return response(envelope('', {choices: [{message: {content, reasoning_content: 'private-upstream ' + SECRET}, finish_reason: 'length'}]}));
    });
    const result = await runAI('analyzeMeal', {consent: true, imageBase64: png, mimeType: 'image/png'}, provider, async () => {});
    assert.equal(calls, 1); assert.equal(result.protein, null); assert.equal(result.kcalMin, null);
    if (content.endsWith('}')) assert.equal(result.name, '一盘菜');
    else assert.equal(result.body, content);
    assert.equal(JSON.stringify(result).includes(SECRET), false);
  }
});

test('network errors and redirects expose no upstream secret text and never retry', async () => {
  let calls = 0;
  await assert.rejects(createTokenHubProvider(env(), async () => { calls++; throw new Error('private-upstream ' + SECRET); }).generate(messages()), errorIs('PROVIDER_NETWORK_ERROR'));
  assert.equal(calls, 1);
});

test('deadline covers stalled fetch even when a transport double ignores AbortSignal', async () => {
  let signal, calls = 0;
  const started = Date.now();
  await assert.rejects(createTokenHubProvider(env({WEIHUO_AI_VISION_TIMEOUT_MS: '1000'}), async (_, options) => { calls++; signal = options.signal; return new Promise(() => {}); }).generate(messages()), errorIs('PROVIDER_TIMEOUT'));
  assert.equal(signal.aborted, true); assert.equal(calls, 1); assert.ok(Date.now() - started < 2000);
});

test('deadline includes slow response-body transfer, not just response headers', async () => {
  const provider = createTokenHubProvider(env({WEIHUO_AI_VISION_TIMEOUT_MS: '1000'}), async (_, options) => new Response(new ReadableStream({start(controller) { options.signal.addEventListener('abort', () => controller.error(new Error(SECRET))); }})));
  await assert.rejects(provider.generate(messages()), errorIs('PROVIDER_TIMEOUT'));
});

test('vision configuration helper keeps key off output and preserves text configuration boundaries', () => {
  assert.deepEqual(preflight.status(env()), {providerSelected: true, keyPresent: true, modelPresent: true, configured: true});
  assert.equal(JSON.stringify(preflight.status(env())).includes(SECRET), false);
  const file = path.resolve(__dirname, '../cloudfunctions/.env.vision-unit-' + process.pid);
  try {
    preflight.initialize(file); assert.equal(fs.statSync(file).mode & 0o777, 0o600);
    const read = readConfiguration(file); assert.equal(read.WEIHUO_AI_VISION_PROVIDER, 'tokenhub'); assert.equal(read.WEIHUO_AI_VISION_MODEL, 'glm-5.3-flash');
    assert.equal(preflight.status(read).configured, false);
    assert.throws(() => preflight.initialize(file), error => error.code === 'CONFIG_ALREADY_EXISTS');
    fs.chmodSync(file, 0o644); assert.throws(() => readConfiguration(file), error => error.code === 'CONFIG_PERMISSIONS');
  } finally { if (fs.existsSync(file)) fs.unlinkSync(file); }
});

test('live preflight uses synthetic bytes, checks exact extracted content and reports only usage metadata', async () => {
  const result = await preflight.liveProbe(env(), async (_, options) => {
    assert.equal(JSON.parse(options.body).messages[1].content[1].image_url.url, 'data:image/png;base64,' + png);
    return contentResponse({metrics: [{name: 'MARKER', value: '42', unit: 'MG', reference: ''}], note: ''});
  });
  assert.equal(result.ok, true); assert.equal(result.syntheticOnly, true); assert.equal(result.usage.total_tokens, 2000);
  assert.equal(JSON.stringify(result).includes(SECRET), false); assert.equal(JSON.stringify(result).includes('MARKER'), false);
  const wrong = await preflight.liveProbe(env(), async () => contentResponse({metrics: [{name: 'MARKER', value: '99', unit: 'MG'}]}));
  assert.equal(wrong.ok, false); assert.equal(wrong.code, 'PROBE_CONTENT_MISMATCH');
  const noUsage = await preflight.liveProbe(env(), async () => response(envelope({metrics: [{name: 'MARKER', value: '42', unit: 'MG'}]}, {usage: {}})));
  assert.equal(noUsage.ok, false); assert.equal(noUsage.code, 'PROBE_USAGE_MISSING');
});

test('ambiguous preflight modes and config arguments cannot accidentally run a live request', async () => {
  for (const args of [['--check', '--live'], ['--live', '--check'], ['--check', '--init'], ['--check', '--check'], ['--config', '--live'], ['--config', 'one', '--config', 'two']]) {
    let called = false;
    await assert.rejects(preflight.main(args, {fetchImpl() { called = true; }}), error => error.code === 'ARGUMENT_INVALID');
    assert.equal(called, false);
  }
});
