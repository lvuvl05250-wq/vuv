'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {readContent, normalizeResult} = require('../cloudfunctions/weihuoApi/model-result');
const planInput = {startDate: '2026-10-05', dayCount: 3, minutes: 10, actions: [{id: 'walk'}]};
const labelText = '每100g\n能量 840kJ\n蛋白质 6g\n碳水化合物 20g\n脂肪 8g\n配料：牛奶、燕麦';
const label = () => ({name: '燕麦饮品', ingredients: '牛奶、燕麦', servingBasis: 'per100g', energyValue: '840', energyUnit: 'kJ', protein: '6', carbs: '20', fat: '8', evidence: {servingBasis: '每100g', energyValue: '能量 840kJ', protein: '蛋白质 6g', carbs: '碳水化合物 20g', fat: '脂肪 8g'}});

test('JSON fences and prose surrounding a JSON object remain usable without losing the original text', () => {
  assert.deepEqual(readContent('```json\n{"minutes":"5"}\n```'), {minutes: '5'});
  const source = '以下是建议 {仅供参考}：\n{"minutes":"5","mood":"看到 {树叶} 很开心"}\n你可以再调整。';
  const read = readContent(source);
  assert.equal(read.minutes, '5'); assert.equal(read.body, source);
  const actual = normalizeResult('parseState', {}, read);
  assert.equal(actual.minutes, 5); assert.equal(actual.body, source); assert.equal(actual.mood, '看到 {树叶} 很开心');
});
test('incomplete JSON and plain prose are available as body on every consumer result', () => {
  for (const task of ['parseState', 'summarizeProfile', 'explainActions', 'analyzeMeal', 'extractReport', 'generatePlan', 'generateTicketTitle', 'mealDayReview', 'analyzeFoodLabel']) {
    for (const source of ['今天可以先休息一会儿。', '{"days":[']) assert.equal(normalizeResult(task, planInput, source).body, source, task);
  }
  const plan = normalizeResult('generatePlan', planInput, '可以在周末散步。');
  assert.deepEqual(plan.days, []); assert.equal(plan.note, '可以在周末散步。');
});
test('numeric strings and Chinese scene names normalize without replacing good sibling fields', () => {
  const actual = normalizeResult('parseState', {}, {energy: '3', minutes: '5 分钟', scene: '在家', mood: '想走走', extra: '不影响现有字段'});
  assert.equal(actual.energy, 3); assert.equal(actual.minutes, 5); assert.equal(actual.scene, 'home'); assert.equal(actual.mood, '想走走');
  const meal = normalizeResult('analyzeMeal', {}, {name: '午餐', kcalMin: '400 kcal', kcalMax: '300', protein: '20克', carbs: '-2', fat: '不清楚'});
  assert.deepEqual([meal.kcalMin, meal.kcalMax, meal.protein, meal.carbs, meal.fat], [300, 400, 20, null, null]);
});
test('blank, arrays, objects, booleans, negative and nonfinite numerics never become zero or NaN', () => {
  for (const invalid of [' ', [], [5], {}, true, false, '-1', -1, Infinity, NaN, '1e999', '0x10']) {
    const actual = normalizeResult('analyzeMeal', {}, {name: '保留名称', protein: invalid, carbs: '12'});
    assert.equal(actual.protein, null, String(invalid)); assert.equal(actual.carbs, 12); assert.equal(actual.name, '保留名称');
  }
  assert.equal(normalizeResult('analyzeMeal', {}, {protein: '0'}).protein, 0);
});
test('partial OCR fields and numbers are presented as editable text, never as a diagnosis field', () => {
  const actual = normalizeResult('extractReport', {}, {items: [null, {item: '血糖', value: 5.1, range: '见报告'}, {name: '字迹不清'}, {}], diagnosis: 'ignored', note: '请核对单位'});
  assert.deepEqual(actual.metrics, [{name: '血糖', value: '5.1', unit: '', reference: '见报告'}, {name: '字迹不清', value: '', unit: '', reference: ''}]);
  assert.equal(actual.note, '请核对单位'); assert.equal(actual.diagnosis, undefined);
});
test('plan days stay editable, dates follow the request, and unknown actions are omitted individually', () => {
  const actual = normalizeResult('generatePlan', planInput, {days: [{date: 'wrong', minutes: '-3', details: '保留说明', actionIds: ['walk', 'unknown', 'walk']}, {minutes: '30', description: '第二天'}]});
  assert.equal(actual.days[0].date, '2026-10-05'); assert.equal(actual.days[0].minutes, null); assert.deepEqual(actual.days[0].actionIds, ['walk']);
  assert.equal(actual.days[1].minutes, 10); assert.equal(actual.days[1].details, '第二天');
  assert.deepEqual(normalizeResult('generatePlan', planInput, {}).days, []);
  assert.equal(normalizeResult('generatePlan', {}, {days: [{minutes: 3}]}).days[0].date, '');
});
test('one unsupported profile restriction cannot erase supported candidates or existing user data', () => {
  const profile = {restrictions: ['wrist'], bodyNotes: '脚踝受伤，先避免跳跃。没有膝盖疼痛。', avoidedActivities: '不喜欢跳跃', allergies: '牛奶'};
  const before = structuredClone(profile);
  const actual = normalizeResult('summarizeProfile', {profile}, {summary: '保持日常记录。', restrictions: ['ankle', 'knee', 'diabetes'], restrictionEvidence: [{tag: 'ankle', text: '脚踝受伤，先避免跳跃'}, {tag: 'knee', text: '膝盖疼痛'}, {tag: 'diabetes', text: '血糖5.1'}], allergies: '花生', avoidedActivities: '禁止全部运动'});
  assert.equal(actual.summary, '保持日常记录。'); assert.deepEqual(actual.restrictions, ['wrist', 'ankle']);
  assert.deepEqual(actual.restrictionEvidence, [{tag: 'ankle', text: '脚踝受伤，先避免跳跃'}]);
  assert.equal(actual.allergies, '牛奶'); assert.equal(actual.avoidedActivities, '不喜欢跳跃'); assert.deepEqual(profile, before);
});
test('label numeric strings keep exact label values with supplied text, even when evidence fields are omitted', () => {
  for (const withEvidence of [true, false]) {
    const result = label(); if (!withEvidence) delete result.evidence;
    const actual = normalizeResult('analyzeFoodLabel', {text: labelText, hasImages: false}, result);
    assert.deepEqual([actual.servingBasis, actual.energyValue, actual.energyUnit, actual.protein, actual.carbs, actual.fat], ['per100g', 840, 'kJ', 6, 20, 8]);
    assert.equal(actual.evidence.protein, '蛋白质 6g'); assert.deepEqual(actual.uncertainFields, []);
  }
});
test('ingredients alone never authorize invented label nutrition or serving basis', () => {
  for (const input of [{text: '配料：牛奶、燕麦', hasImages: false}, {text: '配料：蛋白质 6g、碳水化合物 20g、脂肪 8g', hasImages: false}, {text: '', hasImages: false}]) {
    const actual = normalizeResult('analyzeFoodLabel', input, label());
    assert.equal(actual.name, '燕麦饮品'); assert.equal(actual.ingredients, '牛奶、燕麦');
    assert.deepEqual([actual.servingBasis, actual.energyValue, actual.energyUnit, actual.protein, actual.carbs, actual.fat], ['unknown', null, null, null, null, null]);
    assert.ok(actual.uncertainFields.includes('energyValue'));
  }
});
test('unreadable image nutrition stays empty while independently transcribed fields remain reviewable', () => {
  const result = label(); result.protein = '15'; result.evidence.protein = '蛋白质 6g，NRV 15%'; delete result.evidence.fat;
  const actual = normalizeResult('analyzeFoodLabel', {hasImages: true}, result);
  assert.equal(actual.protein, null); assert.equal(actual.fat, null); assert.equal(actual.energyValue, 840); assert.equal(actual.carbs, 20);
  assert.deepEqual(actual.uncertainFields, ['protein', 'fat']);
});
test('thresholds and explicitly uncertain fields stay empty instead of acquiring false precision', () => {
  const result = label(); result.evidence.protein = '蛋白质 <6g'; result.uncertainFields = ['energyUnit', 'carbs', 'bogus', 'carbs'];
  const actual = normalizeResult('analyzeFoodLabel', {hasImages: true}, result);
  assert.equal(actual.energyValue, null); assert.equal(actual.energyUnit, null); assert.equal(actual.carbs, null); assert.equal(actual.protein, null); assert.equal(actual.fat, 8);
  assert.equal(new Set(actual.uncertainFields).size, actual.uncertainFields.length); assert.ok(!actual.uncertainFields.includes('bogus'));
});
test('JSON pollution keys and excessive numeric values cannot reach normalized data', () => {
  const raw = readContent('{"__proto__":{"polluted":true},"constructor":{},"protein":1e999,"fat":"2"}');
  assert.equal({}.polluted, undefined); assert.equal(Object.hasOwn(raw, '__proto__'), false);
  const actual = normalizeResult('analyzeMeal', {}, raw); assert.equal(actual.protein, null); assert.equal(actual.fat, 2);
});
