'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let dialogs = [], navigation = [], reply, failWrites = false;
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => {
    if (failWrites) throw new Error('test: storage full');
    disk.set(key, JSON.parse(JSON.stringify(value)));
  },
  showToast() {},
  showModal(options) {
    dialogs.push(options);
    if (reply) reply(options);
    else if (options.success) options.success({confirm: true});
  },
  switchTab: options => navigation.push(options.url),
  navigateTo: options => navigation.push(options.url)
};
const store = require(path.join(root, 'services/store'));

function tab() {
  let definition;
  global.Component = value => { definition = value; };
  const file = path.join(root, 'custom-tab-bar/index.js');
  delete require.cache[require.resolve(file)]; require(file);
  return Object.assign({data: JSON.parse(JSON.stringify(definition.data)), setData(patch) { Object.assign(this.data, patch); }}, definition.methods);
}
function actions() {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages/actions/index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const tabs = tab();
  const instance = Object.assign({}, definition, {
    data: JSON.parse(JSON.stringify(definition.data)),
    getTabBar: () => tabs,
    setData(patch) { Object.assign(this.data, patch); }
  });
  instance.onShow();
  return {page: instance, tabs};
}
const input = (field, value) => ({currentTarget: {dataset: {field}}, detail: {value}});

test.beforeEach(() => { failWrites = false; reply = undefined; dialogs = []; navigation = []; store.clearAll(); });

test('opening a custom action hides the tab bar; untouched close restores it without a dialog', async () => {
  const {page, tabs} = actions();
  assert.equal(tabs.data.hiddenForModal, false);
  page.openCustom();
  assert.equal(page.data.showCustom, true);
  assert.equal(tabs.data.hiddenForModal, true);
  await page.closeCustom();
  assert.equal(page.data.showCustom, false);
  assert.equal(tabs.data.hiddenForModal, false);
  assert.equal(dialogs.length, 0);
});

test('canceling a dirty close keeps every field, leaves the tab bar hidden and does not save', async () => {
  const {page, tabs} = actions(); page.openCustom();
  page.customInput(input('title', '给自己读一页诗'));
  page.customInput(input('minutes', '5'));
  page.customInput(input('steps', '找到喜欢的一页\n读出声音'));
  page.customCategory({currentTarget: {dataset: {value: 'focus'}}});
  reply = options => options.success({confirm: false});
  await page.closeCustom();
  assert.equal(page.data.showCustom, true);
  assert.equal(tabs.data.hiddenForModal, true);
  assert.equal(page.data.customTitle, '给自己读一页诗');
  assert.equal(page.data.customMinutes, '5');
  assert.equal(page.data.customSteps, '找到喜欢的一页\n读出声音');
  assert.equal(page.data.customCategory, 'focus');
  assert.equal(store.getCustomActions().length, 0);
  assert.equal(dialogs.length, 1);
});

test('confirming discard closes once and a subsequent new draft starts clean', async () => {
  const {page, tabs} = actions(); page.openCustom();
  page.customInput(input('title', '尚未保存的行动'));
  let pending;
  reply = options => { pending = options; };
  const closing = page.closeCustom();
  await page.closeCustom();
  assert.equal(dialogs.length, 1);
  pending.success({confirm: true}); await closing;
  assert.equal(page.data.showCustom, false);
  assert.equal(tabs.data.hiddenForModal, false);
  assert.equal(store.getCustomActions().length, 0);
  page.openCustom();
  assert.equal(page.data.customTitle, '');
  assert.equal(tabs.data.hiddenForModal, true);
});

test('an unchanged existing action and reverted edits do not require discard confirmation', async () => {
  const saved = store.saveCustomAction({title: '读一页', durationMinutes: 3, kind: 'care', category: 'focus', steps: ['打开书']});
  const {page, tabs} = actions();
  page.editCustom({currentTarget: {dataset: {id: saved.id}}});
  page.customInput(input('title', '临时新标题'));
  page.customInput(input('title', '读一页'));
  await page.closeCustom();
  assert.equal(dialogs.length, 0);
  assert.equal(tabs.data.hiddenForModal, false);
  assert.equal(store.getCustomActions()[0].title, '读一页');
});

test('saving restores tabs only after persistence succeeds; a failed write keeps the draft open', () => {
  const {page, tabs} = actions(); page.openCustom();
  page.customInput(input('title', '读一页诗'));
  failWrites = true; page.saveCustom(); failWrites = false;
  assert.equal(page.data.showCustom, true);
  assert.equal(tabs.data.hiddenForModal, true);
  assert.equal(page.data.customTitle, '读一页诗');
  assert.equal(page.data.saving, false);
  assert.equal(store.getCustomActions().length, 0);
  page.saveCustom();
  assert.equal(page.data.showCustom, false);
  assert.equal(tabs.data.hiddenForModal, false);
  assert.equal(store.getCustomActions()[0].title, '读一页诗');
});

test('leaving restores tabs, returning restores the open draft, and unload cannot leave tabs hidden', async () => {
  const {page, tabs} = actions(); page.openCustom();
  page.customInput(input('title', '还没写完'));
  page.onHide();
  assert.equal(tabs.data.hiddenForModal, false);
  assert.equal(page.data.showCustom, true);
  page.onShow();
  assert.equal(tabs.data.hiddenForModal, true);
  assert.equal(page.data.customTitle, '还没写完');
  let pending;
  reply = options => { pending = options; };
  const closing = page.closeCustom();
  page.onUnload();
  assert.equal(tabs.data.hiddenForModal, false);
  page.setData = () => { throw new Error('setData after unload'); };
  pending.success({confirm: true}); await closing;
  assert.equal(tabs.data.hiddenForModal, false);
});

test('hidden tabs reject a queued tap and visible tabs remain usable', () => {
  const tabs = tab();
  tabs.setData({hiddenForModal: true});
  tabs.change({currentTarget: {dataset: {index: 1}}});
  assert.deepEqual(navigation, []);
  tabs.setData({hiddenForModal: false});
  tabs.change({currentTarget: {dataset: {index: 1}}});
  assert.deepEqual(navigation, ['/pages/meals/index']);
});
