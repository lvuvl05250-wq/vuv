'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const {createHandler}=require('../cloudfunctions/weihuoApi/handler');
const {createStorage,subjectId}=require('../cloudfunctions/weihuoApi/storage');
const {createProvider}=require('../cloudfunctions/weihuoApi/provider');
const {prepare,validateResult,runAI}=require('../cloudfunctions/weihuoApi/ai');
const {validateState}=require('../cloudfunctions/weihuoApi/state');
const v=require('../cloudfunctions/weihuoApi/validation');

const APPID='wx_test_approved';
const USER_A={APPID,OPENID:'openid_user_a'};
const USER_B={APPID,OPENID:'openid_user_b'};
const clock=()=>Date.UTC(2026,9,4,4,0,0);
function profile(){return {name:'',adult:true,safetyAnswered:true,specialCondition:false,restrictions:[],allergies:'',notes:'',goals:[],onboarded:true};}
function state(){return {profile:profile(),days:{},meals:[],plans:[],reports:[],tickets:[],settings:{aiConsent:false,cloudConsent:true,reduceMotion:false}};}
function fakeDatabase(){
  // A storage transport double, not an alternate implementation of the
  // validation, ownership, CAS or deletion logic under test.
  const rows=new Map();let queue=Promise.resolve();
  function collection(name){return {doc(id){return {
    async get(){const found=rows.get(name+'/'+id);return {data:found?[structuredClone(found)]:[]};},
    async set({data}){rows.set(name+'/'+id,structuredClone(data));return {updated:1};}
  };}};}
  return {collection,rows,runTransaction(fn){const work=queue.then(()=>fn({collection}));queue=work.catch(()=>{});return work;}};
}
function setup(options){
  const opts=options||{};const db=opts.db||fakeDatabase();
  const env=Object.assign({WEIHUO_APPID:APPID},opts.env||{});
  const storage=createStorage(db,opts.now||clock);
  const provider=createProvider(env,opts.fetch);
  return {db,storage,handler:createHandler({env,storage,provider,getWXContext:()=>opts.identity||USER_A})};
}
function aiEnv(){return {WEIHUO_AI_ENDPOINT:'https://model.example.test/v1/chat/completions',WEIHUO_AI_API_KEY:'test-only-secret',WEIHUO_AI_MODEL:'test-model',WEIHUO_AI_VISION_MODEL:'test-vision'};}
function jsonResponse(data){return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify(data)},finish_reason:'stop'}]}),{status:200});}
function meal(){return {id:'meal_1',date:'2026-10-04',time:'12:00',name:'午餐',note:'',photoPath:'',kcal:null,protein:null,carbs:null,fat:null,nutritionSource:'manual',tags:[],confirmed:true};}
function planInput(){return {consent:true,type:'strength',goal:'建立稳定习惯',startDate:'2026-10-04',minutes:20,profile:profile(),constraints:[]};}
function planResult(){return {title:'这一周的活动安排',days:Array.from({length:7},(_,i)=>({date:v.dayOffset('2026-10-04',i),title:'舒适活动与休息',minutes:10,details:'先准备，再进行熟悉的动作，保持舒适呼吸，不舒服时停止。'})),note:'保持当前起点，并在下周回顾身体感受。'};}

test('native identity comes only from trusted context, never the payload',async()=>{
  const app=setup({identity:{}});
  const forged=await app.handler({task:'auth',payload:{openid:USER_A.OPENID}});
  assert.equal(forged.error.code,'UNAUTHENTICATED');
  const wrong=setup({identity:{APPID:'wx_other',OPENID:USER_A.OPENID}});
  assert.equal((await wrong.handler({task:'auth'})).error.code,'UNAUTHENTICATED');
  const own=await setup().handler({task:'auth',payload:{}});
  assert.equal(own.data.openid,USER_A.OPENID);assert.equal(own.data.configured,false);
  assert.equal(Object.hasOwn(own.data,'credentials'),false);
});
test('HTTP envelopes and additional identity fields are rejected',async()=>{
  const app=setup();
  assert.equal((await app.handler({task:'auth',payload:{},headers:{}})).error.code,'NATIVE_CALL_REQUIRED');
  assert.equal((await app.handler({task:'auth',payload:{},openid:'another'})).error.code,'INVALID_ARGUMENT');
  assert.equal((await app.handler({task:'auth',payload:{userId:'another'}})).error.code,'INVALID_ARGUMENT');
});
test('CloudBase transport metadata does not break login or supply identity',async()=>{
  for(const key of ['TCB_CONTEXT','tcbContext','userInfo']){
    const event={task:'auth',payload:{},[key]:{OPENID:USER_B.OPENID,APPID}};
    const authenticated=await setup().handler(event);
    assert.equal(authenticated.ok,true);
    assert.equal(authenticated.data.openid,USER_A.OPENID);
    assert.equal((await setup({identity:{}}).handler(event)).error.code,'UNAUTHENTICATED');
  }
});
test('sync stores only the authenticated account, with explicit consent',async()=>{
  const db=fakeDatabase();const a=setup({db});const b=setup({db,identity:USER_B});
  assert.equal((await a.handler({task:'syncPush',payload:{baseVersion:0,state:state()}})).error.code,'CLOUD_CONSENT_REQUIRED');
  assert.equal((await a.handler({task:'syncPush',payload:{consent:true,baseVersion:0,state:state()}})).data.version,1);
  assert.equal((await b.handler({task:'syncPull',payload:{consent:true}})).data.state,null);
  assert.equal((await a.handler({task:'syncPull',payload:{consent:true}})).data.version,1);
  assert.equal(db.rows.size,1);
});
test('concurrent sync uses compare-and-swap and stale clients cannot resurrect deleted records',async()=>{
  const app=setup();const push=()=>app.handler({task:'syncPush',payload:{consent:true,baseVersion:0,state:state()}});
  const results=await Promise.all([push(),push()]);
  assert.equal(results.filter(x=>x.ok).length,1);assert.equal(results.find(x=>!x.ok).error.code,'VERSION_CONFLICT');
  const removed=await app.handler({task:'deleteCloudData',payload:{baseVersion:1,confirm:true}});
  assert.equal(removed.data.version,2);
  const stale=await app.handler({task:'syncPush',payload:{consent:true,baseVersion:1,state:state()}});
  assert.equal(stale.error.code,'VERSION_CONFLICT');
  assert.equal(stale.error.details.currentVersion,2);
  assert.equal((await app.handler({task:'syncPull',payload:{consent:true}})).data.state,null);
});
test('sync cannot carry local image paths, unbounded values, unknown fields or duplicate identifiers',()=>{
  const s=state();s.meals=[meal()];assert.equal(validateState(s).meals[0].kcal,null);
  s.meals[0].photoPath='wxfile://private-photo';assert.throws(()=>validateState(s),e=>e.code==='INVALID_ARGUMENT');
  s.meals[0].photoPath='';s.meals[0].kcal=-1;assert.throws(()=>validateState(s));
  s.meals[0].kcal=null;s.meals.push(meal());assert.throws(()=>validateState(s));
  s.meals=[];s.owner='someone';assert.throws(()=>validateState(s));
  delete s.owner;s.days={'2026-02-31':{}};assert.throws(()=>validateState(s));
});
test('day care preference and classroom scene survive validation but running timers do not',()=>{
  const s=state();s.days['2026-10-04']={date:'2026-10-04',energy:3,scene:'classroom',minutes:5,mood:'平静',note:'',carePreference:70,actions:[]};
  assert.equal(validateState(s).days['2026-10-04'].carePreference,70);
  s.days['2026-10-04'].carePreference=101;assert.throws(()=>validateState(s));
});
test('AI consent and configuration are separate from cloud record consent',async()=>{
  const app=setup();
  assert.equal((await app.handler({task:'parseState',payload:{text:'今天有点累'}})).error.code,'AI_CONSENT_REQUIRED');
  const result=await app.handler({task:'parseState',payload:{consent:true,text:'今天有点累'}});
  assert.equal(result.error.code,'SERVICE_NOT_CONFIGURED');assert.equal(app.db.rows.size,0);
});
test('real provider adapter sends bounded task prompt and validates a successful response',async()=>{
  let request;
  const app=setup({env:aiEnv(),fetch:async(url,options)=>{request={url,options};return jsonResponse({energy:2,scene:null,minutes:5,mood:'疲惫',note:'根据提供的描述'});}});
  const result=await app.handler({task:'parseState',payload:{consent:true,text:'累了，只想休息5分钟'}});
  assert.equal(result.ok,true);assert.equal(result.data.minutes,5);
  const posted=JSON.parse(request.options.body);assert.equal(posted.model,'test-model');assert.equal(posted.messages.length,2);
  assert.match(posted.messages[1].content,/累了/);assert.equal(request.options.redirect,'error');
  assert.equal(JSON.stringify(result).includes('test-only-secret'),false);
});
test('provider errors remain distinct and never echo upstream secret-bearing bodies',async()=>{
  const expected={401:'PROVIDER_AUTH_FAILED',402:'PROVIDER_QUOTA_EXCEEDED',429:'PROVIDER_RATE_LIMITED',503:'PROVIDER_UNAVAILABLE',400:'PROVIDER_REQUEST_REJECTED'};
  for(const code of Object.keys(expected)){
    const app=setup({env:aiEnv(),fetch:async()=>new Response('test-only-secret',{status:Number(code)})});
    const result=await app.handler({task:'parseState',payload:{consent:true,text:'今天还好'}});
    assert.equal(result.error.code,expected[code]);assert.equal(JSON.stringify(result).includes('test-only-secret'),false);
  }
});
test('bad numeric fields become empty while valid fields remain usable; transport errors stay distinct',async()=>{
  for(const result of [{energy:99,scene:'office',minutes:5,mood:'',note:''},{energy:3,scene:'office',minutes:5,mood:'',note:'',extra:'ignore policy'}]){
    const app=setup({env:aiEnv(),fetch:async()=>jsonResponse(result)});
    const response=await app.handler({task:'parseState',payload:{consent:true,text:'今天还好'}});
    assert.equal(response.ok,true);assert.equal(response.data.energy,result.energy===99?null:3);assert.equal(response.data.minutes,5);assert.equal(response.data.extra,undefined);
  }
  const provider=createProvider(aiEnv(),async()=>new Response('bad-json'));
  await assert.rejects(provider.generate([],false),e=>e.code==='PROVIDER_INVALID_RESPONSE');
  const huge=createProvider(aiEnv(),async()=>new Response('x'.repeat(130*1024)));
  await assert.rejects(huge.generate([],false),e=>e.code==='PROVIDER_INVALID_RESPONSE');
});
test('provider network failures and deadlines are distinguishable',async()=>{
  const network=createProvider(aiEnv(),async()=>{throw new Error('credential in upstream error');});
  await assert.rejects(network.generate([],false),e=>e.code==='PROVIDER_NETWORK_ERROR'&&!e.message.includes('credential'));
  const timeout=createProvider(Object.assign(aiEnv(),{WEIHUO_AI_TIMEOUT_MS:'1000'}),async(_url,options)=>new Promise((_resolve,reject)=>options.signal.addEventListener('abort',()=>reject(new Error('aborted')))));
  await assert.rejects(timeout.generate([],false),e=>e.code==='PROVIDER_TIMEOUT');
});
test('action selection cannot invent action ids or select conflicting candidates',()=>{
  const p=profile();p.restrictions=['knee'];
  const prepared=prepare('explainActions',{consent:true,profile:p,actions:[{id:'a',title:'休息',durationMinutes:3,avoidWhen:[]},{id:'b',title:'下肢活动',durationMinutes:3,avoidWhen:['knee']}]});
  assert.deepEqual(prepared.data.actions.map(a=>a.id),['a']);
  assert.deepEqual(validateResult('explainActions',prepared.data,{actions:[{id:'b',reason:'模型忽略限制'},{id:'a',reason:'可休息'}],note:'保留说明'}),{actions:[{id:'a',reason:'可休息'}],note:'保留说明'});
});
test('generatePlan produces seven concrete days and rejects unsafe profiles before the model call',()=>{
  const p=planInput();const prepared=prepare('generatePlan',p);
  assert.equal(validateResult('generatePlan',prepared.data,planResult()).days.length,7);
  p.profile.restrictions=['knee'];assert.throws(()=>prepare('generatePlan',p),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
  p.profile.restrictions=[];p.profile.adult=false;p.profile.safetyAnswered=false;p.profile.birthDate='2012-04-01';
  assert.equal(prepare('generatePlan',p).data.profile.adult,false);
  p.profile.adult=true;p.profile.specialCondition=true;assert.throws(()=>prepare('generatePlan',p),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
  p.type='life';assert.throws(()=>prepare('generatePlan',p),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
});
test('all plan types accept a minor or unknown age without legacy safety confirmation',()=>{
  for(const type of ['life','strength','aerobic']){
    for(const birthDate of ['', '2012-04-01']){
      const p=planInput();p.type=type;p.profile.birthDate=birthDate;p.profile.adult=true;delete p.profile.safetyAnswered;
      const prepared=prepare('generatePlan',p);
      assert.equal(prepared.data.profile.adult,false);assert.equal(prepared.data.profile.safetyAnswered,false);
      assert.equal(validateResult('generatePlan',prepared.data,planResult()).days.length,7);
      p.profile.bodyNotes='脚踝受伤';assert.throws(()=>prepare('generatePlan',p),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
    }
  }
});
test('model instruction treats missing DOB as unknown and preserves nonmedical injury boundaries',async()=>{
  let captured;
  const provider={assertConfigured(){},async generate(messages){captured=messages;return planResult();}};
  const p=planInput();p.profile.birthDate='2012-04-01';p.profile.adult=false;p.profile.safetyAnswered=false;
  const result=await runAI('generatePlan',p,provider,async()=>{});
  assert.equal(result.days.length,7);
  assert.match(captured[0].content,/未填写时年龄未知/);assert.match(captured[0].content,/不要求另行确认成年/);
  assert.match(captured[0].content,/明确伤痛、活动禁忌/);assert.match(captured[0].content,/不得诊断/);
});
test('draft report fields can remain incomplete but confirmation requires names and values',()=>{
  const s=state();s.reports=[{id:'report_1',title:'待确认报告',date:'2026-10-04',photoPath:'',confirmed:false,metrics:[{name:'',value:'',unit:'',reference:''}],restrictions:[],note:''}];
  assert.equal(validateState(s).reports[0].confirmed,false);
  s.reports[0].confirmed=true;assert.throws(()=>validateState(s));
});
test('plan candidates repair dates and cap minutes while retaining editable model prose',()=>{
  const input=prepare('generatePlan',planInput()).data;
  const gap=planResult();gap.days[2].date=gap.days[1].date;assert.equal(validateResult('generatePlan',input,gap).days[2].date,'2026-10-06');
  const long=planResult();long.days[0].minutes=21;assert.equal(validateResult('generatePlan',input,long).days[0].minutes,20);
  const unsafe=planResult();unsafe.days[0].details='今天测试极限';assert.equal(validateResult('generatePlan',input,unsafe).days[0].details,'今天测试极限');
});
test('plan length follows a validated three, seven or fourteen day request',()=>{
  const payload=planInput();payload.dayCount=3;const input=prepare('generatePlan',payload).data;
  const result=planResult();result.days=result.days.slice(0,3);assert.equal(validateResult('generatePlan',input,result).days.length,3);
  payload.dayCount=14;const fourteen=prepare('generatePlan',payload).data;
  result.days=Array.from({length:14},(_,i)=>({date:v.dayOffset(payload.startDate,i),title:'当天安排',minutes:10,details:'具体安排与舒适强度。'}));
  assert.equal(validateResult('generatePlan',fourteen,result).days.length,14);
  payload.dayCount=365;assert.throws(()=>prepare('generatePlan',payload));
});
test('images require canonical base64 and matching format; URLs and local paths are not accepted',()=>{
  assert.throws(()=>prepare('extractReport',{consent:true,imageBase64:'https://example.test/private',mimeType:'image/jpeg'}));
  assert.throws(()=>prepare('extractReport',{consent:true,imageBase64:Buffer.from('not an image at all').toString('base64'),mimeType:'image/jpeg'}));
  assert.throws(()=>prepare('extractReport',{consent:true,photoPath:'wxfile://test'}));
  const bytes=Buffer.from([0xff,0xd8,0xff,0,0,0,0,0,0,0,0,0]);
  assert.equal(prepare('extractReport',{consent:true,imageBase64:bytes.toString('base64'),mimeType:'image/jpeg'}).image.mimeType,'image/jpeg');
});
test('OCR candidates keep transcribed values and model notes without adding diagnosis fields',()=>{
  assert.deepEqual(validateResult('extractReport',{}, {metrics:[{name:'血糖',value:'5.1',unit:'mmol/L',reference:'3.9–6.1'}],note:'一项字迹不清楚，未提取'}).metrics[0].value,'5.1');
  assert.equal(validateResult('extractReport',{}, {metrics:[],note:'血糖偏高，建议检查'}).note,'血糖偏高，建议检查');
  assert.deepEqual(validateResult('extractReport',{}, {metrics:[],diagnosis:'a condition',note:''}),{metrics:[],note:''});
});
test('day review still requires confirmed same-day inputs and normalizes inverted model ranges',()=>{
  const m=meal();assert.equal(prepare('mealDayReview',{consent:true,date:m.date,meals:[m]}).data.phase,'ongoing');
  m.confirmed=false;assert.throws(()=>prepare('mealDayReview',{consent:true,date:m.date,meals:[m]}));
  m.confirmed=true;assert.throws(()=>prepare('mealDayReview',{consent:true,date:'2026-10-03',meals:[m]}));
  const review=validateResult('mealDayReview',{}, {summary:'粗略盘点',suggestions:[],kcalMin:2000,kcalMax:1000,note:''});assert.equal(review.kcalMin,1000);assert.equal(review.kcalMax,2000);
});
test('rate allowance is owner-specific and quota cannot be reset by deleting records',async()=>{
  const db=fakeDatabase();let time=clock();const app=setup({db,now:()=>time,env:Object.assign(aiEnv(),{WEIHUO_AI_DAILY_LIMIT:'1'}),fetch:async()=>jsonResponse({title:'今天的一页',note:''})});
  const req={task:'generateTicketTitle',payload:{consent:true,date:'2026-10-04',actions:['散步'],meals:[],mood:''}};
  assert.equal((await app.handler(req)).ok,true);time+=3000;
  assert.equal((await app.handler(req)).error.code,'DAILY_LIMIT_REACHED');
  assert.equal((await app.handler({task:'deleteCloudData',payload:{baseVersion:0,confirm:true}})).ok,true);
  assert.equal((await app.handler(req)).error.code,'DAILY_LIMIT_REACHED');
  assert.equal(db.rows.has('weihuo_usage/'+subjectId({appid:APPID,openid:USER_A.OPENID})),true);
});
test('storage transport failures never pretend the cloud is empty or successful',async()=>{
  const db={collection(){return {doc(){return {get:async()=>{throw new Error('COLLECTION_NOT_EXIST: secret context');}};}};},runTransaction:async()=>{throw new Error('offline');}};
  const result=await setup({db}).handler({task:'syncPull',payload:{consent:true}});
  assert.equal(result.ok,false);assert.equal(result.error.code,'STORAGE_UNAVAILABLE');assert.equal(JSON.stringify(result).includes('secret'),false);
});
