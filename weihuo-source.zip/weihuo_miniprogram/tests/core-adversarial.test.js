'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const ROOT='../miniprogram/';
function harness(){
  const previousWx=global.wx;
  const storage=new Map(),removed=[],calls=[],dialogs=[];
  for(const path of ['services/store','services/api','services/media'])delete require.cache[require.resolve(ROOT+path)];
  const config=require(ROOT+'config');const oldEnv=config.cloudEnv;config.cloudEnv='test-environment';
  global.wx={
    getStorageSync:key=>storage.has(key)?structuredClone(storage.get(key)):'',
    setStorageSync:(key,value)=>storage.set(key,structuredClone(value)),
    getStorageInfoSync:()=>({keys:Array.from(storage.keys())}),
    removeSavedFile(options){removed.push(options.filePath);if(options.success)options.success({});if(options.complete)options.complete({});},
    showModal(options){dialogs.push(options.title);options.success({confirm:true,cancel:false});},
    cloud:{async callFunction(options){calls.push(structuredClone(options.data));return {result:{ok:true,data:options.data.task==='auth'?{openid:'wx_user_123',configured:true}:{summary:'记录已阅读',suggestions:[],kcalMin:null,kcalMax:null,note:''}}};}}
  };
  const store=require(ROOT+'services/store');store.init();
  return {store,api:require(ROOT+'services/api'),media:require(ROOT+'services/media'),storage,removed,calls,dialogs,close(){config.cloudEnv=oldEnv;global.wx=previousWx;}};
}

test('failed persistence leaves both memory and on-disk data unchanged',()=>{
  const h=harness();try{
    h.store.saveProfile({name:'before'});const prior=h.store.getState();const revision=h.store.getRevision();
    global.wx.setStorageSync=()=>{throw new Error('disk full');};
    assert.throws(()=>h.store.saveProfile({name:'after'}),/保存失败/);
    assert.deepEqual(h.store.getState(),prior);assert.equal(h.store.getRevision(),revision);
    assert.equal(h.storage.get('weihuo:v1:local').state.profile.name,'before');
  }finally{h.close();}
});

test('connecting must preserve an existing account that contains only plans',async()=>{
  const h=harness();try{
    h.store.saveMeal({name:'本机午餐'});
    h.store.switchAccount('wx_user_123');
    const existing=h.store.savePlan({title:'账号原有计划',type:'life',goal:'原目标',source:'manual',days:[{date:h.store.today(),title:'记录',minutes:3,done:false,details:''}],note:''});
    h.store.useLocal();await h.api.connect();
    assert.equal(h.store.getPlans().some(p=>p.id===existing.id),true,'非空账号不可被隐式“迁入”整份覆盖');
  }finally{h.close();}
});

test('removing an account photo must preserve references in the local namespace',async()=>{
  const h=harness();try{
    const local=h.store.saveMeal({name:'有照片的午餐',photoPath:'wxfile://shared-meal'});const backup=h.store.exportData();
    h.store.switchAccount('wx_user_123');h.store.restoreData(backup);
    h.store.deleteMeal(local.id);await h.media.removePhoto('wxfile://shared-meal');
    assert.equal(h.removed.length,0,'另一个本机空间仍持有相同文件引用');
    h.store.useLocal();assert.equal(h.store.getMeals()[0].photoPath,'wxfile://shared-meal');
  }finally{h.close();}
});

test('photo deletion reports a device failure instead of acknowledging completion',async()=>{
  const h=harness();try{
    global.wx.removeSavedFile=options=>{const error={errMsg:'removeSavedFile:fail permission denied'};if(options.fail)options.fail(error);if(options.complete)options.complete(error);};
    await assert.rejects(h.media.removePhoto('wxfile://unreferenced'));
  }finally{h.close();}
});

test('import rejects malformed action metadata before it can break recommendations',()=>{
  const h=harness();try{
    const a=h.store.addAction({title:'手动事项',durationMinutes:3,steps:[],kind:'care'});
    h.store.setActionStatus(a.id,'completed','uncomfortable');
    const backup=JSON.parse(h.store.exportData());backup.state.days[h.store.today()].actions[0].tags='not-an-array';
    assert.throws(()=>h.store.restoreData(JSON.stringify(backup)),'无效tags不能通过导入校验');
  }finally{h.close();}
});

test('meal review uploads structured content without local image paths',async()=>{
  const h=harness();try{
    h.store.saveSettings({aiConsent:true});h.store.saveMeal({name:'午餐',photoPath:'wxfile://private-location'});
    await h.api.request('mealDayReview',{date:h.store.today(),meals:h.store.getMeals(),phase:'ongoing',profile:h.store.getProfile()});
    assert.equal(Object.hasOwn(h.calls[0].payload.meals[0],'photoPath'),false,'AI盘点不需要本机图片地址');
  }finally{h.close();}
});

test('revoking AI consent during photo preparation prevents the later upload',async()=>{
  const h=harness();try{
    h.store.saveSettings({aiConsent:true});let compression;
    global.wx.compressImage=options=>{compression=options;};
    global.wx.getFileSystemManager=()=>({readFile:options=>options.success({data:Buffer.from([255,216,255,0,0,0,0,0,0,0,0,0]).toString('base64')})});
    const pending=h.api.request('extractReport',{photoPath:'wxfile://sensitive-report'});
    h.store.saveSettings({aiConsent:false});
    compression.success({tempFilePath:'wxfile://compressed-report'});
    await assert.rejects(pending,'撤销同意后不应继续发出尚未开始的请求');
    assert.equal(h.calls.length,0);
  }finally{h.close();}
});

test('restoring a cloud snapshot preserves ticket-only local photo references',()=>{
  const h=harness();try{
    const meal=h.store.saveMeal({name:'午餐',photoPath:'wxfile://ticket-only'});const day=h.store.today();
    h.store.sealTicket(day,'当天记录');h.store.deleteMeal(meal.id);
    const cloud=h.api.stripLocal(h.store.getState());h.store.replaceFromCloud(cloud);
    assert.equal(h.store.getTicket(day).meals[0].photoPath,'wxfile://ticket-only','票根快照仍应保留原设备上的原图引用');
  }finally{h.close();}
});
