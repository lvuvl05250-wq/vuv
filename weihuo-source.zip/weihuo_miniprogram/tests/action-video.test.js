'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const clientFile = path.join(__dirname, '../miniprogram/services/action-video.js');
const serverFile = path.join(__dirname, '../cloudfunctions/weihuoApi/action-video.js');
const video = require(clientFile);
const serverVideo = require(serverFile);
const {validateCatalog} = require('../cloudfunctions/weihuoApi/catalog');
const {validateState} = require('../cloudfunctions/weihuoApi/state');
const disk = new Map();
let calls = [], clipboardFailure = '', navigationFailure = '', delayedNavigation = null, deferNavigation = false;
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => disk.set(key, structuredClone(value)),
  showToast: value => calls.push({type: 'toast', title: value.title}),
  showModal: value => value.success({confirm: true}),
  setClipboardData: options => { calls.push({type: 'clipboard', data: options.data}); if (clipboardFailure) options.fail({errMsg: clipboardFailure}); else options.success({}); },
  navigateToMiniProgram: options => {
    calls.push({type: 'navigate', appId: options.appId, path: options.path, envVersion: options.envVersion});
    if (deferNavigation) { delayedNavigation = options; return; }
    if (navigationFailure) options.fail({errMsg: navigationFailure}); else options.success({});
  }
};
const store = require('../miniprogram/services/store');
function resource(patch) { return Object.assign({title: '测试夹具中的视频', url: 'https://media.example.test/reviewed-video', intensity: 'light', equipment: '一把稳固的椅子'}, patch); }
function appResource(patch) { return resource(Object.assign({appId: 'wx0123456789abcdef', path: 'pages/video/index?id=fixture'}, patch)); }
function action(patch) {
  return Object.assign({id: 'reviewed_fixture', title: '测试用视频行动', durationMinutes: 15, steps: ['按审核后的文字说明进行。'], minimumVersion: '只做其中一小段', stopSignal: '感到不舒服时停下', kind: 'movement', category: 'movement', tags: ['fixture'], avoidWhen: ['ankle'], scenes: ['home', 'any'], energyLevels: ['low', 'medium', 'high'], priority: 3, source: 'catalog', video: resource()}, patch);
}
function catalog(items, version) { return {version: version || 'fixture-1', publishedAt: new Date().toISOString(), items: items || [action()]}; }
function publish(item, version) { store.updateCloudCatalog(catalog([item], version)); }
function page(id) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(__dirname, '../miniprogram/pages/action/index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: structuredClone(definition.data)});
  instance.setData = function (patch) { Object.assign(this.data, patch); };
  instance.onLoad({id}); instance.reload();
  return instance;
}

test.beforeEach(() => {
  calls = []; clipboardFailure = ''; navigationFailure = ''; delayedNavigation = null; deferNavigation = false;
  disk.clear(); store.useLocal(); store.clearAll();
});

test('client and cloud video rules remain the exact same source and do not add video seeds', () => {
  assert.equal(fs.readFileSync(clientFile, 'utf8'), fs.readFileSync(serverFile, 'utf8'));
  assert.deepEqual(video.validateVideo(resource()), serverVideo.validateVideo(resource()));
  const bundled = require('../miniprogram/services/catalog');
  assert.equal(bundled.filter(item => item.video).length, 0);
});

test('video validates reviewed metadata, requires an HTTPS URL and rejects unsafe or partial destinations', () => {
  assert.deepEqual(video.validateVideo(appResource()), appResource());
  assert.equal(video.destination(resource({url: 'https://www.bilibili.com/'})).method, 'clipboard');
  assert.equal(video.destination(resource({url: 'https://b23.tv/'})).platformLabel, '哔哩哔哩');
  const invalid = [
    {title: ''}, {equipment: ''}, {equipment: 'x'.repeat(501)}, {intensity: 'extreme'},
    {url: 'http://media.example.test/a'}, {url: 'javascript:alert(1)'}, {url: 'wxfile://video'},
    {url: 'https://user:password@media.example.test/a'}, {url: 'https://127.0.0.1/a'}, {url: 'https://[::1]/a'},
    {url: 'https://localhost/a'}, {url: 'https://internal/a'}, {url: 'https://media.local/a'},
    {url: 'https://media.example.test:8080/a'}, {url: 'https://media.example.test/a\n'},
    {appId: 'wx0123456789abcdef'}, {path: 'pages/video/index'},
    {appId: 'not-an-app-id', path: 'pages/video/index'}, {appId: 'wx0123456789abcdef', path: 'https://example.test'},
    {appId: 'wx0123456789abcdef', path: '../pages/index'}, {appId: 'wx0123456789abcdef', path: '//pages/index'},
    {durationMinutes: 15}, {autoComplete: true}, {extraData: {OPENID: 'forbidden'}}
  ];
  for (const patch of invalid) {
    assert.throws(() => video.validateVideo(resource(patch)), JSON.stringify(Object.keys(patch)));
    assert.throws(() => serverVideo.validateVideo(resource(patch)));
  }
});

test('only a complete app target navigates; HTTPS-only links are copied with a clear next step', async () => {
  const copied = await video.openVideo(resource({url: 'https://www.bilibili.com/'}), wx);
  assert.equal(copied.method, 'clipboard');
  assert.match(copied.message, /到哔哩哔哩或浏览器粘贴打开/);
  assert.equal(calls.filter(call => call.type === 'navigate').length, 0);
  const opened = await video.openVideo(appResource(), wx);
  assert.equal(opened.method, 'miniProgram');
  assert.deepEqual(calls.find(call => call.type === 'navigate'), {type: 'navigate', appId: appResource().appId, path: appResource().path, envVersion: 'release'});
});

test('cancelling system navigation is quiet and failure never silently writes the clipboard', async () => {
  navigationFailure = 'navigateToMiniProgram:fail cancel';
  await assert.rejects(video.openVideo(appResource(), wx), error => error.cancelled === true);
  assert.equal(calls.filter(call => call.type === 'clipboard').length, 0);
  await assert.rejects(video.openVideo(appResource(), {setClipboardData: wx.setClipboardData}), /复制视频链接/);
  assert.equal(calls.filter(call => call.type === 'clipboard').length, 0);
  await video.copyVideo(appResource(), wx);
  assert.equal(calls.filter(call => call.type === 'clipboard').length, 1);
});

test('catalog and cloud state preserve bounded video metadata and reject malformed published resources', () => {
  const row = catalog();
  assert.deepEqual(validateCatalog(row, Date.now() + 100).items[0].video, resource());
  row.items[0].video.appId = 'wx0123456789abcdef';
  assert.throws(() => validateCatalog(row, Date.now() + 100), error => error.code === 'CATALOG_INVALID');
  publish(action());
  const added = store.addAction('reviewed_fixture');
  const cloud = validateState(store.getState());
  assert.deepEqual(cloud.days[store.today()].actions[0].video, added.video);
  cloud.days[store.today()].actions[0].video.url = 'http://example.test/video';
  assert.throws(() => validateState(cloud), error => error.code === 'INVALID_ARGUMENT');
  assert.throws(() => store.updateCloudCatalog(catalog([action({video: {}})])));
});

test('saved actions and ticket snapshots retain the original resource after library updates and backup roundtrips', () => {
  publish(action());
  const added = store.addAction('reviewed_fixture');
  store.setActionStatus(added.id, 'completed');
  store.sealTicket();
  publish(action({video: resource({title: '替换后的视频', url: 'https://media.example.test/new-video'}), durationMinutes: 20}), 'fixture-2');
  assert.equal(store.getAction(added.id).video.title, '测试夹具中的视频');
  assert.equal(store.getTicket().actions[0].video.url, resource().url);
  const editor = page(added.id);
  assert.equal(editor.data.action.video.url, resource().url);
  assert.equal(editor.data.action.durationMinutes, 15);
  const backup = store.exportData(); store.restoreData(backup);
  assert.equal(store.getAction(added.id).video.url, resource().url);
  const state = validateState(store.getState());
  assert.equal(state.tickets[0].actions[0].video.url, resource().url);
});

test('an action saved without video never acquires a later library video, including legacy snapshots', () => {
  const without = action(); delete without.video; publish(without);
  const added = store.addAction('reviewed_fixture');
  assert.equal(added.video, null);
  publish(action(), 'fixture-2');
  assert.equal(page(added.id).data.hasVideo, false);
  const legacy = JSON.parse(store.exportData()); delete legacy.state.days[store.today()].actions[0].video;
  store.restoreData(JSON.stringify(legacy));
  assert.equal(page(added.id).data.hasVideo, false);
});

test('copying, navigation and returning never start timers or mark an action completed', async () => {
  publish(action({video: appResource()}));
  const editor = page('reviewed_fixture');
  const before = store.getState();
  await editor.openVideo(); editor.reload();
  await editor.copyVideoLink(); editor.reload();
  assert.deepEqual(store.getState(), before);
  editor.complete();
  assert.equal(store.getDay().actions.length, 1);
  assert.equal(store.getDay().actions[0].status, 'completed');
  assert.equal(store.getDay().actions[0].timer, undefined);
});

test('new restrictions or recent discomfort cannot be bypassed by a stale video page or copy button', async () => {
  publish(action());
  const editor = page('reviewed_fixture');
  assert.equal(editor.data.blocked, '');
  store.saveProfile({restrictions: ['ankle']});
  await editor.openVideo(); await editor.copyVideoLink();
  assert.equal(calls.filter(call => ['clipboard', 'navigate'].includes(call.type)).length, 0);
  assert.match(editor.data.blocked, /活动限制/);
  assert.equal(store.getDay().actions.length, 0);
  store.saveProfile({restrictions: []});
  publish(action({tags: []}), 'fixture-2');
  const added = store.addAction('reviewed_fixture'); store.setActionStatus(added.id, 'skipped', 'uncomfortable');
  const historical = page(added.id);
  await historical.openVideo();
  assert.match(historical.data.videoError, /不适合开始/);
  assert.equal(calls.filter(call => ['clipboard', 'navigate'].includes(call.type)).length, 0);
});

test('special conditions and changed accounts stop external video actions before platform calls', async () => {
  publish(action());
  const editor = page('reviewed_fixture');
  store.saveProfile({specialCondition: true});
  await editor.openVideo();
  assert.match(editor.data.videoError, /不适合开始/);
  store.switchAccount('video_other_account');
  await editor.copyVideoLink();
  assert.match(editor.data.videoError, /账号已变化/);
  assert.equal(calls.filter(call => ['clipboard', 'navigate'].includes(call.type)).length, 0);
});

test('page shows actionable copy errors, handles cancel quietly, and ignores navigation after unload', async () => {
  publish(action());
  const editor = page('reviewed_fixture');
  clipboardFailure = 'setClipboardData:fail permission denied';
  await editor.openVideo();
  assert.match(editor.data.videoError, /没有复制成功/);
  assert.equal(editor.data.videoBusy, false);
  publish(action({video: appResource()}), 'fixture-2'); editor.reload();
  navigationFailure = 'navigateToMiniProgram:fail cancel';
  await editor.openVideo();
  assert.equal(editor.data.videoError, '');
  assert.equal(editor.data.videoHint, '');
  navigationFailure = ''; deferNavigation = true;
  const pending = editor.openVideo();
  editor.onUnload(); delayedNavigation.success({}); await pending;
  assert.equal(editor.data.videoHint, '');
  assert.equal(store.getDay().actions.length, 0);
});
