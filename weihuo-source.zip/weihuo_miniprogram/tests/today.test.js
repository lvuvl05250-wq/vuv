'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let navigations = [];
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => disk.set(key, JSON.parse(JSON.stringify(value))),
  showToast: () => {}, showModal: () => {},
  navigateTo: options => navigations.push(options.url),
  reLaunch: options => navigations.push(options.url), switchTab: options => navigations.push(options.url)
};
const store = require(path.join(root, 'services/store'));
function todayPage() {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages/today/index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = patch => Object.assign(instance.data, patch);
  return instance;
}
function completedAction(title) {
  const action = store.addAction({title, durationMinutes: 2, kind: 'care', steps: ['打开正在写的那一页']});
  store.setActionStatus(action.id, 'completed', 'comfortable');
  return action;
}
test.beforeEach(() => { navigations = []; store.useLocal(); store.clearAll(); });

test('收成按钮只打开票根草稿，不提前封存已有记录', () => {
  completedAction('封存前完成的行动');
  store.saveMeal({name: '封存前记下的一餐'});
  const page = todayPage();
  page.seal();
  assert.deepEqual(navigations, ['/pages/ticket/index?date=' + store.today()]);
  assert.equal(store.getTicket(), null, '确认动作应留给票根页');
  assert.equal(store.getDay().actions.filter(action => action.status === 'completed').length, 1);
  assert.equal(store.getMeals(store.today()).length, 1);
});

test('空白日仍显示空状态；打开草稿不会生成行动、餐食或票根', () => {
  const page = todayPage();
  page.reload();
  assert.equal(page.data.ticket, null);
  assert.deepEqual(page.data.diary.paragraphs, []);
  assert.deepEqual(page.data.diary.highlights, []);
  page.seal();
  assert.deepEqual(navigations, ['/pages/ticket/index?date=' + store.today()]);
  assert.equal(store.getTicket(), null);
  assert.equal(store.getState().days[store.today()], undefined);
  assert.deepEqual(store.getMeals(store.today()), []);
  const source = fs.readFileSync(path.join(root, 'pages/today/index.wxml'), 'utf8');
  assert.match(source,/template/);assert.doesNotMatch(source,/receipt-row|饮食明细/);
});

test('today presents saved diary prose while small counts reflect the current day',()=>{
 completedAction('散步');store.saveMeal({name:'面条'});store.saveDiary(store.today(),{title:'今日小记',paragraphs:['面条和散步，都写进这一天。'],yi:'自在',quote:'喜欢今天。',stickers:[]},'明天再来');
 store.saveMeal({name:'苹果'});const page=todayPage();page.reload();assert.equal(page.data.diary.paragraphs[0],'面条和散步，都写进这一天。');assert.equal(page.data.diary.personalNote,'明天再来');assert.equal(page.data.mealCount,2);assert.equal(page.data.done,1);assert.equal(page.data.actions,undefined);
});

test('today page centers the companion and real journal counts without duplicate navigation or plan rows', () => {
  const page = todayPage();
  page.reload();
  assert.equal(page.data.companion.status, 'waiting');
  assert.equal(page.data.done, 0);
  assert.equal(page.data.mealCount, 0);
  assert.equal(page.data.hasNote, false);
  assert.equal(page.data.companion.showPawprint, false);

  const source = fs.readFileSync(path.join(root, 'pages/today/index.wxml'), 'utf8');
  assert.match(source,/hero-card/);
  assert.match(source,/bindtap="ticket"/);
  assert.doesNotMatch(source, /bindtap="state"|bindtap="actions"|bindtap="meal"|bindtap="plans"/);
  assert.doesNotMatch(source, /今天的安排|我的计划|找一件小事|记下一餐/);
  assert.doesNotMatch(fs.readFileSync(path.join(root, 'pages/today/index.js'), 'utf8'), /togglePlan|planItems/);
});

test('today companion reflects only completed actions, confirmed meals, and written note', () => {
  store.addAction({title: '还没完成', durationMinutes: 2, kind: 'care', steps: ['随时开始']});
  store.saveMeal({name: '已确认的一餐'});
  store.saveMeal({name: '未确认的草稿', confirmed: false});
  let page = todayPage();
  page.reload();
  assert.equal(page.data.companion.status, 'present');
  assert.equal(page.data.companion.completedCount, 0);
  assert.equal(page.data.companion.recordedMealCount, 1);
  assert.equal(page.data.done, 0);
  assert.equal(page.data.mealCount, 1);

  completedAction('完成的一件小事');
  store.saveDay({note: '写下的一点感受'});
  page = todayPage();
  page.reload();
  assert.equal(page.data.companion.status, 'happy');
  assert.equal(page.data.companion.completedCount, 1);
  assert.equal(page.data.companion.hasNote, true);
  assert.equal(page.data.done, 1);
  assert.equal(page.data.hasNote, true);
});
