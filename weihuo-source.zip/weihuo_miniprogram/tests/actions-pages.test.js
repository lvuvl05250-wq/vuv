'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let events = [], failWrites = false;
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => {
    if (failWrites) throw new Error('test: disk full');
    disk.set(key, JSON.parse(JSON.stringify(value)));
  },
  showToast: value => events.push(value.title),
  showModal: value => { events.push(value.content); if (value.success) value.success({confirm: true}); },
  navigateTo: value => events.push(value.url), navigateBack: () => events.push('back'),
  redirectTo: value => events.push(value.url), switchTab: value => events.push(value.url),
  cloud: {callFunction: async () => { throw new Error('test: offline'); }}
};
global.getCurrentPages = () => [{}, {}];
const store = require(path.join(root, 'services/store'));
const api = require(path.join(root, 'services/api'));
const timer = require(path.join(root, 'pages/action/timer'));

function page(name) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages', name, 'index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = function (patch) {
    Object.entries(patch).forEach(([key, value]) => {
      const segments = key.replace(/\[(\d+)\]/g, '.$1').split('.');
      let target = this.data;
      while (segments.length > 1) target = target[segments.shift()];
      target[segments[0]] = value;
    });
  };
  return instance;
}
function customAction() { return store.addAction({title: '读两页书', durationMinutes: 3, steps: ['打开正在读的书'], kind: 'care', source: 'manual'}); }
test.beforeEach(() => { failWrites = false; events = []; store.clearAll(); });

test('owned WXML interpolations contain no HTML entities or invalid expression syntax', () => {
  ['actions', 'action', 'plans', 'plan-edit', 'measurements', 'report'].forEach(name => {
    const source = fs.readFileSync(path.join(root, 'pages', name, 'index.wxml'), 'utf8');
    for (const match of source.matchAll(/\{\{([\s\S]*?)\}\}/g)) {
      assert(!/&(lt|gt|amp|quot|apos);/.test(match[1]), name + ': HTML entity in WXML expression');
      assert.doesNotThrow(() => new Function('return (' + match[1] + ');'), name + ': invalid expression');
    }
  });
  const editor = page('plan-edit');
  assert.equal(editor.data.dayNumbers[0], '01');
  assert.equal(editor.data.dayNumbers[9], '10');
  assert.equal(editor.data.dayNumbers[30], '31');
});

test('plans empty state has one create action; header plus returns when plans exist', () => {
  const source = fs.readFileSync(path.join(root, 'pages/plans/index.wxml'), 'utf8');
  assert.match(source, /<button wx:if="\{\{plans\.length\}\}" class="add-circle"/);
  assert.match(source, /<view wx:if="\{\{!plans\.length\}\}" class="empty-plan"><image src="\/assets\/sticker-calendar\.png"/);
  assert.doesNotMatch(source, /生活可以安排，也可以随时调整/);
  const empty = page('plans'); empty.onShow();
  assert.equal(empty.data.plans.length, 0);
  store.savePlan({title: '下周的安排', days: [{date: store.today(), title: '留一段阅读时间', minutes: 5}]});
  const filled = page('plans'); filled.onShow();
  assert.equal(filled.data.plans.length, 1);
  assert.match(source, /class="add-circle" aria-label="添加计划"/);
});

test('timer derives elapsed time from persisted timestamps and caps at duration', () => {
  assert.equal(timer.elapsed({running: true, startedAt: 10000, elapsedSeconds: 5, durationSeconds: 60}, 30000), 25);
  assert.equal(timer.elapsed({running: true, startedAt: 10000, elapsedSeconds: 5, durationSeconds: 10}, 30000), 10);
  assert.equal(timer.elapsed({running: false, startedAt: 10000, elapsedSeconds: 5, durationSeconds: 60}, 30000), 5);
  assert.equal(timer.elapsed({running: true, startedAt: 30000, elapsedSeconds: 5, durationSeconds: 60}, 10000), 5);
  assert.equal(timer.display(59.1), '01:00');
});

test('action restores a running session after page closes, pauses and finishes with feedback', t => {
  const action = customAction();
  const original = page('action'); t.after(() => original.onUnload());
  original.onLoad({id: action.id}); original.onShow(); original.start();
  assert.equal(store.getAction(action.id).timer.running, true);
  store.saveActionTimer(action.id, {running: true, startedAt: Date.now() - 40000, elapsedSeconds: 20, durationSeconds: 180, mode: 'full'});
  original.onHide();
  const resumed = page('action'); t.after(() => resumed.onUnload());
  resumed.onLoad({id: action.id}); resumed.onShow();
  assert(resumed.data.remaining <= 120 && resumed.data.remaining >= 118);
  resumed.pause();
  const paused = store.getAction(action.id).timer.elapsedSeconds;
  assert(paused >= 60); assert.equal(store.getAction(action.id).timer.running, false);
  resumed.start(); assert.equal(store.getAction(action.id).timer.elapsedSeconds, paused);
  resumed.complete();
  assert.equal(store.getAction(action.id).status, 'completed');
  assert.equal(store.getAction(action.id).timer, undefined);
  resumed.giveFeedback({currentTarget: {dataset: {value: 'comfortable'}}});
  assert.equal(store.getAction(action.id).feedback, 'comfortable');
});

test('action detail follows the selected companion and switches only after a completed action', t => {
  const action = customAction();
  store.saveSettings({companion: 'cat'});
  const detail = page('action'); t.after(() => detail.onUnload());
  detail.onLoad({id: action.id}); detail.reload();
  assert.equal(detail.data.companionImage, '/assets/companion-cat-welcome.png');
  detail.complete();
  assert.equal(detail.data.companionImage, '/assets/companion-cat-happy.png');
  const source = fs.readFileSync(path.join(root, 'pages/action/index.wxml'), 'utf8');
  assert.match(source, /class="detail-character" src="\{\{companionImage\}\}"/);
});

test('a timer crossing Shanghai midnight finishes on its original record date', t => {
  const realNow = Date.now;
  let now = Date.parse('2026-10-03T15:59:50Z');
  Date.now = () => now;
  t.after(() => { Date.now = realNow; });
  assert.equal(store.today(), '2026-10-03');
  const action = customAction();
  const original = page('action'); t.after(() => original.onUnload());
  original.onLoad({id: action.id}); original.onShow(); original.start(); original.onHide();
  now = Date.parse('2026-10-03T16:00:05Z');
  assert.equal(store.today(), '2026-10-04');
  const reopened = page('action'); t.after(() => reopened.onUnload());
  reopened.onLoad({id: action.id}); reopened.onShow();
  assert.equal(reopened.data.remaining, 165);
  assert.equal(reopened.data.action.date, '2026-10-03');
  reopened.complete();
  assert.equal(store.getAction(action.id).date, '2026-10-03');
  assert.equal(store.getDay('2026-10-03').actions[0].status, 'completed');
  assert.equal(store.getDay('2026-10-04').actions.length, 0);
});

test('custom action validation rejects invalid input and valid save enters personal library without adding to today', () => {
  const list = page('actions'); list.onShow(); list.openCustom();
  list.setData({customTitle: '   ', customMinutes: '0'}); list.saveCustom();
  assert.equal(store.getDay().actions.length, 0);
  list.setData({customTitle: '给植物浇水', customMinutes: '0'}); list.saveCustom();
  assert.equal(store.getDay().actions.length, 0);
  list.setData({customMinutes: '2', customSteps: '确认土壤\n慢慢浇水'}); list.saveCustom();
  assert.equal(store.getDay().actions.length, 0);
  assert.equal(store.getCustomActions().length, 1);
  assert.deepEqual(store.getCustomActions()[0].steps, ['确认土壤', '慢慢浇水']);
});

test('personal action library can be reused, edited and deleted without rewriting today history', async () => {
  const list = page('actions'); list.onShow(); list.openCustom();
  list.setData({customTitle: '听一会儿自然声音', customMinutes: '3', customCategory: 'nature', customSteps: '找一个安静的位置'});
  list.saveCustom(); const custom = store.getCustomActions()[0];
  assert.equal(custom.category, 'nature'); assert.equal(custom.kind, 'care');
  list.setFilter({currentTarget: {dataset: {value: 'manual'}}}); assert.equal(list.data.customLibrary.length, 1);
  list.addSuggestion({currentTarget: {dataset: {id: custom.id}}});
  assert.equal(store.getDay().actions[0].actionId, custom.id); assert.equal(store.getDay().actions[0].source, 'manual');
  list.editCustom({currentTarget: {dataset: {id: custom.id}}}); list.setData({customTitle: '新的名字'}); list.saveCustom();
  assert.equal(store.getCustomActions()[0].title, '新的名字'); assert.equal(store.getDay().actions[0].title, '听一会儿自然声音');
  await list.deleteCustom({currentTarget: {dataset: {id: custom.id}}});
  assert.equal(store.getCustomActions().length, 0); assert.equal(store.getDay().actions[0].title, '听一会儿自然声音');
});

test('daily suggestions are visible before any action is added and do not fabricate user records', () => {
  const list = page('actions'); list.onShow(); list.openCustom();
  assert(list.data.suggestions.length > 0); assert.equal(store.getDay().actions.length, 0);
  assert.equal(Object.keys(store.getState().days).length, 0);
  assert.equal(list.data.plannedActions.length, 0);
  assert.equal(list.data.catalogOpen, false);
  list.onUnload();
});

test('audio is only created for real metadata and pauses on hide then releases on unload', t => {
  let creations = 0, paused = 0, destroyed = 0, audio;
  const original = wx.createInnerAudioContext;
  t.after(() => { wx.createInnerAudioContext = original; });
  wx.createInnerAudioContext = () => {
    creations += 1; const handlers = {};
    audio = {onPlay: fn => { handlers.play = fn; }, onPause: fn => { handlers.pause = fn; }, onStop: fn => { handlers.stop = fn; },
      onEnded: fn => { handlers.ended = fn; }, onError: fn => { handlers.error = fn; }, onTimeUpdate: fn => { handlers.time = fn; },
      play: () => handlers.play(), pause: () => { paused += 1; handlers.pause(); }, destroy: () => { destroyed += 1; }, fail: () => handlers.error()};
    return audio;
  };
  const silent = customAction(); const silentPage = page('action'); t.after(() => silentPage.onUnload());
  silentPage.onLoad({id: silent.id}); silentPage.onShow(); silentPage.playAudio(); assert.equal(creations, 0);
  const custom = store.saveCustomAction({title: '带音频的测试资料', durationMinutes: 3, category: 'meditation', kind: 'care',
    audio: {url: 'https://example.invalid/test-audio.mp3', durationSeconds: 180, transcript: '测试音频文字'}});
  const detail = page('action'); t.after(() => detail.onUnload()); detail.onLoad({id: custom.id}); detail.onShow();
  assert.equal(detail.data.hasAudio, true); detail.playAudio(); assert.equal(creations, 1); assert.equal(detail.data.audioPlaying, true);
  assert.equal(audio.src, 'https://example.invalid/test-audio.mp3'); detail.onHide(); assert.equal(paused, 1); assert.equal(detail.data.audioPlaying, false);
  detail.playAudio(); audio.fail(); assert(detail.data.audioError); assert.equal(detail.data.audioPlaying, false);
  detail.onUnload(); assert.equal(destroyed, 1);
});

test('knowledge reference is copied only after explicit user action', t => {
  const clipboard = []; const original = wx.setClipboardData;
  wx.setClipboardData = value => { clipboard.push(value.data); value.success(); };
  t.after(() => { wx.setClipboardData = original; });
  const custom = store.saveCustomAction({title: '参考资料测试', durationMinutes: 1, category: 'care', kind: 'care',
    knowledgeCard: {title: '生活实践小提示', body: '按自己的节奏做。', sourceTitle: '测试来源', sourceUrl: 'https://example.invalid/reference'}});
  const detail = page('action'); t.after(() => detail.onUnload()); detail.onLoad({id: custom.id}); detail.onShow();
  assert.equal(clipboard.length, 0); detail.copyReference(); assert.deepEqual(clipboard, ['https://example.invalid/reference']);
});

test('plan editing saves a generated id and details, and list toggles completion', () => {
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow();
  editor.setData({title: '自己的安排', days: [{date: store.today(), title: '读两页书', minutes: 5, done: false, details: '午饭之后'}]});
  editor.save();
  const plan = store.getPlans()[0]; assert(plan.id); assert.equal(plan.days[0].details, '午饭之后');
  const list = page('plans'); list.onShow(); list.toggleDay({currentTarget: {dataset: {id: plan.id, index: 0}}});
  assert.equal(store.getPlans()[0].days[0].done, true);
  const reopening = page('plan-edit'); reopening.onLoad({id: plan.id}); reopening.onShow();
  assert.equal(reopening.data.days[0].done, true);
  assert.equal(reopening.data.days[0].details, '午饭之后');
});

test('manual rest day accepts explicit zero minutes while empty and negative duration do not save', () => {
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow();
  editor.setData({title: '休息日', days: [{date: store.today(), title: '留一天休息', minutes: 0, done: false, details: ''}]});
  editor.save(); assert.equal(store.getPlans()[0].days[0].minutes, 0);
  const another = page('plan-edit'); another.onLoad({}); another.onShow();
  another.setData({title: '缺少时长', days: [{date: store.today(), title: '安排小事', minutes: '', done: false, details: ''}]});
  another.save(); assert.equal(store.getPlans().length, 1);
  another.setData({'days[0].minutes': -1}); another.save(); assert.equal(store.getPlans().length, 1);
});

test('injected storage failure is visible and never changes plan completion', () => {
  const plan = store.savePlan({title: '保存失败验证', days: [{date: store.today(), title: '读书', minutes: 5}]});
  const list = page('plans'); list.onShow();
  failWrites = true;
  list.toggleDay({currentTarget: {dataset: {id: plan.id, index: 0}}});
  failWrites = false;
  assert.equal(store.getPlans()[0].days[0].done, false);
  assert.equal(list.data.plans[0].doneCount, 0);
  assert(events.some(value => value.includes('保存失败')));
});

test('invalid and duplicate dates reject saving while retaining the plan draft', () => {
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow();
  editor.setData({title: '日期验证', days: [{date: '2026-02-30', title: '读书', minutes: 5}]}); editor.save();
  assert.equal(store.getPlans().length, 0); assert.equal(editor.data.days[0].title, '读书');
  editor.setData({days: [{date: store.today(), title: '读书', minutes: 2}, {date: store.today(), title: '散步', minutes: 5}]}); editor.save();
  assert.equal(store.getPlans().length, 0); assert(events.some(value => value.includes('同一天')));
});

test('actual unavailable API preserves editable draft and never invents an AI plan', async () => {
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow(); editor.setData({goal: '每天留一点读书时间'});
  const before = JSON.stringify(editor.data.days);
  await editor.generate();
  assert.equal(JSON.stringify(editor.data.days), before);
  assert(editor.data.aiError); assert.equal(editor.data.aiBusy, false);
  assert.equal(store.getPlans().length, 0);
});

test('AI response stays a draft until explicit confirmation and invalid responses retain the draft', async t => {
  const original = api.request; t.after(() => { api.request = original; });
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow(); editor.setData({goal: '给阅读安排时间'});
  api.request = async () => ({title: '阅读安排', days: [{date: store.today(), title: '读两页书', minutes: 5, details: '午饭后打开正在读的书', actionIds: ['office_water_window_break']}], note: '随时可调整'});
  await editor.generate();
  assert.equal(editor.data.aiDraft, true); assert.equal(store.getPlans().length, 0);
  const before = JSON.stringify(editor.data.days);
  api.request = async () => ({title: '错误日程', days: [{date: 'bad-date', title: '无效输入', minutes: -1}]});
  await editor.generate(); assert.equal(JSON.stringify(editor.data.days), before); assert(editor.data.aiNotice.includes('部分')); assert.equal(editor.data.aiError, '');
  editor.save();
  assert.equal(store.getPlans()[0].source, 'ai'); assert.equal(store.getPlans()[0].days[0].details, '午饭后打开正在读的书');
  assert.deepEqual(store.getPlans()[0].days[0].actionIds, ['office_water_window_break']);
  const reopened = page('plan-edit'); reopened.onLoad({id: store.getPlans()[0].id}); reopened.onShow();
  reopened.setData({title: '改个计划名'}); reopened.save();
  assert.deepEqual(store.getPlans()[0].days[0].actionIds, ['office_water_window_break']);
});

test('AI zero-minute rest day remains a draft and saves only after confirmation', async t => {
  const original = api.request; t.after(() => { api.request = original; });
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow(); editor.setData({goal: '给这周留出休息'});
  api.request = async () => ({title: '给自己留白', days: [{date: store.today(), title: '休息日', minutes: 0, details: '按需要休息，不安排活动'}]});
  await editor.generate();
  assert.equal(editor.data.aiError, ''); assert.equal(editor.data.days[0].minutes, 0); assert.equal(store.getPlans().length, 0);
  editor.save(); assert.equal(store.getPlans()[0].days[0].minutes, 0);
});

test('activity restrictions hide conflicting movement and prevent starting a previously saved action', t => {
  store.saveProfile({adult: true, safetyAnswered: true});
  const action = store.addAction('office_shoulder_release');
  store.saveProfile({restrictions: ['shoulder']});
  const detail = page('action'); t.after(() => detail.onUnload()); detail.onLoad({id: action.id}); detail.onShow();
  assert(detail.data.blocked); detail.start(); assert.equal(store.getAction(action.id).timer, undefined);
  const list = page('actions'); list.onShow(); list.openCustom(); assert(!list.data.catalog.some(a => a.id === 'office_shoulder_release'));
});

test('minor and unknown-age profiles can start daily movement without a separate safety answer', t => {
  for (const birthDate of ['2012-04-01', '']) {
    store.clearAll(); store.saveProfile({birthDate, adult: false, safetyAnswered: false});
    const detail = page('action'); t.after(() => detail.onUnload());
    detail.onLoad({id: 'office_shoulder_release'}); detail.onShow();
    assert.equal(detail.data.blocked, ''); detail.start();
    assert.equal(store.getAction(detail._id).timer.running, true); detail.pause(); detail.complete();
    assert.equal(store.getAction(detail._id).status, 'completed');
  }
});

test('minor can generate and confirm a plan while explicit restrictions still stop automatic plans', async t => {
  store.saveProfile({birthDate: '2012-04-01', adult: false, safetyAnswered: false});
  const original = api.request; t.after(() => { api.request = original; });
  let calls = 0;
  api.request = async () => { calls += 1; return {title: '放学后活动', days: [{date: store.today(), title: '舒适散步', minutes: 5, details: '选安全平路，累了就停'}], note: ''}; };
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow(); editor.setData({type: 'aerobic', goal: '放学后走一走'});
  await editor.generate(); assert.equal(calls, 1); assert.equal(editor.data.aiDraft, true);
  editor.save(); assert.equal(store.getPlans().length, 1);
  store.saveProfile({restrictions: ['ankle']});
  await editor.generate(); assert.equal(calls, 1); assert(events.includes('/pages/profile-edit/index'));
});

test('special condition still blocks general movement and strength plan saving', t => {
  store.saveProfile({birthDate: '2012-04-01', specialCondition: true});
  const detail = page('action'); t.after(() => detail.onUnload());
  detail.onLoad({id: 'office_shoulder_release'}); detail.onShow(); detail.start();
  assert.match(detail.data.blocked, /特殊情况/); assert.equal(store.getDay().actions.length, 0);
  const editor = page('plan-edit'); editor.onLoad({}); editor.onShow();
  editor.setData({type: 'strength', title: '自行安排', days: [{date: store.today(), title: '一般运动', minutes: 5}]});
  editor.save(); assert.equal(store.getPlans().length, 0);
});


test('adding a suggestion stays on the page, appears in today and survives a cold store reload', t => {
  const list = page('actions'); list.onShow(); list.openCustom(); t.after(() => list.onUnload());
  const id = list.data.suggestions[0].id;
  list.addSuggestion({currentTarget:{dataset:{id}}});
  assert.equal(list.data.plannedActions.length, 1);
  assert.equal(list.data.plannedActions[0].actionId, id);
  assert(!events.some(item => typeof item === 'string' && item.startsWith('/pages/')));
  const savedModule = require.cache[require.resolve(path.join(root, 'services/store'))];
  try {
    delete require.cache[require.resolve(path.join(root, 'services/store'))];
    const reloaded = require(path.join(root, 'services/store')); reloaded.init();
    const reopened = page('actions'); reopened.reload();
    assert.equal(reloaded.getDay().actions[0].actionId, id);
    assert.equal(reopened.data.plannedActions[0].actionId, id);
  } finally { require.cache[require.resolve(path.join(root, 'services/store'))] = savedModule; }
});

test('library search, source and category filters never hide today pending records', t => {
  const record = customAction(), list = page('actions'); list.onShow(); t.after(() => list.onUnload());
  list.setFilter({currentTarget:{dataset:{value:'suggested'}}});
  list.setCategory({currentTarget:{dataset:{value:'movement'}}});
  list.searchInput({detail:{value:'a title that cannot exist'}});
  assert.equal(list.data.catalog.length, 0);
  assert.deepEqual(list.data.plannedActions.map(item => item.id), [record.id]);
  list.completeAction({currentTarget:{dataset:{id:record.id}}});
  assert.equal(list.data.plannedActions.length, 0);
  assert.equal(list.data.completedActions[0].id, record.id);
  assert.equal(list.data.completedOpen, undefined);
  assert.equal(list.data.celebrationOpen, true);
  list.closeCelebration(); assert.equal(list.data.celebrationOpen, false);
  assert(!events.some(item => typeof item === 'string' && item.startsWith('/pages/')));
});

test('removing today record preserves personal library and sealed ticket history', async t => {
  const custom=store.saveCustomAction({title:'给植物浇水',durationMinutes:2,kind:'care',category:'nature'});
  const record=store.addAction(custom.id); store.setActionStatus(record.id,'completed'); const ticket=store.sealTicket();
  const list=page('actions'); list.onShow(); t.after(() => list.onUnload());
  await list.removeToday({currentTarget:{dataset:{id:record.id}}});
  assert.equal(list.data.plannedActions.length,0); assert.equal(store.getDay().actions.length,0);
  assert.equal(store.getCustomActions()[0].id,custom.id);
  assert.deepEqual(store.getTicket().actions,ticket.actions);
  assert.equal(list.data.catalog.find(item=>item.id===custom.id).added,false);
});

test('canceling removal or storage failure keeps today visible and does not fake success', async t => {
  const record=customAction(),list=page('actions'); list.onShow(); t.after(() => list.onUnload());
  const modal=wx.showModal; t.after(()=>{wx.showModal=modal;failWrites=false;});
  wx.showModal=options=>options.success({confirm:false});
  await list.removeToday({currentTarget:{dataset:{id:record.id}}});
  assert.equal(list.data.plannedActions.length,1);
  wx.showModal=modal; failWrites=true;
  await list.removeToday({currentTarget:{dataset:{id:record.id}}}); failWrites=false;
  assert.equal(list.data.plannedActions[0].id,record.id);
  assert.equal(store.getDay().actions.length,1);
  assert(!events.includes('已从今天移除'));
});

test('custom save-and-add closes its sheet and displays the same durable record immediately', t => {
  const list=page('actions'); list.onShow(); t.after(() => list.onUnload()); list.openCustom();
  list.setData({customTitle:'午后读一页书',customMinutes:'3',customCategory:'focus'});
  list.saveCustom({currentTarget:{dataset:{today:'yes'}}});
  assert.equal(list.data.showCustom,false); assert.equal(list.data.catalogOpen,false);
  assert.equal(list.data.plannedActions.length,1);
  assert.equal(list.data.plannedActions[0].actionId,store.getCustomActions()[0].id);
  assert(!events.some(item => typeof item === 'string' && item.startsWith('/pages/')));
});


test('all-done celebration appears once on new completion, keeps finished rows and respects reduced motion',t=>{
 store.saveSettings({reduceMotion:true});const first=customAction(),second=customAction();const list=page('actions');list.onShow();t.after(()=>list.onUnload());
 list.completeAction({currentTarget:{dataset:{id:first.id}}});assert.equal(list.data.celebrationOpen,false);
 list.completeAction({currentTarget:{dataset:{id:second.id}}});assert.equal(list.data.celebrationOpen,true);assert.equal(list.data.celebrationCount,2);assert.equal(list.data.reduceMotion,true);assert.equal(list.data.completedActions.length,2);
 list.closeCelebration();list.reload();assert.equal(list.data.celebrationOpen,false);
});
test('historical completions and switching accounts do not trigger all-done celebration',t=>{
 const first=customAction();store.setActionStatus(first.id,'completed');const list=page('actions');list.onShow();t.after(()=>list.onUnload());assert.equal(list.data.celebrationOpen,false);
 list.onHide();store.switchAccount('test-done-other');store.clearAll();const other=customAction();store.setActionStatus(other.id,'completed');list.onShow();assert.equal(list.data.celebrationOpen,false);store.useLocal();
});
