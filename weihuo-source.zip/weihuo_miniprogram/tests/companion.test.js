'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const companion = require('../miniprogram/services/companion');

const disk = new Map();
const navigations = [];
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => disk.set(key, JSON.parse(JSON.stringify(value))),
  navigateTo: options => navigations.push(options.url),
  switchTab: options => navigations.push(options.url),
  showToast: () => {},
  setNavigationBarTitle: () => {},
  showModal: options => options.success({confirm: true})
};

const store = require('../miniprogram/services/store');
const date = () => store.today();

function loadPage(name) {
  let definition;
  global.Page = page => { definition = page; };
  const file = path.join(__dirname, '../miniprogram/pages', name, 'index.js');
  delete require.cache[require.resolve(file)];
  require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = patch => Object.assign(instance.data, patch);
  return instance;
}

test.beforeEach(() => {
  navigations.length = 0;
  store.useLocal();
  store.clearAll();
});

test('companion selection is limited to the three named partners and defaults to Xiaowei', () => {
  assert.deepEqual(companion.COMPANIONS.map(item => [item.key, item.name]), [
    ['xiaowei', '小微'], ['cat', '团团'], ['dachshund', '卷卷']
  ]);
  assert.equal(companion.normalizeCompanionKey(undefined), 'xiaowei');
  assert.equal(companion.normalizeCompanionKey('unknown'), 'xiaowei');
  assert.equal(companion.normalizeCompanionKey('cat'), 'cat');
});

test('an empty day, planned actions, and unconfirmed meals remain a gentle waiting state', () => {
  const view = companion.deriveTodayCompanion({
    companionKey: 'cat', date: date(),
    actions: [{status: 'planned'}],
    meals: [{confirmed: false}],
    note: '   '
  });
  assert.equal(view.status, 'waiting');
  assert.equal(view.completedCount, 0);
  assert.equal(view.recordedMealCount, 0);
  assert.equal(view.hasNote, false);
  assert.equal(view.showPawprint, false);
  assert.equal(view.joyLevel, 0);
  assert.equal(view.image, '/assets/companion-cat-waiting.png');
  assert.deepEqual(view.paws, []);
  assert.match(view.message, /喵|陪|小发现/);
  assert.doesNotMatch(view.message, /怎么还|今天没有|应该|加油打卡/);
});

test('confirmed meals and a written note leave a real small record without inventing completed actions', () => {
  const view = companion.deriveTodayCompanion({
    companionKey: 'dachshund', date: date(),
    actions: [{status: 'planned'}, {status: 'skipped'}],
    meals: [{confirmed: true}, {confirmed: false}],
    note: '午后喝了水'
  });
  assert.equal(view.status, 'present');
  assert.equal(view.completedCount, 0);
  assert.equal(view.recordedMealCount, 1);
  assert.equal(view.hasNote, true);
  assert.equal(view.showPawprint, true);
  assert.equal(view.joyLevel, 0);
  assert.equal(view.stickerId, 'mark');
  assert.equal(view.image, '/assets/companion-dachshund-waiting.png');
  assert.equal(view.paws.length, 1);
});

test('completed action count raises the calm happy level and the same day stays deterministic', () => {
  const input = {companionKey: 'xiaowei', date: '2026-10-05', actions: [{status: 'completed'}], meals: [], note: ''};
  const one = companion.deriveTodayCompanion(input);
  const oneAgain = companion.deriveTodayCompanion(input);
  const two = companion.deriveTodayCompanion(Object.assign({}, input, {actions: input.actions.concat({status: 'completed'})}));
  assert.equal(one.status, 'happy');
  assert.equal(one.joyLevel, 1);
  assert.equal(one.message, oneAgain.message);
  assert.equal(two.completedCount, 2);
  assert.equal(two.joyLevel, 2);
  assert.match(two.message, /2/);
  assert.equal(two.showPawprint, false);
  assert.equal(two.stickerImage, '/assets/sticker-ticket.png');
  assert.equal(one.image, '/assets/xiaowei-checkin-v2.png');
  assert.equal(two.image, '/assets/xiaowei-checkin-v2.png');
  assert.equal(two.paws.length, 0);
  const catHappy = companion.deriveTodayCompanion({companionKey:'cat',date:'2026-10-05',actions:[{status:'completed'}]});
  assert.equal(catHappy.image, '/assets/companion-cat-happy.png');
  assert.equal(catHappy.paws.length, 1);
  assert.equal(companion.getCompanionPresentation({companionKey:'xiaowei',scene:'meal'}).image, '/assets/xiaowei-meal-v2.png');
  assert.equal(companion.getCompanionPresentation({companionKey:'cat',scene:'meal',actions:[{status:'completed'}]}).image, '/assets/companion-cat-meal.png');
});

test('presentation API names the animals and selects a matching scene and activity image', () => {
  const waitingCat = companion.getCompanionPresentation({companionKey:'cat',date:'2026-10-05'});
  const happyDog = companion.getCompanionPresentation({companionKey:'dachshund',date:'2026-10-05',actions:[{status:'completed'}]});
  assert.deepEqual([waitingCat.name, waitingCat.image], ['团团','/assets/companion-cat-welcome.png']);
  assert.deepEqual([happyDog.name, happyDog.image], ['卷卷','/assets/companion-dachshund-happy.png']);
  assert.equal(companion.getCompanionPresentation({companionKey:'xiaowei',scene:'meal'}).image, '/assets/xiaowei-meal-v2.png');
  assert.equal(companion.getCompanionPresentation({companionKey:'xiaowei'}).image, '/assets/xiaowei-checkin-v2.png');
});

test('main partner images bind to the saved companion across entry, state, action and today pages', () => {
  const pages = ['welcome','state','actions','action','profile','settings','today'];
  for (const name of pages) {
    const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages', name, 'index.wxml'), 'utf8');
    assert.doesNotMatch(wxml, /src="\/assets\/xiaowei-(greeting|checkin|walking|resting)\.png"/i, name + ' has a static companion portrait');
  }
  for (const name of ['welcome','state','actions']) {
    const js = fs.readFileSync(path.join(__dirname, '../miniprogram/pages', name, 'index.js'), 'utf8');
    assert.match(js, /getCompanionPresentation/, name + ' derives the selected companion');
    const wxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages', name, 'index.wxml'), 'utf8');
    assert.match(wxml, /src="\{\{companionImage\}\}"/, name + ' uses the presentation image');
  }
  const actionWxml = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/action/index.wxml'), 'utf8');
  assert.match(actionWxml, /src="\{\{companionImage\}\}"/);
  assert.match(actionWxml, /和\{\{companionName\}\}一起开始/);
  assert.match(fs.readFileSync(path.join(__dirname, '../miniprogram/pages/profile/index.wxml'), 'utf8'), /src="\{\{companion\.image\}\}"/);
  assert.match(fs.readFileSync(path.join(__dirname, '../miniprogram/pages/today/index.wxml'), 'utf8'), /src="\{\{companion\.image\}\}"/);
});

test('settings page shows and saves only the selected companion', () => {
  const settings = loadPage('settings');
  settings.onLoad({section: 'companion'});
  assert.equal(settings.data.section, 'companion');
  assert.equal(settings.data.title, '陪伴伙伴');
  assert.deepEqual(settings.data.companions.map(item => item.key), ['xiaowei', 'cat', 'dachshund']);

  settings.selectCompanion({currentTarget: {dataset: {key: 'cat'}}});
  assert.equal(store.getSettings().companion, 'cat');
  assert.equal(settings.data.settings.companion, 'cat');
  settings.selectCompanion({currentTarget: {dataset: {key: 'not-a-companion'}}});
  assert.equal(store.getSettings().companion, 'cat');

  const source = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/settings/index.wxml'), 'utf8');
  assert.match(source, /section==='companion'/);
  assert.doesNotMatch(source, /\{\{item\.typeLabel\}\}/);
  assert.doesNotMatch(source, /section==='period'/);
});

test('profile settings keep the archive entrance and replace the period shortcut with companion settings', () => {
  const profile = loadPage('profile');
  assert.equal(profile.data.rows.some(row => row.id === 'companion'), false);
  assert.equal(profile.data.rows.some(row => row.id === 'period'), false);
  profile.onShow();
  assert.equal(profile.data.companion.name, '小微');
  profile.open({currentTarget: {dataset: {id: 'companion'}}});
  assert.equal(navigations.at(-1), '/pages/settings/index?section=companion');
  profile.archive();
  assert.equal(navigations.at(-1), '/pages/archive/index');
  const source = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/profile/index.wxml'), 'utf8');
  assert.match(source, /bindtap="archive"/);
  assert.match(source, /class="partner-preview section" data-id="companion" bindtap="open"/);
});
