'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');

function harness(){
  const previousWx=global.wx;
  const saved=new Map(),calls=[],dialogs=[];
  for(const file of ['store','api','media'])delete require.cache[require.resolve('../miniprogram/services/'+file)];
  const config=require('../miniprogram/config'),oldEnv=config.cloudEnv;config.cloudEnv='test-environment';
  const h={saved,calls,dialogs,onModal:null,onCall:null};
  global.wx={
    getStorageSync:key=>saved.get(key)||'',
    setStorageSync:(key,value)=>saved.set(key,structuredClone(value)),
    showModal(options){dialogs.push(options.title);if(h.onModal)h.onModal(options);else options.success({confirm:true});},
    cloud:{async callFunction(options){
      const req=structuredClone(options.data);calls.push(req);
      if(h.onCall){const custom=await h.onCall(req);if(custom!==undefined)return {result:custom};}
      if(req.task==='auth')return {result:{ok:true,data:{openid:'native_user_a'}}};
      if(req.task==='getCatalog')return {result:{ok:false,error:{code:'CATALOG_NOT_CONFIGURED',message:'未发布'}}};
      return {result:{ok:true,data:{version:req.task==='deleteCloudData'?3:2,state:null}}};
    }}
  };
  h.store=require('../miniprogram/services/store');h.store.init();h.api=require('../miniprogram/services/api');
  h.close=()=>{config.cloudEnv=oldEnv;global.wx=previousWx;};
  return h;
}

test('cloud consent cannot transfer to a local or different account while confirmation is pending',async()=>{
  for(const next of ['local','native_user_b']){
    const h=harness();try{
      await h.api.connect();
      h.onModal=options=>{
        assert.equal(options.title,'允许云端保存个人记录？');
        if(next==='local')h.store.useLocal();else h.store.switchAccount(next);
        h.store.saveProfile({name:'new-scope-data'});options.success({confirm:true});
      };
      await assert.rejects(h.api.syncPush(),/账号状态已变化/);
      assert.equal(h.calls.some(r=>r.task==='syncPush'),false,'新空间的数据不能以原微信身份上传');
      assert.equal(h.store.getSettings().cloudConsent,false,'旧空间弹窗不能为新空间授权');
    }finally{h.close();}
  }
});

test('AI consent cannot transfer to another account while its confirmation is pending',async()=>{
  const h=harness();try{
    await h.api.connect();
    h.onModal=options=>{h.store.switchAccount('native_user_b');options.success({confirm:true});};
    await assert.rejects(h.api.request('parseState',{text:'今天想安静一会儿'}),/账号发生变化/);
    assert.equal(h.store.getSettings().aiConsent,false);
    assert.equal(h.calls.some(r=>r.task==='parseState'),false);
  }finally{h.close();}
});

test('cloud deletion stops if scope changes while reading the current cloud version',async()=>{
  const h=harness();try{
    await h.api.connect();
    h.onCall=async req=>{if(req.task==='syncPull'){h.store.switchAccount('native_user_b');return {ok:true,data:{version:2,state:null}};}};
    await assert.rejects(h.api.deleteCloudData(),/账号状态已变化/);
    assert.equal(h.calls.some(r=>r.task==='deleteCloudData'),false);
    assert.equal(h.dialogs.includes('删除云端备份？'),false);
  }finally{h.close();}
});

test('cloud deletion stops if scope changes while deletion confirmation is pending',async()=>{
  const h=harness();try{
    await h.api.connect();
    h.onModal=options=>{assert.equal(options.title,'删除云端备份？');h.store.switchAccount('native_user_b');h.store.saveSettings({cloudConsent:true});options.success({confirm:true});};
    await assert.rejects(h.api.deleteCloudData(),/账号状态已变化/);
    assert.equal(h.calls.some(r=>r.task==='deleteCloudData'),false);
    assert.equal(h.store.getSettings().cloudConsent,true);
    assert.equal(h.saved.has('weihuo:cloudVersion:native_user_b'),false);
  }finally{h.close();}
});

test('an already sent deletion cannot mutate another local scope when its response arrives',async()=>{
  const h=harness();try{
    await h.api.connect();
    h.onCall=async req=>{if(req.task==='deleteCloudData'){h.store.switchAccount('native_user_b');h.store.saveSettings({cloudConsent:true});return {ok:true,data:{version:3}};}};
    await assert.rejects(h.api.deleteCloudData(),/账号状态已变化/);
    assert.equal(h.calls.filter(r=>r.task==='deleteCloudData').length,1);
    assert.equal(h.store.getSettings().cloudConsent,true);
    assert.equal(h.saved.has('weihuo:cloudVersion:native_user_a'),false);
    assert.equal(h.saved.has('weihuo:cloudVersion:native_user_b'),false);
  }finally{h.close();}
});

test('deletion shares the sync mutex and releases it after completion',async()=>{
  const h=harness();try{
    await h.api.connect();let release,started;
    const ready=new Promise(resolve=>{started=resolve;});
    h.onCall=req=>{if(req.task==='syncPull')return new Promise(resolve=>{release=resolve;started();});};
    const pending=h.api.deleteCloudData();await ready;
    await assert.rejects(h.api.syncPush(),/正在同步/);
    await assert.rejects(h.api.deleteCloudData(),/正在同步/);
    release({ok:true,data:{version:2,state:null}});assert.equal(await pending,true);
    h.onCall=null;h.store.saveSettings({cloudConsent:true});
    assert.equal((await h.api.syncPush()).version,2);
  }finally{h.close();}
});

test('an in-flight sync result cannot write a cloud version into another account namespace',async()=>{
  const h=harness();try{
    await h.api.connect();h.store.saveSettings({cloudConsent:true});
    h.onCall=async req=>{if(req.task==='syncPush'){h.store.switchAccount('native_user_b');return {ok:true,data:{version:4}};}};
    await assert.rejects(h.api.syncPush(),/账号状态已变化/);
    assert.equal(h.saved.has('weihuo:cloudVersion:native_user_a'),false);
    assert.equal(h.saved.has('weihuo:cloudVersion:native_user_b'),false);
  }finally{h.close();}
});

test('planning candidates prioritize twenty personal actions without crossing account namespaces',()=>{
  const h=harness();try{
    h.store.switchAccount('native_user_a');h.store.saveProfile({adult:true,safetyAnswered:true,onboarded:true});
    for(let i=0;i<25;i++)h.store.saveCustomAction({title:'个人行动'+i,durationMinutes:3,kind:'care',category:'care',steps:[]});
    const choices=h.store.getPlanningCandidates();
    assert.equal(choices.length,80);assert.equal(choices.filter(a=>a.source==='manual').length,20);
    assert.equal(choices.slice(0,20).every(a=>a.source==='manual'),true);
    h.store.switchAccount('native_user_b');assert.equal(h.store.getPlanningCandidates().some(a=>a.source==='manual'),false);
    h.store.switchAccount('native_user_a');assert.equal(h.store.getCustomActions().length,25);
  }finally{h.close();}
});
