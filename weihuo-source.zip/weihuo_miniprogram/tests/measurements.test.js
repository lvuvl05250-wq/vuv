'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let failWrites = false;
let accept = true;
let events = [];

global.wx = {
  getStorageSync: key => disk.get(key),
  getStorageInfoSync: () => ({ keys: Array.from(disk.keys()) }),
  setStorageSync: (key, value) => {
    if (failWrites) throw new Error('test: full storage');
    disk.set(key, JSON.parse(JSON.stringify(value)));
  },
  showToast: value => events.push(value.title),
  showModal: value => { if (value.success) value.success({ confirm: accept }); },
  navigateTo: value => events.push(value.url),
  pageScrollTo: () => {},
  navigateBack: () => {},
  switchTab: () => {}
};
const store = require(path.join(root, 'services/store'));
const ui = require(path.join(root, 'services/ui'));
const actualConfirm = ui.confirm;

function page(name = 'measurements', options = {}) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages', name, 'index.js');
  delete require.cache[require.resolve(file)];
  require(file);
  const instance = Object.assign({}, definition, { data: JSON.parse(JSON.stringify(definition.data)) });
  instance.setData = function (patch) { Object.assign(this.data, patch); };
  if (instance.onLoad) instance.onLoad(options);
  if (instance.onShow) instance.onShow();
  return instance;
}
function field(instance, key, value) {
  instance.onField({ currentTarget: { dataset: { field: key } }, detail: { value } });
}
function report(confirmed = true) {
  return store.saveReport({ title: '我核对过的报告', confirmed, date: '2026-09-20', metrics: [
    { name: '骨密度 T 值', value: '-1.2', unit: '', reference: '' },
    { name: '收缩压', value: '118', unit: 'mmHg', reference: '' }
  ] });
}
test.beforeEach(() => {
  failWrites = false;
  accept = true;
  events = [];
  ui.confirm = actualConfirm;
  disk.clear();
  store.useLocal();
  store.clearAll();
});
test.after(() => { ui.confirm = actualConfirm; });

test('preset measurements retain original negative and symbolic values after reopening', () => {
  const editor = page();
  editor.newRecord();
  editor.choosePreset({ currentTarget: { dataset: { name: '骨密度 T 值' } } });
  field(editor, 'value', '-1.2');
  field(editor, 'date', '2026-09-20');
  editor.save();
  const first = store.getMeasurements()[0];
  assert.equal(first.name, '骨密度 T 值');
  assert.equal(first.value, '-1.2');
  assert.equal(first.unit, '');
  assert.equal(first.source, 'manual');
  assert.equal(first.date, '2026-09-20');
  store.useLocal();
  const reopened = page('measurements', { id: first.id });
  assert.equal(reopened.data.value, '-1.2');
  field(reopened, 'name', '自定义原文指标');
  field(reopened, 'value', '<0.1');
  reopened.save();
  assert.equal(store.getMeasurements().length, 1);
  assert.equal(store.getMeasurements()[0].value, '<0.1');
});

test('blood pressure, body composition, lipid and added presets have editable default units', () => {
  const editor = page();
  const names = editor.data.presets.map(item => item.name);
  ['收缩压', '舒张压', '静息心率', '骨密度 T 值', '骨密度 Z 值', '身高', '体重', '体脂率', '空腹血糖', '总胆固醇', '甘油三酯', '高密度脂蛋白胆固醇', '低密度脂蛋白胆固醇', '腰围', '臀围', '尿酸', '握力', '最大摄氧量'].forEach(name => assert(names.includes(name)));
  editor.newRecord();
  editor.choosePreset({ currentTarget: { dataset: { name: '空腹血糖' } } });
  assert.equal(editor.data.unit, 'mmol/L');
  field(editor, 'unit', 'mg/dL');
  field(editor, 'value', '90');
  editor.save();
  assert.equal(store.getMeasurements()[0].unit, 'mg/dL');
});

test('empty name, empty value and invalid date reject saving without losing the draft', () => {
  const editor = page();
  editor.newRecord();
  field(editor, 'name', '体重');
  editor.save();
  assert.equal(store.getMeasurements().length, 0);
  assert(editor.data.error);
  field(editor, 'name', '');
  field(editor, 'value', '55');
  editor.save();
  assert.equal(store.getMeasurements().length, 0);
  field(editor, 'name', '体重');
  field(editor, 'date', '2026-02-30');
  editor.save();
  assert.equal(store.getMeasurements().length, 0);
  assert.equal(editor.data.value, '55');
  assert(editor.data.error);
});

test('history orders measurement dates and can filter by a chosen project', () => {
  store.saveMeasurement({ name: '体重', value: '55', unit: 'kg', date: '2026-09-01' });
  store.saveMeasurement({ name: '收缩压', value: '118', unit: 'mmHg', date: '2026-09-02' });
  store.saveMeasurement({ name: '体重', value: '55.5', unit: 'kg', date: '2026-09-03' });
  const history = page();
  assert.deepEqual(history.data.groups.map(group => group.date), ['2026-09-03', '2026-09-02', '2026-09-01']);
  history.chooseFilter({ detail: { value: history.data.filterNames.indexOf('体重') } });
  assert.deepEqual(history.data.groups.map(group => group.date), ['2026-09-03', '2026-09-01']);
  assert(history.data.groups.every(group => group.records.every(record => record.name === '体重')));
});

test('editing and deleting a report measurement preserves the source report', async () => {
  const source = report();
  store.importReportMeasurements(source.id);
  const original = store.getMeasurements()[0];
  const editor = page('measurements', { id: original.id });
  field(editor, 'value', '-1.1');
  editor.save();
  const changed = store.getMeasurements().find(item => item.id === original.id);
  assert.equal(changed.value, '-1.1');
  assert.equal(changed.source, 'report');
  assert.equal(changed.reportId, source.id);
  const reopened = page('measurements', { id: original.id });
  reopened.openReport();
  assert(events.includes('/pages/report/index?id=' + source.id));
  await reopened.deleteRecord();
  assert.equal(store.getMeasurements().length, 1);
  assert.equal(store.getReports().length, 1);
  assert.equal(store.getReports()[0].metrics.length, 2);
});

test('confirmed report imports only after a separate confirmation and duplicate registration does not add rows', async () => {
  const source = report();
  const editor = page('report', { id: source.id });
  assert.equal(store.getMeasurements().length, 0);
  accept = false;
  await editor.registerMeasurements();
  assert.equal(store.getMeasurements().length, 0);
  accept = true;
  await editor.registerMeasurements();
  assert.equal(store.getMeasurements().length, 2);
  assert(store.getMeasurements().every(item => item.reportId === source.id && item.source === 'report' && item.date === '2026-09-20'));
  await editor.registerMeasurements();
  assert.equal(store.getMeasurements().length, 2);
  assert.match(editor.data.savedMessage, /没有重复/);
});

test('manual correction keeps the report fingerprint so registering again cannot restore an older value', async () => {
  const source = report();
  const reportPage = page('report', { id: source.id });
  await reportPage.registerMeasurements();
  const original = store.getMeasurements().find(item => item.name === '骨密度 T 值');
  assert(original.sourceMetricKey);
  const editor = page('measurements', { id: original.id });
  field(editor, 'value', '-1.1');
  editor.save();
  await reportPage.registerMeasurements();
  assert.equal(store.getMeasurements().length, 2);
  const corrected = store.getMeasurements().find(item => item.id === original.id);
  assert.equal(corrected.value, '-1.1');
  assert.equal(corrected.sourceMetricKey, original.sourceMetricKey);
  assert.equal(store.getReports()[0].metrics[0].value, '-1.2');
});

test('draft reports and unsaved report edits cannot register measurement values', async () => {
  const draft = report(false);
  const draftPage = page('report', { id: draft.id });
  await draftPage.registerMeasurements();
  assert.equal(store.getMeasurements().length, 0);
  assert.throws(() => store.importReportMeasurements(draft.id), /确认报告/);
  store.saveReport({ id: draft.id, confirmed: true });
  const changed = page('report', { id: draft.id });
  field(changed, 'title', '尚未保存的修改');
  await changed.registerMeasurements();
  assert.equal(store.getMeasurements().length, 0);
});

test('storage failure is visible and prevents both manual save and report registration success', async () => {
  const editor = page();
  editor.newRecord();
  field(editor, 'name', '握力');
  field(editor, 'value', '26');
  const source = report();
  const reportPage = page('report', { id: source.id });
  failWrites = true;
  editor.save();
  await reportPage.registerMeasurements();
  failWrites = false;
  assert.equal(store.getMeasurements().length, 0);
  assert.equal(editor.data.value, '26');
  assert.match(editor.data.error, /保存失败/);
  assert.match(reportPage.data.error, /保存失败/);
  assert(!events.includes('这次测量已记下。'));
  assert(!events.includes('指标已登记到个人档案。'));
});

test('cancelled close keeps the measurement draft and confirmed close leaves saved records unchanged', async () => {
  const saved = store.saveMeasurement({ name: '腰围', value: '70', unit: 'cm' });
  const editor = page('measurements', { id: saved.id });
  field(editor, 'value', '71');
  accept = false;
  await editor.closeEditor();
  assert.equal(editor.data.editorOpen, true);
  assert.equal(editor.data.value, '71');
  accept = true;
  await editor.closeEditor();
  assert.equal(editor.data.editorOpen, false);
  assert.equal(store.getMeasurements()[0].value, '70');
});

test('late measurement deletion confirmation is ignored after leaving the page', async () => {
  const saved = store.saveMeasurement({name: '腰围', value: '70', unit: 'cm'});
  const editor = page('measurements', {id: saved.id});
  let resolve;
  ui.confirm = () => new Promise(done => { resolve = done; });
  const pending = editor.deleteRecord();
  editor.onUnload();
  resolve(true);
  await pending;
  assert.equal(store.getMeasurements().length, 1);
});

test('an unsaved measurement cannot be written into a different account', () => {
  const editor = page();
  editor.newRecord();
  field(editor, 'name', '体重');
  field(editor, 'value', '55');
  store.switchAccount('different-account');
  editor.save();
  assert.equal(store.getMeasurements().length, 0);
  assert.match(editor.data.error, /账号已变化/);
  assert.equal(editor.data.value, '55');
});
