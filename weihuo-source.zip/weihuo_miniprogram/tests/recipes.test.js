'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const recipes = require('../miniprogram/services/recipes');
const disk = new Map(); let failWrite = false, events = [];
global.wx = {
  getStorageSync: key => disk.get(key), getStorageInfoSync: () => ({keys: [...disk.keys()]}),
  setStorageSync: (key, value) => { if (failWrite) throw new Error('storage full'); disk.set(key, structuredClone(value)); },
  showToast: value => events.push(value.title), navigateTo: value => events.push(value.url),
  navigateBack: () => events.push('back'), showModal: options => options.success({confirm: true}),
  setClipboardData: options => { events.push(options.data); options.success(); }
};
const store = require('../miniprogram/services/store');
const api = require('../miniprogram/services/api');
const {validateState} = require('../cloudfunctions/weihuoApi/state');
api.request = async () => { throw new Error('Recipe browsing must not invoke AI'); };
function page(name = 'recipes', options = {}) {
  let definition; global.Page = value => { definition = value; };
  const filename = path.join(__dirname, '../miniprogram/pages', name, 'index.js'); delete require.cache[require.resolve(filename)]; require(filename);
  const instance = Object.assign({}, definition, {data: structuredClone(definition.data)});
  instance.setData = function(patch) { Object.assign(this.data, patch); };
  if (instance.onLoad) instance.onLoad(options); if (instance.onShow) instance.onShow(); return instance;
}
const click = id => ({currentTarget: {dataset: {id}}});
const legacyAvoid=(editor,id)=>{store.saveSettings({foodAvoid:[id]});editor.onShow();};
const draw = count => ({currentTarget: {dataset: {count}}});
test.beforeEach(() => { failWrite = false; events = []; disk.clear(); store.useLocal(); store.clearAll(); });

test('ten distinct household recipes have inspected official sources, clear quantities, methods and known tags', () => {
  assert.equal(recipes.RECIPES.length, 10); assert.equal(new Set(recipes.RECIPES.map(r => r.id)).size, 10);
  for (const recipe of recipes.RECIPES) {
    assert.match(recipe.id, /^recipe_[a-z_]+$/); assert(recipe.servings && recipe.time);
    assert(recipe.ingredients.length >= 3); assert(recipe.steps.length >= 3);
    assert(['www.startsmart.gov.hk', 'www.myplate.gov'].includes(new URL(recipe.source.url).hostname));
    assert(recipe.tags.every(tag => recipes.TAGS.some(item => item.id === tag)));
    assert(recipe.allergens.every(tag => recipes.ALLERGENS.some(item => item.id === tag)));
    assert.equal(recipe.kcal, undefined, 'adapted recipes must not inherit the source recipe nutrition');
    assert(!/治愈|补血|调经|补剂|减脂|低卡/.test(JSON.stringify(recipe)));
  }
});
test('preference filters combine and allergen exclusions never loosen to fill a result', () => {
  const breakfast = recipes.filterRecipes({tags: ['breakfast']}); assert.equal(breakfast.length, 2);
  assert.deepEqual(recipes.filterRecipes({tags: ['breakfast'], avoid: ['milk']}), []);
  const quick = recipes.filterRecipes({tags: ['quick', 'vegetarian'], avoid: ['egg']});
  assert.deepEqual(quick.map(r => r.id), ['recipe_banana_walnut_oats']);
  assert.equal(recipes.filterRecipes({query: '  豆腐  ', avoid: ['soy']}).length, 0);
  assert(recipes.filterRecipes({query: '番茄'}).length >= 3);
});
test('known ingredient allergens include seasoning wheat/soy and oats or nuts without declaring foods allergy-free', () => {
  assert.deepEqual(recipes.getRecipe('recipe_garlic_mushrooms').allergens, ['soy', 'gluten']);
  assert.deepEqual(recipes.getRecipe('recipe_tropical_oats').allergens, ['milk', 'gluten', 'tree_nuts']);
  assert(recipes.getRecipe('recipe_tomato_beef_pasta').ingredients.some(value => value.includes('不含蛋')));
  assert(!recipes.filterRecipes({avoid: ['soy', 'gluten']}).some(r => r.id === 'recipe_garlic_mushrooms'));
});
test('random selection returns one or three unique matching recipes, handles small pools and never mutates seeds', () => {
  const before = JSON.stringify(recipes.RECIPES), pool = recipes.filterRecipes({avoid: ['egg']});
  const picked = recipes.pickRecipes(pool, 3, () => 0); assert.equal(picked.length, 3); assert.equal(new Set(picked.map(r => r.id)).size, 3);
  assert(picked.every(r => !r.allergens.includes('egg'))); assert.equal(recipes.pickRecipes(pool, 1, () => 0.9).length, 1);
  assert.equal(recipes.pickRecipes(pool.slice(0, 2), 3).length, 2); assert.deepEqual(recipes.pickRecipes([], 3), []);
  picked[0].ingredients[0] = 'test edit'; assert.equal(JSON.stringify(recipes.RECIPES), before);
});
test('saved recipes persist through reopening and export/cloud validation, independently of meal favorites', () => {
  const editor = page(); editor.toggleSaved(click('recipe_tomato_egg'));
  assert.deepEqual(store.getSettings().savedRecipes, ['recipe_tomato_egg']);
  assert(page().data.items.find(r => r.id === 'recipe_tomato_egg').saved);
  assert.deepEqual(validateState(store.getState()).settings.savedRecipes, ['recipe_tomato_egg']);
  const backup = store.exportData(); store.saveSettings({savedRecipes: []}); store.restoreData(backup);
  assert.deepEqual(store.getSettings().savedRecipes, ['recipe_tomato_egg']);
  store.saveMeal({name: '喜欢的午餐', date: store.today(), time: '12:00', tags: ['喜欢']});
  const journal = page('meals'); assert.equal(journal.data.favorites.length, 1); assert.equal(journal.data.savedRecipes[0].title, '番茄炒蛋');
  journal.browseRecipes(); journal.openRecipe(click('recipe_tomato_egg'));
  assert(events.includes('/pages/recipes/index')); assert(events.includes('/pages/recipes/index?id=recipe_tomato_egg'));
});
test('favorite toggle removes precisely that recipe and unknown IDs cannot be saved through the page', () => {
  const editor = page(); editor.toggleSaved(click('recipe_tomato_egg')); editor.toggleSaved(click('recipe_tropical_oats'));
  editor.toggleSaved(click('recipe_tomato_egg')); assert.deepEqual(store.getSettings().savedRecipes, ['recipe_tropical_oats']);
  editor.toggleSaved(click('fake')); assert.deepEqual(store.getSettings().savedRecipes, ['recipe_tropical_oats']); assert(editor.data.error);
  const only = page('recipes', {favorites: '1'}); assert.equal(only.data.items.length, 1); assert.equal(only.data.items[0].id, 'recipe_tropical_oats');
});
test('storage failure never paints a false successful favorite and retry actually persists', () => {
  const editor = page(); failWrite = true; editor.toggleSaved(click('recipe_tomato_egg'));
  assert.deepEqual(store.getSettings().savedRecipes, []); assert.equal(editor.data.items[0].saved, false); assert(editor.data.error);
  failWrite = false; editor.toggleSaved(click('recipe_tomato_egg')); assert.equal(editor.data.items[0].saved, true); assert.equal(editor.data.error, '');
});
test('an account change blocks a stale favorite click and existing favorites stay account-scoped', () => {
  const editor = page(); editor.toggleSaved(click('recipe_tomato_egg'));
  store.switchAccount('another-user'); editor.toggleSaved(click('recipe_tropical_oats'));
  assert.deepEqual(store.getSettings().savedRecipes, []); assert.match(editor.data.error, /账号已变化/);
  editor.onShow(); assert(editor.data.items.every(r => !r.saved));
  store.useLocal(); assert.deepEqual(store.getSettings().savedRecipes, ['recipe_tomato_egg']);
});
test('draw works on current preferences; clearing an empty selection retains chosen allergen exclusions', () => {
  const editor = page(); editor.toggleTag(click('breakfast')); legacyAvoid(editor,'milk');
  assert.equal(editor.data.items.length, 0); editor.draw(draw(3)); assert.equal(editor.data.items.length, 0);
  editor.clearPreferences(); assert.deepEqual(editor.data.avoid, ['milk']); assert(editor.data.items.every(r => !r.allergens.includes('milk')));
  editor.draw(draw(3)); assert.equal(editor.data.items.length, 3); assert.equal(new Set(editor.data.items.map(r => r.id)).size, 3);
  editor.toggleTag(click('side')); assert.equal(editor.data.drawn, false); assert(editor.data.items.every(r => r.tags.includes('side')));
});
test('direct recipe links expand the recipe while source metadata stays out of the UI', () => {
 const editor=page('recipes',{id:'recipe_tropical_oats'});assert.equal(editor.data.activeId,'recipe_tropical_oats');
 const source=fs.readFileSync(path.join(__dirname,'../miniprogram/pages/recipes/index.wxml'),'utf8');assert.doesNotMatch(source,/copySource|source\.url|source\.title/);assert(recipes.getRecipe('recipe_tropical_oats').source.url.startsWith('https://'));assert.equal(editor.copySource,undefined);
});
test('favorite helper enforces capacity, uniqueness and immutable inputs', () => {
  const ids = ['recipe_tomato_egg', 'recipe_tomato_egg'];
  assert.deepEqual(recipes.toggleFavoriteIds(ids, 'recipe_tropical_oats'), ['recipe_tomato_egg', 'recipe_tropical_oats']); assert.equal(ids.length, 2);
  assert.throws(() => recipes.toggleFavoriteIds(Array.from({length: 100}, (_, i) => 'future_' + i), 'recipe_tropical_oats'));
});
test('meal entry has two distinct food shortcuts and a single nutrition card containing its review', () => {
  const markup = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/meals/index.wxml'), 'utf8');
  assert.equal((markup.match(/class="shortcut-card /g) || []).length, 2);
  assert.match(markup, /shortcut-card recipe-shortcut" bindtap="browseRecipes"/);
  assert(!markup.includes('看看今天的营养')); assert(!markup.includes('class="today-card review-panel"'));
  assert.equal((markup.match(/class="today-card nutrition-card"/g) || []).length, 1);
});

test('the migrated questionnaire retains color, texture, temperature and scene, adds taste, and strips unknown values', () => {
  assert.deepEqual(recipes.PREFERENCE_QUESTIONS.map(question => question.key), ['taste', 'color', 'texture', 'temperature', 'scene']);
  assert(recipes.PREFERENCE_QUESTIONS.every(question => question.options.length === 4));
  assert.deepEqual(recipes.normalizePreferences({taste: 'light', color: 'imaginary', surprise: true}), {taste: 'light', color: '', texture: '', temperature: '', scene: ''});
  assert.deepEqual(recipes.preferenceLabels({taste: 'light', texture: 'soft'}), ['清淡一点', '软糯']);
});
test('recommendations rank actual matching attributes and cannot invent a purple or crispy dish', () => {
  const pool = recipes.filterRecipes({avoid: ['milk']});
  const result = recipes.recommendRecipes(pool, {taste: 'light', texture: 'soft'}, 3);
  assert.equal(result.length, 3); assert(result.every(recipe => recipe.matchLabels.includes('清淡一点') && recipe.matchLabels.includes('软糯')));
  assert(result.every(recipe => !recipe.allergens.includes('milk')));
  assert.deepEqual(recipes.recommendRecipes(pool, {color: 'purple'}, 3), []);
  assert.deepEqual(recipes.recommendRecipes(pool, {texture: 'crisp'}, 3), []);
  assert.equal(recipes.pickRecipes(pool, 3, () => 0).length, 3, 'random choice does not pretend to match an unsupported preference');
});
test('inline quiz choices persist, may be skipped, and both recommendation and random paths retain allergen exclusions', () => {
  const editor = page(); editor.choosePreference(click('light')); editor.nextQuestion(); editor.choosePreference(click('purple'));
  editor.nextQuestion(); editor.choosePreference(click('soft')); editor.nextQuestion(); editor.nextQuestion(); editor.nextQuestion();
  assert.equal(editor.data.quizOpen, false); assert.equal(editor.data.questionIndex, 4);
  assert.equal(store.getSettings().foodPreferences.taste, 'light'); assert.equal(page().data.preferences.color, 'purple');
  legacyAvoid(editor,'milk'); assert.deepEqual(page().data.avoid, ['milk']);
  editor.draw(draw(3)); assert.equal(editor.data.items.length, 3); assert(editor.data.items.every(item => !item.allergens.includes('milk')));
  assert(editor.data.items.every(item => !item.matchLabels.includes('紫色')));
  editor.chooseMode({currentTarget: {dataset: {mode: 'random'}}}); editor.draw(draw(3));
  assert.match(editor.data.resultLabel, /^随机/); assert(editor.data.items.every(item => !item.allergens.includes('milk')));
  assert.deepEqual(store.getSettings().foodAvoid, ['milk']);
  editor.clearPreferences(); assert.equal(editor.data.preferenceSummary, ''); assert.deepEqual(editor.data.avoid, ['milk']);
  assert.deepEqual(store.getSettings().foodPreferences, recipes.normalizePreferences({}));
});
test('preference and exclusion save failures keep the last persisted selection visible', () => {
  const editor = page(); editor.choosePreference(click('light')); failWrite = true;
  editor.choosePreference(click('savory')); assert.equal(editor.data.preferences.taste, 'light'); assert(editor.data.error);
  assert.throws(()=>legacyAvoid(editor,'egg'),/保存失败/); assert.deepEqual(editor.data.avoid, []); assert.deepEqual(store.getSettings().foodAvoid || [], []);
  editor.clearPreferences(); assert.equal(editor.data.preferences.taste, 'light');
  failWrite = false; editor.choosePreference(click('savory')); assert.equal(page().data.preferences.taste, 'savory');
});
test('food preferences and avoidance survive the validated cloud shape and exported backup', () => {
  const editor = page(); editor.choosePreference(click('tangy')); legacyAvoid(editor,'egg');
  const state = validateState(store.getState()); assert.equal(state.settings.foodPreferences.taste, 'tangy'); assert.deepEqual(state.settings.foodAvoid, ['egg']);
  const exported = store.exportData(); store.saveSettings({foodPreferences: recipes.normalizePreferences({}), foodAvoid: []}); store.restoreData(exported);
  assert.equal(page().data.preferences.taste, 'tangy'); assert.deepEqual(page().data.avoid, ['egg']);
});
test('opening a recipe meal draft writes no intake, copies no recipe quantity or calories, and does not invoke AI', async () => {
  const explorer = page(); const before = store.getRevision(); explorer.draftMeal(click('recipe_tomato_egg'));
  assert(events.includes('/pages/meal-edit/index?recipeId=recipe_tomato_egg')); assert.equal(store.getRevision(), before);
  const draft = page('meal-edit', {recipeId: 'recipe_tomato_egg'}); draft.onReady();
  assert.equal(draft.data.name, '番茄炒蛋'); assert.equal(draft.data.fromRecipe, true); assert.equal(draft.data.note, '');
  for (const key of ['kcal', 'protein', 'carbs', 'fat']) assert.equal(draft.data[key], '');
  assert.deepEqual(store.getMeals(), []); assert.deepEqual(store.getDay().actions, []);
  await draft.cancelEdit(); assert.deepEqual(store.getMeals(), []); assert(events.includes('back'));
});
test('a meal draft becomes a real record only after saving and never overrides a specified existing meal', async () => {
  const original = store.saveMeal({name: '已经吃过的饭', date: store.today(), time: '12:00', kcal: 300});
  const edit = page('meal-edit', {id: original.id, recipeId: 'recipe_tomato_egg'});
  assert.equal(edit.data.name, original.name); assert.equal(edit.data.fromRecipe, false);
  const draft = page('meal-edit', {recipeId: 'recipe_tomato_egg'}); await draft.save();
  assert.equal(store.getMeals().length, 2); const saved = store.getMeals().find(item => item.id !== original.id);
  assert.equal(saved.confirmed, true); assert.equal(saved.name, '番茄炒蛋'); assert.equal(saved.kcal, null); assert.equal(saved.nutritionSource, 'manual');
  assert.equal(store.getMeals().find(item => item.id === original.id).kcal, 300);
  assert.equal(page('meal-edit', {recipeId: 'fake'}).data.name, '');
});
test('a tasting action persists a reusable manual template with three questions, not a meal or completion', () => {
  const editor = page(); editor.addTasting(click('recipe_tomato_egg'));
  const actions = store.getDay().actions; assert.equal(actions.length, 1); assert.equal(actions[0].status, 'planned');
  assert.equal(actions[0].source, 'manual'); assert.equal(actions[0].durationMinutes, 2); assert.equal(actions[0].category, 'senses');
  assert.equal(actions[0].steps.length, 3); assert(actions[0].steps.every(step => step.includes('？')));
  assert.match(actions[0].steps[0], /等番茄炒蛋准备好/); assert(!actions[0].audio); assert.deepEqual(store.getMeals(), []);
  assert.equal(store.getCustomActions().length, 1); assert.equal(validateState(store.getState()).days[store.today()].actions.length, 1);
  editor.addTasting(click('recipe_tomato_egg')); assert.equal(store.getDay().actions.length, 1); assert.equal(store.getCustomActions().length, 1);
  assert(events.includes('/pages/action/index?id=' + actions[0].id)); assert(page().data.items.find(item => item.id === 'recipe_tomato_egg').actionId);
  store.setActionStatus(actions[0].id, 'completed'); editor.onShow(); editor.addTasting(click('recipe_tomato_egg'));
  assert.equal(store.getDay().actions.length, 1, 'reopening an already completed tasting must not create another task');
});
test('tasting retains catalog boundaries, blocks excluded food and writes nothing after storage failure or account change', () => {
  const template = recipes.tastingTemplate('recipe_tomato_egg', {avoidWhen: ['dizziness'], tags: ['senses', 'gentle'], minimumVersion: '只看看颜色', stopSignal: '不舒服就停下'});
  assert.deepEqual(template.avoidWhen, ['dizziness']); assert.equal(template.minimumVersion, '只看看颜色'); assert.match(template.stopSignal, /不舒服就停下/);
  assert(template.tags.includes('senses') && template.tags.includes('gentle'), 'catalog feedback-related tags remain present');
  const editor = page(); legacyAvoid(editor,'egg'); editor.addTasting(click('recipe_tomato_egg')); assert.deepEqual(store.getDay().actions, []);
  store.saveSettings({foodAvoid:[]});editor.onShow(); failWrite = true; editor.addTasting(click('recipe_tomato_egg')); assert.deepEqual(store.getCustomActions(), []); assert(editor.data.error);
  failWrite = false; store.switchAccount('different-user');
  editor.addTasting(click('recipe_tomato_egg')); editor.draftMeal(click('recipe_tomato_egg')); editor.choosePreference(click('light'));
  assert.deepEqual(store.getDay().actions, []); assert.deepEqual(store.getMeals(), []); assert.deepEqual(store.getCustomActions(), []); assert.match(editor.data.error, /账号已变化/);
  editor.onShow(); assert.equal(editor.data.preferenceSummary, '');
});
test('a failed day insertion leaves one reusable template and retry adds one planned action', () => {
  const editor = page(), original = store.addAction;
  try { store.addAction = () => { throw new Error('temporary write failure'); }; editor.addTasting(click('recipe_tomato_egg')); }
  finally { store.addAction = original; }
  assert.match(editor.data.error, /temporary write failure/); assert.equal(store.getCustomActions().length, 1); assert.equal(store.getDay().actions.length, 0);
  editor.addTasting(click('recipe_tomato_egg')); assert.equal(store.getCustomActions().length, 1); assert.equal(store.getDay().actions.length, 1); assert.equal(editor.data.error, '');
});
test('recent discomfort and explicit activity boundaries also apply to food discovery actions', () => {
  const editor = page(); store.saveProfile({avoidedActivities: '尝一口 · 番茄炒蛋'}); editor.addTasting(click('recipe_tomato_egg'));
  assert.equal(store.getCustomActions().length, 0); assert.match(editor.data.error, /身体边界/);
  store.saveProfile({avoidedActivities: ''}); const tasting = store.addAction('senses_first_bite'); store.setActionStatus(tasting.id, 'completed', 'uncomfortable');
  editor.addTasting(click('recipe_tomato_egg')); assert.equal(store.getCustomActions().length, 0); assert.equal(store.getDay().actions.length, 1);
});
test('opening an excluded favorite explains its absence instead of silently showing unrelated recipes', () => {
  store.saveSettings({savedRecipes: ['recipe_tomato_egg'], foodAvoid: ['egg']});
  const editor = page('recipes', {id: 'recipe_tomato_egg'});
  assert.match(editor.data.error, /番茄炒蛋.*避开/); assert.equal(editor.data.activeId, ''); assert(editor.data.items.every(item => !item.allergens.includes('egg')));
  assert.deepEqual(store.getSettings().foodAvoid, ['egg']);
});
test('the meal hero follows the selected named companion and live completion status without changing functional artwork', () => {
  store.saveSettings({companion: 'cat'}); const journal = page('meals');
  assert.equal(journal.data.mealCompanion.name, '团团'); assert.match(journal.data.mealCompanion.image, /companion-cat-meal/);
  const action = store.addAction('senses_first_bite'); store.setActionStatus(action.id, 'completed'); journal.onShow();
  assert.match(journal.data.mealCompanion.image, /companion-cat-meal/);
  store.saveSettings({companion: 'dachshund'}); journal.onShow(); assert.equal(journal.data.mealCompanion.name, '卷卷'); assert.match(journal.data.mealCompanion.image, /companion-dog-meal/);
  store.saveSettings({companion: 'xiaowei'}); journal.onShow(); assert.equal(journal.data.mealCompanion.image, '/assets/xiaowei-meal-v2.png');
  const mealMarkup = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/meal-edit/index.wxml'), 'utf8');
  const recipeMarkup = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/recipes/index.wxml'), 'utf8');
  assert(mealMarkup.includes('/assets/sticker-camera.png')); assert(recipeMarkup.includes('/assets/sticker-recipe.png'));
});
