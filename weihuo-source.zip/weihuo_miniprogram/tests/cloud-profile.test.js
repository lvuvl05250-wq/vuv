'use strict';

const test=require('node:test');
const assert=require('node:assert/strict');
const {profile,validateState}=require('../cloudfunctions/weihuoApi/state');
const {prepare,validateResult,runAI}=require('../cloudfunctions/weihuoApi/ai');
const {createProvider}=require('../cloudfunctions/weihuoApi/provider');

function oldProfile(){return {name:'',adult:true,safetyAnswered:true,specialCondition:false,restrictions:[],allergies:'',notes:'',goals:[],onboarded:true};}
function measurement(){return {id:'measure_1',name:'握力',value:'24.5',unit:'kg',date:'2026-10-03',source:'manual',reportId:'',sourceMetricKey:'',createdAt:'2026-10-04T08:00:00.000Z'};}
function richProfile(){return Object.assign(oldProfile(),{birthDate:'1998-03-08',heightCm:165,weightKg:58,bodyFatPercent:29,exerciseHabit:'每周散步两次',avoidedActivities:'不喜欢跳跃',bodyNotes:'脚踝受伤，先避免跳跃。',healthSummary:'此前确认的个人生活摘要',measurements:[measurement()]});}
function summary(){return {summary:'你记录了身高165cm、体重58kg，并喜欢每周散步两次。你提到脚踝受伤，先避免跳跃。',restrictions:['ankle'],restrictionEvidence:[{tag:'ankle',text:'脚踝受伤，先避免跳跃'}],allergies:'',avoidedActivities:'不喜欢跳跃'};}
function input(p){return prepare('summarizeProfile',{consent:true,profile:p||richProfile()}).data;}

test('legacy profiles and backups acquire empty defaults without losing original fields',()=>{
  const original=oldProfile();const normalized=profile(original);
  assert.equal(normalized.birthDate,'');assert.equal(normalized.heightCm,null);assert.equal(normalized.weightKg,null);assert.equal(normalized.bodyFatPercent,null);
  assert.equal(normalized.exerciseHabit,'');assert.equal(normalized.avoidedActivities,'');assert.equal(normalized.bodyNotes,'');assert.equal(normalized.healthSummary,'');assert.deepEqual(normalized.measurements,[]);
  assert.equal(Object.hasOwn(original,'measurements'),false);
  const state=validateState({profile:original,days:{},meals:[],plans:[],reports:[],tickets:[],settings:{aiConsent:false,cloudConsent:true,reduceMotion:false}});
  assert.deepEqual(state.profile,normalized);
});
test('structured profile and measurement source data survive cloud validation',()=>{
  const original=richProfile();const result=profile(original);
  assert.deepEqual(result,{avatarPath:'',foodExclusions:[],...original});assert.equal(typeof result.measurements[0].value,'string');
  original.measurements[0].source='report';original.measurements[0].reportId='confirmed_report_1';assert.equal(profile(original).measurements[0].source,'report');
  original.measurements[0].sourceMetricKey=JSON.stringify(['confirmed_report_1','握力','24.5','kg','2026-10-03']);
  original.measurements[0].value='25';assert.equal(profile(original).measurements[0].sourceMetricKey,original.measurements[0].sourceMetricKey);
  delete original.measurements[0].sourceMetricKey;assert.equal(profile(original).measurements[0].sourceMetricKey,'');
});
test('invalid measurement types, duplicate ids, report provenance, dates and excessive histories fail closed',()=>{
  for(const change of [
    p=>{p.heightCm=0;},p=>{p.weightKg=701;},p=>{p.bodyFatPercent=101;},p=>{p.birthDate='2999-01-01';},p=>{p.birthDate='2026-02-31';},
    p=>{p.measurements[0].value=24.5;},p=>{p.measurements.push(measurement());},p=>{p.measurements[0].source='report';},
    p=>{p.measurements[0].date='2026-02-31';},p=>{p.measurements[0].createdAt='not-a-date';},p=>{p.measurements[0].sourceMetricKey='x'.repeat(601);},
    p=>{p.measurements=Array.from({length:1001},(_,i)=>Object.assign(measurement(),{id:'m'+i}));}
  ]){const p=richProfile();change(p);assert.throws(()=>profile(p),e=>e.code==='INVALID_ARGUMENT');}
});
test('explicit body-note evidence permits a new catalog restriction only as an unsaved candidate',()=>{
  const p=richProfile();p.restrictions=['wrist'];const before=structuredClone(p);
  const result=validateResult('summarizeProfile',input(p),summary());
  assert.deepEqual(result.restrictions,['wrist','ankle']);assert.deepEqual(result.restrictionEvidence,summary().restrictionEvidence);
  assert.deepEqual(p,before,'候选生成不能改写profile');
});
test('restriction evidence cannot be invented, inferred from a number, or lifted from a negated statement',()=>{
  const p=richProfile();
  const check=(profile,result)=>{const actual=validateResult('summarizeProfile',input(profile),result);assert.equal(actual.summary,result.summary);assert.deepEqual(actual.restrictions,profile.restrictions);assert.deepEqual(actual.restrictionEvidence,[]);};
  const fabricated=summary();fabricated.restrictionEvidence[0].text='脚踝疼痛';check(p,fabricated);
  const numberOnly=summary();numberOnly.restrictions=['wrist'];numberOnly.restrictionEvidence=[{tag:'wrist',text:'握力24.5kg'}];check(p,numberOnly);
  const wrongPart=summary();wrongPart.restrictions=['knee'];wrongPart.restrictionEvidence=[{tag:'knee',text:'脚踝受伤，先避免跳跃'}];check(p,wrongPart);
  const negated=richProfile();negated.bodyNotes='脚踝没有疼痛';const negative=summary();negative.restrictionEvidence[0].text='脚踝没有疼痛';check(negated,negative);
  negated.bodyNotes='我没有脚踝疼痛';negative.restrictionEvidence[0].text='脚踝疼痛';check(negated,negative);
  const unknown=summary();unknown.restrictions=['diabetes'];unknown.restrictionEvidence=[];check(p,unknown);
});
test('summary prose remains reviewable without overwriting user allergies or avoided activities',()=>{
  for(const change of [r=>{r.allergies='花生';},r=>{r.avoidedActivities='不能进行所有运动';},r=>{r.summary='你的体脂率偏高，应服用药物。';}]){
    const result=summary();change(result);const actual=validateResult('summarizeProfile',input(),result);assert.equal(actual.summary,result.summary);assert.equal(actual.allergies,'');assert.equal(actual.avoidedActivities,'不喜欢跳跃');
  }
});
test('no new restriction is required and a legacy profile can be summarized',()=>{
  const data=input(oldProfile());
  const result=validateResult('summarizeProfile',data,{summary:'你已确认成年，其他生活资料尚未填写。',restrictions:[],allergies:'',avoidedActivities:''});
  assert.deepEqual(result.restrictionEvidence,[]);assert.deepEqual(result.restrictions,[]);
  assert.throws(()=>prepare('summarizeProfile',{profile:oldProfile()}),e=>e.code==='AI_CONSENT_REQUIRED');
});
test('all existing profile-aware AI requests accept enriched profiles and movement guards consider body notes',()=>{
  const p=richProfile();
  assert.equal(prepare('analyzeMeal',{consent:true,name:'午餐',profile:p}).data.profile.measurements[0].value,'24.5');
  assert.equal(prepare('parseState',{consent:true,text:'今天想轻松一点',profile:p}).data.profile.heightCm,165);
  assert.throws(()=>prepare('generatePlan',{consent:true,profile:p,type:'life',goal:'安排日常',startDate:'2026-10-04'}),e=>e.code==='PLAN_SAFETY_REVIEW_REQUIRED');
});
test('summarizeProfile uses the actual provider adapter with profile facts and independent AI consent',async()=>{
  let posted=null,reservations=0;
  const provider=createProvider({WEIHUO_AI_ENDPOINT:'https://example.test/v1/chat/completions',WEIHUO_AI_API_KEY:'test-only',WEIHUO_AI_MODEL:'test-only'},async(_url,options)=>{posted=JSON.parse(options.body);return new Response(JSON.stringify({choices:[{message:{content:JSON.stringify(summary())},finish_reason:'stop'}]}));});
  const result=await runAI('summarizeProfile',{consent:true,profile:richProfile()},provider,async()=>{reservations++;});
  assert.equal(reservations,1);assert.equal(result.restrictions[0],'ankle');
  const sent=JSON.parse(posted.messages[1].content);assert.equal(sent.input.profile.birthDate,'1998-03-08');assert.equal(sent.input.profile.measurements[0].name,'握力');
  assert.match(posted.messages[0].content,/不得从measurements/);
});
