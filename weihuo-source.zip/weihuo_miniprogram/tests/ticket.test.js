'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let toastMessages = [], albumCalls = [], exportCalls = [], drawnText = [], imageSources = [], failWrites = false;
function canvas() {
  let size = 16;
  const context = {setFontSize: value => { size = value; }, measureText: text => ({width: Array.from(text).reduce((sum, char) => sum + (/^[\x00-\x7f]$/.test(char) ? size * 0.6 : size), 0)}),
    fillText: (text, x, y) => drawnText.push({text, x, y}), draw: (reserve, callback) => callback()};
  Object.defineProperty(context,'font',{set:value=>{size=parseFloat(value);}});
  ['scale','setFillStyle', 'fillRect','strokeRect', 'beginPath', 'moveTo', 'lineTo', 'closePath', 'fill', 'setStrokeStyle', 'setLineWidth', 'stroke', 'save', 'translate', 'rotate', 'arc', 'setTextAlign', 'restore', 'drawImage'].forEach(name => { context[name] = () => {}; });
  return context;
}
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => { if (failWrites) throw new Error('test: disk full'); disk.set(key, JSON.parse(JSON.stringify(value))); },
  showToast: value => toastMessages.push(value.title), showModal: value => { if (value.success) value.success({confirm: true}); },
  createOffscreenCanvas: options => ({...options,getContext:()=>canvas(),createImage(){const image={width:420,height:280};Object.defineProperty(image,'src',{set:value=>{imageSources.push(value);queueMicrotask(()=>image.onload());}});return image;}}), getImageInfo: options => options.success({path: '/assets/xiaowei-ticket.png'}),
  canvasToTempFilePath: options => { exportCalls.push(options); options.success({tempFilePath: '/test/ticket-' + exportCalls.length + '.png'}); },
  saveImageToPhotosAlbum: options => { albumCalls.push(options.filePath); options.success({}); },
  openSetting: options => options.success({authSetting: {'scope.writePhotosAlbum': true}})
};
const store = require(path.join(root, 'services/store'));
const image = require(path.join(root, 'services/ticket-image'));
const api = require(path.join(root, 'services/api'));
const originalRender = image.render, originalRequest = api.request, originalAlbumSave = wx.saveImageToPhotosAlbum, originalExport = wx.canvasToTempFilePath;
function ticketPage() {
  let definition; global.Page = value => { definition = value; };
  const file = path.join(root, 'pages/ticket/index.js'); delete require.cache[require.resolve(file)]; require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = function (patch, callback) { Object.assign(this.data, patch); if (callback) callback(); };
  instance.onLoad({date: store.today()}); instance.onShow(); return instance;
}
function makeSealed(note) {
  const action = store.addAction({title: '读了两页书', durationMinutes: 2, kind: 'care', steps: []});
  store.setActionStatus(action.id, 'completed', 'comfortable');
  store.saveMeal({name: '苹果与酸奶'});
  return store.saveDiary(store.today(),{title:'慢慢收好这一天',yi:'快乐',paragraphs:['读了两页书，也给苹果与酸奶留了个位置。'],quote:'今天有今天的小得意。',stickers:[{kind:'face',side:'right'}]},note||'给自己留了一点时间');
}
test.beforeEach(() => {
  failWrites = false; toastMessages = []; albumCalls = []; exportCalls = []; drawnText = []; imageSources = [];
  image.render = originalRender; api.request = originalRequest; wx.saveImageToPhotosAlbum = originalAlbumSave; wx.canvasToTempFilePath = originalExport;
  store.useLocal(); store.clearAll();
});
test.afterEach(() => { image.render = originalRender; api.request = originalRequest; wx.saveImageToPhotosAlbum = originalAlbumSave; wx.canvasToTempFilePath = originalExport; });

test('long Chinese and mixed-width text wrap without losing characters', () => {
  const text = '今天给自己留了很多很多空间，' + '一小步也是生活的一部分'.repeat(20) + ' very-long-English-title-abcdefghijk';
  const measure = (value, size) => Array.from(value).reduce((sum, char) => sum + (/^[\x00-\x7f]$/.test(char) ? size * 0.6 : size), 0);
  const lines = image.wrapText(text, 288, 16, measure);
  assert.equal(lines.join(''), text); assert(lines.every(line => measure(line, 16) <= 288)); assert(lines.length > 2);
});

test('line wrapping keeps closing Chinese punctuation with the preceding character',()=>{
 const lines=image.wrapText('写下今天。明天再见！',40,10,(text,size)=>Array.from(text).length*size);
 assert.equal(lines.join(''),'写下今天。明天再见！');assert(lines.every(line=>!/[。！]/.test(line[0])&&line.length<=4));
});

test('long title and note paginate at safe image height while preserving the complete contents', () => {
  const title = '一张不会丢掉任何字的生活票根'.repeat(10);
  const note = '今天的每一点感受都值得被好好记住。'.repeat(160);
  const model = image.buildLayout({date: '2026-10-04', title, note, mood: '平静', actions: [], meals: []});
  assert(model.pages.length > 1); assert(model.pages.every(page => page.height <= 1200));
  const lines = model.pages.flatMap(page => page.lines);
  assert.equal(lines.filter(line => line.type === 'title').map(line => line.text).join(''), title);
  assert(lines.filter(line => line.type === 'personal').map(line => line.text).join('').includes(note));
  const newlineTitle = ('甲\n').repeat(90);
  const multiline = image.buildLayout({date: '2026-10-04', title: newlineTitle, note: '', mood: '', actions: [], meals: []});
  assert.equal(multiline.pages.flatMap(page => page.lines).filter(line => line.type === 'title').map(line => line.text).join(''), newlineTitle.replace(/\n/g, ''));
  assert(multiline.pages.every(page => page.height <= 1200));
});

test('canvas export draws all title lines, numbered continuation pages and bounded high-resolution images', async () => {
  const ticket = makeSealed('把一整天的事情慢慢记下来。'.repeat(140));
  ticket.title = '标题里的每一个中文字都应该完整出现'.repeat(6);
  const page = ticketPage(); const paths = await image.render(page, ticket);
  assert(paths.length > 1); assert.equal(paths.length, exportCalls.length);
  assert(exportCalls.every(call => call.destWidth === 1080 && call.destHeight <= 3600));
  assert(drawnText.some(item=>item.text.includes('这一页，收好啦')));
  assert(drawnText.some(item => item.text === ticket.date + ' · ' + paths.length + ' / ' + paths.length));
  const expected = image.buildLayout(ticket).titleLines;
  expected.forEach(line => assert(drawnText.some(item => item.text === line)));
});

test('saved diaries remain editable and preserve one entry while raw records stay separate', () => {
 const first=makeSealed();store.saveMeal({name:'后来记下的一餐'});store.saveMeal({name:'候选',confirmed:false});
 const page=ticketPage();assert.equal(page.data.counts.meals,1);assert.equal(page.data.counts.actions,1);
 page.field({currentTarget:{dataset:{field:'aiText'}},detail:{value:'原来今天还有这么多值得记住的事。'}});
 page.field({currentTarget:{dataset:{field:'note'}},detail:{value:'再补一句自己的话'}});page.seal();
 assert.equal(store.getTickets().length,1);assert.equal(store.getTicket().id,first.id);assert.equal(store.getTicket().diary.paragraphs[0],'原来今天还有这么多值得记住的事。');assert.equal(store.getTicket().note,'再补一句自己的话');assert.equal(page.data.counts.meals,2);assert.equal(store.getMeals().length,3);page.onUnload();
});

test('drawing failure never calls album save or reports success', async () => {
  makeSealed(); const page = ticketPage();
  wx.canvasToTempFilePath = options => options.fail({errMsg: 'canvas export failed'});
  await page.saveImage();
  assert(page.data.error.includes('图片生成失败')); assert.equal(albumCalls.length, 0); assert.equal(page.data.busy, false);
  assert(!toastMessages.some(message => message.includes('已保存')));
});

test('album authorization guidance appears only after an actual permission failure', async () => {
  makeSealed(); const page = ticketPage();
  assert.equal(page.data.albumDenied, false);
  wx.saveImageToPhotosAlbum = options => { albumCalls.push(options.filePath); options.fail({errMsg: 'saveImageToPhotosAlbum:fail auth deny'}); };
  await page.saveImage(); assert.equal(albumCalls.length, 1); assert.equal(page.data.albumDenied, true);
  assert(page.data.error.includes('允许保存')); assert(!toastMessages.some(message => message.includes('已保存')));
  page.openSettings(); assert.equal(page.data.albumDenied, false);
});

test('partial multi-image save reports the exact successful count without a false completion toast', async () => {
  makeSealed(); const page = ticketPage(); image.render = async () => ['/test/one.png', '/test/two.png'];
  wx.saveImageToPhotosAlbum = options => { albumCalls.push(options.filePath); if (albumCalls.length === 1) options.success({}); else options.fail({errMsg: 'album full'}); };
  await page.saveImage(); assert.equal(page.data.albumDenied, false); assert(page.data.error.includes('已保存 1 / 2 张'));
  assert(!toastMessages.some(message => message.includes('已保存')));
});

test('all rendered pages must reach the album before reporting success', async () => {
  makeSealed(); const page = ticketPage(); image.render = async () => ['/test/one.png', '/test/two.png'];
  await page.saveImage(); assert.deepEqual(albumCalls, ['/test/one.png', '/test/two.png']);
  assert.deepEqual(toastMessages, ['2 页日记图片已保存']); assert.equal(page.data.error, '');
});

test('account changes during export stop album writes and reload clears the previous draft title', async () => {
  makeSealed(); const page = ticketPage();
  image.render = async () => { store.switchAccount('ticket-other-test-account'); store.clearAll(); return ['/test/one.png']; };
  await page.saveImage(); assert.equal(albumCalls.length, 0); assert(page.data.error.includes('账号已变化'));
  page.reload(); assert.equal(page.data.title, ''); assert.equal(page.data.note, '');
});

test('storage failure keeps the diary draft and failed AI continuation cannot replace user text', async () => {
  store.saveDay({note: '今天给自己留了空白'}); const page = ticketPage(); await new Promise(resolve=>setImmediate(resolve));
  page.setData({title:'我自己的标题',aiText:'我自己的日记'}); failWrites = true; page.seal(); failWrites = false;
  assert.equal(store.getTicket(), null); assert.equal(page.data.sealed, false); assert(page.data.error.includes('保存失败'));
  api.request = async () => ({paragraphs:[]}); await page.generate(true);
  assert.equal(page.data.aiText,'我自己的日记'); assert(page.data.error.includes('还没写好'));
});

test('image export includes the latest unsaved writing from both diary sections', async () => {
  makeSealed();const page=ticketPage();let rendered;
  page.field({currentTarget:{dataset:{field:'aiText'}},detail:{value:'下午又散了一会儿步。'}});
  page.field({currentTarget:{dataset:{field:'note'}},detail:{value:'我还听见了鸟叫。'}});
  image.render=async (instance,ticket)=>{rendered=ticket;return ['/test/latest.png'];};
  await page.saveImage();
  assert.deepEqual(rendered.diary.paragraphs,['下午又散了一会儿步。']);assert.equal(rendered.note,'我还听见了鸟叫。');
  assert.deepEqual(store.getTicket(),rendered);assert.equal(albumCalls.length,1);
});

test('packaged image paths from getImageInfo remain absolute for offscreen image loading',async t=>{
 const original=wx.getImageInfo;t.after(()=>{wx.getImageInfo=original;});
 wx.getImageInfo=options=>options.success({path:options.src.replace(/^\//,'')});
 const ticket=makeSealed(),page=ticketPage();await image.render(page,ticket,{companionKey:'xiaowei',companionImage:'/assets/xiaowei-checkin-v2.png'});
 assert(imageSources.length>=2);assert(imageSources.every(src=>src.startsWith('/assets/')));
});

test('a personal-note-only diary requests an AI draft without losing the personal note', async () => {
  store.saveDiary(store.today(),{paragraphs:[]},'今天睡了一觉');let payload;
  api.request=async (task,value)=>{assert.equal(task,'generateDiary');payload=value;return {title:'睡醒啦',yi:'自在',paragraphs:['这一觉，给今天按了个暂停。'],quote:'',stickers:[]};};
  const page=ticketPage();await new Promise(resolve=>setImmediate(resolve));
  assert(payload.note.includes('今天睡了一觉'));assert.equal(page.data.note,'今天睡了一觉');
  assert.match(page.data.aiText,/暂停/);assert.deepEqual(store.getTicket().diary.paragraphs,[]);
});

test('stamp ink and sound arrive together after successful persistence', async () => {
  makeSealed();const page=ticketPage();let played=0;page.playStampSound=()=>played++;
  page.seal();assert.equal(page.data.stamping,true);assert.equal(page.data.stampLanded,false);assert.equal(played,0);
  await new Promise(resolve=>setTimeout(resolve,430));
  assert.equal(page.data.stampLanded,true);assert.equal(played,1);page.onUnload();
  failWrites=true;page.seal();failWrites=false;assert.equal(played,1);assert.match(page.data.error,/保存失败/);
});

test('reduced motion stamps immediately and an unloaded page makes no late sound', async () => {
  makeSealed();store.saveSettings({reduceMotion:true});const page=ticketPage();let played=0;page.playStampSound=()=>played++;
  page.seal();assert.equal(page.data.stamping,false);assert.equal(page.data.stampLanded,true);assert.equal(played,1);
  store.saveSettings({reduceMotion:false});page.seal();page.onUnload();
  await new Promise(resolve=>setTimeout(resolve,430));assert.equal(played,1);
});

test('ticket WXML expressions are valid and permission controls are conditional', () => {
  const source = fs.readFileSync(path.join(root, 'pages/ticket/index.wxml'), 'utf8');
  for (const match of source.matchAll(/\{\{([\s\S]*?)\}\}/g)) {
    assert(!/&(lt|gt|amp|quot|apos);/.test(match[1])); assert.doesNotThrow(() => new Function('return (' + match[1] + ');'));
  }
  assert(source.includes('wx:if="{{albumDenied}}"')); assert(!source.includes('相册权限设置'));
});


test('ticket preview and exported image follow the selected companion without changing sealed content',async t=>{
 const ticket=makeSealed();const originalInfo=wx.getImageInfo;const requests=[];wx.getImageInfo=o=>{requests.push(o.src);o.success({path:o.src,width:420,height:280});};t.after(()=>{wx.getImageInfo=originalInfo;});
 store.saveSettings({companion:'cat'});const page=ticketPage();assert.match(page.data.companionImage,/companion-cat-rest/);await page.saveImage();assert.match(requests[0],/companion-cat-rest/);
 store.saveSettings({companion:'dachshund'});page.onShow();assert.match(page.data.companionImage,/companion-dog-rest/);await page.saveImage();assert(requests.some(src=>/companion-dog-rest/.test(src)));assert.deepEqual(store.getTicket(),ticket);
});
