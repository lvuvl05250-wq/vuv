'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
function setup(){const saved=new Map(),oldWx=global.wx,oldPage=global.Page;let pageDef;global.wx={getStorageSync:k=>saved.get(k)||'',setStorageSync:(k,v)=>saved.set(k,structuredClone(v)),showToast:()=>{},navigateBack:()=>{}};for(const m of ['store','api'])delete require.cache[require.resolve('../miniprogram/services/'+m)];const store=require('../miniprogram/services/store');store.init();store.switchAccount('state_test_user');store.saveSettings({aiConsent:true});const api=require('../miniprogram/services/api'),request=api.request;const requests=[];api.request=async()=>({energy:2,scene:'home',minutes:15,mood:'想休息',note:'model rewritten'});global.Page=d=>pageDef=d;delete require.cache[require.resolve('../miniprogram/pages/state/index')];require('../miniprogram/pages/state/index');const page={...pageDef,data:structuredClone(pageDef.data),setData(p){for(const [k,v] of Object.entries(p)){if(k.startsWith('day.'))this.data.day[k.slice(4)]=v;else this.data[k]=v;}}};page.onLoad();page.field({currentTarget:{dataset:{field:'note'}},detail:{value:'我好困，想休息一会儿'}});return {store,api,page,close:()=>{api.request=request;global.wx=oldWx;global.Page=oldPage;}};}
test('one save persists original words immediately and merges only automatic fields afterward',async()=>{const h=setup();try{h.page.pick({currentTarget:{dataset:{field:'minutes',value:20}}});await h.page.save();assert.equal(h.store.getDay().note,'我好困，想休息一会儿');await new Promise(resolve=>setImmediate(resolve));const d=h.store.getDay();assert.equal(d.energy,2);assert.equal(d.scene,'home');assert.deepEqual(d.scenes,['home']);assert.equal(d.minutes,20);assert.equal(d.note,'我好困，想休息一会儿');assert.equal(h.page.data.busy,false);}finally{h.close();}});
test('model failure still leaves durable original state',async()=>{const h=setup();try{h.api.request=async()=>{throw Error('unavailable');};await h.page.save();assert.equal(h.store.getDay().note,'我好困，想休息一会儿');assert.equal(h.store.getDay().energy,3);assert.equal(h.page.data.error,'');}finally{h.close();}});
test('a failed state parse can be retried from the already-saved original',async()=>{const h=setup();try{let calls=0;h.api.request=async()=>{calls++;if(calls===1)throw Error('unavailable');return {energy:4,scene:'home',minutes:15,mood:'平静'};};await h.page.save();await new Promise(resolve=>setImmediate(resolve));assert.equal(h.store.getDay().energy,3);const reopened={...h.page,data:structuredClone(h.page.data)};reopened.onLoad();await reopened.save();await new Promise(resolve=>setImmediate(resolve));assert.equal(calls,2);assert.equal(h.store.getDay().energy,4);assert.equal(h.store.getDay().note,'我好困，想休息一会儿');}finally{h.close();}});
test('disabled AI and blank notes do not send requests',async()=>{const h=setup();try{let count=0;h.api.request=async()=>{count++;};h.store.saveSettings({aiConsent:false});await h.page.save();h.store.saveSettings({aiConsent:true});h.page.data.day.note='';await h.page.save();assert.equal(count,0);}finally{h.close();}});
test('save returns without waiting for AI and a late result cannot overwrite newer state or another account',async()=>{for(const change of ['edit','account']){const h=setup();try{let done;h.api.request=()=>new Promise(r=>done=r);const pending=h.page.save();await pending;assert.equal(h.page.data.busy,false);assert.equal(h.store.getDay().note,'我好困，想休息一会儿');if(change==='edit')h.store.saveDay({note:'后来精神好了',energy:5});else h.store.switchAccount('other_test_user');done({energy:1,scene:'home',minutes:15,mood:'疲惫'});await new Promise(resolve=>setImmediate(resolve));if(change==='edit'){assert.equal(h.store.getDay().energy,5);assert.equal(h.store.getDay().note,'后来精神好了');}else assert.equal(h.store.getDay().note,'');}finally{h.close();}}});


test('multi-place choices and the activity preference survive automatic text organization',async()=>{
 const h=setup();try{
  h.page.toggleScene({currentTarget:{dataset:{value:'outdoor'}}});
  h.page.toggleScene({currentTarget:{dataset:{value:'commute'}}});
  h.page.careChange({detail:{value:75}});
  h.page.energy({currentTarget:{dataset:{value:4}}});
  h.page.pick({currentTarget:{dataset:{field:'minutes',value:60}}});
  h.page.pick({currentTarget:{dataset:{field:'mood',value:'愉快'}}});
  await h.page.save();await new Promise(resolve=>setImmediate(resolve));const d=h.store.getDay();
  assert.deepEqual(d.scenes,['office','outdoor','commute']);assert.equal(d.scene,'office');
  assert.equal(d.carePreference,75);assert.equal(d.energy,4);assert.equal(d.minutes,60);assert.equal(d.mood,'愉快');
  assert.equal(h.page.data.scenes.filter(item=>item.selected).length,3);
 }finally{h.close();}
});

test('place selection cannot become empty, and unspecified location is exclusive',()=>{
 const h=setup();try{
  h.page.toggleScene({currentTarget:{dataset:{value:'office'}}});assert.deepEqual(h.page.data.day.scenes,['office']);
  h.page.toggleScene({currentTarget:{dataset:{value:'any'}}});assert.deepEqual(h.page.data.day.scenes,['any']);
  h.page.toggleScene({currentTarget:{dataset:{value:'home'}}});assert.deepEqual(h.page.data.day.scenes,['home']);
  h.page.toggleScene({currentTarget:{dataset:{value:'invalid'}}});assert.deepEqual(h.page.data.day.scenes,['home']);
 }finally{h.close();}
});

test('available time choices start at ten minutes and invalid event values are ignored',()=>{
 const h=setup();try{
  assert.deepEqual(h.page.data.minutes,[10,20,30,45,60,90]);const initial=h.page.data.day.minutes;
  h.page.pick({currentTarget:{dataset:{field:'minutes',value:3}}});assert.equal(h.page.data.day.minutes,initial);
  h.page.careChange({detail:{value:101}});assert.equal(h.page.data.day.carePreference,50);
  h.page.energy({currentTarget:{dataset:{value:0}}});assert.equal(h.page.data.day.energy,3);
 }finally{h.close();}
});

test('an initial storage failure retains questionnaire fields and never sends AI input',async()=>{
 const h=setup(),write=wx.setStorageSync;try{
  let calls=0;h.api.request=async()=>{calls++;};wx.setStorageSync=()=>{throw Error('disk full');};
  h.page.toggleScene({currentTarget:{dataset:{value:'outdoor'}}});h.page.careChange({detail:{value:25}});
  await h.page.save();assert.match(h.page.data.error,/保存失败/);assert.equal(h.page.data.busy,false);assert.equal(calls,0);
  assert.deepEqual(h.page.data.day.scenes,['office','outdoor']);assert.equal(h.page.data.day.carePreference,25);
  assert.equal(h.store.getDay().note,'');assert.equal(h.page.data.day.note,'我好困，想休息一会儿');
 }finally{wx.setStorageSync=write;h.close();}
});
