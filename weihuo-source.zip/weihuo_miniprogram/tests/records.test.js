'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '../miniprogram');
const disk = new Map();
let failWrites = false;
let modalConfirm = true;
let photoSource = null;
let pendingPhoto = null;
let deferPhoto = false;
let removedFiles = [];
let removalAttempts = [];
let failRemovals = false;
let events = [];

global.wx = {
  getStorageSync: key => disk.get(key),
  getStorageInfoSync: () => ({keys: Array.from(disk.keys())}),
  setStorageSync: (key, value) => {
    if (failWrites) throw new Error('test: storage full');
    disk.set(key, JSON.parse(JSON.stringify(value)));
  },
  showToast: value => events.push(value.title),
  showModal: value => { events.push(value.content); if (value.success) value.success({confirm: modalConfirm}); },
  navigateBack: () => events.push('back'),
  navigateTo: value => events.push(value.url),
  switchTab: value => events.push(value.url),
  chooseMedia: options => {
    if (deferPhoto) { pendingPhoto = options; return; }
    if (!photoSource) options.fail({errMsg: 'chooseMedia:fail cancel'});
    else options.success({tempFiles: [{tempFilePath: photoSource, size: 1000}]});
  },
  saveFile: options => options.success({savedFilePath: options.tempFilePath}),
  removeSavedFile: options => {
    removalAttempts.push(options.filePath);
    const result = {errMsg: failRemovals ? 'removeSavedFile:fail permission denied' : 'removeSavedFile:ok'};
    if (failRemovals) {
      if (options.fail) options.fail(result);
    } else {
      removedFiles.push(options.filePath);
      if (options.success) options.success(result);
    }
    if (options.complete) options.complete(result);
  },
  cloud: {callFunction: async () => { throw new Error('test: offline'); }}
};

const store = require(path.join(root, 'services/store'));
const api = require(path.join(root, 'services/api'));
const media = require(path.join(root, 'services/media'));
const ui = require(path.join(root, 'services/ui'));
const actualRequest = api.request;
const actualConfirm = ui.confirm;

function page(name, options = {}) {
  let definition;
  global.Page = value => { definition = value; };
  const file = path.join(root, 'pages', name, 'index.js');
  delete require.cache[require.resolve(file)];
  require(file);
  const instance = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  instance.setData = function (patch) { Object.assign(this.data, patch); };
  if (instance.onLoad) instance.onLoad(options);
  if (instance.onShow) instance.onShow();
  return instance;
}
function field(instance, key, value) {
  instance.onField({currentTarget: {dataset: {field: key}}, detail: {value}});
}
function metric(instance, index, key, value) {
  instance.editMetric({currentTarget: {dataset: {index, field: key}}, detail: {value}});
}
function saveReport(instance, confirmed) { return instance.save({currentTarget: {dataset: {confirmed}}}); }
function meal(patch = {}) {
  return store.saveMeal(Object.assign({name: '午餐', date: store.today(), time: '12:00'}, patch));
}
function reportEditor() {
  const editor = page('report');
  field(editor, 'title', '我保存的原文资料');
  editor.addMetric();
  metric(editor, 0, 'name', '身高');
  metric(editor, 0, 'value', '163');
  metric(editor, 0, 'unit', 'cm');
  return editor;
}
function labelField(instance, key, value) {
  instance.onLabelField({currentTarget: {dataset: {field: key}}, detail: {value}});
}
function labelCandidate() {
  return {name: '燕麦饼干', ingredients: '燕麦、小麦粉', servingBasis: 'per100g', servingSize: '', energyValue: 836.8, energyUnit: 'kJ', protein: 8, carbs: 30, fat: 4, flags: [], uncertainFields: [], evidence: {servingBasis: '每100克', energyValue: '能量 836.8 kJ', protein: '蛋白质 8 g', carbs: '碳水化合物 30 g', fat: '脂肪 4 g'}};
}
async function labelEditor(options) {
  const editor = page('meal-edit', options);
  if (editor.data.recordType !== 'packaged') await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}});
  field(editor, 'name', '燕麦饼干');
  field(editor, 'note', '营养成分表 每100克 能量836.8kJ 蛋白质8g 碳水30g 脂肪4g');
  api.request = async (task, payload) => { assert.equal(task, 'analyzeFoodLabel'); assert(Array.isArray(payload.photoPaths)); return labelCandidate(); };
  await editor.analyze();
  return editor;
}

test.beforeEach(() => {
  failWrites = false;
  modalConfirm = true;
  photoSource = null;
  pendingPhoto = null;
  deferPhoto = false;
  removedFiles = [];
  removalAttempts = [];
  failRemovals = false;
  events = [];
  api.request = actualRequest;
  ui.confirm = actualConfirm;
  disk.clear();
  store.useLocal();
  store.clearAll();
  store.saveSettings({aiConsent: true});
});
test.after(() => { api.request = actualRequest; ui.confirm = actualConfirm; });

test('packaged food fills editable values, auto-converts amount, and saves only on explicit save', async () => {
  const editor = await labelEditor();
  assert.equal(editor.data.foodLabel.energyValue, 836.8);
  assert.equal(editor.data.kcal, '');
  assert.equal(store.getMeals().length, 0);
  labelField(editor, 'actualQuantity', '50');
  
  assert.equal(editor.data.kcal, '100');
  assert.equal(editor.data.protein, '4');
  assert.equal(store.getMeals().length, 0);
  await editor.save();
  assert.equal(editor.data.error, '');
  const record = store.getMeals()[0];
  assert.equal(record.nutritionSource, 'label');
  assert.equal(record.foodLabel.source, 'label');
  assert.equal(record.foodLabel.energyValue, 836.8);
  assert.equal(record.foodLabel.actualQuantity, 50);
  assert.equal(record.foodLabel.actualUnit, 'g');
  const reopened = page('meal-edit', {id: record.id});
  assert.equal(reopened.data.recordType, 'packaged');
  assert.equal(reopened.data.labelForm.energyValue, '836.8');
  assert.equal(reopened.data.labelForm.actualQuantity, '50');
  assert.equal(reopened.data.kcal, '100');
});

test('changing actual quantity recalculates locally without another AI call', async () => {
  const editor = await labelEditor();
  labelField(editor, 'actualQuantity', '50'); 
  labelField(editor, 'actualQuantity', '25');
  assert.equal(editor.data.foodLabel.actualQuantity, 25);
  assert.equal(editor.data.kcal, '50');
  assert.equal(editor.data.foodLabel.energyValue, 836.8);
  labelField(editor, 'servingBasis', '3');
  assert.equal(editor.data.labelForm.actualQuantity, '');
  assert.equal(editor.data.kcal, '');
});

test('a nutrition edit changes source to manual without losing the original confirmed label', async () => {
  const editor = await labelEditor();
  labelField(editor, 'actualQuantity', '50'); 
  field(editor, 'kcal', '105');
  assert.equal(editor.data.nutritionSource, 'manual');
  assert.equal(editor.data.foodLabel.energyValue, 836.8);
  await editor.save();
  const record = store.getMeals()[0];
  assert.equal(record.nutritionSource, 'manual');
  assert.equal(record.kcal, 105);
  assert.equal(record.foodLabel.energyValue, 836.8);
});

test('replacing a label photo invalidates transcription and removes derived values without touching the original record', async () => {
  const editor = await labelEditor();
  labelField(editor, 'actualQuantity', '50'); 
  await editor.save();
  const original = store.getMeals()[0];
  const reopened = page('meal-edit', {id: original.id});
  photoSource = 'wxfile://replacement-label';
  api.request = async () => { throw new Error('暂时无法识别'); };
  await reopened.choosePhoto();
  assert.equal(reopened.data.foodLabel, null);
  assert.equal(reopened.data.kcal, '');
  assert.equal(reopened.data.labelForm.energyValue, '');
  await reopened.cancelEdit();
  reopened.onUnload();
  assert.deepEqual(store.getMeals()[0], original);
  assert(removedFiles.includes('wxfile://replacement-label'));
});

test('ingredient-only label and missing actual quantity save no invented nutritional totals', async () => {
  const editor = page('meal-edit');
  await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}});
  field(editor, 'name', '只有配料信息的食品');
  labelField(editor, 'ingredients', '燕麦、水');
  
  assert.equal(editor.data.nutritionSource, 'label');
  assert.equal(editor.data.foodLabel.actualQuantity, null);
  await editor.save();
  const record = store.getMeals()[0];
  assert.equal(record.kcal, null);
  assert.equal(record.protein, null);
  assert.equal(record.foodLabel.energyValue, null);
});

test('AI label failure remains visible, and manual transcription still saves', async () => {
  const editor = page('meal-edit');
  await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}});
  field(editor, 'name', '手抄标签'); field(editor, 'note', '配料：燕麦、水');
  api.request = async () => { throw new Error('视觉模型尚未开通'); };
  await editor.analyze();
  assert.equal(editor.data.aiError, '视觉模型尚未开通');
  assert.equal(editor.data.foodLabel, null);
  labelField(editor, 'ingredients', '燕麦、水'); 
  await editor.save();
  assert.equal(store.getMeals()[0].foodLabel.ingredients, '燕麦、水');
});

test('late label result after account switch cannot fill another account draft', async () => {
  const editor = page('meal-edit');
  await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}});
  field(editor, 'note', '配料：燕麦、水');
  let resolve;
  api.request = () => new Promise(done => { resolve = done; });
  const pending = editor.analyze();
  store.switchAccount('other-account');
  resolve(labelCandidate());
  await pending;
  assert.equal(editor.data.foodLabel, null);
  assert.equal(editor.data.labelForm.energyValue, '');
  assert.match(editor.data.error, /账号已变化/);
  assert.equal(store.getMeals().length, 0);
});

test('cancelling edits to auto-calculated label values preserves the saved record', async () => {
  const editor = await labelEditor();
  labelField(editor, 'actualQuantity', '50');  await editor.save();
  const original = store.getMeals()[0];
  const reopened = page('meal-edit', {id: original.id});
  labelField(reopened, 'energyValue', '900');
  modalConfirm = false;
  await reopened.cancelEdit();
  assert.deepEqual(store.getMeals()[0], original);
  assert.equal(reopened.data.foodLabel.energyValue, 900);
});

test('both saved label photos survive page exit and deletion while an immutable ticket references them', async () => {
  const editor = await labelEditor();
  editor.setData({labelPhotoPaths: ['wxfile://nutrition-table', 'wxfile://ingredients-table']});
  editor._newPhotos = editor.data.labelPhotoPaths.slice();
  labelField(editor, 'actualQuantity', '50');  await editor.save();
  editor.onUnload();
  assert.deepEqual(removedFiles, []);
  store.sealTicket();
  const saved = store.getMeals()[0];
  const reopened = page('meal-edit', {id: saved.id});
  await reopened.deleteRecord();
  assert.equal(store.getMeals().length, 0);
  assert.deepEqual(removedFiles, []);
  assert.equal(store.getTicket().meals[0].labelPhotoPaths.length, 2);
  store.deleteTicket(store.today());
  await media.removePhoto('wxfile://nutrition-table');
  await media.removePhoto('wxfile://ingredients-table');
  assert.deepEqual(removedFiles, ['wxfile://nutrition-table', 'wxfile://ingredients-table']);
});

test('manual meal survives reopening with unknown nutrition preserved as null', async () => {
  const editor = page('meal-edit');
  field(editor, 'name', '燕麦牛奶与香蕉');
  field(editor, 'time', '08:12');
  editor.toggleTag({currentTarget: {dataset: {tag: '喜欢'}}});
  await editor.save();
  const records = store.getMeals();
  assert.equal(records.length, 1);
  assert.equal(records[0].kcal, null);
  assert.equal(records[0].protein, null);
  assert.equal(records[0].time, '08:12');
  store.useLocal();
  const reopened = page('meal-edit', {id: records[0].id});
  assert.equal(reopened.data.name, '燕麦牛奶与香蕉');
  assert.equal(reopened.data.kcal, '');
  assert.deepEqual(reopened.data.tags, ['喜欢']);
});

test('editing only a meal note preserves the original nutrition precision', async () => {
  const original = meal({kcal: 123.456, protein: 1.234, carbs: 23.456, fat: 0.0000001});
  const editor = page('meal-edit', {id: original.id});
  field(editor, 'note', '只补充这一句');
  await editor.save();
  const saved = store.getMeals()[0];
  for (const key of ['kcal', 'protein', 'carbs', 'fat']) assert.equal(saved[key], original[key]);
  assert.equal(saved.note, '只补充这一句');
});

test('another meal recognition clears nutrition the model did not identify', async () => {
  const original = meal({name: '原来的一餐', kcal: 300, protein: 10, carbs: 20, fat: 5});
  const editor = page('meal-edit', {id: original.id});
  api.request = async () => ({name: '重新识别的一餐', kcalMin: null, kcalMax: null, protein: 2.35, carbs: null, fat: null});
  await editor.analyze();
  
  assert.equal(editor.data.kcal, '');
  assert.equal(editor.data.carbs, '');
  assert.equal(editor.data.fat, '');
  await editor.save();
  assert.equal(store.getMeals()[0].kcal, null);
  assert.equal(store.getMeals()[0].protein, 2.35);
});

test('changing portion text clears stale auto-filled estimates until explicitly re-requested', async () => {
  const editor = page('meal-edit');
  field(editor, 'name', '半碗饭');
  api.request = async () => ({name: '半碗饭', kcalMin: 80, kcalMax: 100});
  await editor.analyze();
  assert.equal(editor.data.kcal, '90');
  field(editor, 'note', '改为两碗');
  assert.equal(editor.data.kcal, '');
  assert.equal(editor.data.aiNeedsRefresh, true);
  assert.equal(store.getMeals().length, 0);
});

test('cancel buttons preserve the draft when declined and never overwrite saved meal or report data', async () => {
  const originalMeal = meal({note: '原备注'});
  const originalReport = store.saveReport({title: '原资料', note: '原备注'});
  for (const [name, id] of [['meal-edit', originalMeal.id], ['report', originalReport.id]]) {
    const editor = page(name, {id});
    field(editor, 'note', '还没有保存的改动');
    events = []; modalConfirm = false;
    await editor.cancelEdit();
    assert(!events.includes('back'));
    assert.equal(editor.data.note, '还没有保存的改动');
    modalConfirm = true;
    await editor.cancelEdit();
    assert(events.includes('back'));
  }
  assert.equal(store.getMeals()[0].note, '原备注');
  assert.equal(store.getReports()[0].note, '原备注');
});

test('late delete confirmation after leaving meal or report page cannot delete a record', async () => {
  const originalMeal = meal();
  const originalReport = store.saveReport({title: '原资料', note: '保留'});
  for (const [name, id, method] of [['meal-edit', originalMeal.id, 'deleteRecord'], ['report', originalReport.id, 'deleteReport']]) {
    let resolve;
    ui.confirm = () => new Promise(done => { resolve = done; });
    const editor = page(name, {id});
    const pending = editor[method]();
    editor.onUnload();
    resolve(true);
    await pending;
  }
  assert.equal(store.getMeals().length, 1);
  assert.equal(store.getReports().length, 1);
});

test('account changes block meal save and pending report confirmation', async () => {
  const mealEditor = page('meal-edit'); field(mealEditor, 'name', '未保存餐食');
  store.switchAccount('other-account'); await mealEditor.save();
  assert.match(mealEditor.data.error, /账号已变化/); assert.equal(store.getMeals().length, 0);
  store.useLocal(); const editor = reportEditor(); let resolve;
  ui.confirm = () => new Promise(done => { resolve = done; });
  const pending = saveReport(editor, true); store.switchAccount('other-account'); resolve(true); await pending;
  assert.match(editor.data.error, /账号已变化/); assert.equal(store.getReports().length, 0);
});

test('a failed new daily review does not continue displaying the previous AI result', async () => {
  meal();
  const journal = page('meals');
  api.request = async () => ({summary: '第一次回顾', suggestions: []});
  await journal.reviewDay();
  assert.equal(journal.data.review.summary, '第一次回顾');
  api.request = async () => { throw new Error('本次服务不可用'); };
  await journal.reviewDay();
  assert.equal(journal.data.review, null);
  assert.equal(journal.data.reviewError, '本次服务不可用');
  assert.equal(journal.data.reviewBusy, false);
});

test('invalid nutrition never creates a record and leaves the entered draft available', async () => {
  for (const [key, value] of [['kcal', '-2'], ['kcal', 'NaN'], ['kcal', '30001'], ['protein', '3001']]) {
    const editor = page('meal-edit');
    field(editor, 'name', '营养输入检查');
    field(editor, key, value);
    await editor.save();
    assert.equal(store.getMeals().length, 0);
    assert.equal(editor.data[key], value);
    assert(editor.data.error);
    assert.equal(editor.data.saving, false);
  }
});

test('cancelling photo selection is quiet and does not alter a saved meal', async () => {
  const saved = meal({photoPath: 'wxfile://original'});
  const editor = page('meal-edit', {id: saved.id});
  await editor.choosePhoto();
  assert.equal(editor.data.error, '');
  assert.equal(editor.data.photoPath, 'wxfile://original');
  assert.equal(store.getMeals()[0].photoPath, 'wxfile://original');
  assert.deepEqual(removedFiles, []);
});

test('AI meal fills the editable draft automatically and is stored only after save', async () => {
  api.request = async () => ({name: '南瓜饭', kcalMin: 100, kcalMax: 200, protein: 2, carbs: null, fat: null, note: '份量不确定'});
  const editor = page('meal-edit');
  field(editor, 'name', '一碗南瓜饭');
  await editor.analyze();
  assert.equal(store.getMeals().length, 0);
  assert.equal(editor.data.name, '南瓜饭');
  assert.equal(editor.data.kcal, '150');
  assert.equal(editor.data.estimateRange, '100–200');
  
  assert.equal(store.getMeals().length, 0);
  await editor.save();
  const saved = store.getMeals()[0];
  assert.equal(saved.name, '南瓜饭');
  assert.equal(saved.kcal, 150);
  assert.equal(saved.carbs, null);
  assert.equal(saved.nutritionSource, 'ai-estimate');
});

test('editing a meal updates the same record, and deletion removes it', async () => {
  const saved = meal({name: '燕麦', kcal: 200});
  const editor = page('meal-edit', {id: saved.id});
  field(editor, 'name', '燕麦与牛奶');
  field(editor, 'kcal', '280');
  await editor.save();
  assert.equal(store.getMeals().length, 1);
  assert.equal(store.getMeals()[0].id, saved.id);
  assert.equal(store.getMeals()[0].name, '燕麦与牛奶');
  const reopened = page('meal-edit', {id: saved.id});
  await reopened.deleteRecord();
  assert.equal(store.getMeals().length, 0);
});

test('report confirmation and applying activity restrictions are separate user actions', async () => {
  store.saveProfile({restrictions: ['wrist']});
  const editor = reportEditor();
  editor.toggleRestriction({currentTarget: {dataset: {key: 'ankle'}}});
  await saveReport(editor, true);
  assert.equal(store.getReports().length, 1);
  assert.equal(store.getReports()[0].confirmed, true);
  assert.deepEqual(store.getProfile().restrictions, ['wrist']);
  await editor.applyRestrictions();
  assert.deepEqual(store.getProfile().restrictions, ['wrist', 'ankle']);
});

test('OCR values and legibility note remain editable candidates before confirmation', async () => {
  api.request = async () => ({metrics: [{name: '身高', value: '163', unit: 'cm', reference: ''}], note: '表格最后一行不清晰，未提取'});
  const editor = page('report');
  field(editor, 'title', '待核对的照片');
  editor.setData({photoPath: 'wxfile://report'});
  await editor.extract();
  assert.equal(editor.data.candidate, true);
  assert.equal(editor.data.metrics[0].value, '163');
  assert.match(editor.data.ocrNote, /不清晰/);
  assert.equal(store.getReports().length, 0);
  assert.deepEqual(store.getProfile().restrictions, []);
  metric(editor, 0, 'value', '168');
  await saveReport(editor, true);
  assert.equal(store.getReports()[0].metrics[0].value, '168');
});

test('actual unavailable API reports an error without fabricating nutrition or changing text', async () => {
  const editor = page('meal-edit');
  field(editor, 'name', '晚餐');
  await editor.analyze();
  assert(editor.data.aiError);
  assert.equal(editor.data.updated, false);
  assert.equal(editor.data.name, '晚餐');
  assert.equal(editor.data.kcal, '');
  assert.equal(store.getMeals().length, 0);
});

test('failed OCR shows a scan error while preserving the entered metrics and photo', async () => {
  const editor = reportEditor();
  editor.setData({photoPath: 'wxfile://report-source'});
  api.request = async () => { throw new Error('识别服务未配置'); };
  await editor.extract();
  assert.equal(editor.data.ocrError, '识别服务未配置');
  assert.equal(editor.data.metrics[0].value, '163');
  assert.equal(editor.data.photoPath, 'wxfile://report-source');
  assert.equal(editor.data.busy, false);
  await saveReport(editor, false);
  assert.equal(store.getReports().length, 1);
  assert.equal(store.getReports()[0].confirmed, false);
});

test('daily totals count unknown calories separately and failed review has no generated result', async () => {
  meal({name: '早餐', time: '08:00', kcal: null});
  meal({name: '午餐', time: '12:00', kcal: 500});
  const journal = page('meals');
  assert.equal(journal.data.meals.length, 2);
  assert.equal(journal.data.totals.total, 2);
  assert.equal(journal.data.totals.known, 1);
  assert.equal(journal.data.totals.kcal, 500);
  await journal.reviewDay();
  assert(journal.data.reviewError);
  assert.equal(journal.data.review, null);
  assert.equal(journal.data.reviewBusy, false);
});

test('incomplete report metrics can be saved as draft but cannot be confirmed', async () => {
  const editor = reportEditor();
  metric(editor, 0, 'value', '');
  await saveReport(editor, false);
  assert.equal(store.getReports().length, 1);
  assert.equal(store.getReports()[0].confirmed, false);
  assert.equal(store.getReports()[0].metrics[0].value, '');
  await saveReport(editor, true);
  assert(editor.data.error);
  assert.equal(store.getReports()[0].confirmed, false);
});

test('two save taps create only one meal with no extra confirmation step', async () => {
  let confirms = 0; ui.confirm = async () => { confirms += 1; return true; };
  const editor = page('meal-edit'); field(editor, 'name', '本人填写的晚餐');
  await Promise.all([editor.save(), editor.save()]);
  assert.equal(store.getMeals().length, 1); assert.equal(store.getMeals()[0].name, '本人填写的晚餐'); assert.equal(confirms, 0);
});

test('storage failure preserves the old record and neither deletes photos nor claims success', async () => {
  const saved = meal({photoPath: 'wxfile://original'});
  const editor = page('meal-edit', {id: saved.id});
  photoSource = 'wxfile://replacement';
  await editor.choosePhoto();
  field(editor, 'name', '修改后尚未保存');
  failWrites = true;
  await editor.save();
  failWrites = false;
  assert.match(editor.data.error, /保存失败/);
  assert.equal(store.getMeals()[0].name, '午餐');
  assert.equal(store.getMeals()[0].photoPath, 'wxfile://original');
  assert.deepEqual(removedFiles, []);
  assert(!events.includes('这一餐已经记下。'));
  editor.onUnload();
  assert.deepEqual(removedFiles, ['wxfile://replacement']);
});

test('closing without saving cleans up only newly selected photos for meal and report pages', async () => {
  const original = meal({photoPath: 'wxfile://original'});
  const editor = page('meal-edit', {id: original.id});
  photoSource = 'wxfile://abandoned-meal';
  await editor.choosePhoto();
  editor.onUnload();
  assert.deepEqual(removedFiles, ['wxfile://abandoned-meal']);
  assert.equal(store.getMeals()[0].photoPath, 'wxfile://original');
  const report = page('report');
  photoSource = 'wxfile://abandoned-report';
  await report.choosePhoto();
  report.onUnload();
  assert.deepEqual(removedFiles, ['wxfile://abandoned-meal', 'wxfile://abandoned-report']);
  assert.equal(store.getReports().length, 0);
});

test('photo selection resolving after the page closes removes the orphan instead of saving a record', async () => {
  const editor = page('meal-edit');
  deferPhoto = true;
  const selecting = editor.choosePhoto();
  assert(pendingPhoto);
  editor.onUnload();
  pendingPhoto.success({tempFiles: [{tempFilePath: 'wxfile://late-photo', size: 1000}]});
  await selecting;
  assert.deepEqual(removedFiles, ['wxfile://late-photo']);
  assert.equal(store.getMeals().length, 0);
});

test('replacing or deleting a meal cannot remove a photo referenced by a sealed ticket', async () => {
  const saved = meal({photoPath: 'wxfile://sealed-photo'});
  store.sealTicket(store.today());
  const editor = page('meal-edit', {id: saved.id});
  photoSource = 'wxfile://new-photo';
  await editor.choosePhoto();
  await editor.save();
  editor.onUnload();
  assert.deepEqual(removedFiles, []);
  assert.equal(store.getTicket(store.today()).meals[0].photoPath, 'wxfile://sealed-photo');
  const reopening = page('meal-edit', {id: saved.id});
  await reopening.deleteRecord();
  assert.deepEqual(removedFiles, ['wxfile://new-photo']);
  await media.removePhoto('wxfile://sealed-photo');
  assert.deepEqual(removedFiles, ['wxfile://new-photo']);
});

test('report photo survives while another record refers to it and is cleaned after the last deletion', async () => {
  const first = store.saveReport({title: '第一份资料', photoPath: 'wxfile://shared-report'});
  const second = store.saveReport({title: '第二份资料', photoPath: 'wxfile://shared-report'});
  await page('report', {id: first.id}).deleteReport();
  assert.deepEqual(removedFiles, []);
  await page('report', {id: second.id}).deleteReport();
  assert.deepEqual(removedFiles, ['wxfile://shared-report']);
});

test('failed photo deletion rejects, preserves a pending retry, then succeeds exactly once', async () => {
  const photo = 'wxfile://retry-me';
  failRemovals = true;
  await assert.rejects(media.removePhoto(photo), /照片删除失败/);
  assert.deepEqual(removalAttempts, [photo]);
  assert.deepEqual(removedFiles, []);
  assert.deepEqual(wx.getStorageSync('weihuo:photoCleanup'), [photo]);
  failRemovals = false;
  await media.retryCleanup();
  assert.deepEqual(removalAttempts, [photo, photo]);
  assert.deepEqual(removedFiles, [photo]);
  assert.deepEqual(wx.getStorageSync('weihuo:photoCleanup'), []);
  await media.retryCleanup();
  assert.deepEqual(removalAttempts, [photo, photo]);
});

test('deleting a record can complete while photo cleanup failure is retained for a later retry', async () => {
  const saved = meal({photoPath: 'wxfile://deleted-meal'});
  const editor = page('meal-edit', {id: saved.id});
  failRemovals = true;
  await editor.deleteRecord();
  assert.equal(store.getMeals().length, 0);
  assert.deepEqual(removedFiles, []);
  assert.deepEqual(wx.getStorageSync('weihuo:photoCleanup'), ['wxfile://deleted-meal']);
  failRemovals = false;
  await media.retryCleanup();
  assert.deepEqual(removedFiles, ['wxfile://deleted-meal']);
  assert.deepEqual(wx.getStorageSync('weihuo:photoCleanup'), []);
});

test('a reference in another account prevents deletion until its last reference is removed', async () => {
  const photo = 'wxfile://account-shared';
  store.switchAccount('test-account');
  const saved = store.saveReport({title: '账号下的资料', photoPath: photo});
  store.useLocal();
  await media.removePhoto(photo);
  assert.deepEqual(removalAttempts, []);
  assert.deepEqual(removedFiles, []);
  store.switchAccount('test-account');
  store.deleteReport(saved.id);
  store.useLocal();
  await media.removePhoto(photo);
  assert.deepEqual(removalAttempts, [photo]);
  assert.deepEqual(removedFiles, [photo]);
});

test('one selected meal photo triggers one analysis and fills the editable draft without saving', async () => {
  const editor = page('meal-edit'); photoSource = 'wxfile://one-meal-photo'; let calls = 0;
  api.request = async (task, payload) => { calls += 1; assert.equal(task, 'analyzeMeal'); assert.equal(payload.photoPath, photoSource); return {name: '番茄炒蛋', kcalMin: 180, kcalMax: 220, protein: 12, carbs: null, fat: 8, note: '按照片估算'}; };
  await editor.choosePhoto();
  assert.equal(calls, 1); assert.equal(editor.data.name, '番茄炒蛋'); assert.equal(editor.data.kcal, '200'); assert.equal(editor.data.aiBody, '按照片估算');
  assert.equal(editor.data.photoPath, photoSource); assert.equal(store.getMeals().length, 0);
  await editor.save(); assert.equal(store.getMeals()[0].name, '番茄炒蛋');
});
test('slow meal recognition unlocks after ten seconds and backfills only the unchanged saved record', async () => {
  const editor = page('meal-edit');
  editor.setData({photoPath: 'wxfile://slow-meal-photo', name: '我写的午餐'});
  editor._newPhotos.push(editor.data.photoPath);
  let resolveRequest, fireTimeout;
  api.request = () => new Promise(resolve => { resolveRequest = resolve; });
  const realSetTimeout = global.setTimeout, realClearTimeout = global.clearTimeout;
  global.setTimeout = (callback, ms) => { assert.equal(ms, 10000); fireTimeout = callback; return 1; };
  global.clearTimeout = () => {};
  let analyzing;
  try {
    analyzing = editor.analyze();
    assert.equal(editor.data.busy, true);
    fireTimeout();
    assert.equal(await analyzing, 'timeout');
  } finally { global.setTimeout = realSetTimeout; global.clearTimeout = realClearTimeout; }
  assert.equal(editor.data.busy, false);
  assert.match(editor.data.recognitionStatus, /还在整理/);
  await editor.save();
  const original = store.getMeals()[0];
  assert.equal(original.name, '我写的午餐');
  assert.equal(original.photoPath, 'wxfile://slow-meal-photo');
  editor.onUnload();
  resolveRequest({name: '模型给的名字', kcalMin: 100, kcalMax: 200, protein: 12, carbs: null, fat: 8});
  await new Promise(resolve => setImmediate(resolve));
  const meals = store.getMeals();
  assert.equal(meals.length, 1);
  assert.equal(meals[0].id, original.id);
  assert.equal(meals[0].name, '我写的午餐');
  assert.equal(meals[0].note, original.note);
  assert.equal(meals[0].photoPath, original.photoPath);
  assert.equal(meals[0].kcal, 150);
  assert.equal(meals[0].protein, 12);
  assert.equal(meals[0].nutritionSource, 'ai-estimate');
});
test('late meal recognition does not overwrite edits made after the ten-second release', async () => {
  const editor = page('meal-edit');
  editor.setData({photoPath: 'wxfile://edited-after-timeout', name: '午餐'});
  let resolveRequest, fireTimeout;
  api.request = () => new Promise(resolve => { resolveRequest = resolve; });
  const realSetTimeout = global.setTimeout, realClearTimeout = global.clearTimeout;
  global.setTimeout = (callback, ms) => { assert.equal(ms, 10000); fireTimeout = callback; return 1; };
  global.clearTimeout = () => {};
  let analyzing;
  try { analyzing = editor.analyze(); fireTimeout(); await analyzing; }
  finally { global.setTimeout = realSetTimeout; global.clearTimeout = realClearTimeout; }
  field(editor, 'note', '后来补充的分量');
  await editor.save();
  editor.onUnload();
  resolveRequest({name: '模型餐名', kcalMin: 100, kcalMax: 200, protein: 12, carbs: 30, fat: 8});
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(store.getMeals().length, 1);
  assert.equal(store.getMeals()[0].note, '后来补充的分量');
  assert.equal(store.getMeals()[0].kcal, null);
  assert.equal(store.getMeals()[0].name, '午餐');
});
test('the same photo control recognizes labels once and amount changes do not spend another model request', async () => {
  const editor = page('meal-edit'); let calls = 0;
  await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}});
  photoSource = 'wxfile://nutrition-label';
  api.request = async (task, payload) => { calls += 1; assert.equal(task, 'analyzeFoodLabel'); assert.deepEqual(payload.photoPaths, [photoSource]); return labelCandidate(); };
  await editor.choosePhoto(); assert.equal(calls, 1); assert.equal(editor.data.name, '燕麦饼干');
  labelField(editor, 'actualQuantity', '50'); assert.equal(editor.data.kcal, '100');
  labelField(editor, 'actualQuantity', '25'); assert.equal(editor.data.kcal, '50'); assert.equal(calls, 1);
  await editor.save(); assert.equal(store.getMeals()[0].foodLabel.actualQuantity, 25);
});
test('failed automatic recognition keeps a photo-only meal saveable and does not repeat calls on show', async () => {
  const editor = page('meal-edit'); photoSource = 'wxfile://failed-analysis-photo'; let calls = 0;
  api.request = async () => { calls += 1; throw new Error('模型暂不可用'); };
  await editor.choosePhoto(); editor.onShow();
  assert.equal(calls, 1); assert.equal(editor.data.aiError, '模型暂不可用'); assert.equal(editor.data.photoPath, photoSource);
  await editor.save(); assert.equal(store.getMeals()[0].name, '照片餐食'); assert.equal(store.getMeals()[0].kcal, null);
});
test('plain model body is displayed for meal, label and daily review without rejecting the draft', async () => {
  const editor = page('meal-edit'); field(editor, 'name', '我的午餐');
  api.request = async () => ({body: '这张图片的份量看不清，可以补充食物名称。'});
  await editor.analyze(); assert.equal(editor.data.aiBody, '这张图片的份量看不清，可以补充食物名称。'); assert.equal(editor.data.aiError, ''); assert.equal(editor.data.name, '我的午餐');
  await editor.changeRecordType({currentTarget: {dataset: {type: 'packaged'}}}); field(editor, 'note', '包装照片不清楚'); await editor.analyze();
  assert.equal(editor.data.aiBody, '这张图片的份量看不清，可以补充食物名称。'); assert.equal(editor.data.foodLabel, null);
  meal(); const journal = page('meals'); await journal.reviewDay(); assert.equal(journal.data.review.summary, editor.data.aiBody); assert.equal(journal.data.reviewError, '');
});
test('emptying label nutrition clears derived totals and wrong amounts remain an editable error', async () => {
  const editor = await labelEditor(); labelField(editor, 'actualQuantity', '50');
  labelField(editor, 'actualQuantity', '-3'); assert.equal(editor.data.kcal, ''); assert.equal(editor.data.foodLabel, null); assert(editor.data.labelError);
  await editor.save(); assert.equal(store.getMeals().length, 0);
  labelField(editor, 'actualQuantity', ''); labelField(editor, 'ingredients', '');
  for (const key of ['energyValue', 'protein', 'carbs', 'fat']) labelField(editor, key, '');
  assert.equal(editor.data.foodLabel, null); assert.equal(editor.data.kcal, ''); assert.equal(editor.data.nutritionSource, 'manual');
});
test('today journal ignores a stale selected date and distinguishes unknown nutrition from zero', () => {
  const date = new Date(store.today() + 'T12:00:00'); date.setDate(date.getDate() - 1);
  const yesterday = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
  meal({date: yesterday, name: '昨天的一餐', kcal: 300, protein: 10}); meal({name: '今天的一餐'});
  const journal = page('meals'); journal.setData({date: yesterday}); journal.reload();
  assert.equal(journal.data.date, store.today()); assert.equal(journal.data.meals.length, 1); assert.equal(journal.data.meals[0].name, '今天的一餐');
  assert.equal(journal.data.nutrition.macros.status, 'no_data'); assert.equal(journal.data.nutrition.macros.kcal.total, null); assert.equal(journal.data.nutrition.expenditure.minKcal, null);
});
test('daily review completing after an account change never displays the prior account content', async () => {
  meal(); const journal = page('meals'); let resolve;
  api.request = () => new Promise(done => { resolve = done; }); const pending = journal.reviewDay();
  store.switchAccount('review-other-account'); resolve({body: '另一个账号不应看到'}); await pending;
  assert.equal(journal.data.review, null); assert.equal(journal.data.reviewBusy, false);
});
