'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {createManagedProvider} = require('../cloudfunctions/weihuoApi/managed-provider');
const {createProvider} = require('../cloudfunctions/weihuoApi/provider');
const {runAI} = require('../cloudfunctions/weihuoApi/ai');
const env = patch => Object.assign({WEIHUO_AI_PROVIDER: 'cloudbase', WEIHUO_AI_MODEL: 'configured-text-model'}, patch);
function output(value, reason = 'stop') {
  const text = typeof value === 'string' ? value : JSON.stringify(value);
  return {text, rawResponses: [{choices: [{finish_reason: reason, message: {role: 'assistant', content: text}}]}]};
}
function fakeSDK(generate) {
  const calls = [];
  const sdk = {
    SYMBOL_CURRENT_ENV: Symbol('current-runtime-environment'),
    init(options) {
      calls.push({type: 'init', options});
      return {ai: () => ({createModel(group) {
        calls.push({type: 'model', group});
        return {async generateText(input, options) { calls.push({type: 'generate', input, options}); return generate(input, options); }};
      }})};
    }
  };
  return {sdk, calls};
}
const messages = () => [{role: 'system', content: '只输出JSON。'}, {role: 'user', content: '今天想休息'}];

test('managed branch uses fixed cloudbase group, configured model and runtime identity without API keys', async () => {
  const stub = fakeSDK(async () => output({summary: '结果'}));
  const provider = createProvider(env({WEIHUO_AI_API_KEY: 'must-not-be-read'}), undefined, {sdk: stub.sdk});
  assert.equal(provider.configured(false), true);
  assert.equal(stub.calls.length, 0, 'reading capability never calls SDK or authenticates');
  assert.deepEqual(await provider.generate(messages(), false), {summary: '结果'});
  assert.deepEqual(stub.calls[0].options, {env: stub.sdk.SYMBOL_CURRENT_ENV, timeout: 45000, debug: false});
  assert.equal(stub.calls[1].group, 'cloudbase');
  const input = stub.calls[2].input;
  assert.equal(input.model, 'configured-text-model');
  assert.equal(input.maxSteps, 1);
  assert.equal(input.max_tokens, 2048);
  assert.deepEqual(input.response_format, {type: 'json_object'});
  assert.equal(input.tools, undefined);
  assert.equal(input.apiKey, undefined);
});

test('text and vision configuration remain separate and missing vision fails before an SDK call', async () => {
  const stub = fakeSDK(async () => output({ok: true}));
  const provider = createManagedProvider(env(), {sdk: stub.sdk});
  assert.equal(provider.configured(true), false);
  await assert.rejects(provider.generate(messages(), true), error => error.code === 'SERVICE_NOT_CONFIGURED');
  assert.equal(stub.calls.length, 0);
  const vision = createManagedProvider(env({WEIHUO_AI_VISION_MODEL: 'enabled-vision-model'}), {sdk: stub.sdk});
  await vision.generate(messages(), true);
  assert.equal(stub.calls.find(call => call.type === 'generate').input.model, 'enabled-vision-model');
});

test('invalid model and deadline settings fail before remote work', () => {
  for (const patch of [{WEIHUO_AI_MODEL: ''}, {WEIHUO_AI_MODEL: 'bad\nmodel'}, {WEIHUO_AI_TIMEOUT_MS: '999'}, {WEIHUO_AI_TIMEOUT_MS: '50001'}, {WEIHUO_AI_TIMEOUT_MS: 'NaN'}]) {
    const provider = createManagedProvider(env(patch));
    assert.equal(provider.configured(false), false);
    assert.throws(() => provider.assertConfigured(false), error => error.code === 'SERVICE_NOT_CONFIGURED');
  }
});

test('two data URL images pass through intact and SDK mutation cannot alter the original prompt', async () => {
  const original = messages();
  original[1].content = [{type: 'text', text: '标签'}, {type: 'image_url', image_url: {url: 'data:image/jpeg;base64,first'}}, {type: 'image_url', image_url: {url: 'data:image/png;base64,second'}}];
  const snapshot = JSON.stringify(original);
  const stub = fakeSDK(async input => {
    assert.equal(input.messages[1].content.filter(part => part.type === 'image_url').length, 2);
    input.messages.push({role: 'assistant', content: 'SDK appended message'});
    return output({name: '标签'});
  });
  await createManagedProvider(env({WEIHUO_AI_VISION_MODEL: 'vision'}), {sdk: stub.sdk}).generate(original, true);
  assert.equal(JSON.stringify(original), snapshot);
});

test('managed output keeps valid business fields and leaves invalid values empty', async () => {
  const valid = {energy: 2, scene: null, minutes: 5, mood: '疲惫', note: '由本次描述提取'};
  const stub = fakeSDK(async () => output(valid));
  const provider = createManagedProvider(env(), {sdk: stub.sdk});
  assert.deepEqual(await runAI('parseState', {consent: true, text: '累了，只休息五分钟'}, provider, async () => {}), valid);
  const invalid = createManagedProvider(env(), {sdk: fakeSDK(async () => output(Object.assign({}, valid, {energy: 99}))).sdk});
  const normalized = await runAI('parseState', {consent: true, text: '累了'}, invalid, async () => {});
  assert.equal(normalized.energy, null); assert.equal(normalized.minutes, 5); assert.equal(normalized.mood, '疲惫');
});

test('plain prose, fenced JSON, incomplete JSON and non-object text remain readable', async () => {
  for (const body of ['null', '[]', 'true', '{"unfinished":', '今天可以安排一点休息。']) {
    const provider = createManagedProvider(env(), {sdk: fakeSDK(async () => output(body)).sdk});
    assert.deepEqual(await provider.generate(messages(), false), {text: body});
  }
  const fenced = createManagedProvider(env(), {sdk: fakeSDK(async () => output('```json\n{"minutes":"5"}\n```')).sdk});
  assert.deepEqual(await fenced.generate(messages(), false), {minutes: '5'});
  const sanitizing = createManagedProvider(env(), {sdk: fakeSDK(async () => output('{"__proto__":{"polluted":true},"constructor":{},"minutes":"5"}')).sdk});
  assert.deepEqual(await sanitizing.generate(messages(), false), {minutes: '5'});
  assert.equal({}.polluted, undefined);
});

test('finish metadata and unused tool metadata do not discard available text or execute tools', async () => {
  for (const reason of ['length', 'content_filter', 'tool_calls', undefined]) {
    const result = output({ok: true}); result.rawResponses[0].choices[0].finish_reason = reason;
    result.rawResponses[0].choices[0].message.tool_calls = [{id: 'never-executed'}];
    assert.deepEqual(await createManagedProvider(env(), {sdk: fakeSDK(async () => result).sdk}).generate(messages(), false), {ok: true});
  }
  const mismatch = output({ok: true}); mismatch.text = '{"other":true}';
  assert.deepEqual(await createManagedProvider(env(), {sdk: fakeSDK(async () => mismatch).sdk}).generate(messages(), false), {other: true});
});

test('unreadable or excessive SDK transport envelopes remain genuine errors', async () => {
  const hugeRaw = output({ok: true}); hugeRaw.rawResponses[0].extra = 'x'.repeat(130 * 1024);
  for (const result of [hugeRaw, {text: '{}', rawResponses: []}, null]) {
    await assert.rejects(createManagedProvider(env(), {sdk: fakeSDK(async () => result).sdk}).generate(messages(), false), error => error.code === 'PROVIDER_INVALID_RESPONSE');
  }
});

test('SDK partial-step metadata retains a readable result for user review', async () => {
  const stub = fakeSDK(async input => { input.onStepFinish({finishReason: 'length'}); return output('先从今天开始，安排五分钟休息。'); });
  assert.deepEqual(await createManagedProvider(env(), {sdk: stub.sdk}).generate(messages(), false), {text: '先从今天开始，安排五分钟休息。'});
});

test('an empty SDK text field cannot hide readable provider message content', async () => {
  const result=output({paragraphs:['今天睡了一觉。']});result.text='';
  assert.deepEqual(await createManagedProvider(env(),{sdk:fakeSDK(async()=>result).sdk}).generate(messages(),false),{paragraphs:['今天睡了一觉。']});
});

test('SDK and returned errors are classified without exposing upstream secret-bearing text', async () => {
  const cases = [
    [{code: '401'}, 'PROVIDER_AUTH_FAILED'], [{statusCode: 403}, 'PROVIDER_AUTH_FAILED'],
    [{status: 402}, 'PROVIDER_QUOTA_EXCEEDED'], [{code: 'insufficient_quota'}, 'PROVIDER_QUOTA_EXCEEDED'],
    [{code: '429'}, 'PROVIDER_RATE_LIMITED'], [{code: 'RequestLimitExceeded'}, 'PROVIDER_RATE_LIMITED'],
    [{statusCode: 503}, 'PROVIDER_UNAVAILABLE'], [{code: '400'}, 'PROVIDER_REQUEST_REJECTED'],
    [{code: 'model_not_enabled'}, 'SERVICE_NOT_CONFIGURED'], [{code: 'ETIMEDOUT'}, 'PROVIDER_TIMEOUT'],
    [{code: 'ECONNRESET'}, 'PROVIDER_NETWORK_ERROR']
  ];
  for (const [raw, expected] of cases) {
    const upstream = Object.assign({message: 'private prompt and secret must-not-appear'}, raw);
    for (const returned of [false, true]) {
      const stub = fakeSDK(async () => { if (returned) return {error: upstream}; throw upstream; });
      await assert.rejects(createManagedProvider(env(), {sdk: stub.sdk}).generate(messages(), false), error => error.code === expected && !JSON.stringify(error).includes('must-not-appear') && !error.message.includes('private prompt'));
    }
  }
});

test('a stalled SDK call reaches the app deadline without retries', async () => {
  const stub = fakeSDK(() => new Promise(() => {}));
  const provider = createManagedProvider(env({WEIHUO_AI_TIMEOUT_MS: '1000'}), {sdk: stub.sdk});
  await assert.rejects(provider.generate(messages(), false), error => error.code === 'PROVIDER_TIMEOUT');
  assert.equal(stub.calls.filter(call => call.type === 'generate').length, 1);
  assert.equal(stub.calls.find(call => call.type === 'init').options.timeout, 1000);
});

test('empty or excessive prompt is rejected before model invocation', async () => {
  const stub = fakeSDK(async () => output({ok: true}));
  const provider = createManagedProvider(env(), {sdk: stub.sdk});
  for (const value of [[], null, [{role: 'user', content: 'x'.repeat(1700 * 1024)}]]) {
    await assert.rejects(provider.generate(value, false), error => error.code === 'INVALID_ARGUMENT');
  }
  assert.equal(stub.calls.length, 0);
});

test('installed official SDK returns the raw response structure required by the adapter without network access', async () => {
  const sdk = require('../cloudfunctions/weihuoApi/node_modules/@cloudbase/node-sdk');
  assert.equal(sdk.version, '3.18.3');
  const ai = sdk.init({env: 'isolated-sdk-contract-test', timeout: 1000, debug: false}).ai();
  let requests = 0;
  // Keep official model parsing, replacing only transport with a bounded fixture.
  ai.modelRequest = async payload => {
    requests += 1;
    assert.equal(payload.data.model, 'hy3');
    assert.equal(payload.data.max_tokens, 256);
    assert.deepEqual(payload.data.thinking, {type: 'disabled'});
    return {choices: [{finish_reason: 'stop', message: {role: 'assistant', content: '{"sdkContract":true}'}}]};
  };
  const injected = {SYMBOL_CURRENT_ENV: sdk.SYMBOL_CURRENT_ENV, init: () => ({ai: () => ai})};
  assert.deepEqual(await createManagedProvider(env({WEIHUO_AI_MODEL: 'hy3'}), {sdk: injected}).generate(messages(), false, {task: 'parseState'}), {sdkContract: true});
  assert.equal(requests, 1);
});
