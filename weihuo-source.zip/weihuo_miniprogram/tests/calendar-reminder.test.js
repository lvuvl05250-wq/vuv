'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const fs = require('node:fs');
const servicePath = path.join(__dirname, '../miniprogram/services/calendar-reminder.js');
let calendar, callCount, pendingCall, calendarMode, modalConfirm, events;
const disk = new Map();
global.wx = {
  getStorageSync: key => disk.get(key),
  setStorageSync: (key, value) => disk.set(key, JSON.parse(JSON.stringify(value))),
  canIUse: () => true,
  addPhoneCalendar: value => {
    callCount += 1; pendingCall = value;
    if (calendarMode === 'ok') value.success({errMsg: 'addPhoneCalendar:ok'});
    else if (calendarMode === 'cancel') value.fail({errMsg: 'addPhoneCalendar:fail cancel'});
    else if (calendarMode === 'deny') value.fail({errMsg: 'addPhoneCalendar:fail auth deny'});
    else if (calendarMode === 'failure') value.fail({errMsg: 'upstream-private-detail'});
    else if (calendarMode === 'throw') throw new Error('private native failure');
  },
  showModal: value => { events.push(value.content); value.success({confirm: modalConfirm}); },
  showToast: value => events.push(value.title), navigateTo: value => events.push(value.url)
};
const store = require('../miniprogram/services/store');
const originalNow = Date.now;
const NOW = new Date(2026, 9, 5, 10, 10, 30).getTime();
const input = patch => Object.assign({key: 'account:sample:plan:2026-10-05', title: '读两页书', date: '2026-10-05', time: '11:20', durationMinutes: 5}, patch);
test.beforeEach(() => {
  Date.now = () => NOW; callCount = 0; pendingCall = null; calendarMode = 'ok'; modalConfirm = true; events = [];
  wx.canIUse = () => true;
  delete require.cache[require.resolve(servicePath)]; calendar = require(servicePath);
  store.useLocal(); store.clearAll();
});
test.after(() => { Date.now = originalNow; });
function plansPage() {
  let definition; global.Page = value => { definition = value; };
  const file = path.join(__dirname, '../miniprogram/pages/plans/index.js');
  delete require.cache[require.resolve(file)]; require(file);
  const page = Object.assign({}, definition, {data: JSON.parse(JSON.stringify(definition.data))});
  page.setData = function (patch) { Object.assign(this.data, patch); };
  page.onShow(); return page;
}
function plan() { return store.savePlan({title: '自己的计划', days: [{date: '2026-10-05', title: '读两页书', minutes: 5, details: '不应写入日历的私密备注'}, {date: '2026-10-04', title: '过去的事', minutes: 0}]}); }
function event(plan, date) { return {currentTarget: {dataset: {id: plan.id, date: date || '2026-10-05'}}}; }
function time(page, plan, value) { page.reminderTime(Object.assign(event(plan), {detail: {value}})); }

test('calendar payload uses Unix seconds, a string end time and only minimal event fields', () => {
  const result = calendar.createCalendarEvent(input({profile: {bodyNotes: 'private'}, periodRecords: [1], note: 'not sent', location: 'not sent'}), NOW);
  assert.deepEqual(Object.keys(result).sort(), ['alarm', 'alarmOffset', 'allDay', 'endTime', 'startTime', 'title'].sort());
  assert.equal(result.title, '微活 · 读两页书');
  assert.equal(result.startTime, new Date(2026, 9, 5, 11, 20).getTime() / 1000);
  assert.equal(result.endTime, String(result.startTime + 300)); assert.equal(result.alarmOffset, 0);
  assert.equal(result.alarm, true); assert.equal(result.allDay, false);
});

test('invalid dates, times, durations and past or current minute are rejected before calling native API', async () => {
  for (const patch of [{date: '2026-02-30'}, {date: '2026-10-04'}, {time: ''}, {time: '24:00'}, {time: '10:10'}, {durationMinutes: -1}, {durationMinutes: 601}, {title: ''}]) {
    await assert.rejects(calendar.addReminder(input(patch)));
  }
  assert.equal(callCount, 0);
  assert.equal(calendar.canRemindOnDate('2026-10-04', NOW), false);
  assert.equal(calendar.canRemindOnDate('2026-10-05', new Date(2026, 9, 5, 23, 59, 10).getTime()), false);
});

test('local timezone keeps the chosen plan date in Shanghai and Los Angeles and rejects nonexistent DST times', () => {
  const script = `const assert=require('node:assert/strict');const c=require(${JSON.stringify(servicePath)});const now=new Date(2026,9,4,12).getTime();const e=c.createCalendarEvent({title:'活动',date:'2026-10-05',time:'00:15',durationMinutes:3},now);const d=new Date(e.startTime*1000);assert.equal(d.getFullYear(),2026);assert.equal(d.getMonth(),9);assert.equal(d.getDate(),5);assert.equal(d.getHours(),0);assert.equal(d.getMinutes(),15);assert.equal(c.localDate(e.startTime*1000),'2026-10-05');`;
  for (const tz of ['Asia/Shanghai', 'America/Los_Angeles']) execFileSync(process.execPath, ['-e', script], {env: Object.assign({}, process.env, {TZ: tz})});
  const gap = `const assert=require('node:assert/strict');const c=require(${JSON.stringify(servicePath)});assert.throws(()=>c.localTimestamp('2026-03-08','02:30'),e=>e.code==='INVALID_LOCAL_TIME');`;
  execFileSync(process.execPath, ['-e', gap], {env: Object.assign({}, process.env, {TZ: 'America/New_York'})});
});

test('native authorization cancel, denial and failures stay failures and do not echo native details', async () => {
  for (const [mode, code] of [['cancel', 'CALENDAR_CANCELLED'], ['deny', 'CALENDAR_DENIED'], ['failure', 'CALENDAR_FAILED'], ['throw', 'CALENDAR_FAILED']]) {
    calendarMode = mode;
    await assert.rejects(calendar.addReminder(input()), error => error.code === code && !/private|upstream/.test(error.message));
    assert.equal(calendar.lastAdded(input().key), null);
  }
  calendarMode = 'ok'; assert.equal((await calendar.addReminder(input())).status, 'added');
});

test('unsupported devices never call the calendar API', async () => {
  wx.canIUse = () => false;
  await assert.rejects(calendar.addReminder(input()), error => error.code === 'CALENDAR_UNSUPPORTED');
  assert.equal(callCount, 0);
});

test('service serializes pending dialogs and identical successful event is not added twice', async () => {
  calendarMode = 'pending';
  const first = calendar.addReminder(input());
  await assert.rejects(calendar.addReminder(input()), error => error.code === 'CALENDAR_BUSY'); assert.equal(callCount, 1);
  pendingCall.success({}); assert.equal((await first).status, 'added');
  assert.equal((await calendar.addReminder(input())).status, 'already-added'); assert.equal(callCount, 1);
});

test('plan save, display and choosing a time do not invoke calendar permission', () => {
  const saved = plan(); const page = plansPage(); time(page, saved, '11:20');
  assert.equal(callCount, 0);
  assert.equal(page.data.today, calendar.localDate(NOW));
  assert.equal(page.data.plans[0].days.find(day => day.date === '2026-10-04').reminderEligible, false);
  assert.equal(page.data.plans[0].days.find(day => day.date === '2026-10-05').reminderEligible, true);
  assert.equal(store.getPlans()[0].days[0].reminderTime, undefined);
});

test('explicit addition preserves selected time after cancel and only marks success after callback', async () => {
  const saved = plan(), page = plansPage(); time(page, saved, '11:20');
  calendarMode = 'cancel'; await page.addReminder(event(saved));
  let day = page.data.plans[0].days.find(item => item.date === '2026-10-05');
  assert.equal(day.reminderTime, '11:20'); assert.match(day.reminderError, /已取消/); assert.equal(day.reminderAddedTime, '');
  calendarMode = 'pending'; const work = page.addReminder(event(saved));
  await page.addReminder(event(saved)); assert.equal(callCount, 2); assert(page.data.reminderBusyKey);
  day = page.data.plans[0].days.find(item => item.date === '2026-10-05'); assert.equal(day.reminderAddedTime, '');
  pendingCall.success({}); await work;
  day = page.data.plans[0].days.find(item => item.date === '2026-10-05');
  assert.equal(day.reminderAddedTime, '11:20'); assert.equal(day.reminderError, ''); assert.equal(page.data.reminderBusyKey, '');
  assert(events.includes('已添加，请到手机日历查看'));
  await page.addReminder(event(saved)); assert.equal(callCount, 2);
});

test('changing an already-added reminder asks before creating another event', async () => {
  const saved = plan(), page = plansPage(); time(page, saved, '11:20'); await page.addReminder(event(saved));
  time(page, saved, '12:00'); modalConfirm = false; await page.addReminder(event(saved)); assert.equal(callCount, 1);
  assert(events.some(text => text.includes('旧提醒请到手机日历')));
  modalConfirm = true; await page.addReminder(event(saved)); assert.equal(callCount, 2);
});

test('deleted plans or newly passed times do not reach the native API', async () => {
  const saved = plan(), page = plansPage(); time(page, saved, '10:00'); await page.addReminder(event(saved));
  assert.equal(callCount, 0); assert(page.data.plans[0].days[0].reminderError);
  time(page, saved, '11:20'); store.deletePlan(saved.id); await page.addReminder(event(saved)); assert.equal(callCount, 0);
});

test('account change or page unload during system dialog does not report success into another page', async () => {
  const saved = plan(), page = plansPage(); time(page, saved, '11:20'); calendarMode = 'pending';
  const work = page.addReminder(event(saved));
  store.switchAccount('calendar-another-account'); store.clearAll(); pendingCall.success({}); await work;
  assert.deepEqual(page.data.plans, []); assert.equal(events.length, 0); assert.equal(page.data.reminderBusyKey, '');
  store.useLocal(); const reopened = plansPage(); time(reopened, saved, '12:00');
  const second = reopened.addReminder(event(saved));
  // The changed time confirmation resolves first, then the native dialog opens.
  await Promise.resolve(); reopened.onUnload(); const eventCount = events.length; pendingCall.success({}); await second;
  assert.equal(events.length, eventCount);
});

test('plan WXML reminder handlers and interpolation syntax are valid', () => {
  const source = fs.readFileSync(path.join(__dirname, '../miniprogram/pages/plans/index.wxml'), 'utf8');
  const page = plansPage();
  for (const match of source.matchAll(/\{\{([\s\S]*?)\}\}/g)) assert.doesNotThrow(() => new Function('return (' + match[1] + ');'));
  for (const match of source.matchAll(/bind(?:tap|change)="([A-Za-z]+)"/g)) assert.equal(typeof page[match[1]], 'function');
});
