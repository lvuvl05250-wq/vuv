'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { nutritionSummary } = require('../miniprogram/services/nutrition-summary');

const DATE = '2026-10-05';
const adultProfile = {
  birthDate: '1996-06-15',
  heightCm: 165,
  weightKg: 60,
  exerciseHabit: '经常运动'
};

test('adult expenditure is a rounded range using both equation coefficients and explicit light PAL bounds', () => {
  const result = nutritionSummary(adultProfile, [], DATE);
  assert.deepEqual(result.expenditure, {
    status: 'estimated',
    minKcal: 1850,
    maxKcal: 2510,
    label: '日常消耗估算',
    assumption: '静坐或轻活动生活方式范围（PAL 1.40–1.69）；按两组公式系数给出区间。',
    reason: null
  });
  assert.equal(result.macros.status, 'no_data');
  assert.equal(result.macros.kcal.total, null);
});

test('planned exercise text does not change the all-day estimate', () => {
  const first = nutritionSummary(adultProfile, [], DATE).expenditure;
  const second = nutritionSummary(Object.assign({}, adultProfile, { exerciseHabit: '久坐' }), [], DATE).expenditure;
  assert.deepEqual(second, first);
});

test('missing profile data and unsupported ages do not fabricate an expenditure value', () => {
  const missing = nutritionSummary({ adult: true, heightCm: 165, weightKg: 60 }, [], DATE).expenditure;
  assert.equal(missing.status, 'unavailable');
  assert.equal(missing.minKcal, null);
  assert.equal(missing.maxKcal, null);

  const minor = nutritionSummary({ birthDate: '2010-10-06', heightCm: 165, weightKg: 60 }, [], DATE).expenditure;
  assert.equal(minor.status, 'minor');
  assert.equal(minor.minKcal, null);
  assert.equal(minor.maxKcal, null);

  const eighteen = nutritionSummary({ birthDate: '2008-10-05', heightCm: 165, weightKg: 60 }, [], DATE).expenditure;
  assert.equal(eighteen.status, 'out_of_range');
  assert.equal(eighteen.minKcal, null);

  const oldestInScope = nutritionSummary({ birthDate: '1948-10-05', heightCm: 165, weightKg: 60 }, [], DATE).expenditure;
  assert.equal(oldestInScope.status, 'estimated');
  const outsideScope = nutritionSummary({ birthDate: '1947-10-04', heightCm: 165, weightKg: 60 }, [], DATE).expenditure;
  assert.equal(outsideScope.status, 'out_of_range');
  assert.equal(outsideScope.minKcal, null);
});

test('macro energy uses only confirmed meals on the requested date and the 4/4/9 factors', () => {
  const meals = [
    { date: DATE, confirmed: true, protein: 10, carbs: 20, fat: 5 },
    { date: DATE, confirmed: false, protein: 100, carbs: 100, fat: 100 },
    { date: '2026-10-04', confirmed: true, protein: 30, carbs: 40, fat: 20 }
  ];
  const macros = nutritionSummary({}, meals, DATE).macros;
  assert.equal(macros.status, 'available');
  assert.equal(macros.confirmedMealCount, 1);
  assert.deepEqual(macros.grams, { protein: 10, carbs: 20, fat: 5 });
  assert.deepEqual(macros.kcal, { protein: 40, carbs: 80, fat: 45, total: 165 });
  assert.deepEqual(macros.percentages, { protein: 24.2, carbs: 48.5, fat: 27.3 });
  assert.deepEqual(macros.coverage, {
    protein: { recorded: 1, total: 1 },
    carbs: { recorded: 1, total: 1 },
    fat: { recorded: 1, total: 1 }
  });
  assert.equal(Object.values(macros.percentages).reduce((sum, value) => sum + value, 0), 100);
});

test('partial macro fields stay null and proportions describe recorded macros only', () => {
  const macros = nutritionSummary({}, [
    { date: DATE, confirmed: true, protein: 10, carbs: null, fat: 5 },
    { date: DATE, confirmed: true, protein: 4, carbs: 20, fat: null }
  ], DATE).macros;
  assert.equal(macros.status, 'partial');
  assert.equal(macros.confirmedMealCount, 2);
  assert.deepEqual(macros.grams, { protein: 14, carbs: 20, fat: 5 });
  assert.deepEqual(macros.kcal, { protein: 56, carbs: 80, fat: 45, total: 181 });
  assert.equal(Object.values(macros.percentages).reduce((sum, value) => sum + value, 0), 100);
  assert.deepEqual(macros.coverage, {
    protein: { recorded: 2, total: 2 },
    carbs: { recorded: 1, total: 2 },
    fat: { recorded: 1, total: 2 }
  });
});

test('no confirmed meals or all-empty macro fields produce a real no-data state', () => {
  const noMeals = nutritionSummary({}, [
    { date: DATE, confirmed: false, protein: 10, carbs: 20, fat: 5 }
  ], DATE).macros;
  assert.equal(noMeals.status, 'no_data');
  assert.equal(noMeals.confirmedMealCount, 0);
  assert.equal(noMeals.kcal.total, null);

  const emptyMacros = nutritionSummary({}, [
    { date: DATE, confirmed: true, protein: null, carbs: null, fat: null }
  ], DATE).macros;
  assert.equal(emptyMacros.status, 'no_data');
  assert.equal(emptyMacros.confirmedMealCount, 1);
  assert.equal(emptyMacros.kcal.total, null);
  assert.deepEqual(emptyMacros.percentages, { protein: null, carbs: null, fat: null });
});

test('zero recorded grams are data but have no percentage denominator', () => {
  const macros = nutritionSummary({}, [
    { date: DATE, confirmed: true, protein: 0, carbs: 0, fat: 0 }
  ], DATE).macros;
  assert.equal(macros.status, 'available');
  assert.equal(macros.kcal.total, 0);
  assert.deepEqual(macros.percentages, { protein: null, carbs: null, fat: null });
});

test('invalid dates are rejected rather than silently summarized', () => {
  assert.throws(() => nutritionSummary({}, [], '2026-02-30'), /valid YYYY-MM-DD/);
});
