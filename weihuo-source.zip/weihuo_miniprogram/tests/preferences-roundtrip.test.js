"use strict";
const test=require('node:test'),assert=require('node:assert/strict');
const disk=new Map();global.wx={getStorageSync:k=>disk.get(k),setStorageSync:(k,v)=>disk.set(k,structuredClone(v))};
const store=require('../miniprogram/services/store'),{validateState}=require('../cloudfunctions/weihuoApi/state');
test.beforeEach(()=>{store.useLocal();store.clearAll();});
test('legacy backups default preferences, companion and period without discarding records',()=>{
 const state=store.getState();delete state.periodSettings;delete state.settings.companion;delete state.settings.savedRecipes;delete state.settings.foodPreferences;delete state.settings.foodAvoid;
 const cloud=validateState(state);assert.equal(cloud.settings.companion,'xiaowei');assert.deepEqual(cloud.settings.foodPreferences,{taste:'',color:'',texture:'',temperature:'',scene:''});assert.equal(cloud.periodSettings.cycleLengthDays,28);assert.deepEqual(store.validate(state).settings,cloud.settings);
});
test('food preferences and exclusions roundtrip through cloud, backup and account switching',()=>{
 store.switchAccount('test-food-A');store.clearAll();store.saveSettings({companion:'cat',foodPreferences:{taste:'fresh',color:'green',texture:'crisp',temperature:'warm',scene:'home'},foodAvoid:['egg','soy']});
 const saved=store.getSettings();const normalized=validateState(store.getState());assert.deepEqual(normalized.settings,saved);const backup=store.exportData();
 store.switchAccount('test-food-B');store.clearAll();assert.equal(store.getSettings().foodPreferences.taste,'');
 store.switchAccount('test-food-A');assert.deepEqual(store.getSettings(),saved);store.saveSettings({foodAvoid:[]});store.restoreData(backup);assert.deepEqual(store.getSettings().foodAvoid,['egg','soy']);
});
test('malformed preference values do not corrupt previous saved preferences',()=>{
 store.saveSettings({foodPreferences:{taste:'fresh'}});const before=store.getSettings();assert.throws(()=>store.saveSettings({foodPreferences:{taste:{bad:true}}}));assert.deepEqual(store.getSettings(),before);
 const state=store.getState();state.settings.foodAvoid=['egg','egg'];assert.throws(()=>validateState(state));assert.throws(()=>store.saveSettings({companion:'unknown'}));assert.deepEqual(store.getSettings(),before);
});
